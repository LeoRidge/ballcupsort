gdjs.Level_3211Code = {};
gdjs.Level_3211Code.repeatCount4 = 0;

gdjs.Level_3211Code.repeatIndex4 = 0;

gdjs.Level_3211Code.GDBall_951Objects1= [];
gdjs.Level_3211Code.GDBall_951Objects2= [];
gdjs.Level_3211Code.GDBall_951Objects3= [];
gdjs.Level_3211Code.GDBall_951Objects4= [];
gdjs.Level_3211Code.GDBall_951Objects5= [];
gdjs.Level_3211Code.GDBall_951Objects6= [];
gdjs.Level_3211Code.GDBall_952Objects1= [];
gdjs.Level_3211Code.GDBall_952Objects2= [];
gdjs.Level_3211Code.GDBall_952Objects3= [];
gdjs.Level_3211Code.GDBall_952Objects4= [];
gdjs.Level_3211Code.GDBall_952Objects5= [];
gdjs.Level_3211Code.GDBall_952Objects6= [];
gdjs.Level_3211Code.GDBall_953Objects1= [];
gdjs.Level_3211Code.GDBall_953Objects2= [];
gdjs.Level_3211Code.GDBall_953Objects3= [];
gdjs.Level_3211Code.GDBall_953Objects4= [];
gdjs.Level_3211Code.GDBall_953Objects5= [];
gdjs.Level_3211Code.GDBall_953Objects6= [];
gdjs.Level_3211Code.GDBall_954Objects1= [];
gdjs.Level_3211Code.GDBall_954Objects2= [];
gdjs.Level_3211Code.GDBall_954Objects3= [];
gdjs.Level_3211Code.GDBall_954Objects4= [];
gdjs.Level_3211Code.GDBall_954Objects5= [];
gdjs.Level_3211Code.GDBall_954Objects6= [];
gdjs.Level_3211Code.GDBall_955Objects1= [];
gdjs.Level_3211Code.GDBall_955Objects2= [];
gdjs.Level_3211Code.GDBall_955Objects3= [];
gdjs.Level_3211Code.GDBall_955Objects4= [];
gdjs.Level_3211Code.GDBall_955Objects5= [];
gdjs.Level_3211Code.GDBall_955Objects6= [];
gdjs.Level_3211Code.GDBall_956Objects1= [];
gdjs.Level_3211Code.GDBall_956Objects2= [];
gdjs.Level_3211Code.GDBall_956Objects3= [];
gdjs.Level_3211Code.GDBall_956Objects4= [];
gdjs.Level_3211Code.GDBall_956Objects5= [];
gdjs.Level_3211Code.GDBall_956Objects6= [];
gdjs.Level_3211Code.GDGlassBreaking_95ParticlesObjects1= [];
gdjs.Level_3211Code.GDGlassBreaking_95ParticlesObjects2= [];
gdjs.Level_3211Code.GDGlassBreaking_95ParticlesObjects3= [];
gdjs.Level_3211Code.GDGlassBreaking_95ParticlesObjects4= [];
gdjs.Level_3211Code.GDGlassBreaking_95ParticlesObjects5= [];
gdjs.Level_3211Code.GDGlassBreaking_95ParticlesObjects6= [];
gdjs.Level_3211Code.GDCupObjects1= [];
gdjs.Level_3211Code.GDCupObjects2= [];
gdjs.Level_3211Code.GDCupObjects3= [];
gdjs.Level_3211Code.GDCupObjects4= [];
gdjs.Level_3211Code.GDCupObjects5= [];
gdjs.Level_3211Code.GDCupObjects6= [];
gdjs.Level_3211Code.GDCupFrontObjects1= [];
gdjs.Level_3211Code.GDCupFrontObjects2= [];
gdjs.Level_3211Code.GDCupFrontObjects3= [];
gdjs.Level_3211Code.GDCupFrontObjects4= [];
gdjs.Level_3211Code.GDCupFrontObjects5= [];
gdjs.Level_3211Code.GDCupFrontObjects6= [];
gdjs.Level_3211Code.GDCloud1Objects1= [];
gdjs.Level_3211Code.GDCloud1Objects2= [];
gdjs.Level_3211Code.GDCloud1Objects3= [];
gdjs.Level_3211Code.GDCloud1Objects4= [];
gdjs.Level_3211Code.GDCloud1Objects5= [];
gdjs.Level_3211Code.GDCloud1Objects6= [];
gdjs.Level_3211Code.GDCloud2Objects1= [];
gdjs.Level_3211Code.GDCloud2Objects2= [];
gdjs.Level_3211Code.GDCloud2Objects3= [];
gdjs.Level_3211Code.GDCloud2Objects4= [];
gdjs.Level_3211Code.GDCloud2Objects5= [];
gdjs.Level_3211Code.GDCloud2Objects6= [];
gdjs.Level_3211Code.GDCloud3Objects1= [];
gdjs.Level_3211Code.GDCloud3Objects2= [];
gdjs.Level_3211Code.GDCloud3Objects3= [];
gdjs.Level_3211Code.GDCloud3Objects4= [];
gdjs.Level_3211Code.GDCloud3Objects5= [];
gdjs.Level_3211Code.GDCloud3Objects6= [];
gdjs.Level_3211Code.GDCloud4Objects1= [];
gdjs.Level_3211Code.GDCloud4Objects2= [];
gdjs.Level_3211Code.GDCloud4Objects3= [];
gdjs.Level_3211Code.GDCloud4Objects4= [];
gdjs.Level_3211Code.GDCloud4Objects5= [];
gdjs.Level_3211Code.GDCloud4Objects6= [];
gdjs.Level_3211Code.GDEditInGDevelop_95TextObjects1= [];
gdjs.Level_3211Code.GDEditInGDevelop_95TextObjects2= [];
gdjs.Level_3211Code.GDEditInGDevelop_95TextObjects3= [];
gdjs.Level_3211Code.GDEditInGDevelop_95TextObjects4= [];
gdjs.Level_3211Code.GDEditInGDevelop_95TextObjects5= [];
gdjs.Level_3211Code.GDEditInGDevelop_95TextObjects6= [];
gdjs.Level_3211Code.GDGreyButtonObjects1= [];
gdjs.Level_3211Code.GDGreyButtonObjects2= [];
gdjs.Level_3211Code.GDGreyButtonObjects3= [];
gdjs.Level_3211Code.GDGreyButtonObjects4= [];
gdjs.Level_3211Code.GDGreyButtonObjects5= [];
gdjs.Level_3211Code.GDGreyButtonObjects6= [];
gdjs.Level_3211Code.GDCurrentLevel_95TextObjects1= [];
gdjs.Level_3211Code.GDCurrentLevel_95TextObjects2= [];
gdjs.Level_3211Code.GDCurrentLevel_95TextObjects3= [];
gdjs.Level_3211Code.GDCurrentLevel_95TextObjects4= [];
gdjs.Level_3211Code.GDCurrentLevel_95TextObjects5= [];
gdjs.Level_3211Code.GDCurrentLevel_95TextObjects6= [];
gdjs.Level_3211Code.GDMenuObjects1= [];
gdjs.Level_3211Code.GDMenuObjects2= [];
gdjs.Level_3211Code.GDMenuObjects3= [];
gdjs.Level_3211Code.GDMenuObjects4= [];
gdjs.Level_3211Code.GDMenuObjects5= [];
gdjs.Level_3211Code.GDMenuObjects6= [];
gdjs.Level_3211Code.GDGameState_95TextObjects1= [];
gdjs.Level_3211Code.GDGameState_95TextObjects2= [];
gdjs.Level_3211Code.GDGameState_95TextObjects3= [];
gdjs.Level_3211Code.GDGameState_95TextObjects4= [];
gdjs.Level_3211Code.GDGameState_95TextObjects5= [];
gdjs.Level_3211Code.GDGameState_95TextObjects6= [];
gdjs.Level_3211Code.GDMovesMade_95TextObjects1= [];
gdjs.Level_3211Code.GDMovesMade_95TextObjects2= [];
gdjs.Level_3211Code.GDMovesMade_95TextObjects3= [];
gdjs.Level_3211Code.GDMovesMade_95TextObjects4= [];
gdjs.Level_3211Code.GDMovesMade_95TextObjects5= [];
gdjs.Level_3211Code.GDMovesMade_95TextObjects6= [];
gdjs.Level_3211Code.GDTimeSpent_95TextObjects1= [];
gdjs.Level_3211Code.GDTimeSpent_95TextObjects2= [];
gdjs.Level_3211Code.GDTimeSpent_95TextObjects3= [];
gdjs.Level_3211Code.GDTimeSpent_95TextObjects4= [];
gdjs.Level_3211Code.GDTimeSpent_95TextObjects5= [];
gdjs.Level_3211Code.GDTimeSpent_95TextObjects6= [];
gdjs.Level_3211Code.GDBallsInCup_95TextObjects1= [];
gdjs.Level_3211Code.GDBallsInCup_95TextObjects2= [];
gdjs.Level_3211Code.GDBallsInCup_95TextObjects3= [];
gdjs.Level_3211Code.GDBallsInCup_95TextObjects4= [];
gdjs.Level_3211Code.GDBallsInCup_95TextObjects5= [];
gdjs.Level_3211Code.GDBallsInCup_95TextObjects6= [];
gdjs.Level_3211Code.GDPlay_95TextObjects1= [];
gdjs.Level_3211Code.GDPlay_95TextObjects2= [];
gdjs.Level_3211Code.GDPlay_95TextObjects3= [];
gdjs.Level_3211Code.GDPlay_95TextObjects4= [];
gdjs.Level_3211Code.GDPlay_95TextObjects5= [];
gdjs.Level_3211Code.GDPlay_95TextObjects6= [];
gdjs.Level_3211Code.GDLeaderboardObjects1= [];
gdjs.Level_3211Code.GDLeaderboardObjects2= [];
gdjs.Level_3211Code.GDLeaderboardObjects3= [];
gdjs.Level_3211Code.GDLeaderboardObjects4= [];
gdjs.Level_3211Code.GDLeaderboardObjects5= [];
gdjs.Level_3211Code.GDLeaderboardObjects6= [];
gdjs.Level_3211Code.GDMainMenu_95TextObjects1= [];
gdjs.Level_3211Code.GDMainMenu_95TextObjects2= [];
gdjs.Level_3211Code.GDMainMenu_95TextObjects3= [];
gdjs.Level_3211Code.GDMainMenu_95TextObjects4= [];
gdjs.Level_3211Code.GDMainMenu_95TextObjects5= [];
gdjs.Level_3211Code.GDMainMenu_95TextObjects6= [];
gdjs.Level_3211Code.GDResetProgress_95TextObjects1= [];
gdjs.Level_3211Code.GDResetProgress_95TextObjects2= [];
gdjs.Level_3211Code.GDResetProgress_95TextObjects3= [];
gdjs.Level_3211Code.GDResetProgress_95TextObjects4= [];
gdjs.Level_3211Code.GDResetProgress_95TextObjects5= [];
gdjs.Level_3211Code.GDResetProgress_95TextObjects6= [];
gdjs.Level_3211Code.GDStartOver_95TextObjects1= [];
gdjs.Level_3211Code.GDStartOver_95TextObjects2= [];
gdjs.Level_3211Code.GDStartOver_95TextObjects3= [];
gdjs.Level_3211Code.GDStartOver_95TextObjects4= [];
gdjs.Level_3211Code.GDStartOver_95TextObjects5= [];
gdjs.Level_3211Code.GDStartOver_95TextObjects6= [];
gdjs.Level_3211Code.GDSubmit_95TextObjects1= [];
gdjs.Level_3211Code.GDSubmit_95TextObjects2= [];
gdjs.Level_3211Code.GDSubmit_95TextObjects3= [];
gdjs.Level_3211Code.GDSubmit_95TextObjects4= [];
gdjs.Level_3211Code.GDSubmit_95TextObjects5= [];
gdjs.Level_3211Code.GDSubmit_95TextObjects6= [];
gdjs.Level_3211Code.GDVictory_95TextObjects1= [];
gdjs.Level_3211Code.GDVictory_95TextObjects2= [];
gdjs.Level_3211Code.GDVictory_95TextObjects3= [];
gdjs.Level_3211Code.GDVictory_95TextObjects4= [];
gdjs.Level_3211Code.GDVictory_95TextObjects5= [];
gdjs.Level_3211Code.GDVictory_95TextObjects6= [];
gdjs.Level_3211Code.GDMenuObjects1= [];
gdjs.Level_3211Code.GDMenuObjects2= [];
gdjs.Level_3211Code.GDMenuObjects3= [];
gdjs.Level_3211Code.GDMenuObjects4= [];
gdjs.Level_3211Code.GDMenuObjects5= [];
gdjs.Level_3211Code.GDMenuObjects6= [];

gdjs.Level_3211Code.conditionTrue_0 = {val:false};
gdjs.Level_3211Code.condition0IsTrue_0 = {val:false};
gdjs.Level_3211Code.condition1IsTrue_0 = {val:false};
gdjs.Level_3211Code.condition2IsTrue_0 = {val:false};
gdjs.Level_3211Code.condition3IsTrue_0 = {val:false};
gdjs.Level_3211Code.conditionTrue_1 = {val:false};
gdjs.Level_3211Code.condition0IsTrue_1 = {val:false};
gdjs.Level_3211Code.condition1IsTrue_1 = {val:false};
gdjs.Level_3211Code.condition2IsTrue_1 = {val:false};
gdjs.Level_3211Code.condition3IsTrue_1 = {val:false};


gdjs.Level_3211Code.eventsList0 = function(runtimeScene) {

{


gdjs.Level_3211Code.condition0IsTrue_0.val = false;
{
gdjs.Level_3211Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Level_3211Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Victory_Text"), gdjs.Level_3211Code.GDVictory_95TextObjects2);
{runtimeScene.getVariables().get("MaxBalls").setNumber(100);
}{runtimeScene.getVariables().get("BallsCreatedPerFrame").setNumber(1);
}{for(var i = 0, len = gdjs.Level_3211Code.GDVictory_95TextObjects2.length ;i < len;++i) {
    gdjs.Level_3211Code.GDVictory_95TextObjects2[i].setTextAlignment("center");
}
}{for(var i = 0, len = gdjs.Level_3211Code.GDVictory_95TextObjects2.length ;i < len;++i) {
    gdjs.Level_3211Code.GDVictory_95TextObjects2[i].setCenterXInScene(gdjs.evtTools.camera.getCameraX(runtimeScene, "UI", 0));
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "audience_cheers_13.aac", false, 50, 1);
}}

}


};gdjs.Level_3211Code.mapOfEmptyGDBall_951ObjectsEmptyGDBall_952ObjectsEmptyGDBall_954ObjectsEmptyGDBall_953ObjectsEmptyGDBall_955ObjectsEmptyGDBall_956Objects = Hashtable.newFrom({"Ball_1": [], "Ball_2": [], "Ball_4": [], "Ball_3": [], "Ball_5": [], "Ball_6": []});
gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDBall_95951Objects5ObjectsGDgdjs_46Level_953211Code_46GDBall_95952Objects5ObjectsGDgdjs_46Level_953211Code_46GDBall_95954Objects5ObjectsGDgdjs_46Level_953211Code_46GDBall_95953Objects5ObjectsGDgdjs_46Level_953211Code_46GDBall_95955Objects5ObjectsGDgdjs_46Level_953211Code_46GDBall_95956Objects5Objects = Hashtable.newFrom({"Ball_1": gdjs.Level_3211Code.GDBall_951Objects5, "Ball_2": gdjs.Level_3211Code.GDBall_952Objects5, "Ball_4": gdjs.Level_3211Code.GDBall_954Objects5, "Ball_3": gdjs.Level_3211Code.GDBall_953Objects5, "Ball_5": gdjs.Level_3211Code.GDBall_955Objects5, "Ball_6": gdjs.Level_3211Code.GDBall_956Objects5});
gdjs.Level_3211Code.eventsList1 = function(runtimeScene) {

{


{
gdjs.Level_3211Code.GDBall_951Objects5.length = 0;

gdjs.Level_3211Code.GDBall_952Objects5.length = 0;

gdjs.Level_3211Code.GDBall_953Objects5.length = 0;

gdjs.Level_3211Code.GDBall_954Objects5.length = 0;

gdjs.Level_3211Code.GDBall_955Objects5.length = 0;

gdjs.Level_3211Code.GDBall_956Objects5.length = 0;

{gdjs.evtTools.object.createObjectFromGroupOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDBall_95951Objects5ObjectsGDgdjs_46Level_953211Code_46GDBall_95952Objects5ObjectsGDgdjs_46Level_953211Code_46GDBall_95954Objects5ObjectsGDgdjs_46Level_953211Code_46GDBall_95953Objects5ObjectsGDgdjs_46Level_953211Code_46GDBall_95955Objects5ObjectsGDgdjs_46Level_953211Code_46GDBall_95956Objects5Objects, "Ball_" + gdjs.evtTools.common.toString(gdjs.randomInRange(1, 6)), gdjs.randomInRange(gdjs.evtTools.camera.getCameraBorderLeft(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraBorderRight(runtimeScene, "", 0)), gdjs.evtTools.camera.getCameraBorderBottom(runtimeScene, "", 0) - 32, "Balls");
}{for(var i = 0, len = gdjs.Level_3211Code.GDBall_951Objects5.length ;i < len;++i) {
    gdjs.Level_3211Code.GDBall_951Objects5[i].addPolarForce(270, 800, 1);
}
for(var i = 0, len = gdjs.Level_3211Code.GDBall_952Objects5.length ;i < len;++i) {
    gdjs.Level_3211Code.GDBall_952Objects5[i].addPolarForce(270, 800, 1);
}
for(var i = 0, len = gdjs.Level_3211Code.GDBall_954Objects5.length ;i < len;++i) {
    gdjs.Level_3211Code.GDBall_954Objects5[i].addPolarForce(270, 800, 1);
}
for(var i = 0, len = gdjs.Level_3211Code.GDBall_953Objects5.length ;i < len;++i) {
    gdjs.Level_3211Code.GDBall_953Objects5[i].addPolarForce(270, 800, 1);
}
for(var i = 0, len = gdjs.Level_3211Code.GDBall_955Objects5.length ;i < len;++i) {
    gdjs.Level_3211Code.GDBall_955Objects5[i].addPolarForce(270, 800, 1);
}
for(var i = 0, len = gdjs.Level_3211Code.GDBall_956Objects5.length ;i < len;++i) {
    gdjs.Level_3211Code.GDBall_956Objects5[i].addPolarForce(270, 800, 1);
}
}}

}


};gdjs.Level_3211Code.eventsList2 = function(runtimeScene) {

{


gdjs.Level_3211Code.repeatCount4 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("BallsCreatedPerFrame"));
for(gdjs.Level_3211Code.repeatIndex4 = 0;gdjs.Level_3211Code.repeatIndex4 < gdjs.Level_3211Code.repeatCount4;++gdjs.Level_3211Code.repeatIndex4) {

if (true)
{

{ //Subevents: 
gdjs.Level_3211Code.eventsList1(runtimeScene);} //Subevents end.
}
}

}


};gdjs.Level_3211Code.eventsList3 = function(runtimeScene) {

{


gdjs.Level_3211Code.condition0IsTrue_0.val = false;
{
gdjs.Level_3211Code.condition0IsTrue_0.val = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_3211Code.mapOfEmptyGDBall_951ObjectsEmptyGDBall_952ObjectsEmptyGDBall_954ObjectsEmptyGDBall_953ObjectsEmptyGDBall_955ObjectsEmptyGDBall_956Objects) < gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MaxBalls"));
}if (gdjs.Level_3211Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Level_3211Code.eventsList2(runtimeScene);} //End of subevents
}

}


};gdjs.Level_3211Code.eventsList4 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("Ball_1"), gdjs.Level_3211Code.GDBall_951Objects3);
gdjs.copyArray(runtimeScene.getObjects("Ball_2"), gdjs.Level_3211Code.GDBall_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Ball_3"), gdjs.Level_3211Code.GDBall_953Objects3);
gdjs.copyArray(runtimeScene.getObjects("Ball_4"), gdjs.Level_3211Code.GDBall_954Objects3);
gdjs.copyArray(runtimeScene.getObjects("Ball_5"), gdjs.Level_3211Code.GDBall_955Objects3);
gdjs.copyArray(runtimeScene.getObjects("Ball_6"), gdjs.Level_3211Code.GDBall_956Objects3);
{for(var i = 0, len = gdjs.Level_3211Code.GDBall_951Objects3.length ;i < len;++i) {
    gdjs.Level_3211Code.GDBall_951Objects3[i].addPolarForce(90, 10, 1);
}
for(var i = 0, len = gdjs.Level_3211Code.GDBall_952Objects3.length ;i < len;++i) {
    gdjs.Level_3211Code.GDBall_952Objects3[i].addPolarForce(90, 10, 1);
}
for(var i = 0, len = gdjs.Level_3211Code.GDBall_954Objects3.length ;i < len;++i) {
    gdjs.Level_3211Code.GDBall_954Objects3[i].addPolarForce(90, 10, 1);
}
for(var i = 0, len = gdjs.Level_3211Code.GDBall_953Objects3.length ;i < len;++i) {
    gdjs.Level_3211Code.GDBall_953Objects3[i].addPolarForce(90, 10, 1);
}
for(var i = 0, len = gdjs.Level_3211Code.GDBall_955Objects3.length ;i < len;++i) {
    gdjs.Level_3211Code.GDBall_955Objects3[i].addPolarForce(90, 10, 1);
}
for(var i = 0, len = gdjs.Level_3211Code.GDBall_956Objects3.length ;i < len;++i) {
    gdjs.Level_3211Code.GDBall_956Objects3[i].addPolarForce(90, 10, 1);
}
}}

}


};gdjs.Level_3211Code.eventsList5 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Ball_1"), gdjs.Level_3211Code.GDBall_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Ball_2"), gdjs.Level_3211Code.GDBall_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Ball_3"), gdjs.Level_3211Code.GDBall_953Objects2);
gdjs.copyArray(runtimeScene.getObjects("Ball_4"), gdjs.Level_3211Code.GDBall_954Objects2);
gdjs.copyArray(runtimeScene.getObjects("Ball_5"), gdjs.Level_3211Code.GDBall_955Objects2);
gdjs.copyArray(runtimeScene.getObjects("Ball_6"), gdjs.Level_3211Code.GDBall_956Objects2);

gdjs.Level_3211Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_3211Code.GDBall_951Objects2.length;i<l;++i) {
    if ( gdjs.Level_3211Code.GDBall_951Objects2[i].getY() > gdjs.evtTools.camera.getCameraBorderBottom(runtimeScene, "", 0) + 64 ) {
        gdjs.Level_3211Code.condition0IsTrue_0.val = true;
        gdjs.Level_3211Code.GDBall_951Objects2[k] = gdjs.Level_3211Code.GDBall_951Objects2[i];
        ++k;
    }
}
gdjs.Level_3211Code.GDBall_951Objects2.length = k;for(var i = 0, k = 0, l = gdjs.Level_3211Code.GDBall_952Objects2.length;i<l;++i) {
    if ( gdjs.Level_3211Code.GDBall_952Objects2[i].getY() > gdjs.evtTools.camera.getCameraBorderBottom(runtimeScene, "", 0) + 64 ) {
        gdjs.Level_3211Code.condition0IsTrue_0.val = true;
        gdjs.Level_3211Code.GDBall_952Objects2[k] = gdjs.Level_3211Code.GDBall_952Objects2[i];
        ++k;
    }
}
gdjs.Level_3211Code.GDBall_952Objects2.length = k;for(var i = 0, k = 0, l = gdjs.Level_3211Code.GDBall_954Objects2.length;i<l;++i) {
    if ( gdjs.Level_3211Code.GDBall_954Objects2[i].getY() > gdjs.evtTools.camera.getCameraBorderBottom(runtimeScene, "", 0) + 64 ) {
        gdjs.Level_3211Code.condition0IsTrue_0.val = true;
        gdjs.Level_3211Code.GDBall_954Objects2[k] = gdjs.Level_3211Code.GDBall_954Objects2[i];
        ++k;
    }
}
gdjs.Level_3211Code.GDBall_954Objects2.length = k;for(var i = 0, k = 0, l = gdjs.Level_3211Code.GDBall_953Objects2.length;i<l;++i) {
    if ( gdjs.Level_3211Code.GDBall_953Objects2[i].getY() > gdjs.evtTools.camera.getCameraBorderBottom(runtimeScene, "", 0) + 64 ) {
        gdjs.Level_3211Code.condition0IsTrue_0.val = true;
        gdjs.Level_3211Code.GDBall_953Objects2[k] = gdjs.Level_3211Code.GDBall_953Objects2[i];
        ++k;
    }
}
gdjs.Level_3211Code.GDBall_953Objects2.length = k;for(var i = 0, k = 0, l = gdjs.Level_3211Code.GDBall_955Objects2.length;i<l;++i) {
    if ( gdjs.Level_3211Code.GDBall_955Objects2[i].getY() > gdjs.evtTools.camera.getCameraBorderBottom(runtimeScene, "", 0) + 64 ) {
        gdjs.Level_3211Code.condition0IsTrue_0.val = true;
        gdjs.Level_3211Code.GDBall_955Objects2[k] = gdjs.Level_3211Code.GDBall_955Objects2[i];
        ++k;
    }
}
gdjs.Level_3211Code.GDBall_955Objects2.length = k;for(var i = 0, k = 0, l = gdjs.Level_3211Code.GDBall_956Objects2.length;i<l;++i) {
    if ( gdjs.Level_3211Code.GDBall_956Objects2[i].getY() > gdjs.evtTools.camera.getCameraBorderBottom(runtimeScene, "", 0) + 64 ) {
        gdjs.Level_3211Code.condition0IsTrue_0.val = true;
        gdjs.Level_3211Code.GDBall_956Objects2[k] = gdjs.Level_3211Code.GDBall_956Objects2[i];
        ++k;
    }
}
gdjs.Level_3211Code.GDBall_956Objects2.length = k;}if (gdjs.Level_3211Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_3211Code.GDBall_951Objects2 */
/* Reuse gdjs.Level_3211Code.GDBall_952Objects2 */
/* Reuse gdjs.Level_3211Code.GDBall_953Objects2 */
/* Reuse gdjs.Level_3211Code.GDBall_954Objects2 */
/* Reuse gdjs.Level_3211Code.GDBall_955Objects2 */
/* Reuse gdjs.Level_3211Code.GDBall_956Objects2 */
{for(var i = 0, len = gdjs.Level_3211Code.GDBall_951Objects2.length ;i < len;++i) {
    gdjs.Level_3211Code.GDBall_951Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level_3211Code.GDBall_952Objects2.length ;i < len;++i) {
    gdjs.Level_3211Code.GDBall_952Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level_3211Code.GDBall_954Objects2.length ;i < len;++i) {
    gdjs.Level_3211Code.GDBall_954Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level_3211Code.GDBall_953Objects2.length ;i < len;++i) {
    gdjs.Level_3211Code.GDBall_953Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level_3211Code.GDBall_955Objects2.length ;i < len;++i) {
    gdjs.Level_3211Code.GDBall_955Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level_3211Code.GDBall_956Objects2.length ;i < len;++i) {
    gdjs.Level_3211Code.GDBall_956Objects2[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.Level_3211Code.eventsList6 = function(runtimeScene) {

{


gdjs.Level_3211Code.eventsList3(runtimeScene);
}


{


gdjs.Level_3211Code.eventsList4(runtimeScene);
}


{


gdjs.Level_3211Code.eventsList5(runtimeScene);
}


};gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDGreyButtonObjects3ObjectsGDgdjs_46Level_953211Code_46GDLeaderboardObjects3ObjectsGDgdjs_46Level_953211Code_46GDMenuObjects3Objects = Hashtable.newFrom({"GreyButton": gdjs.Level_3211Code.GDGreyButtonObjects3, "Leaderboard": gdjs.Level_3211Code.GDLeaderboardObjects3, "Menu": gdjs.Level_3211Code.GDMenuObjects3});
gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDPlay_9595TextObjects3ObjectsGDgdjs_46Level_953211Code_46GDMainMenu_9595TextObjects3ObjectsGDgdjs_46Level_953211Code_46GDResetProgress_9595TextObjects3ObjectsGDgdjs_46Level_953211Code_46GDStartOver_9595TextObjects3ObjectsGDgdjs_46Level_953211Code_46GDSubmit_9595TextObjects3Objects = Hashtable.newFrom({"Play_Text": gdjs.Level_3211Code.GDPlay_95TextObjects3, "MainMenu_Text": gdjs.Level_3211Code.GDMainMenu_95TextObjects3, "ResetProgress_Text": gdjs.Level_3211Code.GDResetProgress_95TextObjects3, "StartOver_Text": gdjs.Level_3211Code.GDStartOver_95TextObjects3, "Submit_Text": gdjs.Level_3211Code.GDSubmit_95TextObjects3});
gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDGreyButtonObjects3ObjectsGDgdjs_46Level_953211Code_46GDLeaderboardObjects3ObjectsGDgdjs_46Level_953211Code_46GDMenuObjects3Objects = Hashtable.newFrom({"GreyButton": gdjs.Level_3211Code.GDGreyButtonObjects3, "Leaderboard": gdjs.Level_3211Code.GDLeaderboardObjects3, "Menu": gdjs.Level_3211Code.GDMenuObjects3});
gdjs.Level_3211Code.eventsList7 = function(runtimeScene) {

{

/* Reuse gdjs.Level_3211Code.GDGreyButtonObjects3 */
/* Reuse gdjs.Level_3211Code.GDLeaderboardObjects3 */
gdjs.copyArray(runtimeScene.getObjects("MainMenu_Text"), gdjs.Level_3211Code.GDMainMenu_95TextObjects3);
/* Reuse gdjs.Level_3211Code.GDMenuObjects3 */
gdjs.copyArray(runtimeScene.getObjects("Play_Text"), gdjs.Level_3211Code.GDPlay_95TextObjects3);
gdjs.copyArray(runtimeScene.getObjects("ResetProgress_Text"), gdjs.Level_3211Code.GDResetProgress_95TextObjects3);
gdjs.copyArray(runtimeScene.getObjects("StartOver_Text"), gdjs.Level_3211Code.GDStartOver_95TextObjects3);
gdjs.copyArray(runtimeScene.getObjects("Submit_Text"), gdjs.Level_3211Code.GDSubmit_95TextObjects3);

gdjs.Level_3211Code.condition0IsTrue_0.val = false;
{
gdjs.Level_3211Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDPlay_9595TextObjects3ObjectsGDgdjs_46Level_953211Code_46GDMainMenu_9595TextObjects3ObjectsGDgdjs_46Level_953211Code_46GDResetProgress_9595TextObjects3ObjectsGDgdjs_46Level_953211Code_46GDStartOver_9595TextObjects3ObjectsGDgdjs_46Level_953211Code_46GDSubmit_9595TextObjects3Objects, gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDGreyButtonObjects3ObjectsGDgdjs_46Level_953211Code_46GDLeaderboardObjects3ObjectsGDgdjs_46Level_953211Code_46GDMenuObjects3Objects, false, runtimeScene, false);
}if (gdjs.Level_3211Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_3211Code.GDMainMenu_95TextObjects3 */
/* Reuse gdjs.Level_3211Code.GDPlay_95TextObjects3 */
/* Reuse gdjs.Level_3211Code.GDResetProgress_95TextObjects3 */
/* Reuse gdjs.Level_3211Code.GDStartOver_95TextObjects3 */
/* Reuse gdjs.Level_3211Code.GDSubmit_95TextObjects3 */
{for(var i = 0, len = gdjs.Level_3211Code.GDPlay_95TextObjects3.length ;i < len;++i) {
    gdjs.Level_3211Code.GDPlay_95TextObjects3[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.Level_3211Code.GDMainMenu_95TextObjects3.length ;i < len;++i) {
    gdjs.Level_3211Code.GDMainMenu_95TextObjects3[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.Level_3211Code.GDResetProgress_95TextObjects3.length ;i < len;++i) {
    gdjs.Level_3211Code.GDResetProgress_95TextObjects3[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.Level_3211Code.GDStartOver_95TextObjects3.length ;i < len;++i) {
    gdjs.Level_3211Code.GDStartOver_95TextObjects3[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.Level_3211Code.GDSubmit_95TextObjects3.length ;i < len;++i) {
    gdjs.Level_3211Code.GDSubmit_95TextObjects3[i].setColor("255;255;255");
}
}}

}


};gdjs.Level_3211Code.eventsList8 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("GreyButton"), gdjs.Level_3211Code.GDGreyButtonObjects3);
gdjs.copyArray(runtimeScene.getObjects("Leaderboard"), gdjs.Level_3211Code.GDLeaderboardObjects3);
gdjs.copyArray(runtimeScene.getObjects("Menu"), gdjs.Level_3211Code.GDMenuObjects3);

gdjs.Level_3211Code.condition0IsTrue_0.val = false;
{
gdjs.Level_3211Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDGreyButtonObjects3ObjectsGDgdjs_46Level_953211Code_46GDLeaderboardObjects3ObjectsGDgdjs_46Level_953211Code_46GDMenuObjects3Objects, runtimeScene, true, true);
}if (gdjs.Level_3211Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_3211Code.GDGreyButtonObjects3 */
/* Reuse gdjs.Level_3211Code.GDLeaderboardObjects3 */
/* Reuse gdjs.Level_3211Code.GDMenuObjects3 */
{for(var i = 0, len = gdjs.Level_3211Code.GDGreyButtonObjects3.length ;i < len;++i) {
    gdjs.Level_3211Code.GDGreyButtonObjects3[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.Level_3211Code.GDLeaderboardObjects3.length ;i < len;++i) {
    gdjs.Level_3211Code.GDLeaderboardObjects3[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.Level_3211Code.GDMenuObjects3.length ;i < len;++i) {
    gdjs.Level_3211Code.GDMenuObjects3[i].setColor("255;255;255");
}
}{for(var i = 0, len = gdjs.Level_3211Code.GDGreyButtonObjects3.length ;i < len;++i) {
    gdjs.Level_3211Code.GDGreyButtonObjects3[i].enableEffect("Effect", false);
}
for(var i = 0, len = gdjs.Level_3211Code.GDLeaderboardObjects3.length ;i < len;++i) {
    gdjs.Level_3211Code.GDLeaderboardObjects3[i].enableEffect("Effect", false);
}
for(var i = 0, len = gdjs.Level_3211Code.GDMenuObjects3.length ;i < len;++i) {
    gdjs.Level_3211Code.GDMenuObjects3[i].enableEffect("Effect", false);
}
}
{ //Subevents
gdjs.Level_3211Code.eventsList7(runtimeScene);} //End of subevents
}

}


};gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDGreyButtonObjects3ObjectsGDgdjs_46Level_953211Code_46GDLeaderboardObjects3ObjectsGDgdjs_46Level_953211Code_46GDMenuObjects3Objects = Hashtable.newFrom({"GreyButton": gdjs.Level_3211Code.GDGreyButtonObjects3, "Leaderboard": gdjs.Level_3211Code.GDLeaderboardObjects3, "Menu": gdjs.Level_3211Code.GDMenuObjects3});
gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDPlay_9595TextObjects3ObjectsGDgdjs_46Level_953211Code_46GDMainMenu_9595TextObjects3ObjectsGDgdjs_46Level_953211Code_46GDResetProgress_9595TextObjects3ObjectsGDgdjs_46Level_953211Code_46GDStartOver_9595TextObjects3ObjectsGDgdjs_46Level_953211Code_46GDSubmit_9595TextObjects3Objects = Hashtable.newFrom({"Play_Text": gdjs.Level_3211Code.GDPlay_95TextObjects3, "MainMenu_Text": gdjs.Level_3211Code.GDMainMenu_95TextObjects3, "ResetProgress_Text": gdjs.Level_3211Code.GDResetProgress_95TextObjects3, "StartOver_Text": gdjs.Level_3211Code.GDStartOver_95TextObjects3, "Submit_Text": gdjs.Level_3211Code.GDSubmit_95TextObjects3});
gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDGreyButtonObjects3ObjectsGDgdjs_46Level_953211Code_46GDLeaderboardObjects3ObjectsGDgdjs_46Level_953211Code_46GDMenuObjects3Objects = Hashtable.newFrom({"GreyButton": gdjs.Level_3211Code.GDGreyButtonObjects3, "Leaderboard": gdjs.Level_3211Code.GDLeaderboardObjects3, "Menu": gdjs.Level_3211Code.GDMenuObjects3});
gdjs.Level_3211Code.eventsList9 = function(runtimeScene) {

{

/* Reuse gdjs.Level_3211Code.GDGreyButtonObjects3 */
/* Reuse gdjs.Level_3211Code.GDLeaderboardObjects3 */
gdjs.copyArray(runtimeScene.getObjects("MainMenu_Text"), gdjs.Level_3211Code.GDMainMenu_95TextObjects3);
/* Reuse gdjs.Level_3211Code.GDMenuObjects3 */
gdjs.copyArray(runtimeScene.getObjects("Play_Text"), gdjs.Level_3211Code.GDPlay_95TextObjects3);
gdjs.copyArray(runtimeScene.getObjects("ResetProgress_Text"), gdjs.Level_3211Code.GDResetProgress_95TextObjects3);
gdjs.copyArray(runtimeScene.getObjects("StartOver_Text"), gdjs.Level_3211Code.GDStartOver_95TextObjects3);
gdjs.copyArray(runtimeScene.getObjects("Submit_Text"), gdjs.Level_3211Code.GDSubmit_95TextObjects3);

gdjs.Level_3211Code.condition0IsTrue_0.val = false;
{
gdjs.Level_3211Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDPlay_9595TextObjects3ObjectsGDgdjs_46Level_953211Code_46GDMainMenu_9595TextObjects3ObjectsGDgdjs_46Level_953211Code_46GDResetProgress_9595TextObjects3ObjectsGDgdjs_46Level_953211Code_46GDStartOver_9595TextObjects3ObjectsGDgdjs_46Level_953211Code_46GDSubmit_9595TextObjects3Objects, gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDGreyButtonObjects3ObjectsGDgdjs_46Level_953211Code_46GDLeaderboardObjects3ObjectsGDgdjs_46Level_953211Code_46GDMenuObjects3Objects, false, runtimeScene, false);
}if (gdjs.Level_3211Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_3211Code.GDMainMenu_95TextObjects3 */
/* Reuse gdjs.Level_3211Code.GDPlay_95TextObjects3 */
/* Reuse gdjs.Level_3211Code.GDResetProgress_95TextObjects3 */
/* Reuse gdjs.Level_3211Code.GDStartOver_95TextObjects3 */
/* Reuse gdjs.Level_3211Code.GDSubmit_95TextObjects3 */
{for(var i = 0, len = gdjs.Level_3211Code.GDPlay_95TextObjects3.length ;i < len;++i) {
    gdjs.Level_3211Code.GDPlay_95TextObjects3[i].setColor("241;91;181");
}
for(var i = 0, len = gdjs.Level_3211Code.GDMainMenu_95TextObjects3.length ;i < len;++i) {
    gdjs.Level_3211Code.GDMainMenu_95TextObjects3[i].setColor("241;91;181");
}
for(var i = 0, len = gdjs.Level_3211Code.GDResetProgress_95TextObjects3.length ;i < len;++i) {
    gdjs.Level_3211Code.GDResetProgress_95TextObjects3[i].setColor("241;91;181");
}
for(var i = 0, len = gdjs.Level_3211Code.GDStartOver_95TextObjects3.length ;i < len;++i) {
    gdjs.Level_3211Code.GDStartOver_95TextObjects3[i].setColor("241;91;181");
}
for(var i = 0, len = gdjs.Level_3211Code.GDSubmit_95TextObjects3.length ;i < len;++i) {
    gdjs.Level_3211Code.GDSubmit_95TextObjects3[i].setColor("241;91;181");
}
}}

}


};gdjs.Level_3211Code.eventsList10 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("GreyButton"), gdjs.Level_3211Code.GDGreyButtonObjects3);
gdjs.copyArray(runtimeScene.getObjects("Leaderboard"), gdjs.Level_3211Code.GDLeaderboardObjects3);
gdjs.copyArray(runtimeScene.getObjects("Menu"), gdjs.Level_3211Code.GDMenuObjects3);

gdjs.Level_3211Code.condition0IsTrue_0.val = false;
gdjs.Level_3211Code.condition1IsTrue_0.val = false;
{
gdjs.Level_3211Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDGreyButtonObjects3ObjectsGDgdjs_46Level_953211Code_46GDLeaderboardObjects3ObjectsGDgdjs_46Level_953211Code_46GDMenuObjects3Objects, runtimeScene, true, false);
}if ( gdjs.Level_3211Code.condition0IsTrue_0.val ) {
{
{gdjs.Level_3211Code.conditionTrue_1 = gdjs.Level_3211Code.condition1IsTrue_0;
gdjs.Level_3211Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11702508);
}
}}
if (gdjs.Level_3211Code.condition1IsTrue_0.val) {
/* Reuse gdjs.Level_3211Code.GDGreyButtonObjects3 */
/* Reuse gdjs.Level_3211Code.GDLeaderboardObjects3 */
/* Reuse gdjs.Level_3211Code.GDMenuObjects3 */
{for(var i = 0, len = gdjs.Level_3211Code.GDGreyButtonObjects3.length ;i < len;++i) {
    gdjs.Level_3211Code.GDGreyButtonObjects3[i].enableEffect("Effect", true);
}
for(var i = 0, len = gdjs.Level_3211Code.GDLeaderboardObjects3.length ;i < len;++i) {
    gdjs.Level_3211Code.GDLeaderboardObjects3[i].enableEffect("Effect", true);
}
for(var i = 0, len = gdjs.Level_3211Code.GDMenuObjects3.length ;i < len;++i) {
    gdjs.Level_3211Code.GDMenuObjects3[i].enableEffect("Effect", true);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\audio - BLLTImpt Hit Marker 07.aac", false, 15, 4);
}
{ //Subevents
gdjs.Level_3211Code.eventsList9(runtimeScene);} //End of subevents
}

}


};gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDGreyButtonObjects3ObjectsGDgdjs_46Level_953211Code_46GDLeaderboardObjects3ObjectsGDgdjs_46Level_953211Code_46GDMenuObjects3Objects = Hashtable.newFrom({"GreyButton": gdjs.Level_3211Code.GDGreyButtonObjects3, "Leaderboard": gdjs.Level_3211Code.GDLeaderboardObjects3, "Menu": gdjs.Level_3211Code.GDMenuObjects3});
gdjs.Level_3211Code.eventsList11 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("GreyButton"), gdjs.Level_3211Code.GDGreyButtonObjects3);
gdjs.copyArray(runtimeScene.getObjects("Leaderboard"), gdjs.Level_3211Code.GDLeaderboardObjects3);
gdjs.copyArray(runtimeScene.getObjects("Menu"), gdjs.Level_3211Code.GDMenuObjects3);

gdjs.Level_3211Code.condition0IsTrue_0.val = false;
{
gdjs.Level_3211Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDGreyButtonObjects3ObjectsGDgdjs_46Level_953211Code_46GDLeaderboardObjects3ObjectsGDgdjs_46Level_953211Code_46GDMenuObjects3Objects, runtimeScene, true, false);
}if (gdjs.Level_3211Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_3211Code.GDGreyButtonObjects3 */
/* Reuse gdjs.Level_3211Code.GDLeaderboardObjects3 */
/* Reuse gdjs.Level_3211Code.GDMenuObjects3 */
{for(var i = 0, len = gdjs.Level_3211Code.GDGreyButtonObjects3.length ;i < len;++i) {
    gdjs.Level_3211Code.GDGreyButtonObjects3[i].setColor("74;74;74");
}
for(var i = 0, len = gdjs.Level_3211Code.GDLeaderboardObjects3.length ;i < len;++i) {
    gdjs.Level_3211Code.GDLeaderboardObjects3[i].setColor("74;74;74");
}
for(var i = 0, len = gdjs.Level_3211Code.GDMenuObjects3.length ;i < len;++i) {
    gdjs.Level_3211Code.GDMenuObjects3[i].setColor("74;74;74");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\audio - BLLTImpt Hit Marker 07.aac", false, 40, 2);
}}

}


};gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDGreyButtonObjects2ObjectsGDgdjs_46Level_953211Code_46GDLeaderboardObjects2ObjectsGDgdjs_46Level_953211Code_46GDMenuObjects2Objects = Hashtable.newFrom({"GreyButton": gdjs.Level_3211Code.GDGreyButtonObjects2, "Leaderboard": gdjs.Level_3211Code.GDLeaderboardObjects2, "Menu": gdjs.Level_3211Code.GDMenuObjects2});
gdjs.Level_3211Code.eventsList12 = function(runtimeScene) {

{


gdjs.Level_3211Code.condition0IsTrue_0.val = false;
gdjs.Level_3211Code.condition1IsTrue_0.val = false;
{
gdjs.Level_3211Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.Level_3211Code.condition0IsTrue_0.val ) {
{
{gdjs.Level_3211Code.conditionTrue_1 = gdjs.Level_3211Code.condition1IsTrue_0;
gdjs.Level_3211Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11704564);
}
}}
if (gdjs.Level_3211Code.condition1IsTrue_0.val) {

{ //Subevents
gdjs.Level_3211Code.eventsList11(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("GreyButton"), gdjs.Level_3211Code.GDGreyButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Leaderboard"), gdjs.Level_3211Code.GDLeaderboardObjects2);
gdjs.copyArray(runtimeScene.getObjects("Menu"), gdjs.Level_3211Code.GDMenuObjects2);

gdjs.Level_3211Code.condition0IsTrue_0.val = false;
gdjs.Level_3211Code.condition1IsTrue_0.val = false;
{
gdjs.Level_3211Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.Level_3211Code.condition0IsTrue_0.val ) {
{
gdjs.Level_3211Code.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDGreyButtonObjects2ObjectsGDgdjs_46Level_953211Code_46GDLeaderboardObjects2ObjectsGDgdjs_46Level_953211Code_46GDMenuObjects2Objects, runtimeScene, true, false);
}}
if (gdjs.Level_3211Code.condition1IsTrue_0.val) {
/* Reuse gdjs.Level_3211Code.GDGreyButtonObjects2 */
/* Reuse gdjs.Level_3211Code.GDLeaderboardObjects2 */
/* Reuse gdjs.Level_3211Code.GDMenuObjects2 */
{for(var i = 0, len = gdjs.Level_3211Code.GDGreyButtonObjects2.length ;i < len;++i) {
    gdjs.Level_3211Code.GDGreyButtonObjects2[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.Level_3211Code.GDLeaderboardObjects2.length ;i < len;++i) {
    gdjs.Level_3211Code.GDLeaderboardObjects2[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.Level_3211Code.GDMenuObjects2.length ;i < len;++i) {
    gdjs.Level_3211Code.GDMenuObjects2[i].setColor("255;255;255");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\audio - BLLTImpt Hit Marker 07.aac", false, 40, 3);
}}

}


};gdjs.Level_3211Code.eventsList13 = function(runtimeScene) {

{


gdjs.Level_3211Code.eventsList8(runtimeScene);
}


{


gdjs.Level_3211Code.eventsList10(runtimeScene);
}


{


gdjs.Level_3211Code.eventsList12(runtimeScene);
}


};gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDGreyButtonObjects2Objects = Hashtable.newFrom({"GreyButton": gdjs.Level_3211Code.GDGreyButtonObjects2});
gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDSubmit_9595TextObjects2Objects = Hashtable.newFrom({"Submit_Text": gdjs.Level_3211Code.GDSubmit_95TextObjects2});
gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDGreyButtonObjects2Objects = Hashtable.newFrom({"GreyButton": gdjs.Level_3211Code.GDGreyButtonObjects2});
gdjs.Level_3211Code.asyncCallback11522460 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "SubmitScore", false);
}}
gdjs.Level_3211Code.eventsList14 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.25), (runtimeScene) => (gdjs.Level_3211Code.asyncCallback11522460(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_3211Code.eventsList15 = function(runtimeScene) {

{


{

{ //Subevents
gdjs.Level_3211Code.eventsList14(runtimeScene);} //End of subevents
}

}


};gdjs.Level_3211Code.eventsList16 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("GreyButton"), gdjs.Level_3211Code.GDGreyButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Submit_Text"), gdjs.Level_3211Code.GDSubmit_95TextObjects2);

gdjs.Level_3211Code.condition0IsTrue_0.val = false;
gdjs.Level_3211Code.condition1IsTrue_0.val = false;
gdjs.Level_3211Code.condition2IsTrue_0.val = false;
{
gdjs.Level_3211Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.Level_3211Code.condition0IsTrue_0.val ) {
{
gdjs.Level_3211Code.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDGreyButtonObjects2Objects, runtimeScene, true, false);
}if ( gdjs.Level_3211Code.condition1IsTrue_0.val ) {
{
gdjs.Level_3211Code.condition2IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDSubmit_9595TextObjects2Objects, gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDGreyButtonObjects2Objects, false, runtimeScene, false);
}}
}
if (gdjs.Level_3211Code.condition2IsTrue_0.val) {

{ //Subevents
gdjs.Level_3211Code.eventsList15(runtimeScene);} //End of subevents
}

}


};gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDGreyButtonObjects1Objects = Hashtable.newFrom({"GreyButton": gdjs.Level_3211Code.GDGreyButtonObjects1});
gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDStartOver_9595TextObjects1Objects = Hashtable.newFrom({"StartOver_Text": gdjs.Level_3211Code.GDStartOver_95TextObjects1});
gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDGreyButtonObjects1Objects = Hashtable.newFrom({"GreyButton": gdjs.Level_3211Code.GDGreyButtonObjects1});
gdjs.Level_3211Code.asyncCallback11524812 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Title Screen", false);
}}
gdjs.Level_3211Code.eventsList17 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.25), (runtimeScene) => (gdjs.Level_3211Code.asyncCallback11524812(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_3211Code.eventsList18 = function(runtimeScene) {

{


{
{gdjs.evtTools.storage.writeNumberInJSONFile("BallCupBoom", "CurrentLevel", 0);
}{gdjs.evtTools.storage.writeNumberInJSONFile("BallCupBoom", "PlayTimer", 0);
}{gdjs.evtTools.storage.writeNumberInJSONFile("BallCupBoom", "MovesMade", 0);
}
{ //Subevents
gdjs.Level_3211Code.eventsList17(runtimeScene);} //End of subevents
}

}


};gdjs.Level_3211Code.eventsList19 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("GreyButton"), gdjs.Level_3211Code.GDGreyButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("StartOver_Text"), gdjs.Level_3211Code.GDStartOver_95TextObjects1);

gdjs.Level_3211Code.condition0IsTrue_0.val = false;
gdjs.Level_3211Code.condition1IsTrue_0.val = false;
gdjs.Level_3211Code.condition2IsTrue_0.val = false;
{
gdjs.Level_3211Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.Level_3211Code.condition0IsTrue_0.val ) {
{
gdjs.Level_3211Code.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDGreyButtonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.Level_3211Code.condition1IsTrue_0.val ) {
{
gdjs.Level_3211Code.condition2IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDStartOver_9595TextObjects1Objects, gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDGreyButtonObjects1Objects, false, runtimeScene, false);
}}
}
if (gdjs.Level_3211Code.condition2IsTrue_0.val) {

{ //Subevents
gdjs.Level_3211Code.eventsList18(runtimeScene);} //End of subevents
}

}


};gdjs.Level_3211Code.eventsList20 = function(runtimeScene) {

{



}


{


gdjs.Level_3211Code.eventsList13(runtimeScene);
}


{


gdjs.Level_3211Code.eventsList16(runtimeScene);
}


{


gdjs.Level_3211Code.eventsList19(runtimeScene);
}


};gdjs.Level_3211Code.eventsList21 = function(runtimeScene) {

{


gdjs.Level_3211Code.eventsList0(runtimeScene);
}


{


gdjs.Level_3211Code.eventsList6(runtimeScene);
}


{


gdjs.Level_3211Code.eventsList20(runtimeScene);
}


};gdjs.Level_3211Code.eventsList22 = function(runtimeScene) {

{


gdjs.Level_3211Code.eventsList21(runtimeScene);
}


};

gdjs.Level_3211Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Level_3211Code.GDBall_951Objects1.length = 0;
gdjs.Level_3211Code.GDBall_951Objects2.length = 0;
gdjs.Level_3211Code.GDBall_951Objects3.length = 0;
gdjs.Level_3211Code.GDBall_951Objects4.length = 0;
gdjs.Level_3211Code.GDBall_951Objects5.length = 0;
gdjs.Level_3211Code.GDBall_951Objects6.length = 0;
gdjs.Level_3211Code.GDBall_952Objects1.length = 0;
gdjs.Level_3211Code.GDBall_952Objects2.length = 0;
gdjs.Level_3211Code.GDBall_952Objects3.length = 0;
gdjs.Level_3211Code.GDBall_952Objects4.length = 0;
gdjs.Level_3211Code.GDBall_952Objects5.length = 0;
gdjs.Level_3211Code.GDBall_952Objects6.length = 0;
gdjs.Level_3211Code.GDBall_953Objects1.length = 0;
gdjs.Level_3211Code.GDBall_953Objects2.length = 0;
gdjs.Level_3211Code.GDBall_953Objects3.length = 0;
gdjs.Level_3211Code.GDBall_953Objects4.length = 0;
gdjs.Level_3211Code.GDBall_953Objects5.length = 0;
gdjs.Level_3211Code.GDBall_953Objects6.length = 0;
gdjs.Level_3211Code.GDBall_954Objects1.length = 0;
gdjs.Level_3211Code.GDBall_954Objects2.length = 0;
gdjs.Level_3211Code.GDBall_954Objects3.length = 0;
gdjs.Level_3211Code.GDBall_954Objects4.length = 0;
gdjs.Level_3211Code.GDBall_954Objects5.length = 0;
gdjs.Level_3211Code.GDBall_954Objects6.length = 0;
gdjs.Level_3211Code.GDBall_955Objects1.length = 0;
gdjs.Level_3211Code.GDBall_955Objects2.length = 0;
gdjs.Level_3211Code.GDBall_955Objects3.length = 0;
gdjs.Level_3211Code.GDBall_955Objects4.length = 0;
gdjs.Level_3211Code.GDBall_955Objects5.length = 0;
gdjs.Level_3211Code.GDBall_955Objects6.length = 0;
gdjs.Level_3211Code.GDBall_956Objects1.length = 0;
gdjs.Level_3211Code.GDBall_956Objects2.length = 0;
gdjs.Level_3211Code.GDBall_956Objects3.length = 0;
gdjs.Level_3211Code.GDBall_956Objects4.length = 0;
gdjs.Level_3211Code.GDBall_956Objects5.length = 0;
gdjs.Level_3211Code.GDBall_956Objects6.length = 0;
gdjs.Level_3211Code.GDGlassBreaking_95ParticlesObjects1.length = 0;
gdjs.Level_3211Code.GDGlassBreaking_95ParticlesObjects2.length = 0;
gdjs.Level_3211Code.GDGlassBreaking_95ParticlesObjects3.length = 0;
gdjs.Level_3211Code.GDGlassBreaking_95ParticlesObjects4.length = 0;
gdjs.Level_3211Code.GDGlassBreaking_95ParticlesObjects5.length = 0;
gdjs.Level_3211Code.GDGlassBreaking_95ParticlesObjects6.length = 0;
gdjs.Level_3211Code.GDCupObjects1.length = 0;
gdjs.Level_3211Code.GDCupObjects2.length = 0;
gdjs.Level_3211Code.GDCupObjects3.length = 0;
gdjs.Level_3211Code.GDCupObjects4.length = 0;
gdjs.Level_3211Code.GDCupObjects5.length = 0;
gdjs.Level_3211Code.GDCupObjects6.length = 0;
gdjs.Level_3211Code.GDCupFrontObjects1.length = 0;
gdjs.Level_3211Code.GDCupFrontObjects2.length = 0;
gdjs.Level_3211Code.GDCupFrontObjects3.length = 0;
gdjs.Level_3211Code.GDCupFrontObjects4.length = 0;
gdjs.Level_3211Code.GDCupFrontObjects5.length = 0;
gdjs.Level_3211Code.GDCupFrontObjects6.length = 0;
gdjs.Level_3211Code.GDCloud1Objects1.length = 0;
gdjs.Level_3211Code.GDCloud1Objects2.length = 0;
gdjs.Level_3211Code.GDCloud1Objects3.length = 0;
gdjs.Level_3211Code.GDCloud1Objects4.length = 0;
gdjs.Level_3211Code.GDCloud1Objects5.length = 0;
gdjs.Level_3211Code.GDCloud1Objects6.length = 0;
gdjs.Level_3211Code.GDCloud2Objects1.length = 0;
gdjs.Level_3211Code.GDCloud2Objects2.length = 0;
gdjs.Level_3211Code.GDCloud2Objects3.length = 0;
gdjs.Level_3211Code.GDCloud2Objects4.length = 0;
gdjs.Level_3211Code.GDCloud2Objects5.length = 0;
gdjs.Level_3211Code.GDCloud2Objects6.length = 0;
gdjs.Level_3211Code.GDCloud3Objects1.length = 0;
gdjs.Level_3211Code.GDCloud3Objects2.length = 0;
gdjs.Level_3211Code.GDCloud3Objects3.length = 0;
gdjs.Level_3211Code.GDCloud3Objects4.length = 0;
gdjs.Level_3211Code.GDCloud3Objects5.length = 0;
gdjs.Level_3211Code.GDCloud3Objects6.length = 0;
gdjs.Level_3211Code.GDCloud4Objects1.length = 0;
gdjs.Level_3211Code.GDCloud4Objects2.length = 0;
gdjs.Level_3211Code.GDCloud4Objects3.length = 0;
gdjs.Level_3211Code.GDCloud4Objects4.length = 0;
gdjs.Level_3211Code.GDCloud4Objects5.length = 0;
gdjs.Level_3211Code.GDCloud4Objects6.length = 0;
gdjs.Level_3211Code.GDEditInGDevelop_95TextObjects1.length = 0;
gdjs.Level_3211Code.GDEditInGDevelop_95TextObjects2.length = 0;
gdjs.Level_3211Code.GDEditInGDevelop_95TextObjects3.length = 0;
gdjs.Level_3211Code.GDEditInGDevelop_95TextObjects4.length = 0;
gdjs.Level_3211Code.GDEditInGDevelop_95TextObjects5.length = 0;
gdjs.Level_3211Code.GDEditInGDevelop_95TextObjects6.length = 0;
gdjs.Level_3211Code.GDGreyButtonObjects1.length = 0;
gdjs.Level_3211Code.GDGreyButtonObjects2.length = 0;
gdjs.Level_3211Code.GDGreyButtonObjects3.length = 0;
gdjs.Level_3211Code.GDGreyButtonObjects4.length = 0;
gdjs.Level_3211Code.GDGreyButtonObjects5.length = 0;
gdjs.Level_3211Code.GDGreyButtonObjects6.length = 0;
gdjs.Level_3211Code.GDCurrentLevel_95TextObjects1.length = 0;
gdjs.Level_3211Code.GDCurrentLevel_95TextObjects2.length = 0;
gdjs.Level_3211Code.GDCurrentLevel_95TextObjects3.length = 0;
gdjs.Level_3211Code.GDCurrentLevel_95TextObjects4.length = 0;
gdjs.Level_3211Code.GDCurrentLevel_95TextObjects5.length = 0;
gdjs.Level_3211Code.GDCurrentLevel_95TextObjects6.length = 0;
gdjs.Level_3211Code.GDMenuObjects1.length = 0;
gdjs.Level_3211Code.GDMenuObjects2.length = 0;
gdjs.Level_3211Code.GDMenuObjects3.length = 0;
gdjs.Level_3211Code.GDMenuObjects4.length = 0;
gdjs.Level_3211Code.GDMenuObjects5.length = 0;
gdjs.Level_3211Code.GDMenuObjects6.length = 0;
gdjs.Level_3211Code.GDGameState_95TextObjects1.length = 0;
gdjs.Level_3211Code.GDGameState_95TextObjects2.length = 0;
gdjs.Level_3211Code.GDGameState_95TextObjects3.length = 0;
gdjs.Level_3211Code.GDGameState_95TextObjects4.length = 0;
gdjs.Level_3211Code.GDGameState_95TextObjects5.length = 0;
gdjs.Level_3211Code.GDGameState_95TextObjects6.length = 0;
gdjs.Level_3211Code.GDMovesMade_95TextObjects1.length = 0;
gdjs.Level_3211Code.GDMovesMade_95TextObjects2.length = 0;
gdjs.Level_3211Code.GDMovesMade_95TextObjects3.length = 0;
gdjs.Level_3211Code.GDMovesMade_95TextObjects4.length = 0;
gdjs.Level_3211Code.GDMovesMade_95TextObjects5.length = 0;
gdjs.Level_3211Code.GDMovesMade_95TextObjects6.length = 0;
gdjs.Level_3211Code.GDTimeSpent_95TextObjects1.length = 0;
gdjs.Level_3211Code.GDTimeSpent_95TextObjects2.length = 0;
gdjs.Level_3211Code.GDTimeSpent_95TextObjects3.length = 0;
gdjs.Level_3211Code.GDTimeSpent_95TextObjects4.length = 0;
gdjs.Level_3211Code.GDTimeSpent_95TextObjects5.length = 0;
gdjs.Level_3211Code.GDTimeSpent_95TextObjects6.length = 0;
gdjs.Level_3211Code.GDBallsInCup_95TextObjects1.length = 0;
gdjs.Level_3211Code.GDBallsInCup_95TextObjects2.length = 0;
gdjs.Level_3211Code.GDBallsInCup_95TextObjects3.length = 0;
gdjs.Level_3211Code.GDBallsInCup_95TextObjects4.length = 0;
gdjs.Level_3211Code.GDBallsInCup_95TextObjects5.length = 0;
gdjs.Level_3211Code.GDBallsInCup_95TextObjects6.length = 0;
gdjs.Level_3211Code.GDPlay_95TextObjects1.length = 0;
gdjs.Level_3211Code.GDPlay_95TextObjects2.length = 0;
gdjs.Level_3211Code.GDPlay_95TextObjects3.length = 0;
gdjs.Level_3211Code.GDPlay_95TextObjects4.length = 0;
gdjs.Level_3211Code.GDPlay_95TextObjects5.length = 0;
gdjs.Level_3211Code.GDPlay_95TextObjects6.length = 0;
gdjs.Level_3211Code.GDLeaderboardObjects1.length = 0;
gdjs.Level_3211Code.GDLeaderboardObjects2.length = 0;
gdjs.Level_3211Code.GDLeaderboardObjects3.length = 0;
gdjs.Level_3211Code.GDLeaderboardObjects4.length = 0;
gdjs.Level_3211Code.GDLeaderboardObjects5.length = 0;
gdjs.Level_3211Code.GDLeaderboardObjects6.length = 0;
gdjs.Level_3211Code.GDMainMenu_95TextObjects1.length = 0;
gdjs.Level_3211Code.GDMainMenu_95TextObjects2.length = 0;
gdjs.Level_3211Code.GDMainMenu_95TextObjects3.length = 0;
gdjs.Level_3211Code.GDMainMenu_95TextObjects4.length = 0;
gdjs.Level_3211Code.GDMainMenu_95TextObjects5.length = 0;
gdjs.Level_3211Code.GDMainMenu_95TextObjects6.length = 0;
gdjs.Level_3211Code.GDResetProgress_95TextObjects1.length = 0;
gdjs.Level_3211Code.GDResetProgress_95TextObjects2.length = 0;
gdjs.Level_3211Code.GDResetProgress_95TextObjects3.length = 0;
gdjs.Level_3211Code.GDResetProgress_95TextObjects4.length = 0;
gdjs.Level_3211Code.GDResetProgress_95TextObjects5.length = 0;
gdjs.Level_3211Code.GDResetProgress_95TextObjects6.length = 0;
gdjs.Level_3211Code.GDStartOver_95TextObjects1.length = 0;
gdjs.Level_3211Code.GDStartOver_95TextObjects2.length = 0;
gdjs.Level_3211Code.GDStartOver_95TextObjects3.length = 0;
gdjs.Level_3211Code.GDStartOver_95TextObjects4.length = 0;
gdjs.Level_3211Code.GDStartOver_95TextObjects5.length = 0;
gdjs.Level_3211Code.GDStartOver_95TextObjects6.length = 0;
gdjs.Level_3211Code.GDSubmit_95TextObjects1.length = 0;
gdjs.Level_3211Code.GDSubmit_95TextObjects2.length = 0;
gdjs.Level_3211Code.GDSubmit_95TextObjects3.length = 0;
gdjs.Level_3211Code.GDSubmit_95TextObjects4.length = 0;
gdjs.Level_3211Code.GDSubmit_95TextObjects5.length = 0;
gdjs.Level_3211Code.GDSubmit_95TextObjects6.length = 0;
gdjs.Level_3211Code.GDVictory_95TextObjects1.length = 0;
gdjs.Level_3211Code.GDVictory_95TextObjects2.length = 0;
gdjs.Level_3211Code.GDVictory_95TextObjects3.length = 0;
gdjs.Level_3211Code.GDVictory_95TextObjects4.length = 0;
gdjs.Level_3211Code.GDVictory_95TextObjects5.length = 0;
gdjs.Level_3211Code.GDVictory_95TextObjects6.length = 0;
gdjs.Level_3211Code.GDMenuObjects1.length = 0;
gdjs.Level_3211Code.GDMenuObjects2.length = 0;
gdjs.Level_3211Code.GDMenuObjects3.length = 0;
gdjs.Level_3211Code.GDMenuObjects4.length = 0;
gdjs.Level_3211Code.GDMenuObjects5.length = 0;
gdjs.Level_3211Code.GDMenuObjects6.length = 0;

gdjs.Level_3211Code.eventsList22(runtimeScene);

return;

}

gdjs['Level_3211Code'] = gdjs.Level_3211Code;
