gdjs.SubmitScoreCode = {};
gdjs.SubmitScoreCode.repeatCount3 = 0;

gdjs.SubmitScoreCode.repeatIndex3 = 0;

gdjs.SubmitScoreCode.GDBall_951Objects1= [];
gdjs.SubmitScoreCode.GDBall_951Objects2= [];
gdjs.SubmitScoreCode.GDBall_951Objects3= [];
gdjs.SubmitScoreCode.GDBall_951Objects4= [];
gdjs.SubmitScoreCode.GDBall_951Objects5= [];
gdjs.SubmitScoreCode.GDBall_952Objects1= [];
gdjs.SubmitScoreCode.GDBall_952Objects2= [];
gdjs.SubmitScoreCode.GDBall_952Objects3= [];
gdjs.SubmitScoreCode.GDBall_952Objects4= [];
gdjs.SubmitScoreCode.GDBall_952Objects5= [];
gdjs.SubmitScoreCode.GDBall_953Objects1= [];
gdjs.SubmitScoreCode.GDBall_953Objects2= [];
gdjs.SubmitScoreCode.GDBall_953Objects3= [];
gdjs.SubmitScoreCode.GDBall_953Objects4= [];
gdjs.SubmitScoreCode.GDBall_953Objects5= [];
gdjs.SubmitScoreCode.GDBall_954Objects1= [];
gdjs.SubmitScoreCode.GDBall_954Objects2= [];
gdjs.SubmitScoreCode.GDBall_954Objects3= [];
gdjs.SubmitScoreCode.GDBall_954Objects4= [];
gdjs.SubmitScoreCode.GDBall_954Objects5= [];
gdjs.SubmitScoreCode.GDBall_955Objects1= [];
gdjs.SubmitScoreCode.GDBall_955Objects2= [];
gdjs.SubmitScoreCode.GDBall_955Objects3= [];
gdjs.SubmitScoreCode.GDBall_955Objects4= [];
gdjs.SubmitScoreCode.GDBall_955Objects5= [];
gdjs.SubmitScoreCode.GDBall_956Objects1= [];
gdjs.SubmitScoreCode.GDBall_956Objects2= [];
gdjs.SubmitScoreCode.GDBall_956Objects3= [];
gdjs.SubmitScoreCode.GDBall_956Objects4= [];
gdjs.SubmitScoreCode.GDBall_956Objects5= [];
gdjs.SubmitScoreCode.GDGlassBreaking_95ParticlesObjects1= [];
gdjs.SubmitScoreCode.GDGlassBreaking_95ParticlesObjects2= [];
gdjs.SubmitScoreCode.GDGlassBreaking_95ParticlesObjects3= [];
gdjs.SubmitScoreCode.GDGlassBreaking_95ParticlesObjects4= [];
gdjs.SubmitScoreCode.GDGlassBreaking_95ParticlesObjects5= [];
gdjs.SubmitScoreCode.GDCupObjects1= [];
gdjs.SubmitScoreCode.GDCupObjects2= [];
gdjs.SubmitScoreCode.GDCupObjects3= [];
gdjs.SubmitScoreCode.GDCupObjects4= [];
gdjs.SubmitScoreCode.GDCupObjects5= [];
gdjs.SubmitScoreCode.GDCupFrontObjects1= [];
gdjs.SubmitScoreCode.GDCupFrontObjects2= [];
gdjs.SubmitScoreCode.GDCupFrontObjects3= [];
gdjs.SubmitScoreCode.GDCupFrontObjects4= [];
gdjs.SubmitScoreCode.GDCupFrontObjects5= [];
gdjs.SubmitScoreCode.GDCloud1Objects1= [];
gdjs.SubmitScoreCode.GDCloud1Objects2= [];
gdjs.SubmitScoreCode.GDCloud1Objects3= [];
gdjs.SubmitScoreCode.GDCloud1Objects4= [];
gdjs.SubmitScoreCode.GDCloud1Objects5= [];
gdjs.SubmitScoreCode.GDCloud2Objects1= [];
gdjs.SubmitScoreCode.GDCloud2Objects2= [];
gdjs.SubmitScoreCode.GDCloud2Objects3= [];
gdjs.SubmitScoreCode.GDCloud2Objects4= [];
gdjs.SubmitScoreCode.GDCloud2Objects5= [];
gdjs.SubmitScoreCode.GDCloud3Objects1= [];
gdjs.SubmitScoreCode.GDCloud3Objects2= [];
gdjs.SubmitScoreCode.GDCloud3Objects3= [];
gdjs.SubmitScoreCode.GDCloud3Objects4= [];
gdjs.SubmitScoreCode.GDCloud3Objects5= [];
gdjs.SubmitScoreCode.GDCloud4Objects1= [];
gdjs.SubmitScoreCode.GDCloud4Objects2= [];
gdjs.SubmitScoreCode.GDCloud4Objects3= [];
gdjs.SubmitScoreCode.GDCloud4Objects4= [];
gdjs.SubmitScoreCode.GDCloud4Objects5= [];
gdjs.SubmitScoreCode.GDEditInGDevelop_95TextObjects1= [];
gdjs.SubmitScoreCode.GDEditInGDevelop_95TextObjects2= [];
gdjs.SubmitScoreCode.GDEditInGDevelop_95TextObjects3= [];
gdjs.SubmitScoreCode.GDEditInGDevelop_95TextObjects4= [];
gdjs.SubmitScoreCode.GDEditInGDevelop_95TextObjects5= [];
gdjs.SubmitScoreCode.GDGreyButtonObjects1= [];
gdjs.SubmitScoreCode.GDGreyButtonObjects2= [];
gdjs.SubmitScoreCode.GDGreyButtonObjects3= [];
gdjs.SubmitScoreCode.GDGreyButtonObjects4= [];
gdjs.SubmitScoreCode.GDGreyButtonObjects5= [];
gdjs.SubmitScoreCode.GDCurrentLevel_95TextObjects1= [];
gdjs.SubmitScoreCode.GDCurrentLevel_95TextObjects2= [];
gdjs.SubmitScoreCode.GDCurrentLevel_95TextObjects3= [];
gdjs.SubmitScoreCode.GDCurrentLevel_95TextObjects4= [];
gdjs.SubmitScoreCode.GDCurrentLevel_95TextObjects5= [];
gdjs.SubmitScoreCode.GDMenuObjects1= [];
gdjs.SubmitScoreCode.GDMenuObjects2= [];
gdjs.SubmitScoreCode.GDMenuObjects3= [];
gdjs.SubmitScoreCode.GDMenuObjects4= [];
gdjs.SubmitScoreCode.GDMenuObjects5= [];
gdjs.SubmitScoreCode.GDGameState_95TextObjects1= [];
gdjs.SubmitScoreCode.GDGameState_95TextObjects2= [];
gdjs.SubmitScoreCode.GDGameState_95TextObjects3= [];
gdjs.SubmitScoreCode.GDGameState_95TextObjects4= [];
gdjs.SubmitScoreCode.GDGameState_95TextObjects5= [];
gdjs.SubmitScoreCode.GDMovesMade_95TextObjects1= [];
gdjs.SubmitScoreCode.GDMovesMade_95TextObjects2= [];
gdjs.SubmitScoreCode.GDMovesMade_95TextObjects3= [];
gdjs.SubmitScoreCode.GDMovesMade_95TextObjects4= [];
gdjs.SubmitScoreCode.GDMovesMade_95TextObjects5= [];
gdjs.SubmitScoreCode.GDTimeSpent_95TextObjects1= [];
gdjs.SubmitScoreCode.GDTimeSpent_95TextObjects2= [];
gdjs.SubmitScoreCode.GDTimeSpent_95TextObjects3= [];
gdjs.SubmitScoreCode.GDTimeSpent_95TextObjects4= [];
gdjs.SubmitScoreCode.GDTimeSpent_95TextObjects5= [];
gdjs.SubmitScoreCode.GDBallsInCup_95TextObjects1= [];
gdjs.SubmitScoreCode.GDBallsInCup_95TextObjects2= [];
gdjs.SubmitScoreCode.GDBallsInCup_95TextObjects3= [];
gdjs.SubmitScoreCode.GDBallsInCup_95TextObjects4= [];
gdjs.SubmitScoreCode.GDBallsInCup_95TextObjects5= [];
gdjs.SubmitScoreCode.GDPlay_95TextObjects1= [];
gdjs.SubmitScoreCode.GDPlay_95TextObjects2= [];
gdjs.SubmitScoreCode.GDPlay_95TextObjects3= [];
gdjs.SubmitScoreCode.GDPlay_95TextObjects4= [];
gdjs.SubmitScoreCode.GDPlay_95TextObjects5= [];
gdjs.SubmitScoreCode.GDLeaderboardObjects1= [];
gdjs.SubmitScoreCode.GDLeaderboardObjects2= [];
gdjs.SubmitScoreCode.GDLeaderboardObjects3= [];
gdjs.SubmitScoreCode.GDLeaderboardObjects4= [];
gdjs.SubmitScoreCode.GDLeaderboardObjects5= [];
gdjs.SubmitScoreCode.GDMainMenu_95TextObjects1= [];
gdjs.SubmitScoreCode.GDMainMenu_95TextObjects2= [];
gdjs.SubmitScoreCode.GDMainMenu_95TextObjects3= [];
gdjs.SubmitScoreCode.GDMainMenu_95TextObjects4= [];
gdjs.SubmitScoreCode.GDMainMenu_95TextObjects5= [];
gdjs.SubmitScoreCode.GDResetProgress_95TextObjects1= [];
gdjs.SubmitScoreCode.GDResetProgress_95TextObjects2= [];
gdjs.SubmitScoreCode.GDResetProgress_95TextObjects3= [];
gdjs.SubmitScoreCode.GDResetProgress_95TextObjects4= [];
gdjs.SubmitScoreCode.GDResetProgress_95TextObjects5= [];
gdjs.SubmitScoreCode.GDStartOver_95TextObjects1= [];
gdjs.SubmitScoreCode.GDStartOver_95TextObjects2= [];
gdjs.SubmitScoreCode.GDStartOver_95TextObjects3= [];
gdjs.SubmitScoreCode.GDStartOver_95TextObjects4= [];
gdjs.SubmitScoreCode.GDStartOver_95TextObjects5= [];
gdjs.SubmitScoreCode.GDSubmit_95TextObjects1= [];
gdjs.SubmitScoreCode.GDSubmit_95TextObjects2= [];
gdjs.SubmitScoreCode.GDSubmit_95TextObjects3= [];
gdjs.SubmitScoreCode.GDSubmit_95TextObjects4= [];
gdjs.SubmitScoreCode.GDSubmit_95TextObjects5= [];
gdjs.SubmitScoreCode.GDMovesValue_95TextObjects1= [];
gdjs.SubmitScoreCode.GDMovesValue_95TextObjects2= [];
gdjs.SubmitScoreCode.GDMovesValue_95TextObjects3= [];
gdjs.SubmitScoreCode.GDMovesValue_95TextObjects4= [];
gdjs.SubmitScoreCode.GDMovesValue_95TextObjects5= [];
gdjs.SubmitScoreCode.GDTimeValue_95TextObjects1= [];
gdjs.SubmitScoreCode.GDTimeValue_95TextObjects2= [];
gdjs.SubmitScoreCode.GDTimeValue_95TextObjects3= [];
gdjs.SubmitScoreCode.GDTimeValue_95TextObjects4= [];
gdjs.SubmitScoreCode.GDTimeValue_95TextObjects5= [];
gdjs.SubmitScoreCode.GDSubmitScore_95TextObjects1= [];
gdjs.SubmitScoreCode.GDSubmitScore_95TextObjects2= [];
gdjs.SubmitScoreCode.GDSubmitScore_95TextObjects3= [];
gdjs.SubmitScoreCode.GDSubmitScore_95TextObjects4= [];
gdjs.SubmitScoreCode.GDSubmitScore_95TextObjects5= [];
gdjs.SubmitScoreCode.GDPlayerName_95InputObjects1= [];
gdjs.SubmitScoreCode.GDPlayerName_95InputObjects2= [];
gdjs.SubmitScoreCode.GDPlayerName_95InputObjects3= [];
gdjs.SubmitScoreCode.GDPlayerName_95InputObjects4= [];
gdjs.SubmitScoreCode.GDPlayerName_95InputObjects5= [];

gdjs.SubmitScoreCode.conditionTrue_0 = {val:false};
gdjs.SubmitScoreCode.condition0IsTrue_0 = {val:false};
gdjs.SubmitScoreCode.condition1IsTrue_0 = {val:false};
gdjs.SubmitScoreCode.condition2IsTrue_0 = {val:false};
gdjs.SubmitScoreCode.condition3IsTrue_0 = {val:false};
gdjs.SubmitScoreCode.condition4IsTrue_0 = {val:false};
gdjs.SubmitScoreCode.conditionTrue_1 = {val:false};
gdjs.SubmitScoreCode.condition0IsTrue_1 = {val:false};
gdjs.SubmitScoreCode.condition1IsTrue_1 = {val:false};
gdjs.SubmitScoreCode.condition2IsTrue_1 = {val:false};
gdjs.SubmitScoreCode.condition3IsTrue_1 = {val:false};
gdjs.SubmitScoreCode.condition4IsTrue_1 = {val:false};


gdjs.SubmitScoreCode.mapOfGDgdjs_46SubmitScoreCode_46GDGreyButtonObjects2ObjectsGDgdjs_46SubmitScoreCode_46GDLeaderboardObjects2ObjectsGDgdjs_46SubmitScoreCode_46GDMenuObjects2Objects = Hashtable.newFrom({"GreyButton": gdjs.SubmitScoreCode.GDGreyButtonObjects2, "Leaderboard": gdjs.SubmitScoreCode.GDLeaderboardObjects2, "Menu": gdjs.SubmitScoreCode.GDMenuObjects2});
gdjs.SubmitScoreCode.mapOfGDgdjs_46SubmitScoreCode_46GDPlay_9595TextObjects2ObjectsGDgdjs_46SubmitScoreCode_46GDMainMenu_9595TextObjects2ObjectsGDgdjs_46SubmitScoreCode_46GDResetProgress_9595TextObjects2ObjectsGDgdjs_46SubmitScoreCode_46GDStartOver_9595TextObjects2ObjectsGDgdjs_46SubmitScoreCode_46GDSubmit_9595TextObjects2Objects = Hashtable.newFrom({"Play_Text": gdjs.SubmitScoreCode.GDPlay_95TextObjects2, "MainMenu_Text": gdjs.SubmitScoreCode.GDMainMenu_95TextObjects2, "ResetProgress_Text": gdjs.SubmitScoreCode.GDResetProgress_95TextObjects2, "StartOver_Text": gdjs.SubmitScoreCode.GDStartOver_95TextObjects2, "Submit_Text": gdjs.SubmitScoreCode.GDSubmit_95TextObjects2});
gdjs.SubmitScoreCode.mapOfGDgdjs_46SubmitScoreCode_46GDGreyButtonObjects2ObjectsGDgdjs_46SubmitScoreCode_46GDLeaderboardObjects2ObjectsGDgdjs_46SubmitScoreCode_46GDMenuObjects2Objects = Hashtable.newFrom({"GreyButton": gdjs.SubmitScoreCode.GDGreyButtonObjects2, "Leaderboard": gdjs.SubmitScoreCode.GDLeaderboardObjects2, "Menu": gdjs.SubmitScoreCode.GDMenuObjects2});
gdjs.SubmitScoreCode.eventsList0 = function(runtimeScene) {

{

/* Reuse gdjs.SubmitScoreCode.GDGreyButtonObjects2 */
/* Reuse gdjs.SubmitScoreCode.GDLeaderboardObjects2 */
gdjs.copyArray(runtimeScene.getObjects("MainMenu_Text"), gdjs.SubmitScoreCode.GDMainMenu_95TextObjects2);
/* Reuse gdjs.SubmitScoreCode.GDMenuObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Play_Text"), gdjs.SubmitScoreCode.GDPlay_95TextObjects2);
gdjs.copyArray(runtimeScene.getObjects("ResetProgress_Text"), gdjs.SubmitScoreCode.GDResetProgress_95TextObjects2);
gdjs.copyArray(runtimeScene.getObjects("StartOver_Text"), gdjs.SubmitScoreCode.GDStartOver_95TextObjects2);
gdjs.copyArray(runtimeScene.getObjects("Submit_Text"), gdjs.SubmitScoreCode.GDSubmit_95TextObjects2);

gdjs.SubmitScoreCode.condition0IsTrue_0.val = false;
{
gdjs.SubmitScoreCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.SubmitScoreCode.mapOfGDgdjs_46SubmitScoreCode_46GDPlay_9595TextObjects2ObjectsGDgdjs_46SubmitScoreCode_46GDMainMenu_9595TextObjects2ObjectsGDgdjs_46SubmitScoreCode_46GDResetProgress_9595TextObjects2ObjectsGDgdjs_46SubmitScoreCode_46GDStartOver_9595TextObjects2ObjectsGDgdjs_46SubmitScoreCode_46GDSubmit_9595TextObjects2Objects, gdjs.SubmitScoreCode.mapOfGDgdjs_46SubmitScoreCode_46GDGreyButtonObjects2ObjectsGDgdjs_46SubmitScoreCode_46GDLeaderboardObjects2ObjectsGDgdjs_46SubmitScoreCode_46GDMenuObjects2Objects, false, runtimeScene, false);
}if (gdjs.SubmitScoreCode.condition0IsTrue_0.val) {
/* Reuse gdjs.SubmitScoreCode.GDMainMenu_95TextObjects2 */
/* Reuse gdjs.SubmitScoreCode.GDPlay_95TextObjects2 */
/* Reuse gdjs.SubmitScoreCode.GDResetProgress_95TextObjects2 */
/* Reuse gdjs.SubmitScoreCode.GDStartOver_95TextObjects2 */
/* Reuse gdjs.SubmitScoreCode.GDSubmit_95TextObjects2 */
{for(var i = 0, len = gdjs.SubmitScoreCode.GDPlay_95TextObjects2.length ;i < len;++i) {
    gdjs.SubmitScoreCode.GDPlay_95TextObjects2[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.SubmitScoreCode.GDMainMenu_95TextObjects2.length ;i < len;++i) {
    gdjs.SubmitScoreCode.GDMainMenu_95TextObjects2[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.SubmitScoreCode.GDResetProgress_95TextObjects2.length ;i < len;++i) {
    gdjs.SubmitScoreCode.GDResetProgress_95TextObjects2[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.SubmitScoreCode.GDStartOver_95TextObjects2.length ;i < len;++i) {
    gdjs.SubmitScoreCode.GDStartOver_95TextObjects2[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.SubmitScoreCode.GDSubmit_95TextObjects2.length ;i < len;++i) {
    gdjs.SubmitScoreCode.GDSubmit_95TextObjects2[i].setColor("255;255;255");
}
}}

}


};gdjs.SubmitScoreCode.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("GreyButton"), gdjs.SubmitScoreCode.GDGreyButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Leaderboard"), gdjs.SubmitScoreCode.GDLeaderboardObjects2);
gdjs.copyArray(runtimeScene.getObjects("Menu"), gdjs.SubmitScoreCode.GDMenuObjects2);

gdjs.SubmitScoreCode.condition0IsTrue_0.val = false;
{
gdjs.SubmitScoreCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.SubmitScoreCode.mapOfGDgdjs_46SubmitScoreCode_46GDGreyButtonObjects2ObjectsGDgdjs_46SubmitScoreCode_46GDLeaderboardObjects2ObjectsGDgdjs_46SubmitScoreCode_46GDMenuObjects2Objects, runtimeScene, true, true);
}if (gdjs.SubmitScoreCode.condition0IsTrue_0.val) {
/* Reuse gdjs.SubmitScoreCode.GDGreyButtonObjects2 */
/* Reuse gdjs.SubmitScoreCode.GDLeaderboardObjects2 */
/* Reuse gdjs.SubmitScoreCode.GDMenuObjects2 */
{for(var i = 0, len = gdjs.SubmitScoreCode.GDGreyButtonObjects2.length ;i < len;++i) {
    gdjs.SubmitScoreCode.GDGreyButtonObjects2[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.SubmitScoreCode.GDLeaderboardObjects2.length ;i < len;++i) {
    gdjs.SubmitScoreCode.GDLeaderboardObjects2[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.SubmitScoreCode.GDMenuObjects2.length ;i < len;++i) {
    gdjs.SubmitScoreCode.GDMenuObjects2[i].setColor("255;255;255");
}
}{for(var i = 0, len = gdjs.SubmitScoreCode.GDGreyButtonObjects2.length ;i < len;++i) {
    gdjs.SubmitScoreCode.GDGreyButtonObjects2[i].enableEffect("Effect", false);
}
for(var i = 0, len = gdjs.SubmitScoreCode.GDLeaderboardObjects2.length ;i < len;++i) {
    gdjs.SubmitScoreCode.GDLeaderboardObjects2[i].enableEffect("Effect", false);
}
for(var i = 0, len = gdjs.SubmitScoreCode.GDMenuObjects2.length ;i < len;++i) {
    gdjs.SubmitScoreCode.GDMenuObjects2[i].enableEffect("Effect", false);
}
}
{ //Subevents
gdjs.SubmitScoreCode.eventsList0(runtimeScene);} //End of subevents
}

}


};gdjs.SubmitScoreCode.mapOfGDgdjs_46SubmitScoreCode_46GDGreyButtonObjects2ObjectsGDgdjs_46SubmitScoreCode_46GDLeaderboardObjects2ObjectsGDgdjs_46SubmitScoreCode_46GDMenuObjects2Objects = Hashtable.newFrom({"GreyButton": gdjs.SubmitScoreCode.GDGreyButtonObjects2, "Leaderboard": gdjs.SubmitScoreCode.GDLeaderboardObjects2, "Menu": gdjs.SubmitScoreCode.GDMenuObjects2});
gdjs.SubmitScoreCode.mapOfGDgdjs_46SubmitScoreCode_46GDPlay_9595TextObjects2ObjectsGDgdjs_46SubmitScoreCode_46GDMainMenu_9595TextObjects2ObjectsGDgdjs_46SubmitScoreCode_46GDResetProgress_9595TextObjects2ObjectsGDgdjs_46SubmitScoreCode_46GDStartOver_9595TextObjects2ObjectsGDgdjs_46SubmitScoreCode_46GDSubmit_9595TextObjects2Objects = Hashtable.newFrom({"Play_Text": gdjs.SubmitScoreCode.GDPlay_95TextObjects2, "MainMenu_Text": gdjs.SubmitScoreCode.GDMainMenu_95TextObjects2, "ResetProgress_Text": gdjs.SubmitScoreCode.GDResetProgress_95TextObjects2, "StartOver_Text": gdjs.SubmitScoreCode.GDStartOver_95TextObjects2, "Submit_Text": gdjs.SubmitScoreCode.GDSubmit_95TextObjects2});
gdjs.SubmitScoreCode.mapOfGDgdjs_46SubmitScoreCode_46GDGreyButtonObjects2ObjectsGDgdjs_46SubmitScoreCode_46GDLeaderboardObjects2ObjectsGDgdjs_46SubmitScoreCode_46GDMenuObjects2Objects = Hashtable.newFrom({"GreyButton": gdjs.SubmitScoreCode.GDGreyButtonObjects2, "Leaderboard": gdjs.SubmitScoreCode.GDLeaderboardObjects2, "Menu": gdjs.SubmitScoreCode.GDMenuObjects2});
gdjs.SubmitScoreCode.eventsList2 = function(runtimeScene) {

{

/* Reuse gdjs.SubmitScoreCode.GDGreyButtonObjects2 */
/* Reuse gdjs.SubmitScoreCode.GDLeaderboardObjects2 */
gdjs.copyArray(runtimeScene.getObjects("MainMenu_Text"), gdjs.SubmitScoreCode.GDMainMenu_95TextObjects2);
/* Reuse gdjs.SubmitScoreCode.GDMenuObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Play_Text"), gdjs.SubmitScoreCode.GDPlay_95TextObjects2);
gdjs.copyArray(runtimeScene.getObjects("ResetProgress_Text"), gdjs.SubmitScoreCode.GDResetProgress_95TextObjects2);
gdjs.copyArray(runtimeScene.getObjects("StartOver_Text"), gdjs.SubmitScoreCode.GDStartOver_95TextObjects2);
gdjs.copyArray(runtimeScene.getObjects("Submit_Text"), gdjs.SubmitScoreCode.GDSubmit_95TextObjects2);

gdjs.SubmitScoreCode.condition0IsTrue_0.val = false;
{
gdjs.SubmitScoreCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.SubmitScoreCode.mapOfGDgdjs_46SubmitScoreCode_46GDPlay_9595TextObjects2ObjectsGDgdjs_46SubmitScoreCode_46GDMainMenu_9595TextObjects2ObjectsGDgdjs_46SubmitScoreCode_46GDResetProgress_9595TextObjects2ObjectsGDgdjs_46SubmitScoreCode_46GDStartOver_9595TextObjects2ObjectsGDgdjs_46SubmitScoreCode_46GDSubmit_9595TextObjects2Objects, gdjs.SubmitScoreCode.mapOfGDgdjs_46SubmitScoreCode_46GDGreyButtonObjects2ObjectsGDgdjs_46SubmitScoreCode_46GDLeaderboardObjects2ObjectsGDgdjs_46SubmitScoreCode_46GDMenuObjects2Objects, false, runtimeScene, false);
}if (gdjs.SubmitScoreCode.condition0IsTrue_0.val) {
/* Reuse gdjs.SubmitScoreCode.GDMainMenu_95TextObjects2 */
/* Reuse gdjs.SubmitScoreCode.GDPlay_95TextObjects2 */
/* Reuse gdjs.SubmitScoreCode.GDResetProgress_95TextObjects2 */
/* Reuse gdjs.SubmitScoreCode.GDStartOver_95TextObjects2 */
/* Reuse gdjs.SubmitScoreCode.GDSubmit_95TextObjects2 */
{for(var i = 0, len = gdjs.SubmitScoreCode.GDPlay_95TextObjects2.length ;i < len;++i) {
    gdjs.SubmitScoreCode.GDPlay_95TextObjects2[i].setColor("241;91;181");
}
for(var i = 0, len = gdjs.SubmitScoreCode.GDMainMenu_95TextObjects2.length ;i < len;++i) {
    gdjs.SubmitScoreCode.GDMainMenu_95TextObjects2[i].setColor("241;91;181");
}
for(var i = 0, len = gdjs.SubmitScoreCode.GDResetProgress_95TextObjects2.length ;i < len;++i) {
    gdjs.SubmitScoreCode.GDResetProgress_95TextObjects2[i].setColor("241;91;181");
}
for(var i = 0, len = gdjs.SubmitScoreCode.GDStartOver_95TextObjects2.length ;i < len;++i) {
    gdjs.SubmitScoreCode.GDStartOver_95TextObjects2[i].setColor("241;91;181");
}
for(var i = 0, len = gdjs.SubmitScoreCode.GDSubmit_95TextObjects2.length ;i < len;++i) {
    gdjs.SubmitScoreCode.GDSubmit_95TextObjects2[i].setColor("241;91;181");
}
}}

}


};gdjs.SubmitScoreCode.eventsList3 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("GreyButton"), gdjs.SubmitScoreCode.GDGreyButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Leaderboard"), gdjs.SubmitScoreCode.GDLeaderboardObjects2);
gdjs.copyArray(runtimeScene.getObjects("Menu"), gdjs.SubmitScoreCode.GDMenuObjects2);

gdjs.SubmitScoreCode.condition0IsTrue_0.val = false;
gdjs.SubmitScoreCode.condition1IsTrue_0.val = false;
{
gdjs.SubmitScoreCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.SubmitScoreCode.mapOfGDgdjs_46SubmitScoreCode_46GDGreyButtonObjects2ObjectsGDgdjs_46SubmitScoreCode_46GDLeaderboardObjects2ObjectsGDgdjs_46SubmitScoreCode_46GDMenuObjects2Objects, runtimeScene, true, false);
}if ( gdjs.SubmitScoreCode.condition0IsTrue_0.val ) {
{
{gdjs.SubmitScoreCode.conditionTrue_1 = gdjs.SubmitScoreCode.condition1IsTrue_0;
gdjs.SubmitScoreCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11702508);
}
}}
if (gdjs.SubmitScoreCode.condition1IsTrue_0.val) {
/* Reuse gdjs.SubmitScoreCode.GDGreyButtonObjects2 */
/* Reuse gdjs.SubmitScoreCode.GDLeaderboardObjects2 */
/* Reuse gdjs.SubmitScoreCode.GDMenuObjects2 */
{for(var i = 0, len = gdjs.SubmitScoreCode.GDGreyButtonObjects2.length ;i < len;++i) {
    gdjs.SubmitScoreCode.GDGreyButtonObjects2[i].enableEffect("Effect", true);
}
for(var i = 0, len = gdjs.SubmitScoreCode.GDLeaderboardObjects2.length ;i < len;++i) {
    gdjs.SubmitScoreCode.GDLeaderboardObjects2[i].enableEffect("Effect", true);
}
for(var i = 0, len = gdjs.SubmitScoreCode.GDMenuObjects2.length ;i < len;++i) {
    gdjs.SubmitScoreCode.GDMenuObjects2[i].enableEffect("Effect", true);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\audio - BLLTImpt Hit Marker 07.aac", false, 15, 4);
}
{ //Subevents
gdjs.SubmitScoreCode.eventsList2(runtimeScene);} //End of subevents
}

}


};gdjs.SubmitScoreCode.mapOfGDgdjs_46SubmitScoreCode_46GDGreyButtonObjects2ObjectsGDgdjs_46SubmitScoreCode_46GDLeaderboardObjects2ObjectsGDgdjs_46SubmitScoreCode_46GDMenuObjects2Objects = Hashtable.newFrom({"GreyButton": gdjs.SubmitScoreCode.GDGreyButtonObjects2, "Leaderboard": gdjs.SubmitScoreCode.GDLeaderboardObjects2, "Menu": gdjs.SubmitScoreCode.GDMenuObjects2});
gdjs.SubmitScoreCode.eventsList4 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("GreyButton"), gdjs.SubmitScoreCode.GDGreyButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Leaderboard"), gdjs.SubmitScoreCode.GDLeaderboardObjects2);
gdjs.copyArray(runtimeScene.getObjects("Menu"), gdjs.SubmitScoreCode.GDMenuObjects2);

gdjs.SubmitScoreCode.condition0IsTrue_0.val = false;
{
gdjs.SubmitScoreCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.SubmitScoreCode.mapOfGDgdjs_46SubmitScoreCode_46GDGreyButtonObjects2ObjectsGDgdjs_46SubmitScoreCode_46GDLeaderboardObjects2ObjectsGDgdjs_46SubmitScoreCode_46GDMenuObjects2Objects, runtimeScene, true, false);
}if (gdjs.SubmitScoreCode.condition0IsTrue_0.val) {
/* Reuse gdjs.SubmitScoreCode.GDGreyButtonObjects2 */
/* Reuse gdjs.SubmitScoreCode.GDLeaderboardObjects2 */
/* Reuse gdjs.SubmitScoreCode.GDMenuObjects2 */
{for(var i = 0, len = gdjs.SubmitScoreCode.GDGreyButtonObjects2.length ;i < len;++i) {
    gdjs.SubmitScoreCode.GDGreyButtonObjects2[i].setColor("74;74;74");
}
for(var i = 0, len = gdjs.SubmitScoreCode.GDLeaderboardObjects2.length ;i < len;++i) {
    gdjs.SubmitScoreCode.GDLeaderboardObjects2[i].setColor("74;74;74");
}
for(var i = 0, len = gdjs.SubmitScoreCode.GDMenuObjects2.length ;i < len;++i) {
    gdjs.SubmitScoreCode.GDMenuObjects2[i].setColor("74;74;74");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\audio - BLLTImpt Hit Marker 07.aac", false, 40, 2);
}}

}


};gdjs.SubmitScoreCode.mapOfGDgdjs_46SubmitScoreCode_46GDGreyButtonObjects1ObjectsGDgdjs_46SubmitScoreCode_46GDLeaderboardObjects1ObjectsGDgdjs_46SubmitScoreCode_46GDMenuObjects1Objects = Hashtable.newFrom({"GreyButton": gdjs.SubmitScoreCode.GDGreyButtonObjects1, "Leaderboard": gdjs.SubmitScoreCode.GDLeaderboardObjects1, "Menu": gdjs.SubmitScoreCode.GDMenuObjects1});
gdjs.SubmitScoreCode.eventsList5 = function(runtimeScene) {

{


gdjs.SubmitScoreCode.condition0IsTrue_0.val = false;
gdjs.SubmitScoreCode.condition1IsTrue_0.val = false;
{
gdjs.SubmitScoreCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.SubmitScoreCode.condition0IsTrue_0.val ) {
{
{gdjs.SubmitScoreCode.conditionTrue_1 = gdjs.SubmitScoreCode.condition1IsTrue_0;
gdjs.SubmitScoreCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11704564);
}
}}
if (gdjs.SubmitScoreCode.condition1IsTrue_0.val) {

{ //Subevents
gdjs.SubmitScoreCode.eventsList4(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("GreyButton"), gdjs.SubmitScoreCode.GDGreyButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("Leaderboard"), gdjs.SubmitScoreCode.GDLeaderboardObjects1);
gdjs.copyArray(runtimeScene.getObjects("Menu"), gdjs.SubmitScoreCode.GDMenuObjects1);

gdjs.SubmitScoreCode.condition0IsTrue_0.val = false;
gdjs.SubmitScoreCode.condition1IsTrue_0.val = false;
{
gdjs.SubmitScoreCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.SubmitScoreCode.condition0IsTrue_0.val ) {
{
gdjs.SubmitScoreCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.SubmitScoreCode.mapOfGDgdjs_46SubmitScoreCode_46GDGreyButtonObjects1ObjectsGDgdjs_46SubmitScoreCode_46GDLeaderboardObjects1ObjectsGDgdjs_46SubmitScoreCode_46GDMenuObjects1Objects, runtimeScene, true, false);
}}
if (gdjs.SubmitScoreCode.condition1IsTrue_0.val) {
/* Reuse gdjs.SubmitScoreCode.GDGreyButtonObjects1 */
/* Reuse gdjs.SubmitScoreCode.GDLeaderboardObjects1 */
/* Reuse gdjs.SubmitScoreCode.GDMenuObjects1 */
{for(var i = 0, len = gdjs.SubmitScoreCode.GDGreyButtonObjects1.length ;i < len;++i) {
    gdjs.SubmitScoreCode.GDGreyButtonObjects1[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.SubmitScoreCode.GDLeaderboardObjects1.length ;i < len;++i) {
    gdjs.SubmitScoreCode.GDLeaderboardObjects1[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.SubmitScoreCode.GDMenuObjects1.length ;i < len;++i) {
    gdjs.SubmitScoreCode.GDMenuObjects1[i].setColor("255;255;255");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\audio - BLLTImpt Hit Marker 07.aac", false, 40, 3);
}}

}


};gdjs.SubmitScoreCode.eventsList6 = function(runtimeScene) {

{


gdjs.SubmitScoreCode.eventsList1(runtimeScene);
}


{


gdjs.SubmitScoreCode.eventsList3(runtimeScene);
}


{


gdjs.SubmitScoreCode.eventsList5(runtimeScene);
}


};gdjs.SubmitScoreCode.eventsList7 = function(runtimeScene) {

{


{
{gdjs.evtTools.storage.readNumberFromJSONFile("BallCupBoom", "PlayTimer", runtimeScene, runtimeScene.getVariables().get("PlayTimer"));
}{gdjs.evtTools.storage.readNumberFromJSONFile("BallCupBoom", "MovesMade", runtimeScene, runtimeScene.getVariables().get("MovesMade"));
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("MovesValue_Text"), gdjs.SubmitScoreCode.GDMovesValue_95TextObjects2);
gdjs.copyArray(runtimeScene.getObjects("TimeValue_Text"), gdjs.SubmitScoreCode.GDTimeValue_95TextObjects2);
{for(var i = 0, len = gdjs.SubmitScoreCode.GDTimeValue_95TextObjects2.length ;i < len;++i) {
    gdjs.SubmitScoreCode.GDTimeValue_95TextObjects2[i].setString(gdjs.evtsExt__ExtendedMath__ToFixedString.func(runtimeScene, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("PlayTimer")) + gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSeconds(runtimeScene, "PlayTimer"), 1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) + " seconds");
}
}{for(var i = 0, len = gdjs.SubmitScoreCode.GDMovesValue_95TextObjects2.length ;i < len;++i) {
    gdjs.SubmitScoreCode.GDMovesValue_95TextObjects2[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MovesMade"))));
}
}}

}


{


{
{runtimeScene.getVariables().get("MaxBalls").setNumber(100);
}{runtimeScene.getVariables().get("BallsCreatedPerFrame").setNumber(1);
}}

}


};gdjs.SubmitScoreCode.eventsList8 = function(runtimeScene) {

{


gdjs.SubmitScoreCode.condition0IsTrue_0.val = false;
{
gdjs.SubmitScoreCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.SubmitScoreCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("SubmitScore_Text"), gdjs.SubmitScoreCode.GDSubmitScore_95TextObjects1);
{for(var i = 0, len = gdjs.SubmitScoreCode.GDSubmitScore_95TextObjects1.length ;i < len;++i) {
    gdjs.SubmitScoreCode.GDSubmitScore_95TextObjects1[i].setTextAlignment("center");
}
}
{ //Subevents
gdjs.SubmitScoreCode.eventsList7(runtimeScene);} //End of subevents
}

}


};gdjs.SubmitScoreCode.mapOfGDgdjs_46SubmitScoreCode_46GDGreyButtonObjects1Objects = Hashtable.newFrom({"GreyButton": gdjs.SubmitScoreCode.GDGreyButtonObjects1});
gdjs.SubmitScoreCode.mapOfGDgdjs_46SubmitScoreCode_46GDSubmit_9595TextObjects1Objects = Hashtable.newFrom({"Submit_Text": gdjs.SubmitScoreCode.GDSubmit_95TextObjects1});
gdjs.SubmitScoreCode.mapOfGDgdjs_46SubmitScoreCode_46GDGreyButtonObjects1Objects = Hashtable.newFrom({"GreyButton": gdjs.SubmitScoreCode.GDGreyButtonObjects1});
gdjs.SubmitScoreCode.eventsList9 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("GreyButton"), gdjs.SubmitScoreCode.GDGreyButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("Submit_Text"), gdjs.SubmitScoreCode.GDSubmit_95TextObjects1);

gdjs.SubmitScoreCode.condition0IsTrue_0.val = false;
gdjs.SubmitScoreCode.condition1IsTrue_0.val = false;
gdjs.SubmitScoreCode.condition2IsTrue_0.val = false;
gdjs.SubmitScoreCode.condition3IsTrue_0.val = false;
{
gdjs.SubmitScoreCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.SubmitScoreCode.condition0IsTrue_0.val ) {
{
gdjs.SubmitScoreCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getVariables().get("ScoreSubmitted"), false);
}if ( gdjs.SubmitScoreCode.condition1IsTrue_0.val ) {
{
gdjs.SubmitScoreCode.condition2IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.SubmitScoreCode.mapOfGDgdjs_46SubmitScoreCode_46GDGreyButtonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.SubmitScoreCode.condition2IsTrue_0.val ) {
{
gdjs.SubmitScoreCode.condition3IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.SubmitScoreCode.mapOfGDgdjs_46SubmitScoreCode_46GDSubmit_9595TextObjects1Objects, gdjs.SubmitScoreCode.mapOfGDgdjs_46SubmitScoreCode_46GDGreyButtonObjects1Objects, false, runtimeScene, false);
}}
}
}
if (gdjs.SubmitScoreCode.condition3IsTrue_0.val) {
/* Reuse gdjs.SubmitScoreCode.GDGreyButtonObjects1 */
gdjs.copyArray(runtimeScene.getObjects("PlayerName_Input"), gdjs.SubmitScoreCode.GDPlayerName_95InputObjects1);
/* Reuse gdjs.SubmitScoreCode.GDSubmit_95TextObjects1 */
{gdjs.evtTools.leaderboards.savePlayerScore(runtimeScene, "eced0c01-aecc-4839-bc86-73cd218ddfc2", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("PlayTimer")), (( gdjs.SubmitScoreCode.GDPlayerName_95InputObjects1.length === 0 ) ? "" :gdjs.SubmitScoreCode.GDPlayerName_95InputObjects1[0].getString()));
}{gdjs.evtTools.leaderboards.savePlayerScore(runtimeScene, "77688ec1-5415-49c3-90cd-6e3d51bc9b44", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MovesMade")), (( gdjs.SubmitScoreCode.GDPlayerName_95InputObjects1.length === 0 ) ? "" :gdjs.SubmitScoreCode.GDPlayerName_95InputObjects1[0].getString()));
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().get("ScoreSubmitted"), true);
}{for(var i = 0, len = gdjs.SubmitScoreCode.GDPlayerName_95InputObjects1.length ;i < len;++i) {
    gdjs.SubmitScoreCode.GDPlayerName_95InputObjects1[i].setDisabled(true);
}
}{for(var i = 0, len = gdjs.SubmitScoreCode.GDSubmit_95TextObjects1.length ;i < len;++i) {
    gdjs.SubmitScoreCode.GDSubmit_95TextObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.SubmitScoreCode.GDGreyButtonObjects1.length ;i < len;++i) {
    gdjs.SubmitScoreCode.GDGreyButtonObjects1[i].hide();
}
}}

}


};gdjs.SubmitScoreCode.asyncCallback11542636 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Title Screen", false);
}}
gdjs.SubmitScoreCode.eventsList10 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.25), (runtimeScene) => (gdjs.SubmitScoreCode.asyncCallback11542636(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.SubmitScoreCode.eventsList11 = function(runtimeScene) {

{


gdjs.SubmitScoreCode.condition0IsTrue_0.val = false;
{
{gdjs.SubmitScoreCode.conditionTrue_1 = gdjs.SubmitScoreCode.condition0IsTrue_0;
gdjs.SubmitScoreCode.condition0IsTrue_1.val = false;
gdjs.SubmitScoreCode.condition1IsTrue_1.val = false;
{
gdjs.SubmitScoreCode.condition0IsTrue_1.val = gdjs.evtTools.leaderboards.hasSavingErrored("eced0c01-aecc-4839-bc86-73cd218ddfc2");
if( gdjs.SubmitScoreCode.condition0IsTrue_1.val ) {
    gdjs.SubmitScoreCode.conditionTrue_1.val = true;
}
}
{
gdjs.SubmitScoreCode.condition1IsTrue_1.val = gdjs.evtTools.leaderboards.hasSavingErrored("77688ec1-5415-49c3-90cd-6e3d51bc9b44");
if( gdjs.SubmitScoreCode.condition1IsTrue_1.val ) {
    gdjs.SubmitScoreCode.conditionTrue_1.val = true;
}
}
{
}
}
}if (gdjs.SubmitScoreCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("GreyButton"), gdjs.SubmitScoreCode.GDGreyButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("PlayerName_Input"), gdjs.SubmitScoreCode.GDPlayerName_95InputObjects2);
gdjs.copyArray(runtimeScene.getObjects("Submit_Text"), gdjs.SubmitScoreCode.GDSubmit_95TextObjects2);
{for(var i = 0, len = gdjs.SubmitScoreCode.GDGreyButtonObjects2.length ;i < len;++i) {
    gdjs.SubmitScoreCode.GDGreyButtonObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.SubmitScoreCode.GDSubmit_95TextObjects2.length ;i < len;++i) {
    gdjs.SubmitScoreCode.GDSubmit_95TextObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.SubmitScoreCode.GDPlayerName_95InputObjects2.length ;i < len;++i) {
    gdjs.SubmitScoreCode.GDPlayerName_95InputObjects2[i].setDisabled(false);
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().get("ScoreSubmitted"), false);
}}

}


{


gdjs.SubmitScoreCode.condition0IsTrue_0.val = false;
gdjs.SubmitScoreCode.condition1IsTrue_0.val = false;
{
gdjs.SubmitScoreCode.condition0IsTrue_0.val = gdjs.evtTools.leaderboards.hasBeenSaved("eced0c01-aecc-4839-bc86-73cd218ddfc2");
}if ( gdjs.SubmitScoreCode.condition0IsTrue_0.val ) {
{
gdjs.SubmitScoreCode.condition1IsTrue_0.val = gdjs.evtTools.leaderboards.hasBeenSaved("77688ec1-5415-49c3-90cd-6e3d51bc9b44");
}}
if (gdjs.SubmitScoreCode.condition1IsTrue_0.val) {

{ //Subevents
gdjs.SubmitScoreCode.eventsList10(runtimeScene);} //End of subevents
}

}


};gdjs.SubmitScoreCode.eventsList12 = function(runtimeScene) {

{


gdjs.SubmitScoreCode.condition0IsTrue_0.val = false;
{
{gdjs.SubmitScoreCode.conditionTrue_1 = gdjs.SubmitScoreCode.condition0IsTrue_0;
gdjs.SubmitScoreCode.condition0IsTrue_1.val = false;
gdjs.SubmitScoreCode.condition1IsTrue_1.val = false;
{
gdjs.SubmitScoreCode.condition0IsTrue_1.val = !(gdjs.evtTools.leaderboards.isSaving("eced0c01-aecc-4839-bc86-73cd218ddfc2"));
if( gdjs.SubmitScoreCode.condition0IsTrue_1.val ) {
    gdjs.SubmitScoreCode.conditionTrue_1.val = true;
}
}
{
gdjs.SubmitScoreCode.condition1IsTrue_1.val = !(gdjs.evtTools.leaderboards.isSaving("77688ec1-5415-49c3-90cd-6e3d51bc9b44"));
if( gdjs.SubmitScoreCode.condition1IsTrue_1.val ) {
    gdjs.SubmitScoreCode.conditionTrue_1.val = true;
}
}
{
}
}
}if (gdjs.SubmitScoreCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.SubmitScoreCode.eventsList11(runtimeScene);} //End of subevents
}

}


};gdjs.SubmitScoreCode.eventsList13 = function(runtimeScene) {

{


gdjs.SubmitScoreCode.condition0IsTrue_0.val = false;
{
gdjs.SubmitScoreCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getVariables().get("ScoreSubmitted"), true);
}if (gdjs.SubmitScoreCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.SubmitScoreCode.eventsList12(runtimeScene);} //End of subevents
}

}


};gdjs.SubmitScoreCode.mapOfGDgdjs_46SubmitScoreCode_46GDGreyButtonObjects1Objects = Hashtable.newFrom({"GreyButton": gdjs.SubmitScoreCode.GDGreyButtonObjects1});
gdjs.SubmitScoreCode.mapOfGDgdjs_46SubmitScoreCode_46GDMainMenu_9595TextObjects1Objects = Hashtable.newFrom({"MainMenu_Text": gdjs.SubmitScoreCode.GDMainMenu_95TextObjects1});
gdjs.SubmitScoreCode.mapOfGDgdjs_46SubmitScoreCode_46GDGreyButtonObjects1Objects = Hashtable.newFrom({"GreyButton": gdjs.SubmitScoreCode.GDGreyButtonObjects1});
gdjs.SubmitScoreCode.asyncCallback11543788 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Title Screen", false);
}}
gdjs.SubmitScoreCode.eventsList14 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.25), (runtimeScene) => (gdjs.SubmitScoreCode.asyncCallback11543788(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.SubmitScoreCode.eventsList15 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("GreyButton"), gdjs.SubmitScoreCode.GDGreyButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("MainMenu_Text"), gdjs.SubmitScoreCode.GDMainMenu_95TextObjects1);

gdjs.SubmitScoreCode.condition0IsTrue_0.val = false;
gdjs.SubmitScoreCode.condition1IsTrue_0.val = false;
gdjs.SubmitScoreCode.condition2IsTrue_0.val = false;
{
gdjs.SubmitScoreCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.SubmitScoreCode.condition0IsTrue_0.val ) {
{
gdjs.SubmitScoreCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.SubmitScoreCode.mapOfGDgdjs_46SubmitScoreCode_46GDGreyButtonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.SubmitScoreCode.condition1IsTrue_0.val ) {
{
gdjs.SubmitScoreCode.condition2IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.SubmitScoreCode.mapOfGDgdjs_46SubmitScoreCode_46GDMainMenu_9595TextObjects1Objects, gdjs.SubmitScoreCode.mapOfGDgdjs_46SubmitScoreCode_46GDGreyButtonObjects1Objects, false, runtimeScene, false);
}}
}
if (gdjs.SubmitScoreCode.condition2IsTrue_0.val) {

{ //Subevents
gdjs.SubmitScoreCode.eventsList14(runtimeScene);} //End of subevents
}

}


};gdjs.SubmitScoreCode.mapOfEmptyGDBall_951ObjectsEmptyGDBall_952ObjectsEmptyGDBall_954ObjectsEmptyGDBall_953ObjectsEmptyGDBall_955ObjectsEmptyGDBall_956Objects = Hashtable.newFrom({"Ball_1": [], "Ball_2": [], "Ball_4": [], "Ball_3": [], "Ball_5": [], "Ball_6": []});
gdjs.SubmitScoreCode.mapOfGDgdjs_46SubmitScoreCode_46GDBall_95951Objects4ObjectsGDgdjs_46SubmitScoreCode_46GDBall_95952Objects4ObjectsGDgdjs_46SubmitScoreCode_46GDBall_95954Objects4ObjectsGDgdjs_46SubmitScoreCode_46GDBall_95953Objects4ObjectsGDgdjs_46SubmitScoreCode_46GDBall_95955Objects4ObjectsGDgdjs_46SubmitScoreCode_46GDBall_95956Objects4Objects = Hashtable.newFrom({"Ball_1": gdjs.SubmitScoreCode.GDBall_951Objects4, "Ball_2": gdjs.SubmitScoreCode.GDBall_952Objects4, "Ball_4": gdjs.SubmitScoreCode.GDBall_954Objects4, "Ball_3": gdjs.SubmitScoreCode.GDBall_953Objects4, "Ball_5": gdjs.SubmitScoreCode.GDBall_955Objects4, "Ball_6": gdjs.SubmitScoreCode.GDBall_956Objects4});
gdjs.SubmitScoreCode.eventsList16 = function(runtimeScene) {

{


{
gdjs.SubmitScoreCode.GDBall_951Objects4.length = 0;

gdjs.SubmitScoreCode.GDBall_952Objects4.length = 0;

gdjs.SubmitScoreCode.GDBall_953Objects4.length = 0;

gdjs.SubmitScoreCode.GDBall_954Objects4.length = 0;

gdjs.SubmitScoreCode.GDBall_955Objects4.length = 0;

gdjs.SubmitScoreCode.GDBall_956Objects4.length = 0;

{gdjs.evtTools.object.createObjectFromGroupOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.SubmitScoreCode.mapOfGDgdjs_46SubmitScoreCode_46GDBall_95951Objects4ObjectsGDgdjs_46SubmitScoreCode_46GDBall_95952Objects4ObjectsGDgdjs_46SubmitScoreCode_46GDBall_95954Objects4ObjectsGDgdjs_46SubmitScoreCode_46GDBall_95953Objects4ObjectsGDgdjs_46SubmitScoreCode_46GDBall_95955Objects4ObjectsGDgdjs_46SubmitScoreCode_46GDBall_95956Objects4Objects, "Ball_" + gdjs.evtTools.common.toString(gdjs.randomInRange(1, 6)), gdjs.randomInRange(gdjs.evtTools.camera.getCameraBorderLeft(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraBorderRight(runtimeScene, "", 0)), gdjs.evtTools.camera.getCameraBorderBottom(runtimeScene, "", 0) - 32, "Balls");
}{for(var i = 0, len = gdjs.SubmitScoreCode.GDBall_951Objects4.length ;i < len;++i) {
    gdjs.SubmitScoreCode.GDBall_951Objects4[i].addPolarForce(270, 800, 1);
}
for(var i = 0, len = gdjs.SubmitScoreCode.GDBall_952Objects4.length ;i < len;++i) {
    gdjs.SubmitScoreCode.GDBall_952Objects4[i].addPolarForce(270, 800, 1);
}
for(var i = 0, len = gdjs.SubmitScoreCode.GDBall_954Objects4.length ;i < len;++i) {
    gdjs.SubmitScoreCode.GDBall_954Objects4[i].addPolarForce(270, 800, 1);
}
for(var i = 0, len = gdjs.SubmitScoreCode.GDBall_953Objects4.length ;i < len;++i) {
    gdjs.SubmitScoreCode.GDBall_953Objects4[i].addPolarForce(270, 800, 1);
}
for(var i = 0, len = gdjs.SubmitScoreCode.GDBall_955Objects4.length ;i < len;++i) {
    gdjs.SubmitScoreCode.GDBall_955Objects4[i].addPolarForce(270, 800, 1);
}
for(var i = 0, len = gdjs.SubmitScoreCode.GDBall_956Objects4.length ;i < len;++i) {
    gdjs.SubmitScoreCode.GDBall_956Objects4[i].addPolarForce(270, 800, 1);
}
}}

}


};gdjs.SubmitScoreCode.eventsList17 = function(runtimeScene) {

{


gdjs.SubmitScoreCode.repeatCount3 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("BallsCreatedPerFrame"));
for(gdjs.SubmitScoreCode.repeatIndex3 = 0;gdjs.SubmitScoreCode.repeatIndex3 < gdjs.SubmitScoreCode.repeatCount3;++gdjs.SubmitScoreCode.repeatIndex3) {

if (true)
{

{ //Subevents: 
gdjs.SubmitScoreCode.eventsList16(runtimeScene);} //Subevents end.
}
}

}


};gdjs.SubmitScoreCode.eventsList18 = function(runtimeScene) {

{


gdjs.SubmitScoreCode.condition0IsTrue_0.val = false;
{
gdjs.SubmitScoreCode.condition0IsTrue_0.val = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.SubmitScoreCode.mapOfEmptyGDBall_951ObjectsEmptyGDBall_952ObjectsEmptyGDBall_954ObjectsEmptyGDBall_953ObjectsEmptyGDBall_955ObjectsEmptyGDBall_956Objects) < gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MaxBalls"));
}if (gdjs.SubmitScoreCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.SubmitScoreCode.eventsList17(runtimeScene);} //End of subevents
}

}


};gdjs.SubmitScoreCode.eventsList19 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("Ball_1"), gdjs.SubmitScoreCode.GDBall_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Ball_2"), gdjs.SubmitScoreCode.GDBall_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Ball_3"), gdjs.SubmitScoreCode.GDBall_953Objects2);
gdjs.copyArray(runtimeScene.getObjects("Ball_4"), gdjs.SubmitScoreCode.GDBall_954Objects2);
gdjs.copyArray(runtimeScene.getObjects("Ball_5"), gdjs.SubmitScoreCode.GDBall_955Objects2);
gdjs.copyArray(runtimeScene.getObjects("Ball_6"), gdjs.SubmitScoreCode.GDBall_956Objects2);
{for(var i = 0, len = gdjs.SubmitScoreCode.GDBall_951Objects2.length ;i < len;++i) {
    gdjs.SubmitScoreCode.GDBall_951Objects2[i].addPolarForce(90, 10, 1);
}
for(var i = 0, len = gdjs.SubmitScoreCode.GDBall_952Objects2.length ;i < len;++i) {
    gdjs.SubmitScoreCode.GDBall_952Objects2[i].addPolarForce(90, 10, 1);
}
for(var i = 0, len = gdjs.SubmitScoreCode.GDBall_954Objects2.length ;i < len;++i) {
    gdjs.SubmitScoreCode.GDBall_954Objects2[i].addPolarForce(90, 10, 1);
}
for(var i = 0, len = gdjs.SubmitScoreCode.GDBall_953Objects2.length ;i < len;++i) {
    gdjs.SubmitScoreCode.GDBall_953Objects2[i].addPolarForce(90, 10, 1);
}
for(var i = 0, len = gdjs.SubmitScoreCode.GDBall_955Objects2.length ;i < len;++i) {
    gdjs.SubmitScoreCode.GDBall_955Objects2[i].addPolarForce(90, 10, 1);
}
for(var i = 0, len = gdjs.SubmitScoreCode.GDBall_956Objects2.length ;i < len;++i) {
    gdjs.SubmitScoreCode.GDBall_956Objects2[i].addPolarForce(90, 10, 1);
}
}}

}


};gdjs.SubmitScoreCode.eventsList20 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Ball_1"), gdjs.SubmitScoreCode.GDBall_951Objects1);
gdjs.copyArray(runtimeScene.getObjects("Ball_2"), gdjs.SubmitScoreCode.GDBall_952Objects1);
gdjs.copyArray(runtimeScene.getObjects("Ball_3"), gdjs.SubmitScoreCode.GDBall_953Objects1);
gdjs.copyArray(runtimeScene.getObjects("Ball_4"), gdjs.SubmitScoreCode.GDBall_954Objects1);
gdjs.copyArray(runtimeScene.getObjects("Ball_5"), gdjs.SubmitScoreCode.GDBall_955Objects1);
gdjs.copyArray(runtimeScene.getObjects("Ball_6"), gdjs.SubmitScoreCode.GDBall_956Objects1);

gdjs.SubmitScoreCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.SubmitScoreCode.GDBall_951Objects1.length;i<l;++i) {
    if ( gdjs.SubmitScoreCode.GDBall_951Objects1[i].getY() > gdjs.evtTools.camera.getCameraBorderBottom(runtimeScene, "", 0) + 64 ) {
        gdjs.SubmitScoreCode.condition0IsTrue_0.val = true;
        gdjs.SubmitScoreCode.GDBall_951Objects1[k] = gdjs.SubmitScoreCode.GDBall_951Objects1[i];
        ++k;
    }
}
gdjs.SubmitScoreCode.GDBall_951Objects1.length = k;for(var i = 0, k = 0, l = gdjs.SubmitScoreCode.GDBall_952Objects1.length;i<l;++i) {
    if ( gdjs.SubmitScoreCode.GDBall_952Objects1[i].getY() > gdjs.evtTools.camera.getCameraBorderBottom(runtimeScene, "", 0) + 64 ) {
        gdjs.SubmitScoreCode.condition0IsTrue_0.val = true;
        gdjs.SubmitScoreCode.GDBall_952Objects1[k] = gdjs.SubmitScoreCode.GDBall_952Objects1[i];
        ++k;
    }
}
gdjs.SubmitScoreCode.GDBall_952Objects1.length = k;for(var i = 0, k = 0, l = gdjs.SubmitScoreCode.GDBall_954Objects1.length;i<l;++i) {
    if ( gdjs.SubmitScoreCode.GDBall_954Objects1[i].getY() > gdjs.evtTools.camera.getCameraBorderBottom(runtimeScene, "", 0) + 64 ) {
        gdjs.SubmitScoreCode.condition0IsTrue_0.val = true;
        gdjs.SubmitScoreCode.GDBall_954Objects1[k] = gdjs.SubmitScoreCode.GDBall_954Objects1[i];
        ++k;
    }
}
gdjs.SubmitScoreCode.GDBall_954Objects1.length = k;for(var i = 0, k = 0, l = gdjs.SubmitScoreCode.GDBall_953Objects1.length;i<l;++i) {
    if ( gdjs.SubmitScoreCode.GDBall_953Objects1[i].getY() > gdjs.evtTools.camera.getCameraBorderBottom(runtimeScene, "", 0) + 64 ) {
        gdjs.SubmitScoreCode.condition0IsTrue_0.val = true;
        gdjs.SubmitScoreCode.GDBall_953Objects1[k] = gdjs.SubmitScoreCode.GDBall_953Objects1[i];
        ++k;
    }
}
gdjs.SubmitScoreCode.GDBall_953Objects1.length = k;for(var i = 0, k = 0, l = gdjs.SubmitScoreCode.GDBall_955Objects1.length;i<l;++i) {
    if ( gdjs.SubmitScoreCode.GDBall_955Objects1[i].getY() > gdjs.evtTools.camera.getCameraBorderBottom(runtimeScene, "", 0) + 64 ) {
        gdjs.SubmitScoreCode.condition0IsTrue_0.val = true;
        gdjs.SubmitScoreCode.GDBall_955Objects1[k] = gdjs.SubmitScoreCode.GDBall_955Objects1[i];
        ++k;
    }
}
gdjs.SubmitScoreCode.GDBall_955Objects1.length = k;for(var i = 0, k = 0, l = gdjs.SubmitScoreCode.GDBall_956Objects1.length;i<l;++i) {
    if ( gdjs.SubmitScoreCode.GDBall_956Objects1[i].getY() > gdjs.evtTools.camera.getCameraBorderBottom(runtimeScene, "", 0) + 64 ) {
        gdjs.SubmitScoreCode.condition0IsTrue_0.val = true;
        gdjs.SubmitScoreCode.GDBall_956Objects1[k] = gdjs.SubmitScoreCode.GDBall_956Objects1[i];
        ++k;
    }
}
gdjs.SubmitScoreCode.GDBall_956Objects1.length = k;}if (gdjs.SubmitScoreCode.condition0IsTrue_0.val) {
/* Reuse gdjs.SubmitScoreCode.GDBall_951Objects1 */
/* Reuse gdjs.SubmitScoreCode.GDBall_952Objects1 */
/* Reuse gdjs.SubmitScoreCode.GDBall_953Objects1 */
/* Reuse gdjs.SubmitScoreCode.GDBall_954Objects1 */
/* Reuse gdjs.SubmitScoreCode.GDBall_955Objects1 */
/* Reuse gdjs.SubmitScoreCode.GDBall_956Objects1 */
{for(var i = 0, len = gdjs.SubmitScoreCode.GDBall_951Objects1.length ;i < len;++i) {
    gdjs.SubmitScoreCode.GDBall_951Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.SubmitScoreCode.GDBall_952Objects1.length ;i < len;++i) {
    gdjs.SubmitScoreCode.GDBall_952Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.SubmitScoreCode.GDBall_954Objects1.length ;i < len;++i) {
    gdjs.SubmitScoreCode.GDBall_954Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.SubmitScoreCode.GDBall_953Objects1.length ;i < len;++i) {
    gdjs.SubmitScoreCode.GDBall_953Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.SubmitScoreCode.GDBall_955Objects1.length ;i < len;++i) {
    gdjs.SubmitScoreCode.GDBall_955Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.SubmitScoreCode.GDBall_956Objects1.length ;i < len;++i) {
    gdjs.SubmitScoreCode.GDBall_956Objects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.SubmitScoreCode.eventsList21 = function(runtimeScene) {

{


gdjs.SubmitScoreCode.eventsList18(runtimeScene);
}


{


gdjs.SubmitScoreCode.eventsList19(runtimeScene);
}


{


gdjs.SubmitScoreCode.eventsList20(runtimeScene);
}


};gdjs.SubmitScoreCode.eventsList22 = function(runtimeScene) {

{



}


{


gdjs.SubmitScoreCode.eventsList6(runtimeScene);
}


{


gdjs.SubmitScoreCode.eventsList8(runtimeScene);
}


{


gdjs.SubmitScoreCode.eventsList9(runtimeScene);
}


{


gdjs.SubmitScoreCode.eventsList13(runtimeScene);
}


{


gdjs.SubmitScoreCode.eventsList15(runtimeScene);
}


{


gdjs.SubmitScoreCode.eventsList21(runtimeScene);
}


};

gdjs.SubmitScoreCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.SubmitScoreCode.GDBall_951Objects1.length = 0;
gdjs.SubmitScoreCode.GDBall_951Objects2.length = 0;
gdjs.SubmitScoreCode.GDBall_951Objects3.length = 0;
gdjs.SubmitScoreCode.GDBall_951Objects4.length = 0;
gdjs.SubmitScoreCode.GDBall_951Objects5.length = 0;
gdjs.SubmitScoreCode.GDBall_952Objects1.length = 0;
gdjs.SubmitScoreCode.GDBall_952Objects2.length = 0;
gdjs.SubmitScoreCode.GDBall_952Objects3.length = 0;
gdjs.SubmitScoreCode.GDBall_952Objects4.length = 0;
gdjs.SubmitScoreCode.GDBall_952Objects5.length = 0;
gdjs.SubmitScoreCode.GDBall_953Objects1.length = 0;
gdjs.SubmitScoreCode.GDBall_953Objects2.length = 0;
gdjs.SubmitScoreCode.GDBall_953Objects3.length = 0;
gdjs.SubmitScoreCode.GDBall_953Objects4.length = 0;
gdjs.SubmitScoreCode.GDBall_953Objects5.length = 0;
gdjs.SubmitScoreCode.GDBall_954Objects1.length = 0;
gdjs.SubmitScoreCode.GDBall_954Objects2.length = 0;
gdjs.SubmitScoreCode.GDBall_954Objects3.length = 0;
gdjs.SubmitScoreCode.GDBall_954Objects4.length = 0;
gdjs.SubmitScoreCode.GDBall_954Objects5.length = 0;
gdjs.SubmitScoreCode.GDBall_955Objects1.length = 0;
gdjs.SubmitScoreCode.GDBall_955Objects2.length = 0;
gdjs.SubmitScoreCode.GDBall_955Objects3.length = 0;
gdjs.SubmitScoreCode.GDBall_955Objects4.length = 0;
gdjs.SubmitScoreCode.GDBall_955Objects5.length = 0;
gdjs.SubmitScoreCode.GDBall_956Objects1.length = 0;
gdjs.SubmitScoreCode.GDBall_956Objects2.length = 0;
gdjs.SubmitScoreCode.GDBall_956Objects3.length = 0;
gdjs.SubmitScoreCode.GDBall_956Objects4.length = 0;
gdjs.SubmitScoreCode.GDBall_956Objects5.length = 0;
gdjs.SubmitScoreCode.GDGlassBreaking_95ParticlesObjects1.length = 0;
gdjs.SubmitScoreCode.GDGlassBreaking_95ParticlesObjects2.length = 0;
gdjs.SubmitScoreCode.GDGlassBreaking_95ParticlesObjects3.length = 0;
gdjs.SubmitScoreCode.GDGlassBreaking_95ParticlesObjects4.length = 0;
gdjs.SubmitScoreCode.GDGlassBreaking_95ParticlesObjects5.length = 0;
gdjs.SubmitScoreCode.GDCupObjects1.length = 0;
gdjs.SubmitScoreCode.GDCupObjects2.length = 0;
gdjs.SubmitScoreCode.GDCupObjects3.length = 0;
gdjs.SubmitScoreCode.GDCupObjects4.length = 0;
gdjs.SubmitScoreCode.GDCupObjects5.length = 0;
gdjs.SubmitScoreCode.GDCupFrontObjects1.length = 0;
gdjs.SubmitScoreCode.GDCupFrontObjects2.length = 0;
gdjs.SubmitScoreCode.GDCupFrontObjects3.length = 0;
gdjs.SubmitScoreCode.GDCupFrontObjects4.length = 0;
gdjs.SubmitScoreCode.GDCupFrontObjects5.length = 0;
gdjs.SubmitScoreCode.GDCloud1Objects1.length = 0;
gdjs.SubmitScoreCode.GDCloud1Objects2.length = 0;
gdjs.SubmitScoreCode.GDCloud1Objects3.length = 0;
gdjs.SubmitScoreCode.GDCloud1Objects4.length = 0;
gdjs.SubmitScoreCode.GDCloud1Objects5.length = 0;
gdjs.SubmitScoreCode.GDCloud2Objects1.length = 0;
gdjs.SubmitScoreCode.GDCloud2Objects2.length = 0;
gdjs.SubmitScoreCode.GDCloud2Objects3.length = 0;
gdjs.SubmitScoreCode.GDCloud2Objects4.length = 0;
gdjs.SubmitScoreCode.GDCloud2Objects5.length = 0;
gdjs.SubmitScoreCode.GDCloud3Objects1.length = 0;
gdjs.SubmitScoreCode.GDCloud3Objects2.length = 0;
gdjs.SubmitScoreCode.GDCloud3Objects3.length = 0;
gdjs.SubmitScoreCode.GDCloud3Objects4.length = 0;
gdjs.SubmitScoreCode.GDCloud3Objects5.length = 0;
gdjs.SubmitScoreCode.GDCloud4Objects1.length = 0;
gdjs.SubmitScoreCode.GDCloud4Objects2.length = 0;
gdjs.SubmitScoreCode.GDCloud4Objects3.length = 0;
gdjs.SubmitScoreCode.GDCloud4Objects4.length = 0;
gdjs.SubmitScoreCode.GDCloud4Objects5.length = 0;
gdjs.SubmitScoreCode.GDEditInGDevelop_95TextObjects1.length = 0;
gdjs.SubmitScoreCode.GDEditInGDevelop_95TextObjects2.length = 0;
gdjs.SubmitScoreCode.GDEditInGDevelop_95TextObjects3.length = 0;
gdjs.SubmitScoreCode.GDEditInGDevelop_95TextObjects4.length = 0;
gdjs.SubmitScoreCode.GDEditInGDevelop_95TextObjects5.length = 0;
gdjs.SubmitScoreCode.GDGreyButtonObjects1.length = 0;
gdjs.SubmitScoreCode.GDGreyButtonObjects2.length = 0;
gdjs.SubmitScoreCode.GDGreyButtonObjects3.length = 0;
gdjs.SubmitScoreCode.GDGreyButtonObjects4.length = 0;
gdjs.SubmitScoreCode.GDGreyButtonObjects5.length = 0;
gdjs.SubmitScoreCode.GDCurrentLevel_95TextObjects1.length = 0;
gdjs.SubmitScoreCode.GDCurrentLevel_95TextObjects2.length = 0;
gdjs.SubmitScoreCode.GDCurrentLevel_95TextObjects3.length = 0;
gdjs.SubmitScoreCode.GDCurrentLevel_95TextObjects4.length = 0;
gdjs.SubmitScoreCode.GDCurrentLevel_95TextObjects5.length = 0;
gdjs.SubmitScoreCode.GDMenuObjects1.length = 0;
gdjs.SubmitScoreCode.GDMenuObjects2.length = 0;
gdjs.SubmitScoreCode.GDMenuObjects3.length = 0;
gdjs.SubmitScoreCode.GDMenuObjects4.length = 0;
gdjs.SubmitScoreCode.GDMenuObjects5.length = 0;
gdjs.SubmitScoreCode.GDGameState_95TextObjects1.length = 0;
gdjs.SubmitScoreCode.GDGameState_95TextObjects2.length = 0;
gdjs.SubmitScoreCode.GDGameState_95TextObjects3.length = 0;
gdjs.SubmitScoreCode.GDGameState_95TextObjects4.length = 0;
gdjs.SubmitScoreCode.GDGameState_95TextObjects5.length = 0;
gdjs.SubmitScoreCode.GDMovesMade_95TextObjects1.length = 0;
gdjs.SubmitScoreCode.GDMovesMade_95TextObjects2.length = 0;
gdjs.SubmitScoreCode.GDMovesMade_95TextObjects3.length = 0;
gdjs.SubmitScoreCode.GDMovesMade_95TextObjects4.length = 0;
gdjs.SubmitScoreCode.GDMovesMade_95TextObjects5.length = 0;
gdjs.SubmitScoreCode.GDTimeSpent_95TextObjects1.length = 0;
gdjs.SubmitScoreCode.GDTimeSpent_95TextObjects2.length = 0;
gdjs.SubmitScoreCode.GDTimeSpent_95TextObjects3.length = 0;
gdjs.SubmitScoreCode.GDTimeSpent_95TextObjects4.length = 0;
gdjs.SubmitScoreCode.GDTimeSpent_95TextObjects5.length = 0;
gdjs.SubmitScoreCode.GDBallsInCup_95TextObjects1.length = 0;
gdjs.SubmitScoreCode.GDBallsInCup_95TextObjects2.length = 0;
gdjs.SubmitScoreCode.GDBallsInCup_95TextObjects3.length = 0;
gdjs.SubmitScoreCode.GDBallsInCup_95TextObjects4.length = 0;
gdjs.SubmitScoreCode.GDBallsInCup_95TextObjects5.length = 0;
gdjs.SubmitScoreCode.GDPlay_95TextObjects1.length = 0;
gdjs.SubmitScoreCode.GDPlay_95TextObjects2.length = 0;
gdjs.SubmitScoreCode.GDPlay_95TextObjects3.length = 0;
gdjs.SubmitScoreCode.GDPlay_95TextObjects4.length = 0;
gdjs.SubmitScoreCode.GDPlay_95TextObjects5.length = 0;
gdjs.SubmitScoreCode.GDLeaderboardObjects1.length = 0;
gdjs.SubmitScoreCode.GDLeaderboardObjects2.length = 0;
gdjs.SubmitScoreCode.GDLeaderboardObjects3.length = 0;
gdjs.SubmitScoreCode.GDLeaderboardObjects4.length = 0;
gdjs.SubmitScoreCode.GDLeaderboardObjects5.length = 0;
gdjs.SubmitScoreCode.GDMainMenu_95TextObjects1.length = 0;
gdjs.SubmitScoreCode.GDMainMenu_95TextObjects2.length = 0;
gdjs.SubmitScoreCode.GDMainMenu_95TextObjects3.length = 0;
gdjs.SubmitScoreCode.GDMainMenu_95TextObjects4.length = 0;
gdjs.SubmitScoreCode.GDMainMenu_95TextObjects5.length = 0;
gdjs.SubmitScoreCode.GDResetProgress_95TextObjects1.length = 0;
gdjs.SubmitScoreCode.GDResetProgress_95TextObjects2.length = 0;
gdjs.SubmitScoreCode.GDResetProgress_95TextObjects3.length = 0;
gdjs.SubmitScoreCode.GDResetProgress_95TextObjects4.length = 0;
gdjs.SubmitScoreCode.GDResetProgress_95TextObjects5.length = 0;
gdjs.SubmitScoreCode.GDStartOver_95TextObjects1.length = 0;
gdjs.SubmitScoreCode.GDStartOver_95TextObjects2.length = 0;
gdjs.SubmitScoreCode.GDStartOver_95TextObjects3.length = 0;
gdjs.SubmitScoreCode.GDStartOver_95TextObjects4.length = 0;
gdjs.SubmitScoreCode.GDStartOver_95TextObjects5.length = 0;
gdjs.SubmitScoreCode.GDSubmit_95TextObjects1.length = 0;
gdjs.SubmitScoreCode.GDSubmit_95TextObjects2.length = 0;
gdjs.SubmitScoreCode.GDSubmit_95TextObjects3.length = 0;
gdjs.SubmitScoreCode.GDSubmit_95TextObjects4.length = 0;
gdjs.SubmitScoreCode.GDSubmit_95TextObjects5.length = 0;
gdjs.SubmitScoreCode.GDMovesValue_95TextObjects1.length = 0;
gdjs.SubmitScoreCode.GDMovesValue_95TextObjects2.length = 0;
gdjs.SubmitScoreCode.GDMovesValue_95TextObjects3.length = 0;
gdjs.SubmitScoreCode.GDMovesValue_95TextObjects4.length = 0;
gdjs.SubmitScoreCode.GDMovesValue_95TextObjects5.length = 0;
gdjs.SubmitScoreCode.GDTimeValue_95TextObjects1.length = 0;
gdjs.SubmitScoreCode.GDTimeValue_95TextObjects2.length = 0;
gdjs.SubmitScoreCode.GDTimeValue_95TextObjects3.length = 0;
gdjs.SubmitScoreCode.GDTimeValue_95TextObjects4.length = 0;
gdjs.SubmitScoreCode.GDTimeValue_95TextObjects5.length = 0;
gdjs.SubmitScoreCode.GDSubmitScore_95TextObjects1.length = 0;
gdjs.SubmitScoreCode.GDSubmitScore_95TextObjects2.length = 0;
gdjs.SubmitScoreCode.GDSubmitScore_95TextObjects3.length = 0;
gdjs.SubmitScoreCode.GDSubmitScore_95TextObjects4.length = 0;
gdjs.SubmitScoreCode.GDSubmitScore_95TextObjects5.length = 0;
gdjs.SubmitScoreCode.GDPlayerName_95InputObjects1.length = 0;
gdjs.SubmitScoreCode.GDPlayerName_95InputObjects2.length = 0;
gdjs.SubmitScoreCode.GDPlayerName_95InputObjects3.length = 0;
gdjs.SubmitScoreCode.GDPlayerName_95InputObjects4.length = 0;
gdjs.SubmitScoreCode.GDPlayerName_95InputObjects5.length = 0;

gdjs.SubmitScoreCode.eventsList22(runtimeScene);

return;

}

gdjs['SubmitScoreCode'] = gdjs.SubmitScoreCode;
