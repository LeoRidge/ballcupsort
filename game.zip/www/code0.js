gdjs.Title_32ScreenCode = {};
gdjs.Title_32ScreenCode.forEachCount0_2 = 0;

gdjs.Title_32ScreenCode.forEachCount1_2 = 0;

gdjs.Title_32ScreenCode.forEachCount2_2 = 0;

gdjs.Title_32ScreenCode.forEachCount3_2 = 0;

gdjs.Title_32ScreenCode.forEachCount4_2 = 0;

gdjs.Title_32ScreenCode.forEachCount5_2 = 0;

gdjs.Title_32ScreenCode.forEachIndex2 = 0;

gdjs.Title_32ScreenCode.forEachObjects2 = [];

gdjs.Title_32ScreenCode.forEachTotalCount2 = 0;

gdjs.Title_32ScreenCode.GDBall_951Objects1= [];
gdjs.Title_32ScreenCode.GDBall_951Objects2= [];
gdjs.Title_32ScreenCode.GDBall_951Objects3= [];
gdjs.Title_32ScreenCode.GDBall_951Objects4= [];
gdjs.Title_32ScreenCode.GDBall_951Objects5= [];
gdjs.Title_32ScreenCode.GDBall_951Objects6= [];
gdjs.Title_32ScreenCode.GDBall_951Objects7= [];
gdjs.Title_32ScreenCode.GDBall_952Objects1= [];
gdjs.Title_32ScreenCode.GDBall_952Objects2= [];
gdjs.Title_32ScreenCode.GDBall_952Objects3= [];
gdjs.Title_32ScreenCode.GDBall_952Objects4= [];
gdjs.Title_32ScreenCode.GDBall_952Objects5= [];
gdjs.Title_32ScreenCode.GDBall_952Objects6= [];
gdjs.Title_32ScreenCode.GDBall_952Objects7= [];
gdjs.Title_32ScreenCode.GDBall_953Objects1= [];
gdjs.Title_32ScreenCode.GDBall_953Objects2= [];
gdjs.Title_32ScreenCode.GDBall_953Objects3= [];
gdjs.Title_32ScreenCode.GDBall_953Objects4= [];
gdjs.Title_32ScreenCode.GDBall_953Objects5= [];
gdjs.Title_32ScreenCode.GDBall_953Objects6= [];
gdjs.Title_32ScreenCode.GDBall_953Objects7= [];
gdjs.Title_32ScreenCode.GDBall_954Objects1= [];
gdjs.Title_32ScreenCode.GDBall_954Objects2= [];
gdjs.Title_32ScreenCode.GDBall_954Objects3= [];
gdjs.Title_32ScreenCode.GDBall_954Objects4= [];
gdjs.Title_32ScreenCode.GDBall_954Objects5= [];
gdjs.Title_32ScreenCode.GDBall_954Objects6= [];
gdjs.Title_32ScreenCode.GDBall_954Objects7= [];
gdjs.Title_32ScreenCode.GDBall_955Objects1= [];
gdjs.Title_32ScreenCode.GDBall_955Objects2= [];
gdjs.Title_32ScreenCode.GDBall_955Objects3= [];
gdjs.Title_32ScreenCode.GDBall_955Objects4= [];
gdjs.Title_32ScreenCode.GDBall_955Objects5= [];
gdjs.Title_32ScreenCode.GDBall_955Objects6= [];
gdjs.Title_32ScreenCode.GDBall_955Objects7= [];
gdjs.Title_32ScreenCode.GDBall_956Objects1= [];
gdjs.Title_32ScreenCode.GDBall_956Objects2= [];
gdjs.Title_32ScreenCode.GDBall_956Objects3= [];
gdjs.Title_32ScreenCode.GDBall_956Objects4= [];
gdjs.Title_32ScreenCode.GDBall_956Objects5= [];
gdjs.Title_32ScreenCode.GDBall_956Objects6= [];
gdjs.Title_32ScreenCode.GDBall_956Objects7= [];
gdjs.Title_32ScreenCode.GDGlassBreaking_95ParticlesObjects1= [];
gdjs.Title_32ScreenCode.GDGlassBreaking_95ParticlesObjects2= [];
gdjs.Title_32ScreenCode.GDGlassBreaking_95ParticlesObjects3= [];
gdjs.Title_32ScreenCode.GDGlassBreaking_95ParticlesObjects4= [];
gdjs.Title_32ScreenCode.GDGlassBreaking_95ParticlesObjects5= [];
gdjs.Title_32ScreenCode.GDGlassBreaking_95ParticlesObjects6= [];
gdjs.Title_32ScreenCode.GDGlassBreaking_95ParticlesObjects7= [];
gdjs.Title_32ScreenCode.GDCupObjects1= [];
gdjs.Title_32ScreenCode.GDCupObjects2= [];
gdjs.Title_32ScreenCode.GDCupObjects3= [];
gdjs.Title_32ScreenCode.GDCupObjects4= [];
gdjs.Title_32ScreenCode.GDCupObjects5= [];
gdjs.Title_32ScreenCode.GDCupObjects6= [];
gdjs.Title_32ScreenCode.GDCupObjects7= [];
gdjs.Title_32ScreenCode.GDCupFrontObjects1= [];
gdjs.Title_32ScreenCode.GDCupFrontObjects2= [];
gdjs.Title_32ScreenCode.GDCupFrontObjects3= [];
gdjs.Title_32ScreenCode.GDCupFrontObjects4= [];
gdjs.Title_32ScreenCode.GDCupFrontObjects5= [];
gdjs.Title_32ScreenCode.GDCupFrontObjects6= [];
gdjs.Title_32ScreenCode.GDCupFrontObjects7= [];
gdjs.Title_32ScreenCode.GDCloud1Objects1= [];
gdjs.Title_32ScreenCode.GDCloud1Objects2= [];
gdjs.Title_32ScreenCode.GDCloud1Objects3= [];
gdjs.Title_32ScreenCode.GDCloud1Objects4= [];
gdjs.Title_32ScreenCode.GDCloud1Objects5= [];
gdjs.Title_32ScreenCode.GDCloud1Objects6= [];
gdjs.Title_32ScreenCode.GDCloud1Objects7= [];
gdjs.Title_32ScreenCode.GDCloud2Objects1= [];
gdjs.Title_32ScreenCode.GDCloud2Objects2= [];
gdjs.Title_32ScreenCode.GDCloud2Objects3= [];
gdjs.Title_32ScreenCode.GDCloud2Objects4= [];
gdjs.Title_32ScreenCode.GDCloud2Objects5= [];
gdjs.Title_32ScreenCode.GDCloud2Objects6= [];
gdjs.Title_32ScreenCode.GDCloud2Objects7= [];
gdjs.Title_32ScreenCode.GDCloud3Objects1= [];
gdjs.Title_32ScreenCode.GDCloud3Objects2= [];
gdjs.Title_32ScreenCode.GDCloud3Objects3= [];
gdjs.Title_32ScreenCode.GDCloud3Objects4= [];
gdjs.Title_32ScreenCode.GDCloud3Objects5= [];
gdjs.Title_32ScreenCode.GDCloud3Objects6= [];
gdjs.Title_32ScreenCode.GDCloud3Objects7= [];
gdjs.Title_32ScreenCode.GDCloud4Objects1= [];
gdjs.Title_32ScreenCode.GDCloud4Objects2= [];
gdjs.Title_32ScreenCode.GDCloud4Objects3= [];
gdjs.Title_32ScreenCode.GDCloud4Objects4= [];
gdjs.Title_32ScreenCode.GDCloud4Objects5= [];
gdjs.Title_32ScreenCode.GDCloud4Objects6= [];
gdjs.Title_32ScreenCode.GDCloud4Objects7= [];
gdjs.Title_32ScreenCode.GDEditInGDevelop_95TextObjects1= [];
gdjs.Title_32ScreenCode.GDEditInGDevelop_95TextObjects2= [];
gdjs.Title_32ScreenCode.GDEditInGDevelop_95TextObjects3= [];
gdjs.Title_32ScreenCode.GDEditInGDevelop_95TextObjects4= [];
gdjs.Title_32ScreenCode.GDEditInGDevelop_95TextObjects5= [];
gdjs.Title_32ScreenCode.GDEditInGDevelop_95TextObjects6= [];
gdjs.Title_32ScreenCode.GDEditInGDevelop_95TextObjects7= [];
gdjs.Title_32ScreenCode.GDGreyButtonObjects1= [];
gdjs.Title_32ScreenCode.GDGreyButtonObjects2= [];
gdjs.Title_32ScreenCode.GDGreyButtonObjects3= [];
gdjs.Title_32ScreenCode.GDGreyButtonObjects4= [];
gdjs.Title_32ScreenCode.GDGreyButtonObjects5= [];
gdjs.Title_32ScreenCode.GDGreyButtonObjects6= [];
gdjs.Title_32ScreenCode.GDGreyButtonObjects7= [];
gdjs.Title_32ScreenCode.GDCurrentLevel_95TextObjects1= [];
gdjs.Title_32ScreenCode.GDCurrentLevel_95TextObjects2= [];
gdjs.Title_32ScreenCode.GDCurrentLevel_95TextObjects3= [];
gdjs.Title_32ScreenCode.GDCurrentLevel_95TextObjects4= [];
gdjs.Title_32ScreenCode.GDCurrentLevel_95TextObjects5= [];
gdjs.Title_32ScreenCode.GDCurrentLevel_95TextObjects6= [];
gdjs.Title_32ScreenCode.GDCurrentLevel_95TextObjects7= [];
gdjs.Title_32ScreenCode.GDMenuObjects1= [];
gdjs.Title_32ScreenCode.GDMenuObjects2= [];
gdjs.Title_32ScreenCode.GDMenuObjects3= [];
gdjs.Title_32ScreenCode.GDMenuObjects4= [];
gdjs.Title_32ScreenCode.GDMenuObjects5= [];
gdjs.Title_32ScreenCode.GDMenuObjects6= [];
gdjs.Title_32ScreenCode.GDMenuObjects7= [];
gdjs.Title_32ScreenCode.GDGameState_95TextObjects1= [];
gdjs.Title_32ScreenCode.GDGameState_95TextObjects2= [];
gdjs.Title_32ScreenCode.GDGameState_95TextObjects3= [];
gdjs.Title_32ScreenCode.GDGameState_95TextObjects4= [];
gdjs.Title_32ScreenCode.GDGameState_95TextObjects5= [];
gdjs.Title_32ScreenCode.GDGameState_95TextObjects6= [];
gdjs.Title_32ScreenCode.GDGameState_95TextObjects7= [];
gdjs.Title_32ScreenCode.GDMovesMade_95TextObjects1= [];
gdjs.Title_32ScreenCode.GDMovesMade_95TextObjects2= [];
gdjs.Title_32ScreenCode.GDMovesMade_95TextObjects3= [];
gdjs.Title_32ScreenCode.GDMovesMade_95TextObjects4= [];
gdjs.Title_32ScreenCode.GDMovesMade_95TextObjects5= [];
gdjs.Title_32ScreenCode.GDMovesMade_95TextObjects6= [];
gdjs.Title_32ScreenCode.GDMovesMade_95TextObjects7= [];
gdjs.Title_32ScreenCode.GDTimeSpent_95TextObjects1= [];
gdjs.Title_32ScreenCode.GDTimeSpent_95TextObjects2= [];
gdjs.Title_32ScreenCode.GDTimeSpent_95TextObjects3= [];
gdjs.Title_32ScreenCode.GDTimeSpent_95TextObjects4= [];
gdjs.Title_32ScreenCode.GDTimeSpent_95TextObjects5= [];
gdjs.Title_32ScreenCode.GDTimeSpent_95TextObjects6= [];
gdjs.Title_32ScreenCode.GDTimeSpent_95TextObjects7= [];
gdjs.Title_32ScreenCode.GDBallsInCup_95TextObjects1= [];
gdjs.Title_32ScreenCode.GDBallsInCup_95TextObjects2= [];
gdjs.Title_32ScreenCode.GDBallsInCup_95TextObjects3= [];
gdjs.Title_32ScreenCode.GDBallsInCup_95TextObjects4= [];
gdjs.Title_32ScreenCode.GDBallsInCup_95TextObjects5= [];
gdjs.Title_32ScreenCode.GDBallsInCup_95TextObjects6= [];
gdjs.Title_32ScreenCode.GDBallsInCup_95TextObjects7= [];
gdjs.Title_32ScreenCode.GDPlay_95TextObjects1= [];
gdjs.Title_32ScreenCode.GDPlay_95TextObjects2= [];
gdjs.Title_32ScreenCode.GDPlay_95TextObjects3= [];
gdjs.Title_32ScreenCode.GDPlay_95TextObjects4= [];
gdjs.Title_32ScreenCode.GDPlay_95TextObjects5= [];
gdjs.Title_32ScreenCode.GDPlay_95TextObjects6= [];
gdjs.Title_32ScreenCode.GDPlay_95TextObjects7= [];
gdjs.Title_32ScreenCode.GDLeaderboardObjects1= [];
gdjs.Title_32ScreenCode.GDLeaderboardObjects2= [];
gdjs.Title_32ScreenCode.GDLeaderboardObjects3= [];
gdjs.Title_32ScreenCode.GDLeaderboardObjects4= [];
gdjs.Title_32ScreenCode.GDLeaderboardObjects5= [];
gdjs.Title_32ScreenCode.GDLeaderboardObjects6= [];
gdjs.Title_32ScreenCode.GDLeaderboardObjects7= [];
gdjs.Title_32ScreenCode.GDMainMenu_95TextObjects1= [];
gdjs.Title_32ScreenCode.GDMainMenu_95TextObjects2= [];
gdjs.Title_32ScreenCode.GDMainMenu_95TextObjects3= [];
gdjs.Title_32ScreenCode.GDMainMenu_95TextObjects4= [];
gdjs.Title_32ScreenCode.GDMainMenu_95TextObjects5= [];
gdjs.Title_32ScreenCode.GDMainMenu_95TextObjects6= [];
gdjs.Title_32ScreenCode.GDMainMenu_95TextObjects7= [];
gdjs.Title_32ScreenCode.GDResetProgress_95TextObjects1= [];
gdjs.Title_32ScreenCode.GDResetProgress_95TextObjects2= [];
gdjs.Title_32ScreenCode.GDResetProgress_95TextObjects3= [];
gdjs.Title_32ScreenCode.GDResetProgress_95TextObjects4= [];
gdjs.Title_32ScreenCode.GDResetProgress_95TextObjects5= [];
gdjs.Title_32ScreenCode.GDResetProgress_95TextObjects6= [];
gdjs.Title_32ScreenCode.GDResetProgress_95TextObjects7= [];
gdjs.Title_32ScreenCode.GDStartOver_95TextObjects1= [];
gdjs.Title_32ScreenCode.GDStartOver_95TextObjects2= [];
gdjs.Title_32ScreenCode.GDStartOver_95TextObjects3= [];
gdjs.Title_32ScreenCode.GDStartOver_95TextObjects4= [];
gdjs.Title_32ScreenCode.GDStartOver_95TextObjects5= [];
gdjs.Title_32ScreenCode.GDStartOver_95TextObjects6= [];
gdjs.Title_32ScreenCode.GDStartOver_95TextObjects7= [];
gdjs.Title_32ScreenCode.GDSubmit_95TextObjects1= [];
gdjs.Title_32ScreenCode.GDSubmit_95TextObjects2= [];
gdjs.Title_32ScreenCode.GDSubmit_95TextObjects3= [];
gdjs.Title_32ScreenCode.GDSubmit_95TextObjects4= [];
gdjs.Title_32ScreenCode.GDSubmit_95TextObjects5= [];
gdjs.Title_32ScreenCode.GDSubmit_95TextObjects6= [];
gdjs.Title_32ScreenCode.GDSubmit_95TextObjects7= [];
gdjs.Title_32ScreenCode.GDBall_95TextObjects1= [];
gdjs.Title_32ScreenCode.GDBall_95TextObjects2= [];
gdjs.Title_32ScreenCode.GDBall_95TextObjects3= [];
gdjs.Title_32ScreenCode.GDBall_95TextObjects4= [];
gdjs.Title_32ScreenCode.GDBall_95TextObjects5= [];
gdjs.Title_32ScreenCode.GDBall_95TextObjects6= [];
gdjs.Title_32ScreenCode.GDBall_95TextObjects7= [];
gdjs.Title_32ScreenCode.GDViewLeaderboards_95TextObjects1= [];
gdjs.Title_32ScreenCode.GDViewLeaderboards_95TextObjects2= [];
gdjs.Title_32ScreenCode.GDViewLeaderboards_95TextObjects3= [];
gdjs.Title_32ScreenCode.GDViewLeaderboards_95TextObjects4= [];
gdjs.Title_32ScreenCode.GDViewLeaderboards_95TextObjects5= [];
gdjs.Title_32ScreenCode.GDViewLeaderboards_95TextObjects6= [];
gdjs.Title_32ScreenCode.GDViewLeaderboards_95TextObjects7= [];
gdjs.Title_32ScreenCode.GDCup_95TextObjects1= [];
gdjs.Title_32ScreenCode.GDCup_95TextObjects2= [];
gdjs.Title_32ScreenCode.GDCup_95TextObjects3= [];
gdjs.Title_32ScreenCode.GDCup_95TextObjects4= [];
gdjs.Title_32ScreenCode.GDCup_95TextObjects5= [];
gdjs.Title_32ScreenCode.GDCup_95TextObjects6= [];
gdjs.Title_32ScreenCode.GDCup_95TextObjects7= [];
gdjs.Title_32ScreenCode.GDBoom_95TextObjects1= [];
gdjs.Title_32ScreenCode.GDBoom_95TextObjects2= [];
gdjs.Title_32ScreenCode.GDBoom_95TextObjects3= [];
gdjs.Title_32ScreenCode.GDBoom_95TextObjects4= [];
gdjs.Title_32ScreenCode.GDBoom_95TextObjects5= [];
gdjs.Title_32ScreenCode.GDBoom_95TextObjects6= [];
gdjs.Title_32ScreenCode.GDBoom_95TextObjects7= [];

gdjs.Title_32ScreenCode.conditionTrue_0 = {val:false};
gdjs.Title_32ScreenCode.condition0IsTrue_0 = {val:false};
gdjs.Title_32ScreenCode.condition1IsTrue_0 = {val:false};
gdjs.Title_32ScreenCode.condition2IsTrue_0 = {val:false};
gdjs.Title_32ScreenCode.condition3IsTrue_0 = {val:false};
gdjs.Title_32ScreenCode.condition4IsTrue_0 = {val:false};
gdjs.Title_32ScreenCode.conditionTrue_1 = {val:false};
gdjs.Title_32ScreenCode.condition0IsTrue_1 = {val:false};
gdjs.Title_32ScreenCode.condition1IsTrue_1 = {val:false};
gdjs.Title_32ScreenCode.condition2IsTrue_1 = {val:false};
gdjs.Title_32ScreenCode.condition3IsTrue_1 = {val:false};
gdjs.Title_32ScreenCode.condition4IsTrue_1 = {val:false};


gdjs.Title_32ScreenCode.eventsList0 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("Cloud1"), gdjs.Title_32ScreenCode.GDCloud1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Cloud2"), gdjs.Title_32ScreenCode.GDCloud2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Cloud3"), gdjs.Title_32ScreenCode.GDCloud3Objects2);
gdjs.copyArray(runtimeScene.getObjects("Cloud4"), gdjs.Title_32ScreenCode.GDCloud4Objects2);
{for(var i = 0, len = gdjs.Title_32ScreenCode.GDCloud1Objects2.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDCloud1Objects2[i].addPolarForce(180, gdjs.randomInRange(5, 10), 1);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDCloud2Objects2.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDCloud2Objects2[i].addPolarForce(180, gdjs.randomInRange(5, 10), 1);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDCloud3Objects2.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDCloud3Objects2[i].addPolarForce(180, gdjs.randomInRange(5, 10), 1);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDCloud4Objects2.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDCloud4Objects2[i].addPolarForce(180, gdjs.randomInRange(5, 10), 1);
}
}{for(var i = 0, len = gdjs.Title_32ScreenCode.GDCloud1Objects2.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDCloud1Objects2[i].setOpacity(gdjs.randomInRange(128, 196));
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDCloud2Objects2.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDCloud2Objects2[i].setOpacity(gdjs.randomInRange(128, 196));
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDCloud3Objects2.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDCloud3Objects2[i].setOpacity(gdjs.randomInRange(128, 196));
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDCloud4Objects2.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDCloud4Objects2[i].setOpacity(gdjs.randomInRange(128, 196));
}
}}

}


};gdjs.Title_32ScreenCode.eventsList1 = function(runtimeScene) {

{



}


{


{
{gdjs.evtTools.storage.readNumberFromJSONFile("BallCupBoom", "CurrentLevel", runtimeScene, runtimeScene.getVariables().get("CurrentLevel"));
}}

}


{



}


{


gdjs.Title_32ScreenCode.condition0IsTrue_0.val = false;
{
gdjs.Title_32ScreenCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("CurrentLevel")) == 0;
}if (gdjs.Title_32ScreenCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().get("CurrentLevel").setNumber(1);
}}

}


};gdjs.Title_32ScreenCode.eventsList2 = function(runtimeScene) {

{


{
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "assets\\audio\\audio - AlexBouncyMaster.aac", 1, true, 50, 1);
}}

}


{


gdjs.Title_32ScreenCode.eventsList0(runtimeScene);
}


{


gdjs.Title_32ScreenCode.eventsList1(runtimeScene);
}


};gdjs.Title_32ScreenCode.eventsList3 = function(runtimeScene) {

{


gdjs.Title_32ScreenCode.condition0IsTrue_0.val = false;
{
gdjs.Title_32ScreenCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Title_32ScreenCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Title_32ScreenCode.eventsList2(runtimeScene);} //End of subevents
}

}


};gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDCupObjects2Objects = Hashtable.newFrom({"Cup": gdjs.Title_32ScreenCode.GDCupObjects2});
gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDCupFrontObjects2Objects = Hashtable.newFrom({"CupFront": gdjs.Title_32ScreenCode.GDCupFrontObjects2});
gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDCupObjects2Objects = Hashtable.newFrom({"Cup": gdjs.Title_32ScreenCode.GDCupObjects2});
gdjs.Title_32ScreenCode.asyncCallback11344948 = function (runtimeScene, asyncObjectsList) {
{runtimeScene.getVariables().get("GameState").setString("DropBalls");
}}
gdjs.Title_32ScreenCode.eventsList4 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.0), (runtimeScene) => (gdjs.Title_32ScreenCode.asyncCallback11344948(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Title_32ScreenCode.eventsList5 = function(runtimeScene) {

{


{
gdjs.Title_32ScreenCode.GDCupObjects2.length = 0;

gdjs.Title_32ScreenCode.GDCupFrontObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDCupObjects2Objects, gdjs.evtTools.camera.getCameraBorderLeft(runtimeScene, "", 0) - 64, 0.35 * gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDCupFrontObjects2Objects, (( gdjs.Title_32ScreenCode.GDCupObjects2.length === 0 ) ? 0 :gdjs.Title_32ScreenCode.GDCupObjects2[0].getPointX("")), (( gdjs.Title_32ScreenCode.GDCupObjects2.length === 0 ) ? 0 :gdjs.Title_32ScreenCode.GDCupObjects2[0].getPointY("")), "FrontCups");
}{for(var i = 0, len = gdjs.Title_32ScreenCode.GDCupFrontObjects2.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDCupFrontObjects2[i].enableEffect("Effect", false);
}
}{for(var i = 0, len = gdjs.Title_32ScreenCode.GDCupObjects2.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDCupObjects2[i].setOpacity(128);
}
}{for(var i = 0, len = gdjs.Title_32ScreenCode.GDCupFrontObjects2.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDCupFrontObjects2[i].setOpacity(64);
}
}{for(var i = 0, len = gdjs.Title_32ScreenCode.GDCupFrontObjects2.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDCupFrontObjects2[i].getBehavior("Sticker").Stick(gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDCupObjects2Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Title_32ScreenCode.GDCupObjects2.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDCupObjects2[i].getBehavior("Tween").addObjectPositionXTween("SlideCupIn", gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) + 30, "easeOutQuad", 1000, false);
}
}
{ //Subevents
gdjs.Title_32ScreenCode.eventsList4(runtimeScene);} //End of subevents
}

}


};gdjs.Title_32ScreenCode.eventsList6 = function(runtimeScene) {

{


gdjs.Title_32ScreenCode.condition0IsTrue_0.val = false;
gdjs.Title_32ScreenCode.condition1IsTrue_0.val = false;
{
gdjs.Title_32ScreenCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("GameState")) == "SlideCupIn";
}if ( gdjs.Title_32ScreenCode.condition0IsTrue_0.val ) {
{
{gdjs.Title_32ScreenCode.conditionTrue_1 = gdjs.Title_32ScreenCode.condition1IsTrue_0;
gdjs.Title_32ScreenCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11343156);
}
}}
if (gdjs.Title_32ScreenCode.condition1IsTrue_0.val) {

{ //Subevents
gdjs.Title_32ScreenCode.eventsList5(runtimeScene);} //End of subevents
}

}


};gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDBall_95951Objects2ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95952Objects2ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95954Objects2ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95953Objects2ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95955Objects2ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95956Objects2Objects = Hashtable.newFrom({"Ball_1": gdjs.Title_32ScreenCode.GDBall_951Objects2, "Ball_2": gdjs.Title_32ScreenCode.GDBall_952Objects2, "Ball_4": gdjs.Title_32ScreenCode.GDBall_954Objects2, "Ball_3": gdjs.Title_32ScreenCode.GDBall_953Objects2, "Ball_5": gdjs.Title_32ScreenCode.GDBall_955Objects2, "Ball_6": gdjs.Title_32ScreenCode.GDBall_956Objects2});
gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDBall_95951Objects2ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95952Objects2ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95954Objects2ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95953Objects2ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95955Objects2ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95956Objects2Objects = Hashtable.newFrom({"Ball_1": gdjs.Title_32ScreenCode.GDBall_951Objects2, "Ball_2": gdjs.Title_32ScreenCode.GDBall_952Objects2, "Ball_4": gdjs.Title_32ScreenCode.GDBall_954Objects2, "Ball_3": gdjs.Title_32ScreenCode.GDBall_953Objects2, "Ball_5": gdjs.Title_32ScreenCode.GDBall_955Objects2, "Ball_6": gdjs.Title_32ScreenCode.GDBall_956Objects2});
gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDBall_95951Objects3ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95952Objects3ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95954Objects3ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95953Objects3ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95955Objects3ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95956Objects3Objects = Hashtable.newFrom({"Ball_1": gdjs.Title_32ScreenCode.GDBall_951Objects3, "Ball_2": gdjs.Title_32ScreenCode.GDBall_952Objects3, "Ball_4": gdjs.Title_32ScreenCode.GDBall_954Objects3, "Ball_3": gdjs.Title_32ScreenCode.GDBall_953Objects3, "Ball_5": gdjs.Title_32ScreenCode.GDBall_955Objects3, "Ball_6": gdjs.Title_32ScreenCode.GDBall_956Objects3});
gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDBall_95951Objects3ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95952Objects3ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95954Objects3ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95953Objects3ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95955Objects3ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95956Objects3Objects = Hashtable.newFrom({"Ball_1": gdjs.Title_32ScreenCode.GDBall_951Objects3, "Ball_2": gdjs.Title_32ScreenCode.GDBall_952Objects3, "Ball_4": gdjs.Title_32ScreenCode.GDBall_954Objects3, "Ball_3": gdjs.Title_32ScreenCode.GDBall_953Objects3, "Ball_5": gdjs.Title_32ScreenCode.GDBall_955Objects3, "Ball_6": gdjs.Title_32ScreenCode.GDBall_956Objects3});
gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDBall_95951Objects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95952Objects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95954Objects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95953Objects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95955Objects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95956Objects4Objects = Hashtable.newFrom({"Ball_1": gdjs.Title_32ScreenCode.GDBall_951Objects4, "Ball_2": gdjs.Title_32ScreenCode.GDBall_952Objects4, "Ball_4": gdjs.Title_32ScreenCode.GDBall_954Objects4, "Ball_3": gdjs.Title_32ScreenCode.GDBall_953Objects4, "Ball_5": gdjs.Title_32ScreenCode.GDBall_955Objects4, "Ball_6": gdjs.Title_32ScreenCode.GDBall_956Objects4});
gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDBall_95951Objects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95952Objects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95954Objects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95953Objects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95955Objects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95956Objects4Objects = Hashtable.newFrom({"Ball_1": gdjs.Title_32ScreenCode.GDBall_951Objects4, "Ball_2": gdjs.Title_32ScreenCode.GDBall_952Objects4, "Ball_4": gdjs.Title_32ScreenCode.GDBall_954Objects4, "Ball_3": gdjs.Title_32ScreenCode.GDBall_953Objects4, "Ball_5": gdjs.Title_32ScreenCode.GDBall_955Objects4, "Ball_6": gdjs.Title_32ScreenCode.GDBall_956Objects4});
gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDBall_95951Objects5ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95952Objects5ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95954Objects5ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95953Objects5ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95955Objects5ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95956Objects5Objects = Hashtable.newFrom({"Ball_1": gdjs.Title_32ScreenCode.GDBall_951Objects5, "Ball_2": gdjs.Title_32ScreenCode.GDBall_952Objects5, "Ball_4": gdjs.Title_32ScreenCode.GDBall_954Objects5, "Ball_3": gdjs.Title_32ScreenCode.GDBall_953Objects5, "Ball_5": gdjs.Title_32ScreenCode.GDBall_955Objects5, "Ball_6": gdjs.Title_32ScreenCode.GDBall_956Objects5});
gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDBall_95951Objects5ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95952Objects5ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95954Objects5ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95953Objects5ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95955Objects5ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95956Objects5Objects = Hashtable.newFrom({"Ball_1": gdjs.Title_32ScreenCode.GDBall_951Objects5, "Ball_2": gdjs.Title_32ScreenCode.GDBall_952Objects5, "Ball_4": gdjs.Title_32ScreenCode.GDBall_954Objects5, "Ball_3": gdjs.Title_32ScreenCode.GDBall_953Objects5, "Ball_5": gdjs.Title_32ScreenCode.GDBall_955Objects5, "Ball_6": gdjs.Title_32ScreenCode.GDBall_956Objects5});
gdjs.Title_32ScreenCode.asyncCallback11354012 = function (runtimeScene, asyncObjectsList) {
{runtimeScene.getVariables().get("GameState").setString("CheckForMatch");
}}
gdjs.Title_32ScreenCode.eventsList7 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Title_32ScreenCode.asyncCallback11354012(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Title_32ScreenCode.eventsList8 = function(runtimeScene, asyncObjectsList) {

{


{

{ //Subevents
gdjs.Title_32ScreenCode.eventsList7(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.Title_32ScreenCode.asyncCallback11352852 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\audio - BLLTImpt Hit Marker 07.aac", false, 30, gdjs.randomFloatInRange(0.9, 1.1));
}
{ //Subevents
gdjs.Title_32ScreenCode.eventsList8(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Title_32ScreenCode.eventsList9 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Title_32ScreenCode.asyncCallback11352852(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Title_32ScreenCode.eventsList10 = function(runtimeScene, asyncObjectsList) {

{

/* Reuse gdjs.Title_32ScreenCode.GDBall_951Objects5 */
/* Reuse gdjs.Title_32ScreenCode.GDBall_952Objects5 */
/* Reuse gdjs.Title_32ScreenCode.GDBall_953Objects5 */
/* Reuse gdjs.Title_32ScreenCode.GDBall_954Objects5 */
/* Reuse gdjs.Title_32ScreenCode.GDBall_955Objects5 */
/* Reuse gdjs.Title_32ScreenCode.GDBall_956Objects5 */
/* Reuse gdjs.Title_32ScreenCode.GDCupObjects5 */

gdjs.Title_32ScreenCode.condition0IsTrue_0.val = false;
{
gdjs.Title_32ScreenCode.condition0IsTrue_0.val = gdjs.evtTools.object.pickNearestObject(gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDBall_95951Objects5ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95952Objects5ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95954Objects5ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95953Objects5ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95955Objects5ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95956Objects5Objects, (( gdjs.Title_32ScreenCode.GDCupObjects5.length === 0 ) ? 0 :gdjs.Title_32ScreenCode.GDCupObjects5[0].getCenterXInScene()), gdjs.evtTools.camera.getCameraBorderTop(runtimeScene, "", 0), false);
}if (gdjs.Title_32ScreenCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Title_32ScreenCode.GDBall_951Objects5 */
/* Reuse gdjs.Title_32ScreenCode.GDBall_952Objects5 */
/* Reuse gdjs.Title_32ScreenCode.GDBall_953Objects5 */
/* Reuse gdjs.Title_32ScreenCode.GDBall_954Objects5 */
/* Reuse gdjs.Title_32ScreenCode.GDBall_955Objects5 */
/* Reuse gdjs.Title_32ScreenCode.GDBall_956Objects5 */
/* Reuse gdjs.Title_32ScreenCode.GDCupObjects5 */
{for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_951Objects5.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_951Objects5[i].getBehavior("Tween").addObjectPositionYTween("DropBall", (( gdjs.Title_32ScreenCode.GDCupObjects5.length === 0 ) ? 0 :gdjs.Title_32ScreenCode.GDCupObjects5[0].getPointY("")), "easeOutSine", 500, false);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_952Objects5.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_952Objects5[i].getBehavior("Tween").addObjectPositionYTween("DropBall", (( gdjs.Title_32ScreenCode.GDCupObjects5.length === 0 ) ? 0 :gdjs.Title_32ScreenCode.GDCupObjects5[0].getPointY("")), "easeOutSine", 500, false);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_954Objects5.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_954Objects5[i].getBehavior("Tween").addObjectPositionYTween("DropBall", (( gdjs.Title_32ScreenCode.GDCupObjects5.length === 0 ) ? 0 :gdjs.Title_32ScreenCode.GDCupObjects5[0].getPointY("")), "easeOutSine", 500, false);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_953Objects5.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_953Objects5[i].getBehavior("Tween").addObjectPositionYTween("DropBall", (( gdjs.Title_32ScreenCode.GDCupObjects5.length === 0 ) ? 0 :gdjs.Title_32ScreenCode.GDCupObjects5[0].getPointY("")), "easeOutSine", 500, false);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_955Objects5.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_955Objects5[i].getBehavior("Tween").addObjectPositionYTween("DropBall", (( gdjs.Title_32ScreenCode.GDCupObjects5.length === 0 ) ? 0 :gdjs.Title_32ScreenCode.GDCupObjects5[0].getPointY("")), "easeOutSine", 500, false);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_956Objects5.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_956Objects5[i].getBehavior("Tween").addObjectPositionYTween("DropBall", (( gdjs.Title_32ScreenCode.GDCupObjects5.length === 0 ) ? 0 :gdjs.Title_32ScreenCode.GDCupObjects5[0].getPointY("")), "easeOutSine", 500, false);
}
}
{ //Subevents
gdjs.Title_32ScreenCode.eventsList9(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.Title_32ScreenCode.asyncCallback11351468 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Cup"), gdjs.Title_32ScreenCode.GDCupObjects5);

gdjs.copyArray(asyncObjectsList.getObjects("Ball_1"), gdjs.Title_32ScreenCode.GDBall_951Objects5);

gdjs.copyArray(asyncObjectsList.getObjects("Ball_2"), gdjs.Title_32ScreenCode.GDBall_952Objects5);

gdjs.copyArray(asyncObjectsList.getObjects("Ball_3"), gdjs.Title_32ScreenCode.GDBall_953Objects5);

gdjs.copyArray(asyncObjectsList.getObjects("Ball_4"), gdjs.Title_32ScreenCode.GDBall_954Objects5);

gdjs.copyArray(asyncObjectsList.getObjects("Ball_5"), gdjs.Title_32ScreenCode.GDBall_955Objects5);

gdjs.copyArray(asyncObjectsList.getObjects("Ball_6"), gdjs.Title_32ScreenCode.GDBall_956Objects5);

{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\audio - BLLTImpt Hit Marker 07.aac", false, 30, gdjs.randomFloatInRange(0.9, 1.1));
}{gdjs.evtTools.object.createObjectFromGroupOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDBall_95951Objects5ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95952Objects5ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95954Objects5ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95953Objects5ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95955Objects5ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95956Objects5Objects, "Ball_" + gdjs.evtTools.common.toString(gdjs.randomInRange(1, 4)), (( gdjs.Title_32ScreenCode.GDCupObjects5.length === 0 ) ? 0 :gdjs.Title_32ScreenCode.GDCupObjects5[0].getCenterXInScene()), gdjs.evtTools.camera.getCameraBorderTop(runtimeScene, "", 0) - 32, "Balls");
}
{ //Subevents
gdjs.Title_32ScreenCode.eventsList10(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Title_32ScreenCode.eventsList11 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.Title_32ScreenCode.GDBall_951Objects4) asyncObjectsList.addObject("Ball_1", obj);
for (const obj of gdjs.Title_32ScreenCode.GDBall_952Objects4) asyncObjectsList.addObject("Ball_2", obj);
for (const obj of gdjs.Title_32ScreenCode.GDBall_953Objects4) asyncObjectsList.addObject("Ball_3", obj);
for (const obj of gdjs.Title_32ScreenCode.GDBall_954Objects4) asyncObjectsList.addObject("Ball_4", obj);
for (const obj of gdjs.Title_32ScreenCode.GDBall_955Objects4) asyncObjectsList.addObject("Ball_5", obj);
for (const obj of gdjs.Title_32ScreenCode.GDBall_956Objects4) asyncObjectsList.addObject("Ball_6", obj);
for (const obj of gdjs.Title_32ScreenCode.GDCupObjects4) asyncObjectsList.addObject("Cup", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Title_32ScreenCode.asyncCallback11351468(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Title_32ScreenCode.eventsList12 = function(runtimeScene, asyncObjectsList) {

{

/* Reuse gdjs.Title_32ScreenCode.GDBall_951Objects4 */
/* Reuse gdjs.Title_32ScreenCode.GDBall_952Objects4 */
/* Reuse gdjs.Title_32ScreenCode.GDBall_953Objects4 */
/* Reuse gdjs.Title_32ScreenCode.GDBall_954Objects4 */
/* Reuse gdjs.Title_32ScreenCode.GDBall_955Objects4 */
/* Reuse gdjs.Title_32ScreenCode.GDBall_956Objects4 */
/* Reuse gdjs.Title_32ScreenCode.GDCupObjects4 */

gdjs.Title_32ScreenCode.condition0IsTrue_0.val = false;
{
gdjs.Title_32ScreenCode.condition0IsTrue_0.val = gdjs.evtTools.object.pickNearestObject(gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDBall_95951Objects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95952Objects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95954Objects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95953Objects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95955Objects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95956Objects4Objects, (( gdjs.Title_32ScreenCode.GDCupObjects4.length === 0 ) ? 0 :gdjs.Title_32ScreenCode.GDCupObjects4[0].getCenterXInScene()), gdjs.evtTools.camera.getCameraBorderTop(runtimeScene, "", 0), false);
}if (gdjs.Title_32ScreenCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Title_32ScreenCode.GDBall_951Objects4 */
/* Reuse gdjs.Title_32ScreenCode.GDBall_952Objects4 */
/* Reuse gdjs.Title_32ScreenCode.GDBall_953Objects4 */
/* Reuse gdjs.Title_32ScreenCode.GDBall_954Objects4 */
/* Reuse gdjs.Title_32ScreenCode.GDBall_955Objects4 */
/* Reuse gdjs.Title_32ScreenCode.GDBall_956Objects4 */
/* Reuse gdjs.Title_32ScreenCode.GDCupObjects4 */
{for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_951Objects4.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_951Objects4[i].getBehavior("Tween").addObjectPositionYTween("DropBall", (( gdjs.Title_32ScreenCode.GDCupObjects4.length === 0 ) ? 0 :gdjs.Title_32ScreenCode.GDCupObjects4[0].getPointY("")) + (gdjs.Title_32ScreenCode.GDBall_951Objects4[i].getHeight()) * 1, "easeOutSine", 500, false);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_952Objects4.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_952Objects4[i].getBehavior("Tween").addObjectPositionYTween("DropBall", (( gdjs.Title_32ScreenCode.GDCupObjects4.length === 0 ) ? 0 :gdjs.Title_32ScreenCode.GDCupObjects4[0].getPointY("")) + (gdjs.Title_32ScreenCode.GDBall_952Objects4[i].getHeight()) * 1, "easeOutSine", 500, false);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_954Objects4.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_954Objects4[i].getBehavior("Tween").addObjectPositionYTween("DropBall", (( gdjs.Title_32ScreenCode.GDCupObjects4.length === 0 ) ? 0 :gdjs.Title_32ScreenCode.GDCupObjects4[0].getPointY("")) + (gdjs.Title_32ScreenCode.GDBall_954Objects4[i].getHeight()) * 1, "easeOutSine", 500, false);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_953Objects4.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_953Objects4[i].getBehavior("Tween").addObjectPositionYTween("DropBall", (( gdjs.Title_32ScreenCode.GDCupObjects4.length === 0 ) ? 0 :gdjs.Title_32ScreenCode.GDCupObjects4[0].getPointY("")) + (gdjs.Title_32ScreenCode.GDBall_953Objects4[i].getHeight()) * 1, "easeOutSine", 500, false);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_955Objects4.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_955Objects4[i].getBehavior("Tween").addObjectPositionYTween("DropBall", (( gdjs.Title_32ScreenCode.GDCupObjects4.length === 0 ) ? 0 :gdjs.Title_32ScreenCode.GDCupObjects4[0].getPointY("")) + (gdjs.Title_32ScreenCode.GDBall_955Objects4[i].getHeight()) * 1, "easeOutSine", 500, false);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_956Objects4.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_956Objects4[i].getBehavior("Tween").addObjectPositionYTween("DropBall", (( gdjs.Title_32ScreenCode.GDCupObjects4.length === 0 ) ? 0 :gdjs.Title_32ScreenCode.GDCupObjects4[0].getPointY("")) + (gdjs.Title_32ScreenCode.GDBall_956Objects4[i].getHeight()) * 1, "easeOutSine", 500, false);
}
}
{ //Subevents
gdjs.Title_32ScreenCode.eventsList11(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.Title_32ScreenCode.asyncCallback11349772 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Cup"), gdjs.Title_32ScreenCode.GDCupObjects4);

gdjs.copyArray(asyncObjectsList.getObjects("Ball_1"), gdjs.Title_32ScreenCode.GDBall_951Objects4);

gdjs.copyArray(asyncObjectsList.getObjects("Ball_2"), gdjs.Title_32ScreenCode.GDBall_952Objects4);

gdjs.copyArray(asyncObjectsList.getObjects("Ball_3"), gdjs.Title_32ScreenCode.GDBall_953Objects4);

gdjs.copyArray(asyncObjectsList.getObjects("Ball_4"), gdjs.Title_32ScreenCode.GDBall_954Objects4);

gdjs.copyArray(asyncObjectsList.getObjects("Ball_5"), gdjs.Title_32ScreenCode.GDBall_955Objects4);

gdjs.copyArray(asyncObjectsList.getObjects("Ball_6"), gdjs.Title_32ScreenCode.GDBall_956Objects4);

{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\audio - BLLTImpt Hit Marker 07.aac", false, 30, gdjs.randomFloatInRange(0.9, 1.1));
}{gdjs.evtTools.object.createObjectFromGroupOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDBall_95951Objects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95952Objects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95954Objects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95953Objects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95955Objects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95956Objects4Objects, "Ball_" + gdjs.evtTools.common.toString(gdjs.randomInRange(1, 4)), (( gdjs.Title_32ScreenCode.GDCupObjects4.length === 0 ) ? 0 :gdjs.Title_32ScreenCode.GDCupObjects4[0].getCenterXInScene()), gdjs.evtTools.camera.getCameraBorderTop(runtimeScene, "", 0) - 32, "Balls");
}
{ //Subevents
gdjs.Title_32ScreenCode.eventsList12(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Title_32ScreenCode.eventsList13 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.Title_32ScreenCode.GDBall_951Objects3) asyncObjectsList.addObject("Ball_1", obj);
for (const obj of gdjs.Title_32ScreenCode.GDBall_952Objects3) asyncObjectsList.addObject("Ball_2", obj);
for (const obj of gdjs.Title_32ScreenCode.GDBall_953Objects3) asyncObjectsList.addObject("Ball_3", obj);
for (const obj of gdjs.Title_32ScreenCode.GDBall_954Objects3) asyncObjectsList.addObject("Ball_4", obj);
for (const obj of gdjs.Title_32ScreenCode.GDBall_955Objects3) asyncObjectsList.addObject("Ball_5", obj);
for (const obj of gdjs.Title_32ScreenCode.GDBall_956Objects3) asyncObjectsList.addObject("Ball_6", obj);
for (const obj of gdjs.Title_32ScreenCode.GDCupObjects3) asyncObjectsList.addObject("Cup", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Title_32ScreenCode.asyncCallback11349772(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Title_32ScreenCode.eventsList14 = function(runtimeScene, asyncObjectsList) {

{

/* Reuse gdjs.Title_32ScreenCode.GDBall_951Objects3 */
/* Reuse gdjs.Title_32ScreenCode.GDBall_952Objects3 */
/* Reuse gdjs.Title_32ScreenCode.GDBall_953Objects3 */
/* Reuse gdjs.Title_32ScreenCode.GDBall_954Objects3 */
/* Reuse gdjs.Title_32ScreenCode.GDBall_955Objects3 */
/* Reuse gdjs.Title_32ScreenCode.GDBall_956Objects3 */
/* Reuse gdjs.Title_32ScreenCode.GDCupObjects3 */

gdjs.Title_32ScreenCode.condition0IsTrue_0.val = false;
{
gdjs.Title_32ScreenCode.condition0IsTrue_0.val = gdjs.evtTools.object.pickNearestObject(gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDBall_95951Objects3ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95952Objects3ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95954Objects3ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95953Objects3ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95955Objects3ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95956Objects3Objects, (( gdjs.Title_32ScreenCode.GDCupObjects3.length === 0 ) ? 0 :gdjs.Title_32ScreenCode.GDCupObjects3[0].getCenterXInScene()), gdjs.evtTools.camera.getCameraBorderTop(runtimeScene, "", 0), false);
}if (gdjs.Title_32ScreenCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Title_32ScreenCode.GDBall_951Objects3 */
/* Reuse gdjs.Title_32ScreenCode.GDBall_952Objects3 */
/* Reuse gdjs.Title_32ScreenCode.GDBall_953Objects3 */
/* Reuse gdjs.Title_32ScreenCode.GDBall_954Objects3 */
/* Reuse gdjs.Title_32ScreenCode.GDBall_955Objects3 */
/* Reuse gdjs.Title_32ScreenCode.GDBall_956Objects3 */
/* Reuse gdjs.Title_32ScreenCode.GDCupObjects3 */
{for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_951Objects3.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_951Objects3[i].getBehavior("Tween").addObjectPositionYTween("DropBall", (( gdjs.Title_32ScreenCode.GDCupObjects3.length === 0 ) ? 0 :gdjs.Title_32ScreenCode.GDCupObjects3[0].getPointY("")) + (gdjs.Title_32ScreenCode.GDBall_951Objects3[i].getHeight()) * 2, "easeOutSine", 500, false);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_952Objects3.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_952Objects3[i].getBehavior("Tween").addObjectPositionYTween("DropBall", (( gdjs.Title_32ScreenCode.GDCupObjects3.length === 0 ) ? 0 :gdjs.Title_32ScreenCode.GDCupObjects3[0].getPointY("")) + (gdjs.Title_32ScreenCode.GDBall_952Objects3[i].getHeight()) * 2, "easeOutSine", 500, false);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_954Objects3.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_954Objects3[i].getBehavior("Tween").addObjectPositionYTween("DropBall", (( gdjs.Title_32ScreenCode.GDCupObjects3.length === 0 ) ? 0 :gdjs.Title_32ScreenCode.GDCupObjects3[0].getPointY("")) + (gdjs.Title_32ScreenCode.GDBall_954Objects3[i].getHeight()) * 2, "easeOutSine", 500, false);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_953Objects3.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_953Objects3[i].getBehavior("Tween").addObjectPositionYTween("DropBall", (( gdjs.Title_32ScreenCode.GDCupObjects3.length === 0 ) ? 0 :gdjs.Title_32ScreenCode.GDCupObjects3[0].getPointY("")) + (gdjs.Title_32ScreenCode.GDBall_953Objects3[i].getHeight()) * 2, "easeOutSine", 500, false);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_955Objects3.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_955Objects3[i].getBehavior("Tween").addObjectPositionYTween("DropBall", (( gdjs.Title_32ScreenCode.GDCupObjects3.length === 0 ) ? 0 :gdjs.Title_32ScreenCode.GDCupObjects3[0].getPointY("")) + (gdjs.Title_32ScreenCode.GDBall_955Objects3[i].getHeight()) * 2, "easeOutSine", 500, false);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_956Objects3.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_956Objects3[i].getBehavior("Tween").addObjectPositionYTween("DropBall", (( gdjs.Title_32ScreenCode.GDCupObjects3.length === 0 ) ? 0 :gdjs.Title_32ScreenCode.GDCupObjects3[0].getPointY("")) + (gdjs.Title_32ScreenCode.GDBall_956Objects3[i].getHeight()) * 2, "easeOutSine", 500, false);
}
}
{ //Subevents
gdjs.Title_32ScreenCode.eventsList13(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.Title_32ScreenCode.asyncCallback11347652 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Cup"), gdjs.Title_32ScreenCode.GDCupObjects3);

gdjs.copyArray(asyncObjectsList.getObjects("Ball_1"), gdjs.Title_32ScreenCode.GDBall_951Objects3);

gdjs.copyArray(asyncObjectsList.getObjects("Ball_2"), gdjs.Title_32ScreenCode.GDBall_952Objects3);

gdjs.copyArray(asyncObjectsList.getObjects("Ball_3"), gdjs.Title_32ScreenCode.GDBall_953Objects3);

gdjs.copyArray(asyncObjectsList.getObjects("Ball_4"), gdjs.Title_32ScreenCode.GDBall_954Objects3);

gdjs.copyArray(asyncObjectsList.getObjects("Ball_5"), gdjs.Title_32ScreenCode.GDBall_955Objects3);

gdjs.copyArray(asyncObjectsList.getObjects("Ball_6"), gdjs.Title_32ScreenCode.GDBall_956Objects3);

{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\audio - BLLTImpt Hit Marker 07.aac", false, 30, gdjs.randomFloatInRange(0.9, 1.1));
}{gdjs.evtTools.object.createObjectFromGroupOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDBall_95951Objects3ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95952Objects3ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95954Objects3ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95953Objects3ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95955Objects3ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95956Objects3Objects, "Ball_" + gdjs.evtTools.common.toString(gdjs.randomInRange(1, 4)), (( gdjs.Title_32ScreenCode.GDCupObjects3.length === 0 ) ? 0 :gdjs.Title_32ScreenCode.GDCupObjects3[0].getCenterXInScene()), gdjs.evtTools.camera.getCameraBorderTop(runtimeScene, "", 0) - 32, "Balls");
}
{ //Subevents
gdjs.Title_32ScreenCode.eventsList14(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Title_32ScreenCode.eventsList15 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Title_32ScreenCode.GDBall_951Objects2) asyncObjectsList.addObject("Ball_1", obj);
for (const obj of gdjs.Title_32ScreenCode.GDBall_952Objects2) asyncObjectsList.addObject("Ball_2", obj);
for (const obj of gdjs.Title_32ScreenCode.GDBall_953Objects2) asyncObjectsList.addObject("Ball_3", obj);
for (const obj of gdjs.Title_32ScreenCode.GDBall_954Objects2) asyncObjectsList.addObject("Ball_4", obj);
for (const obj of gdjs.Title_32ScreenCode.GDBall_955Objects2) asyncObjectsList.addObject("Ball_5", obj);
for (const obj of gdjs.Title_32ScreenCode.GDBall_956Objects2) asyncObjectsList.addObject("Ball_6", obj);
for (const obj of gdjs.Title_32ScreenCode.GDCupObjects2) asyncObjectsList.addObject("Cup", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Title_32ScreenCode.asyncCallback11347652(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Title_32ScreenCode.eventsList16 = function(runtimeScene) {

{

/* Reuse gdjs.Title_32ScreenCode.GDBall_951Objects2 */
/* Reuse gdjs.Title_32ScreenCode.GDBall_952Objects2 */
/* Reuse gdjs.Title_32ScreenCode.GDBall_953Objects2 */
/* Reuse gdjs.Title_32ScreenCode.GDBall_954Objects2 */
/* Reuse gdjs.Title_32ScreenCode.GDBall_955Objects2 */
/* Reuse gdjs.Title_32ScreenCode.GDBall_956Objects2 */
/* Reuse gdjs.Title_32ScreenCode.GDCupObjects2 */

gdjs.Title_32ScreenCode.condition0IsTrue_0.val = false;
{
gdjs.Title_32ScreenCode.condition0IsTrue_0.val = gdjs.evtTools.object.pickNearestObject(gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDBall_95951Objects2ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95952Objects2ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95954Objects2ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95953Objects2ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95955Objects2ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95956Objects2Objects, (( gdjs.Title_32ScreenCode.GDCupObjects2.length === 0 ) ? 0 :gdjs.Title_32ScreenCode.GDCupObjects2[0].getCenterXInScene()), gdjs.evtTools.camera.getCameraBorderTop(runtimeScene, "", 0), false);
}if (gdjs.Title_32ScreenCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Title_32ScreenCode.GDBall_951Objects2 */
/* Reuse gdjs.Title_32ScreenCode.GDBall_952Objects2 */
/* Reuse gdjs.Title_32ScreenCode.GDBall_953Objects2 */
/* Reuse gdjs.Title_32ScreenCode.GDBall_954Objects2 */
/* Reuse gdjs.Title_32ScreenCode.GDBall_955Objects2 */
/* Reuse gdjs.Title_32ScreenCode.GDBall_956Objects2 */
/* Reuse gdjs.Title_32ScreenCode.GDCupObjects2 */
{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\Nikolay Overchenko - Whoosh, cartoon, whirring 2.aac", false, 20, gdjs.randomFloatInRange(1.5, 1.7));
}{for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_951Objects2.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_951Objects2[i].getBehavior("Tween").addObjectPositionYTween("DropBall", (( gdjs.Title_32ScreenCode.GDCupObjects2.length === 0 ) ? 0 :gdjs.Title_32ScreenCode.GDCupObjects2[0].getPointY("")) + (gdjs.Title_32ScreenCode.GDBall_951Objects2[i].getHeight()) * 3, "easeOutSine", 500, false);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_952Objects2.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_952Objects2[i].getBehavior("Tween").addObjectPositionYTween("DropBall", (( gdjs.Title_32ScreenCode.GDCupObjects2.length === 0 ) ? 0 :gdjs.Title_32ScreenCode.GDCupObjects2[0].getPointY("")) + (gdjs.Title_32ScreenCode.GDBall_952Objects2[i].getHeight()) * 3, "easeOutSine", 500, false);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_954Objects2.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_954Objects2[i].getBehavior("Tween").addObjectPositionYTween("DropBall", (( gdjs.Title_32ScreenCode.GDCupObjects2.length === 0 ) ? 0 :gdjs.Title_32ScreenCode.GDCupObjects2[0].getPointY("")) + (gdjs.Title_32ScreenCode.GDBall_954Objects2[i].getHeight()) * 3, "easeOutSine", 500, false);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_953Objects2.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_953Objects2[i].getBehavior("Tween").addObjectPositionYTween("DropBall", (( gdjs.Title_32ScreenCode.GDCupObjects2.length === 0 ) ? 0 :gdjs.Title_32ScreenCode.GDCupObjects2[0].getPointY("")) + (gdjs.Title_32ScreenCode.GDBall_953Objects2[i].getHeight()) * 3, "easeOutSine", 500, false);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_955Objects2.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_955Objects2[i].getBehavior("Tween").addObjectPositionYTween("DropBall", (( gdjs.Title_32ScreenCode.GDCupObjects2.length === 0 ) ? 0 :gdjs.Title_32ScreenCode.GDCupObjects2[0].getPointY("")) + (gdjs.Title_32ScreenCode.GDBall_955Objects2[i].getHeight()) * 3, "easeOutSine", 500, false);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_956Objects2.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_956Objects2[i].getBehavior("Tween").addObjectPositionYTween("DropBall", (( gdjs.Title_32ScreenCode.GDCupObjects2.length === 0 ) ? 0 :gdjs.Title_32ScreenCode.GDCupObjects2[0].getPointY("")) + (gdjs.Title_32ScreenCode.GDBall_956Objects2[i].getHeight()) * 3, "easeOutSine", 500, false);
}
}
{ //Subevents
gdjs.Title_32ScreenCode.eventsList15(runtimeScene);} //End of subevents
}

}


};gdjs.Title_32ScreenCode.eventsList17 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("Cup"), gdjs.Title_32ScreenCode.GDCupObjects2);
gdjs.Title_32ScreenCode.GDBall_951Objects2.length = 0;

gdjs.Title_32ScreenCode.GDBall_952Objects2.length = 0;

gdjs.Title_32ScreenCode.GDBall_953Objects2.length = 0;

gdjs.Title_32ScreenCode.GDBall_954Objects2.length = 0;

gdjs.Title_32ScreenCode.GDBall_955Objects2.length = 0;

gdjs.Title_32ScreenCode.GDBall_956Objects2.length = 0;

{gdjs.evtTools.object.createObjectFromGroupOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDBall_95951Objects2ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95952Objects2ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95954Objects2ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95953Objects2ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95955Objects2ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95956Objects2Objects, "Ball_" + gdjs.evtTools.common.toString(gdjs.randomInRange(1, 4)), (( gdjs.Title_32ScreenCode.GDCupObjects2.length === 0 ) ? 0 :gdjs.Title_32ScreenCode.GDCupObjects2[0].getCenterXInScene()), gdjs.evtTools.camera.getCameraBorderTop(runtimeScene, "", 0) - 32, "Balls");
}
{ //Subevents
gdjs.Title_32ScreenCode.eventsList16(runtimeScene);} //End of subevents
}

}


};gdjs.Title_32ScreenCode.eventsList18 = function(runtimeScene) {

{


gdjs.Title_32ScreenCode.condition0IsTrue_0.val = false;
gdjs.Title_32ScreenCode.condition1IsTrue_0.val = false;
{
gdjs.Title_32ScreenCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("GameState")) == "DropBalls";
}if ( gdjs.Title_32ScreenCode.condition0IsTrue_0.val ) {
{
{gdjs.Title_32ScreenCode.conditionTrue_1 = gdjs.Title_32ScreenCode.condition1IsTrue_0;
gdjs.Title_32ScreenCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11345932);
}
}}
if (gdjs.Title_32ScreenCode.condition1IsTrue_0.val) {

{ //Subevents
gdjs.Title_32ScreenCode.eventsList17(runtimeScene);} //End of subevents
}

}


};gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDBall_95951Objects2ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95952Objects2ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95954Objects2ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95953Objects2ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95955Objects2ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95956Objects2Objects = Hashtable.newFrom({"Ball_1": gdjs.Title_32ScreenCode.GDBall_951Objects2, "Ball_2": gdjs.Title_32ScreenCode.GDBall_952Objects2, "Ball_4": gdjs.Title_32ScreenCode.GDBall_954Objects2, "Ball_3": gdjs.Title_32ScreenCode.GDBall_953Objects2, "Ball_5": gdjs.Title_32ScreenCode.GDBall_955Objects2, "Ball_6": gdjs.Title_32ScreenCode.GDBall_956Objects2});
gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDCupObjects2Objects = Hashtable.newFrom({"Cup": gdjs.Title_32ScreenCode.GDCupObjects2});
gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDBall_95951Objects2Objects = Hashtable.newFrom({"Ball_1": gdjs.Title_32ScreenCode.GDBall_951Objects2});
gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDBall_95952Objects2Objects = Hashtable.newFrom({"Ball_2": gdjs.Title_32ScreenCode.GDBall_952Objects2});
gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDBall_95953Objects2Objects = Hashtable.newFrom({"Ball_3": gdjs.Title_32ScreenCode.GDBall_953Objects2});
gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDBall_95954Objects2Objects = Hashtable.newFrom({"Ball_4": gdjs.Title_32ScreenCode.GDBall_954Objects2});
gdjs.Title_32ScreenCode.asyncCallback11356636 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("CupFront"), gdjs.Title_32ScreenCode.GDCupFrontObjects4);
{for(var i = 0, len = gdjs.Title_32ScreenCode.GDCupFrontObjects4.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDCupFrontObjects4[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getVariables().get("GameState").setString("SlideCupIn");
}}
gdjs.Title_32ScreenCode.eventsList19 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.Title_32ScreenCode.asyncCallback11356636(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Title_32ScreenCode.eventsList20 = function(runtimeScene) {

{


gdjs.Title_32ScreenCode.condition0IsTrue_0.val = false;
gdjs.Title_32ScreenCode.condition1IsTrue_0.val = false;
gdjs.Title_32ScreenCode.condition2IsTrue_0.val = false;
gdjs.Title_32ScreenCode.condition3IsTrue_0.val = false;
{
gdjs.Title_32ScreenCode.condition0IsTrue_0.val = gdjs.evtTools.object.getPickedInstancesCount(gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDBall_95951Objects2Objects) != 4;
}if ( gdjs.Title_32ScreenCode.condition0IsTrue_0.val ) {
{
gdjs.Title_32ScreenCode.condition1IsTrue_0.val = gdjs.evtTools.object.getPickedInstancesCount(gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDBall_95952Objects2Objects) != 4;
}if ( gdjs.Title_32ScreenCode.condition1IsTrue_0.val ) {
{
gdjs.Title_32ScreenCode.condition2IsTrue_0.val = gdjs.evtTools.object.getPickedInstancesCount(gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDBall_95953Objects2Objects) != 4;
}if ( gdjs.Title_32ScreenCode.condition2IsTrue_0.val ) {
{
gdjs.Title_32ScreenCode.condition3IsTrue_0.val = gdjs.evtTools.object.getPickedInstancesCount(gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDBall_95954Objects2Objects) != 4;
}}
}
}
if (gdjs.Title_32ScreenCode.condition3IsTrue_0.val) {
gdjs.copyArray(gdjs.Title_32ScreenCode.GDBall_951Objects2, gdjs.Title_32ScreenCode.GDBall_951Objects3);

gdjs.copyArray(gdjs.Title_32ScreenCode.GDBall_952Objects2, gdjs.Title_32ScreenCode.GDBall_952Objects3);

gdjs.copyArray(gdjs.Title_32ScreenCode.GDBall_953Objects2, gdjs.Title_32ScreenCode.GDBall_953Objects3);

gdjs.copyArray(gdjs.Title_32ScreenCode.GDBall_954Objects2, gdjs.Title_32ScreenCode.GDBall_954Objects3);

gdjs.copyArray(gdjs.Title_32ScreenCode.GDBall_955Objects2, gdjs.Title_32ScreenCode.GDBall_955Objects3);

gdjs.copyArray(gdjs.Title_32ScreenCode.GDBall_956Objects2, gdjs.Title_32ScreenCode.GDBall_956Objects3);

gdjs.copyArray(gdjs.Title_32ScreenCode.GDCupObjects2, gdjs.Title_32ScreenCode.GDCupObjects3);

{for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_951Objects3.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_951Objects3[i].getBehavior("Tween").addObjectPositionXTween("SlideOut", gdjs.evtTools.camera.getCameraBorderRight(runtimeScene, "", 0) + 64, "easeInCubic", 1000, true);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_952Objects3.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_952Objects3[i].getBehavior("Tween").addObjectPositionXTween("SlideOut", gdjs.evtTools.camera.getCameraBorderRight(runtimeScene, "", 0) + 64, "easeInCubic", 1000, true);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_954Objects3.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_954Objects3[i].getBehavior("Tween").addObjectPositionXTween("SlideOut", gdjs.evtTools.camera.getCameraBorderRight(runtimeScene, "", 0) + 64, "easeInCubic", 1000, true);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_953Objects3.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_953Objects3[i].getBehavior("Tween").addObjectPositionXTween("SlideOut", gdjs.evtTools.camera.getCameraBorderRight(runtimeScene, "", 0) + 64, "easeInCubic", 1000, true);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_955Objects3.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_955Objects3[i].getBehavior("Tween").addObjectPositionXTween("SlideOut", gdjs.evtTools.camera.getCameraBorderRight(runtimeScene, "", 0) + 64, "easeInCubic", 1000, true);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_956Objects3.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_956Objects3[i].getBehavior("Tween").addObjectPositionXTween("SlideOut", gdjs.evtTools.camera.getCameraBorderRight(runtimeScene, "", 0) + 64, "easeInCubic", 1000, true);
}
}{for(var i = 0, len = gdjs.Title_32ScreenCode.GDCupObjects3.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDCupObjects3[i].getBehavior("Tween").addObjectPositionXTween("SlideOut", gdjs.evtTools.camera.getCameraBorderRight(runtimeScene, "", 0) + 64, "easeInCubic", 1000, true);
}
}
{ //Subevents
gdjs.Title_32ScreenCode.eventsList19(runtimeScene);} //End of subevents
}

}


};gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDBall_95951Objects2Objects = Hashtable.newFrom({"Ball_1": gdjs.Title_32ScreenCode.GDBall_951Objects2});
gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDBall_95952Objects2Objects = Hashtable.newFrom({"Ball_2": gdjs.Title_32ScreenCode.GDBall_952Objects2});
gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDBall_95953Objects2Objects = Hashtable.newFrom({"Ball_3": gdjs.Title_32ScreenCode.GDBall_953Objects2});
gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDBall_95954Objects2Objects = Hashtable.newFrom({"Ball_4": gdjs.Title_32ScreenCode.GDBall_954Objects2});
gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDGlassBreaking_9595ParticlesObjects3Objects = Hashtable.newFrom({"GlassBreaking_Particles": gdjs.Title_32ScreenCode.GDGlassBreaking_95ParticlesObjects3});
gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDGlassBreaking_9595ParticlesObjects3Objects = Hashtable.newFrom({"GlassBreaking_Particles": gdjs.Title_32ScreenCode.GDGlassBreaking_95ParticlesObjects3});
gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDGlassBreaking_9595ParticlesObjects3Objects = Hashtable.newFrom({"GlassBreaking_Particles": gdjs.Title_32ScreenCode.GDGlassBreaking_95ParticlesObjects3});
gdjs.Title_32ScreenCode.eventsList21 = function(runtimeScene) {

{



}


{


{
{gdjs.evtsExt__CameraShake__CameraShake.func(runtimeScene, 20, 20, "", 0, 0.4, 0, 0, 0.10, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{



}


{


{
gdjs.copyArray(gdjs.Title_32ScreenCode.GDCupObjects2, gdjs.Title_32ScreenCode.GDCupObjects3);

gdjs.Title_32ScreenCode.GDGlassBreaking_95ParticlesObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDGlassBreaking_9595ParticlesObjects3Objects, (( gdjs.Title_32ScreenCode.GDCupObjects3.length === 0 ) ? 0 :gdjs.Title_32ScreenCode.GDCupObjects3[0].getCenterXInScene()), (( gdjs.Title_32ScreenCode.GDCupObjects3.length === 0 ) ? 0 :gdjs.Title_32ScreenCode.GDCupObjects3[0].getPointY("")) + (( gdjs.Title_32ScreenCode.GDCupObjects3.length === 0 ) ? 0 :gdjs.Title_32ScreenCode.GDCupObjects3[0].getHeight()) * 0.25, "FrontCups");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDGlassBreaking_9595ParticlesObjects3Objects, (( gdjs.Title_32ScreenCode.GDCupObjects3.length === 0 ) ? 0 :gdjs.Title_32ScreenCode.GDCupObjects3[0].getCenterXInScene()), (( gdjs.Title_32ScreenCode.GDCupObjects3.length === 0 ) ? 0 :gdjs.Title_32ScreenCode.GDCupObjects3[0].getPointY("")) + (( gdjs.Title_32ScreenCode.GDCupObjects3.length === 0 ) ? 0 :gdjs.Title_32ScreenCode.GDCupObjects3[0].getHeight()) * 0.50, "FrontCups");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDGlassBreaking_9595ParticlesObjects3Objects, (( gdjs.Title_32ScreenCode.GDCupObjects3.length === 0 ) ? 0 :gdjs.Title_32ScreenCode.GDCupObjects3[0].getCenterXInScene()), (( gdjs.Title_32ScreenCode.GDCupObjects3.length === 0 ) ? 0 :gdjs.Title_32ScreenCode.GDCupObjects3[0].getPointY("")) + (( gdjs.Title_32ScreenCode.GDCupObjects3.length === 0 ) ? 0 :gdjs.Title_32ScreenCode.GDCupObjects3[0].getHeight()) * 0.75, "FrontCups");
}{for(var i = 0, len = gdjs.Title_32ScreenCode.GDGlassBreaking_95ParticlesObjects3.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDGlassBreaking_95ParticlesObjects3[i].setZOrder((( gdjs.Title_32ScreenCode.GDCupObjects3.length === 0 ) ? 0 :gdjs.Title_32ScreenCode.GDCupObjects3[0].getZOrder()) + 1);
}
}}

}


};gdjs.Title_32ScreenCode.asyncCallback11583260 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\audio - Glass,Bottle,Break,Smash,Messy.aac", false, 20, 1);
}}
gdjs.Title_32ScreenCode.eventsList22 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.100), (runtimeScene) => (gdjs.Title_32ScreenCode.asyncCallback11583260(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Title_32ScreenCode.eventsList23 = function(runtimeScene) {

{



}


{


{
{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\Generdyn - 13.aac", false, 50, 1.3);
}
{ //Subevents
gdjs.Title_32ScreenCode.eventsList22(runtimeScene);} //End of subevents
}

}


{



}


{


gdjs.Title_32ScreenCode.condition0IsTrue_0.val = false;
{
{gdjs.Title_32ScreenCode.conditionTrue_1 = gdjs.Title_32ScreenCode.condition0IsTrue_0;
gdjs.Title_32ScreenCode.conditionTrue_1.val = (gdjs.randomInRange(1, 2) == 1);
}
}if (gdjs.Title_32ScreenCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\audio - Hit Rock Debris RBD 02.aac", false, 50, 1);
}}

}


{


gdjs.Title_32ScreenCode.condition0IsTrue_0.val = false;
{
{gdjs.Title_32ScreenCode.conditionTrue_1 = gdjs.Title_32ScreenCode.condition0IsTrue_0;
gdjs.Title_32ScreenCode.conditionTrue_1.val = (gdjs.randomInRange(1, 2) == 1);
}
}if (gdjs.Title_32ScreenCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\audio - Glass,Shards,Smash,Medium Impact,Lots of Large Shards.aac", false, 20, 1);
}}

}


};gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDBall_95951Objects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95952Objects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95954Objects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95953Objects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95955Objects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95956Objects4Objects = Hashtable.newFrom({"Ball_1": gdjs.Title_32ScreenCode.GDBall_951Objects4, "Ball_2": gdjs.Title_32ScreenCode.GDBall_952Objects4, "Ball_4": gdjs.Title_32ScreenCode.GDBall_954Objects4, "Ball_3": gdjs.Title_32ScreenCode.GDBall_953Objects4, "Ball_5": gdjs.Title_32ScreenCode.GDBall_955Objects4, "Ball_6": gdjs.Title_32ScreenCode.GDBall_956Objects4});
gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDCupObjects4Objects = Hashtable.newFrom({"Cup": gdjs.Title_32ScreenCode.GDCupObjects4});
gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDCupFrontObjects3Objects = Hashtable.newFrom({"CupFront": gdjs.Title_32ScreenCode.GDCupFrontObjects3});
gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDCupObjects3Objects = Hashtable.newFrom({"Cup": gdjs.Title_32ScreenCode.GDCupObjects3});
gdjs.Title_32ScreenCode.eventsList24 = function(runtimeScene) {

{


{
/* Reuse gdjs.Title_32ScreenCode.GDCupObjects3 */
{for(var i = 0, len = gdjs.Title_32ScreenCode.GDCupObjects3.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDCupObjects3[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.Title_32ScreenCode.eventsList25 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Title_32ScreenCode.GDBall_951Objects2, gdjs.Title_32ScreenCode.GDBall_951Objects4);

gdjs.copyArray(gdjs.Title_32ScreenCode.GDBall_952Objects2, gdjs.Title_32ScreenCode.GDBall_952Objects4);

gdjs.copyArray(gdjs.Title_32ScreenCode.GDBall_953Objects2, gdjs.Title_32ScreenCode.GDBall_953Objects4);

gdjs.copyArray(gdjs.Title_32ScreenCode.GDBall_954Objects2, gdjs.Title_32ScreenCode.GDBall_954Objects4);

gdjs.copyArray(gdjs.Title_32ScreenCode.GDBall_955Objects2, gdjs.Title_32ScreenCode.GDBall_955Objects4);

gdjs.copyArray(gdjs.Title_32ScreenCode.GDBall_956Objects2, gdjs.Title_32ScreenCode.GDBall_956Objects4);

gdjs.copyArray(gdjs.Title_32ScreenCode.GDCupObjects2, gdjs.Title_32ScreenCode.GDCupObjects4);


gdjs.Title_32ScreenCode.condition0IsTrue_0.val = false;
{
gdjs.Title_32ScreenCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDBall_95951Objects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95952Objects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95954Objects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95953Objects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95955Objects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95956Objects4Objects, gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDCupObjects4Objects, false, runtimeScene, false);
}if (gdjs.Title_32ScreenCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Title_32ScreenCode.GDBall_951Objects4 */
/* Reuse gdjs.Title_32ScreenCode.GDBall_952Objects4 */
/* Reuse gdjs.Title_32ScreenCode.GDBall_953Objects4 */
/* Reuse gdjs.Title_32ScreenCode.GDBall_954Objects4 */
/* Reuse gdjs.Title_32ScreenCode.GDBall_955Objects4 */
/* Reuse gdjs.Title_32ScreenCode.GDBall_956Objects4 */
{for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_951Objects4.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_951Objects4[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_952Objects4.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_952Objects4[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_954Objects4.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_954Objects4[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_953Objects4.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_953Objects4[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_955Objects4.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_955Objects4[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_956Objects4.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_956Objects4[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(gdjs.Title_32ScreenCode.GDCupObjects2, gdjs.Title_32ScreenCode.GDCupObjects3);

gdjs.copyArray(runtimeScene.getObjects("CupFront"), gdjs.Title_32ScreenCode.GDCupFrontObjects3);

gdjs.Title_32ScreenCode.condition0IsTrue_0.val = false;
{
gdjs.Title_32ScreenCode.condition0IsTrue_0.val = gdjs.evtsExt__Sticker__IsStuck.func(runtimeScene, gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDCupFrontObjects3Objects, "Sticker", gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDCupObjects3Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}if (gdjs.Title_32ScreenCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Title_32ScreenCode.GDCupFrontObjects3 */
{for(var i = 0, len = gdjs.Title_32ScreenCode.GDCupFrontObjects3.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDCupFrontObjects3[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.Title_32ScreenCode.eventsList24(runtimeScene);} //End of subevents
}

}


};gdjs.Title_32ScreenCode.asyncCallback11357956 = function (runtimeScene, asyncObjectsList) {
{runtimeScene.getVariables().get("GameState").setString("SlideCupIn");
}}
gdjs.Title_32ScreenCode.eventsList26 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.Title_32ScreenCode.asyncCallback11357956(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Title_32ScreenCode.eventsList27 = function(runtimeScene) {

{



}


{


gdjs.Title_32ScreenCode.eventsList21(runtimeScene);
}


{


gdjs.Title_32ScreenCode.eventsList23(runtimeScene);
}


{


gdjs.Title_32ScreenCode.eventsList25(runtimeScene);
}


{


{

{ //Subevents
gdjs.Title_32ScreenCode.eventsList26(runtimeScene);} //End of subevents
}

}


};gdjs.Title_32ScreenCode.eventsList28 = function(runtimeScene) {

{


gdjs.Title_32ScreenCode.condition0IsTrue_0.val = false;
{
{gdjs.Title_32ScreenCode.conditionTrue_1 = gdjs.Title_32ScreenCode.condition0IsTrue_0;
gdjs.Title_32ScreenCode.condition0IsTrue_1.val = false;
gdjs.Title_32ScreenCode.condition1IsTrue_1.val = false;
gdjs.Title_32ScreenCode.condition2IsTrue_1.val = false;
gdjs.Title_32ScreenCode.condition3IsTrue_1.val = false;
{
gdjs.Title_32ScreenCode.condition0IsTrue_1.val = gdjs.evtTools.object.getPickedInstancesCount(gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDBall_95951Objects2Objects) == 4;
if( gdjs.Title_32ScreenCode.condition0IsTrue_1.val ) {
    gdjs.Title_32ScreenCode.conditionTrue_1.val = true;
}
}
{
gdjs.Title_32ScreenCode.condition1IsTrue_1.val = gdjs.evtTools.object.getPickedInstancesCount(gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDBall_95952Objects2Objects) == 4;
if( gdjs.Title_32ScreenCode.condition1IsTrue_1.val ) {
    gdjs.Title_32ScreenCode.conditionTrue_1.val = true;
}
}
{
gdjs.Title_32ScreenCode.condition2IsTrue_1.val = gdjs.evtTools.object.getPickedInstancesCount(gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDBall_95953Objects2Objects) == 4;
if( gdjs.Title_32ScreenCode.condition2IsTrue_1.val ) {
    gdjs.Title_32ScreenCode.conditionTrue_1.val = true;
}
}
{
gdjs.Title_32ScreenCode.condition3IsTrue_1.val = gdjs.evtTools.object.getPickedInstancesCount(gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDBall_95954Objects2Objects) == 4;
if( gdjs.Title_32ScreenCode.condition3IsTrue_1.val ) {
    gdjs.Title_32ScreenCode.conditionTrue_1.val = true;
}
}
{
}
}
}if (gdjs.Title_32ScreenCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Title_32ScreenCode.eventsList27(runtimeScene);} //End of subevents
}

}


};gdjs.Title_32ScreenCode.eventsList29 = function(runtimeScene) {

{


gdjs.Title_32ScreenCode.eventsList20(runtimeScene);
}


{


gdjs.Title_32ScreenCode.eventsList28(runtimeScene);
}


};gdjs.Title_32ScreenCode.eventsList30 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Ball_1"), gdjs.Title_32ScreenCode.GDBall_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Ball_2"), gdjs.Title_32ScreenCode.GDBall_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Ball_3"), gdjs.Title_32ScreenCode.GDBall_953Objects2);
gdjs.copyArray(runtimeScene.getObjects("Ball_4"), gdjs.Title_32ScreenCode.GDBall_954Objects2);
gdjs.copyArray(runtimeScene.getObjects("Ball_5"), gdjs.Title_32ScreenCode.GDBall_955Objects2);
gdjs.copyArray(runtimeScene.getObjects("Ball_6"), gdjs.Title_32ScreenCode.GDBall_956Objects2);
gdjs.copyArray(runtimeScene.getObjects("Cup"), gdjs.Title_32ScreenCode.GDCupObjects2);

gdjs.Title_32ScreenCode.condition0IsTrue_0.val = false;
gdjs.Title_32ScreenCode.condition1IsTrue_0.val = false;
gdjs.Title_32ScreenCode.condition2IsTrue_0.val = false;
{
gdjs.Title_32ScreenCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("GameState")) == "CheckForMatch";
}if ( gdjs.Title_32ScreenCode.condition0IsTrue_0.val ) {
{
gdjs.Title_32ScreenCode.condition1IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDBall_95951Objects2ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95952Objects2ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95954Objects2ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95953Objects2ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95955Objects2ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95956Objects2Objects, gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDCupObjects2Objects, false, runtimeScene, false);
}if ( gdjs.Title_32ScreenCode.condition1IsTrue_0.val ) {
{
{gdjs.Title_32ScreenCode.conditionTrue_1 = gdjs.Title_32ScreenCode.condition2IsTrue_0;
gdjs.Title_32ScreenCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11354852);
}
}}
}
if (gdjs.Title_32ScreenCode.condition2IsTrue_0.val) {

{ //Subevents
gdjs.Title_32ScreenCode.eventsList29(runtimeScene);} //End of subevents
}

}


};gdjs.Title_32ScreenCode.eventsList31 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("Cloud1"), gdjs.Title_32ScreenCode.GDCloud1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Cloud2"), gdjs.Title_32ScreenCode.GDCloud2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Cloud3"), gdjs.Title_32ScreenCode.GDCloud3Objects2);
gdjs.copyArray(runtimeScene.getObjects("Cloud4"), gdjs.Title_32ScreenCode.GDCloud4Objects2);
{gdjs.evtTools.tween.tweenCamera(runtimeScene, "SlideCameraOut", gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) + gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0) + (( gdjs.Title_32ScreenCode.GDCloud4Objects2.length === 0 ) ? (( gdjs.Title_32ScreenCode.GDCloud3Objects2.length === 0 ) ? (( gdjs.Title_32ScreenCode.GDCloud2Objects2.length === 0 ) ? (( gdjs.Title_32ScreenCode.GDCloud1Objects2.length === 0 ) ? 0 :gdjs.Title_32ScreenCode.GDCloud1Objects2[0].getWidth()) :gdjs.Title_32ScreenCode.GDCloud2Objects2[0].getWidth()) :gdjs.Title_32ScreenCode.GDCloud3Objects2[0].getWidth()) :gdjs.Title_32ScreenCode.GDCloud4Objects2[0].getWidth()), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0), "", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) * 1000, "easeInBack");
}}

}


};gdjs.Title_32ScreenCode.asyncCallback11362540 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.storage.writeNumberInJSONFile("BallCupBoom", "CurrentLevel", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("CurrentLevel")));
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("CurrentLevel"))), false);
}}
gdjs.Title_32ScreenCode.eventsList32 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0))), (runtimeScene) => (gdjs.Title_32ScreenCode.asyncCallback11362540(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Title_32ScreenCode.eventsList33 = function(runtimeScene) {

{


gdjs.Title_32ScreenCode.eventsList31(runtimeScene);
}


{


{

{ //Subevents
gdjs.Title_32ScreenCode.eventsList32(runtimeScene);} //End of subevents
}

}


};gdjs.Title_32ScreenCode.eventsList34 = function(runtimeScene) {

{


gdjs.Title_32ScreenCode.condition0IsTrue_0.val = false;
{
{gdjs.Title_32ScreenCode.conditionTrue_1 = gdjs.Title_32ScreenCode.condition0IsTrue_0;
gdjs.Title_32ScreenCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11361028);
}
}if (gdjs.Title_32ScreenCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Ball_1"), gdjs.Title_32ScreenCode.GDBall_951Objects1);
gdjs.copyArray(runtimeScene.getObjects("Ball_2"), gdjs.Title_32ScreenCode.GDBall_952Objects1);
gdjs.copyArray(runtimeScene.getObjects("Ball_3"), gdjs.Title_32ScreenCode.GDBall_953Objects1);
gdjs.copyArray(runtimeScene.getObjects("Ball_4"), gdjs.Title_32ScreenCode.GDBall_954Objects1);
gdjs.copyArray(runtimeScene.getObjects("Ball_5"), gdjs.Title_32ScreenCode.GDBall_955Objects1);
gdjs.copyArray(runtimeScene.getObjects("Ball_6"), gdjs.Title_32ScreenCode.GDBall_956Objects1);
{for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_951Objects1.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_951Objects1[i].getBehavior("Tween").addObjectOpacityTween("FadeOut", 0, "linear", 500, true);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_952Objects1.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_952Objects1[i].getBehavior("Tween").addObjectOpacityTween("FadeOut", 0, "linear", 500, true);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_954Objects1.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_954Objects1[i].getBehavior("Tween").addObjectOpacityTween("FadeOut", 0, "linear", 500, true);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_953Objects1.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_953Objects1[i].getBehavior("Tween").addObjectOpacityTween("FadeOut", 0, "linear", 500, true);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_955Objects1.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_955Objects1[i].getBehavior("Tween").addObjectOpacityTween("FadeOut", 0, "linear", 500, true);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_956Objects1.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_956Objects1[i].getBehavior("Tween").addObjectOpacityTween("FadeOut", 0, "linear", 500, true);
}
}
{ //Subevents
gdjs.Title_32ScreenCode.eventsList33(runtimeScene);} //End of subevents
}

}


};gdjs.Title_32ScreenCode.eventsList35 = function(runtimeScene) {

{


gdjs.Title_32ScreenCode.condition0IsTrue_0.val = false;
{
gdjs.Title_32ScreenCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("GameState")) == "StartGame";
}if (gdjs.Title_32ScreenCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Title_32ScreenCode.eventsList34(runtimeScene);} //End of subevents
}

}


};gdjs.Title_32ScreenCode.eventsList36 = function(runtimeScene) {

{


gdjs.Title_32ScreenCode.eventsList6(runtimeScene);
}


{


gdjs.Title_32ScreenCode.eventsList18(runtimeScene);
}


{


gdjs.Title_32ScreenCode.eventsList30(runtimeScene);
}


{


gdjs.Title_32ScreenCode.eventsList35(runtimeScene);
}


};gdjs.Title_32ScreenCode.mapOfEmptyGDBall_951ObjectsEmptyGDBall_952ObjectsEmptyGDBall_954ObjectsEmptyGDBall_953ObjectsEmptyGDBall_955ObjectsEmptyGDBall_956Objects = Hashtable.newFrom({"Ball_1": [], "Ball_2": [], "Ball_4": [], "Ball_3": [], "Ball_5": [], "Ball_6": []});
gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDBall_95951Objects3ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95952Objects3ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95954Objects3ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95953Objects3ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95955Objects3ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95956Objects3Objects = Hashtable.newFrom({"Ball_1": gdjs.Title_32ScreenCode.GDBall_951Objects3, "Ball_2": gdjs.Title_32ScreenCode.GDBall_952Objects3, "Ball_4": gdjs.Title_32ScreenCode.GDBall_954Objects3, "Ball_3": gdjs.Title_32ScreenCode.GDBall_953Objects3, "Ball_5": gdjs.Title_32ScreenCode.GDBall_955Objects3, "Ball_6": gdjs.Title_32ScreenCode.GDBall_956Objects3});
gdjs.Title_32ScreenCode.eventsList37 = function(runtimeScene) {

{


{
gdjs.Title_32ScreenCode.GDBall_951Objects3.length = 0;

gdjs.Title_32ScreenCode.GDBall_952Objects3.length = 0;

gdjs.Title_32ScreenCode.GDBall_953Objects3.length = 0;

gdjs.Title_32ScreenCode.GDBall_954Objects3.length = 0;

gdjs.Title_32ScreenCode.GDBall_955Objects3.length = 0;

gdjs.Title_32ScreenCode.GDBall_956Objects3.length = 0;

{gdjs.evtTools.object.createObjectFromGroupOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDBall_95951Objects3ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95952Objects3ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95954Objects3ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95953Objects3ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95955Objects3ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95956Objects3Objects, "Ball_" + gdjs.evtTools.common.toString(gdjs.randomInRange(1, 6)), gdjs.evtTools.camera.getCameraBorderLeft(runtimeScene, "", 0) - 32, gdjs.randomInRange(gdjs.evtTools.camera.getCameraBorderTop(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraBorderBottom(runtimeScene, "", 0)), "Balls");
}{for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_951Objects3.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_951Objects3[i].addPolarForce((gdjs.Title_32ScreenCode.GDBall_951Objects3[i].getAngleToPosition(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0))), 300, 1);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_952Objects3.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_952Objects3[i].addPolarForce((gdjs.Title_32ScreenCode.GDBall_952Objects3[i].getAngleToPosition(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0))), 300, 1);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_954Objects3.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_954Objects3[i].addPolarForce((gdjs.Title_32ScreenCode.GDBall_954Objects3[i].getAngleToPosition(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0))), 300, 1);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_953Objects3.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_953Objects3[i].addPolarForce((gdjs.Title_32ScreenCode.GDBall_953Objects3[i].getAngleToPosition(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0))), 300, 1);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_955Objects3.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_955Objects3[i].addPolarForce((gdjs.Title_32ScreenCode.GDBall_955Objects3[i].getAngleToPosition(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0))), 300, 1);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_956Objects3.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_956Objects3[i].addPolarForce((gdjs.Title_32ScreenCode.GDBall_956Objects3[i].getAngleToPosition(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0))), 300, 1);
}
}{for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_951Objects3.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_951Objects3[i].setVariableBoolean(gdjs.Title_32ScreenCode.GDBall_951Objects3[i].getVariables().get("BorderAnimation"), true);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_952Objects3.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_952Objects3[i].setVariableBoolean(gdjs.Title_32ScreenCode.GDBall_952Objects3[i].getVariables().get("BorderAnimation"), true);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_954Objects3.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_954Objects3[i].setVariableBoolean(gdjs.Title_32ScreenCode.GDBall_954Objects3[i].getVariables().get("BorderAnimation"), true);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_953Objects3.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_953Objects3[i].setVariableBoolean(gdjs.Title_32ScreenCode.GDBall_953Objects3[i].getVariables().get("BorderAnimation"), true);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_955Objects3.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_955Objects3[i].setVariableBoolean(gdjs.Title_32ScreenCode.GDBall_955Objects3[i].getVariables().get("BorderAnimation"), true);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_956Objects3.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_956Objects3[i].setVariableBoolean(gdjs.Title_32ScreenCode.GDBall_956Objects3[i].getVariables().get("BorderAnimation"), true);
}
}}

}


};gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDBall_95951Objects2ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95952Objects2ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95954Objects2ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95953Objects2ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95955Objects2ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95956Objects2Objects = Hashtable.newFrom({"Ball_1": gdjs.Title_32ScreenCode.GDBall_951Objects2, "Ball_2": gdjs.Title_32ScreenCode.GDBall_952Objects2, "Ball_4": gdjs.Title_32ScreenCode.GDBall_954Objects2, "Ball_3": gdjs.Title_32ScreenCode.GDBall_953Objects2, "Ball_5": gdjs.Title_32ScreenCode.GDBall_955Objects2, "Ball_6": gdjs.Title_32ScreenCode.GDBall_956Objects2});
gdjs.Title_32ScreenCode.eventsList38 = function(runtimeScene) {

{


{
gdjs.Title_32ScreenCode.GDBall_951Objects2.length = 0;

gdjs.Title_32ScreenCode.GDBall_952Objects2.length = 0;

gdjs.Title_32ScreenCode.GDBall_953Objects2.length = 0;

gdjs.Title_32ScreenCode.GDBall_954Objects2.length = 0;

gdjs.Title_32ScreenCode.GDBall_955Objects2.length = 0;

gdjs.Title_32ScreenCode.GDBall_956Objects2.length = 0;

{gdjs.evtTools.object.createObjectFromGroupOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDBall_95951Objects2ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95952Objects2ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95954Objects2ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95953Objects2ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95955Objects2ObjectsGDgdjs_46Title_9532ScreenCode_46GDBall_95956Objects2Objects, "Ball_" + gdjs.evtTools.common.toString(gdjs.randomInRange(1, 6)), gdjs.evtTools.camera.getCameraBorderRight(runtimeScene, "", 0) + 32, gdjs.randomInRange(gdjs.evtTools.camera.getCameraBorderTop(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraBorderBottom(runtimeScene, "", 0)), "Balls");
}{for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_951Objects2.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_951Objects2[i].addPolarForce((gdjs.Title_32ScreenCode.GDBall_951Objects2[i].getAngleToPosition(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0))), 300, 1);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_952Objects2.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_952Objects2[i].addPolarForce((gdjs.Title_32ScreenCode.GDBall_952Objects2[i].getAngleToPosition(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0))), 300, 1);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_954Objects2.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_954Objects2[i].addPolarForce((gdjs.Title_32ScreenCode.GDBall_954Objects2[i].getAngleToPosition(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0))), 300, 1);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_953Objects2.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_953Objects2[i].addPolarForce((gdjs.Title_32ScreenCode.GDBall_953Objects2[i].getAngleToPosition(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0))), 300, 1);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_955Objects2.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_955Objects2[i].addPolarForce((gdjs.Title_32ScreenCode.GDBall_955Objects2[i].getAngleToPosition(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0))), 300, 1);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_956Objects2.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_956Objects2[i].addPolarForce((gdjs.Title_32ScreenCode.GDBall_956Objects2[i].getAngleToPosition(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0))), 300, 1);
}
}{for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_951Objects2.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_951Objects2[i].setVariableBoolean(gdjs.Title_32ScreenCode.GDBall_951Objects2[i].getVariables().get("BorderAnimation"), true);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_952Objects2.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_952Objects2[i].setVariableBoolean(gdjs.Title_32ScreenCode.GDBall_952Objects2[i].getVariables().get("BorderAnimation"), true);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_954Objects2.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_954Objects2[i].setVariableBoolean(gdjs.Title_32ScreenCode.GDBall_954Objects2[i].getVariables().get("BorderAnimation"), true);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_953Objects2.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_953Objects2[i].setVariableBoolean(gdjs.Title_32ScreenCode.GDBall_953Objects2[i].getVariables().get("BorderAnimation"), true);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_955Objects2.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_955Objects2[i].setVariableBoolean(gdjs.Title_32ScreenCode.GDBall_955Objects2[i].getVariables().get("BorderAnimation"), true);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_956Objects2.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_956Objects2[i].setVariableBoolean(gdjs.Title_32ScreenCode.GDBall_956Objects2[i].getVariables().get("BorderAnimation"), true);
}
}}

}


};gdjs.Title_32ScreenCode.eventsList39 = function(runtimeScene) {

{


gdjs.Title_32ScreenCode.eventsList37(runtimeScene);
}


{


gdjs.Title_32ScreenCode.eventsList38(runtimeScene);
}


};gdjs.Title_32ScreenCode.eventsList40 = function(runtimeScene) {

{


gdjs.Title_32ScreenCode.condition0IsTrue_0.val = false;
gdjs.Title_32ScreenCode.condition1IsTrue_0.val = false;
gdjs.Title_32ScreenCode.condition2IsTrue_0.val = false;
{
gdjs.Title_32ScreenCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("GameState")) != "0";
}if ( gdjs.Title_32ScreenCode.condition0IsTrue_0.val ) {
{
gdjs.Title_32ScreenCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("GameState")) != "StartGame";
}if ( gdjs.Title_32ScreenCode.condition1IsTrue_0.val ) {
{
gdjs.Title_32ScreenCode.condition2IsTrue_0.val = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Title_32ScreenCode.mapOfEmptyGDBall_951ObjectsEmptyGDBall_952ObjectsEmptyGDBall_954ObjectsEmptyGDBall_953ObjectsEmptyGDBall_955ObjectsEmptyGDBall_956Objects) < 100;
}}
}
if (gdjs.Title_32ScreenCode.condition2IsTrue_0.val) {

{ //Subevents
gdjs.Title_32ScreenCode.eventsList39(runtimeScene);} //End of subevents
}

}


};gdjs.Title_32ScreenCode.eventsList41 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Ball_1"), gdjs.Title_32ScreenCode.GDBall_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Ball_2"), gdjs.Title_32ScreenCode.GDBall_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Ball_3"), gdjs.Title_32ScreenCode.GDBall_953Objects2);
gdjs.copyArray(runtimeScene.getObjects("Ball_4"), gdjs.Title_32ScreenCode.GDBall_954Objects2);
gdjs.copyArray(runtimeScene.getObjects("Ball_5"), gdjs.Title_32ScreenCode.GDBall_955Objects2);
gdjs.copyArray(runtimeScene.getObjects("Ball_6"), gdjs.Title_32ScreenCode.GDBall_956Objects2);

gdjs.Title_32ScreenCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Title_32ScreenCode.GDBall_951Objects2.length;i<l;++i) {
    if ( gdjs.Title_32ScreenCode.GDBall_951Objects2[i].getVariableBoolean(gdjs.Title_32ScreenCode.GDBall_951Objects2[i].getVariables().get("BorderAnimation"), true) ) {
        gdjs.Title_32ScreenCode.condition0IsTrue_0.val = true;
        gdjs.Title_32ScreenCode.GDBall_951Objects2[k] = gdjs.Title_32ScreenCode.GDBall_951Objects2[i];
        ++k;
    }
}
gdjs.Title_32ScreenCode.GDBall_951Objects2.length = k;for(var i = 0, k = 0, l = gdjs.Title_32ScreenCode.GDBall_952Objects2.length;i<l;++i) {
    if ( gdjs.Title_32ScreenCode.GDBall_952Objects2[i].getVariableBoolean(gdjs.Title_32ScreenCode.GDBall_952Objects2[i].getVariables().get("BorderAnimation"), true) ) {
        gdjs.Title_32ScreenCode.condition0IsTrue_0.val = true;
        gdjs.Title_32ScreenCode.GDBall_952Objects2[k] = gdjs.Title_32ScreenCode.GDBall_952Objects2[i];
        ++k;
    }
}
gdjs.Title_32ScreenCode.GDBall_952Objects2.length = k;for(var i = 0, k = 0, l = gdjs.Title_32ScreenCode.GDBall_954Objects2.length;i<l;++i) {
    if ( gdjs.Title_32ScreenCode.GDBall_954Objects2[i].getVariableBoolean(gdjs.Title_32ScreenCode.GDBall_954Objects2[i].getVariables().get("BorderAnimation"), true) ) {
        gdjs.Title_32ScreenCode.condition0IsTrue_0.val = true;
        gdjs.Title_32ScreenCode.GDBall_954Objects2[k] = gdjs.Title_32ScreenCode.GDBall_954Objects2[i];
        ++k;
    }
}
gdjs.Title_32ScreenCode.GDBall_954Objects2.length = k;for(var i = 0, k = 0, l = gdjs.Title_32ScreenCode.GDBall_953Objects2.length;i<l;++i) {
    if ( gdjs.Title_32ScreenCode.GDBall_953Objects2[i].getVariableBoolean(gdjs.Title_32ScreenCode.GDBall_953Objects2[i].getVariables().get("BorderAnimation"), true) ) {
        gdjs.Title_32ScreenCode.condition0IsTrue_0.val = true;
        gdjs.Title_32ScreenCode.GDBall_953Objects2[k] = gdjs.Title_32ScreenCode.GDBall_953Objects2[i];
        ++k;
    }
}
gdjs.Title_32ScreenCode.GDBall_953Objects2.length = k;for(var i = 0, k = 0, l = gdjs.Title_32ScreenCode.GDBall_955Objects2.length;i<l;++i) {
    if ( gdjs.Title_32ScreenCode.GDBall_955Objects2[i].getVariableBoolean(gdjs.Title_32ScreenCode.GDBall_955Objects2[i].getVariables().get("BorderAnimation"), true) ) {
        gdjs.Title_32ScreenCode.condition0IsTrue_0.val = true;
        gdjs.Title_32ScreenCode.GDBall_955Objects2[k] = gdjs.Title_32ScreenCode.GDBall_955Objects2[i];
        ++k;
    }
}
gdjs.Title_32ScreenCode.GDBall_955Objects2.length = k;for(var i = 0, k = 0, l = gdjs.Title_32ScreenCode.GDBall_956Objects2.length;i<l;++i) {
    if ( gdjs.Title_32ScreenCode.GDBall_956Objects2[i].getVariableBoolean(gdjs.Title_32ScreenCode.GDBall_956Objects2[i].getVariables().get("BorderAnimation"), true) ) {
        gdjs.Title_32ScreenCode.condition0IsTrue_0.val = true;
        gdjs.Title_32ScreenCode.GDBall_956Objects2[k] = gdjs.Title_32ScreenCode.GDBall_956Objects2[i];
        ++k;
    }
}
gdjs.Title_32ScreenCode.GDBall_956Objects2.length = k;}if (gdjs.Title_32ScreenCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Title_32ScreenCode.GDBall_951Objects2 */
/* Reuse gdjs.Title_32ScreenCode.GDBall_952Objects2 */
/* Reuse gdjs.Title_32ScreenCode.GDBall_953Objects2 */
/* Reuse gdjs.Title_32ScreenCode.GDBall_954Objects2 */
/* Reuse gdjs.Title_32ScreenCode.GDBall_955Objects2 */
/* Reuse gdjs.Title_32ScreenCode.GDBall_956Objects2 */
{for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_951Objects2.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_951Objects2[i].addPolarForce(180 + (gdjs.Title_32ScreenCode.GDBall_951Objects2[i].getAngleToPosition(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0))), 10, 1);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_952Objects2.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_952Objects2[i].addPolarForce(180 + (gdjs.Title_32ScreenCode.GDBall_952Objects2[i].getAngleToPosition(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0))), 10, 1);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_954Objects2.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_954Objects2[i].addPolarForce(180 + (gdjs.Title_32ScreenCode.GDBall_954Objects2[i].getAngleToPosition(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0))), 10, 1);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_953Objects2.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_953Objects2[i].addPolarForce(180 + (gdjs.Title_32ScreenCode.GDBall_953Objects2[i].getAngleToPosition(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0))), 10, 1);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_955Objects2.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_955Objects2[i].addPolarForce(180 + (gdjs.Title_32ScreenCode.GDBall_955Objects2[i].getAngleToPosition(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0))), 10, 1);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_956Objects2.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_956Objects2[i].addPolarForce(180 + (gdjs.Title_32ScreenCode.GDBall_956Objects2[i].getAngleToPosition(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0))), 10, 1);
}
}}

}


};gdjs.Title_32ScreenCode.eventsList42 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Title_32ScreenCode.GDBall_951Objects2, gdjs.Title_32ScreenCode.GDBall_951Objects3);

gdjs.copyArray(gdjs.Title_32ScreenCode.GDBall_952Objects2, gdjs.Title_32ScreenCode.GDBall_952Objects3);

gdjs.copyArray(gdjs.Title_32ScreenCode.GDBall_953Objects2, gdjs.Title_32ScreenCode.GDBall_953Objects3);

gdjs.copyArray(gdjs.Title_32ScreenCode.GDBall_954Objects2, gdjs.Title_32ScreenCode.GDBall_954Objects3);

gdjs.copyArray(gdjs.Title_32ScreenCode.GDBall_955Objects2, gdjs.Title_32ScreenCode.GDBall_955Objects3);

gdjs.copyArray(gdjs.Title_32ScreenCode.GDBall_956Objects2, gdjs.Title_32ScreenCode.GDBall_956Objects3);

gdjs.copyArray(runtimeScene.getObjects("GreyButton"), gdjs.Title_32ScreenCode.GDGreyButtonObjects3);

gdjs.Title_32ScreenCode.condition0IsTrue_0.val = false;
{
{gdjs.Title_32ScreenCode.conditionTrue_1 = gdjs.Title_32ScreenCode.condition0IsTrue_0;
gdjs.Title_32ScreenCode.conditionTrue_1.val = (Math.abs((( gdjs.Title_32ScreenCode.GDBall_956Objects3.length === 0 ) ? (( gdjs.Title_32ScreenCode.GDBall_955Objects3.length === 0 ) ? (( gdjs.Title_32ScreenCode.GDBall_953Objects3.length === 0 ) ? (( gdjs.Title_32ScreenCode.GDBall_954Objects3.length === 0 ) ? (( gdjs.Title_32ScreenCode.GDBall_952Objects3.length === 0 ) ? (( gdjs.Title_32ScreenCode.GDBall_951Objects3.length === 0 ) ? 0 :gdjs.Title_32ScreenCode.GDBall_951Objects3[0].getCenterXInScene()) :gdjs.Title_32ScreenCode.GDBall_952Objects3[0].getCenterXInScene()) :gdjs.Title_32ScreenCode.GDBall_954Objects3[0].getCenterXInScene()) :gdjs.Title_32ScreenCode.GDBall_953Objects3[0].getCenterXInScene()) :gdjs.Title_32ScreenCode.GDBall_955Objects3[0].getCenterXInScene()) :gdjs.Title_32ScreenCode.GDBall_956Objects3[0].getCenterXInScene()) - (( gdjs.Title_32ScreenCode.GDGreyButtonObjects3.length === 0 ) ? 0 :gdjs.Title_32ScreenCode.GDGreyButtonObjects3[0].getCenterXInScene())) > gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0) / 2 + 64);
}
}if (gdjs.Title_32ScreenCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Title_32ScreenCode.GDBall_951Objects3 */
/* Reuse gdjs.Title_32ScreenCode.GDBall_952Objects3 */
/* Reuse gdjs.Title_32ScreenCode.GDBall_953Objects3 */
/* Reuse gdjs.Title_32ScreenCode.GDBall_954Objects3 */
/* Reuse gdjs.Title_32ScreenCode.GDBall_955Objects3 */
/* Reuse gdjs.Title_32ScreenCode.GDBall_956Objects3 */
{for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_951Objects3.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_951Objects3[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_952Objects3.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_952Objects3[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_954Objects3.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_954Objects3[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_953Objects3.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_953Objects3[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_955Objects3.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_955Objects3[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDBall_956Objects3.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDBall_956Objects3[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.Title_32ScreenCode.eventsList43 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Ball_1"), gdjs.Title_32ScreenCode.GDBall_951Objects1);
gdjs.copyArray(runtimeScene.getObjects("Ball_2"), gdjs.Title_32ScreenCode.GDBall_952Objects1);
gdjs.copyArray(runtimeScene.getObjects("Ball_3"), gdjs.Title_32ScreenCode.GDBall_953Objects1);
gdjs.copyArray(runtimeScene.getObjects("Ball_4"), gdjs.Title_32ScreenCode.GDBall_954Objects1);
gdjs.copyArray(runtimeScene.getObjects("Ball_5"), gdjs.Title_32ScreenCode.GDBall_955Objects1);
gdjs.copyArray(runtimeScene.getObjects("Ball_6"), gdjs.Title_32ScreenCode.GDBall_956Objects1);

gdjs.Title_32ScreenCode.forEachTotalCount2 = 0;
gdjs.Title_32ScreenCode.forEachObjects2.length = 0;
gdjs.Title_32ScreenCode.forEachCount0_2 = gdjs.Title_32ScreenCode.GDBall_951Objects1.length;
gdjs.Title_32ScreenCode.forEachTotalCount2 += gdjs.Title_32ScreenCode.forEachCount0_2;
gdjs.Title_32ScreenCode.forEachObjects2.push.apply(gdjs.Title_32ScreenCode.forEachObjects2,gdjs.Title_32ScreenCode.GDBall_951Objects1);
gdjs.Title_32ScreenCode.forEachCount1_2 = gdjs.Title_32ScreenCode.GDBall_952Objects1.length;
gdjs.Title_32ScreenCode.forEachTotalCount2 += gdjs.Title_32ScreenCode.forEachCount1_2;
gdjs.Title_32ScreenCode.forEachObjects2.push.apply(gdjs.Title_32ScreenCode.forEachObjects2,gdjs.Title_32ScreenCode.GDBall_952Objects1);
gdjs.Title_32ScreenCode.forEachCount2_2 = gdjs.Title_32ScreenCode.GDBall_954Objects1.length;
gdjs.Title_32ScreenCode.forEachTotalCount2 += gdjs.Title_32ScreenCode.forEachCount2_2;
gdjs.Title_32ScreenCode.forEachObjects2.push.apply(gdjs.Title_32ScreenCode.forEachObjects2,gdjs.Title_32ScreenCode.GDBall_954Objects1);
gdjs.Title_32ScreenCode.forEachCount3_2 = gdjs.Title_32ScreenCode.GDBall_953Objects1.length;
gdjs.Title_32ScreenCode.forEachTotalCount2 += gdjs.Title_32ScreenCode.forEachCount3_2;
gdjs.Title_32ScreenCode.forEachObjects2.push.apply(gdjs.Title_32ScreenCode.forEachObjects2,gdjs.Title_32ScreenCode.GDBall_953Objects1);
gdjs.Title_32ScreenCode.forEachCount4_2 = gdjs.Title_32ScreenCode.GDBall_955Objects1.length;
gdjs.Title_32ScreenCode.forEachTotalCount2 += gdjs.Title_32ScreenCode.forEachCount4_2;
gdjs.Title_32ScreenCode.forEachObjects2.push.apply(gdjs.Title_32ScreenCode.forEachObjects2,gdjs.Title_32ScreenCode.GDBall_955Objects1);
gdjs.Title_32ScreenCode.forEachCount5_2 = gdjs.Title_32ScreenCode.GDBall_956Objects1.length;
gdjs.Title_32ScreenCode.forEachTotalCount2 += gdjs.Title_32ScreenCode.forEachCount5_2;
gdjs.Title_32ScreenCode.forEachObjects2.push.apply(gdjs.Title_32ScreenCode.forEachObjects2,gdjs.Title_32ScreenCode.GDBall_956Objects1);
for(gdjs.Title_32ScreenCode.forEachIndex2 = 0;gdjs.Title_32ScreenCode.forEachIndex2 < gdjs.Title_32ScreenCode.forEachTotalCount2;++gdjs.Title_32ScreenCode.forEachIndex2) {
gdjs.Title_32ScreenCode.GDBall_951Objects2.length = 0;

gdjs.Title_32ScreenCode.GDBall_952Objects2.length = 0;

gdjs.Title_32ScreenCode.GDBall_953Objects2.length = 0;

gdjs.Title_32ScreenCode.GDBall_954Objects2.length = 0;

gdjs.Title_32ScreenCode.GDBall_955Objects2.length = 0;

gdjs.Title_32ScreenCode.GDBall_956Objects2.length = 0;


if (gdjs.Title_32ScreenCode.forEachIndex2 < gdjs.Title_32ScreenCode.forEachCount0_2) {
    gdjs.Title_32ScreenCode.GDBall_951Objects2.push(gdjs.Title_32ScreenCode.forEachObjects2[gdjs.Title_32ScreenCode.forEachIndex2]);
}
else if (gdjs.Title_32ScreenCode.forEachIndex2 < gdjs.Title_32ScreenCode.forEachCount0_2+gdjs.Title_32ScreenCode.forEachCount1_2) {
    gdjs.Title_32ScreenCode.GDBall_952Objects2.push(gdjs.Title_32ScreenCode.forEachObjects2[gdjs.Title_32ScreenCode.forEachIndex2]);
}
else if (gdjs.Title_32ScreenCode.forEachIndex2 < gdjs.Title_32ScreenCode.forEachCount0_2+gdjs.Title_32ScreenCode.forEachCount1_2+gdjs.Title_32ScreenCode.forEachCount2_2) {
    gdjs.Title_32ScreenCode.GDBall_954Objects2.push(gdjs.Title_32ScreenCode.forEachObjects2[gdjs.Title_32ScreenCode.forEachIndex2]);
}
else if (gdjs.Title_32ScreenCode.forEachIndex2 < gdjs.Title_32ScreenCode.forEachCount0_2+gdjs.Title_32ScreenCode.forEachCount1_2+gdjs.Title_32ScreenCode.forEachCount2_2+gdjs.Title_32ScreenCode.forEachCount3_2) {
    gdjs.Title_32ScreenCode.GDBall_953Objects2.push(gdjs.Title_32ScreenCode.forEachObjects2[gdjs.Title_32ScreenCode.forEachIndex2]);
}
else if (gdjs.Title_32ScreenCode.forEachIndex2 < gdjs.Title_32ScreenCode.forEachCount0_2+gdjs.Title_32ScreenCode.forEachCount1_2+gdjs.Title_32ScreenCode.forEachCount2_2+gdjs.Title_32ScreenCode.forEachCount3_2+gdjs.Title_32ScreenCode.forEachCount4_2) {
    gdjs.Title_32ScreenCode.GDBall_955Objects2.push(gdjs.Title_32ScreenCode.forEachObjects2[gdjs.Title_32ScreenCode.forEachIndex2]);
}
else if (gdjs.Title_32ScreenCode.forEachIndex2 < gdjs.Title_32ScreenCode.forEachCount0_2+gdjs.Title_32ScreenCode.forEachCount1_2+gdjs.Title_32ScreenCode.forEachCount2_2+gdjs.Title_32ScreenCode.forEachCount3_2+gdjs.Title_32ScreenCode.forEachCount4_2+gdjs.Title_32ScreenCode.forEachCount5_2) {
    gdjs.Title_32ScreenCode.GDBall_956Objects2.push(gdjs.Title_32ScreenCode.forEachObjects2[gdjs.Title_32ScreenCode.forEachIndex2]);
}
if (true) {

{ //Subevents: 
gdjs.Title_32ScreenCode.eventsList42(runtimeScene);} //Subevents end.
}
}

}


};gdjs.Title_32ScreenCode.eventsList44 = function(runtimeScene) {

{


gdjs.Title_32ScreenCode.eventsList40(runtimeScene);
}


{


gdjs.Title_32ScreenCode.eventsList41(runtimeScene);
}


{


gdjs.Title_32ScreenCode.eventsList43(runtimeScene);
}


};gdjs.Title_32ScreenCode.asyncCallback11373388 = function (runtimeScene, asyncObjectsList) {
{runtimeScene.getVariables().get("GameState").setString("SlideCupIn");
}}
gdjs.Title_32ScreenCode.eventsList45 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0))), (runtimeScene) => (gdjs.Title_32ScreenCode.asyncCallback11373388(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Title_32ScreenCode.eventsList46 = function(runtimeScene) {

{



}


{


{
{gdjs.evtTools.camera.setCameraX(runtimeScene, gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) - (gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0) + 0), "", 0);
}}

}


{



}


{


{
{gdjs.evtTools.tween.tweenCamera(runtimeScene, "SlideCameraIn", gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) + gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0), "", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) * 1000, "easeOutBack");
}}

}


{



}


{


{

{ //Subevents
gdjs.Title_32ScreenCode.eventsList45(runtimeScene);} //End of subevents
}

}


};gdjs.Title_32ScreenCode.eventsList47 = function(runtimeScene) {

{


gdjs.Title_32ScreenCode.eventsList46(runtimeScene);
}


};gdjs.Title_32ScreenCode.eventsList48 = function(runtimeScene) {

{


gdjs.Title_32ScreenCode.condition0IsTrue_0.val = false;
{
gdjs.Title_32ScreenCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Title_32ScreenCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Title_32ScreenCode.eventsList47(runtimeScene);} //End of subevents
}

}


{



}


{


{
{gdjs.evtsExt__CopyCameraSettings__CopyCameraSettings.func(runtimeScene, "", 0, "Balls", 0, true, true, true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__CopyCameraSettings__CopyCameraSettings.func(runtimeScene, "", 0, "FrontCups", 0, true, true, true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__CopyCameraSettings__CopyCameraSettings.func(runtimeScene, "", 0, "Debugging", 0, true, true, true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__CopyCameraSettings__CopyCameraSettings.func(runtimeScene, "", 0, "Clouds", 0, true, true, false, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__CopyCameraSettings__CopyCameraSettings.func(runtimeScene, "", 0, "UI", 0, true, true, false, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDGreyButtonObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDLeaderboardObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDMenuObjects4Objects = Hashtable.newFrom({"GreyButton": gdjs.Title_32ScreenCode.GDGreyButtonObjects4, "Leaderboard": gdjs.Title_32ScreenCode.GDLeaderboardObjects4, "Menu": gdjs.Title_32ScreenCode.GDMenuObjects4});
gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDPlay_9595TextObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDMainMenu_9595TextObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDResetProgress_9595TextObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDStartOver_9595TextObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDSubmit_9595TextObjects4Objects = Hashtable.newFrom({"Play_Text": gdjs.Title_32ScreenCode.GDPlay_95TextObjects4, "MainMenu_Text": gdjs.Title_32ScreenCode.GDMainMenu_95TextObjects4, "ResetProgress_Text": gdjs.Title_32ScreenCode.GDResetProgress_95TextObjects4, "StartOver_Text": gdjs.Title_32ScreenCode.GDStartOver_95TextObjects4, "Submit_Text": gdjs.Title_32ScreenCode.GDSubmit_95TextObjects4});
gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDGreyButtonObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDLeaderboardObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDMenuObjects4Objects = Hashtable.newFrom({"GreyButton": gdjs.Title_32ScreenCode.GDGreyButtonObjects4, "Leaderboard": gdjs.Title_32ScreenCode.GDLeaderboardObjects4, "Menu": gdjs.Title_32ScreenCode.GDMenuObjects4});
gdjs.Title_32ScreenCode.eventsList49 = function(runtimeScene) {

{

/* Reuse gdjs.Title_32ScreenCode.GDGreyButtonObjects4 */
/* Reuse gdjs.Title_32ScreenCode.GDLeaderboardObjects4 */
gdjs.copyArray(runtimeScene.getObjects("MainMenu_Text"), gdjs.Title_32ScreenCode.GDMainMenu_95TextObjects4);
/* Reuse gdjs.Title_32ScreenCode.GDMenuObjects4 */
gdjs.copyArray(runtimeScene.getObjects("Play_Text"), gdjs.Title_32ScreenCode.GDPlay_95TextObjects4);
gdjs.copyArray(runtimeScene.getObjects("ResetProgress_Text"), gdjs.Title_32ScreenCode.GDResetProgress_95TextObjects4);
gdjs.copyArray(runtimeScene.getObjects("StartOver_Text"), gdjs.Title_32ScreenCode.GDStartOver_95TextObjects4);
gdjs.copyArray(runtimeScene.getObjects("Submit_Text"), gdjs.Title_32ScreenCode.GDSubmit_95TextObjects4);

gdjs.Title_32ScreenCode.condition0IsTrue_0.val = false;
{
gdjs.Title_32ScreenCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDPlay_9595TextObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDMainMenu_9595TextObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDResetProgress_9595TextObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDStartOver_9595TextObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDSubmit_9595TextObjects4Objects, gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDGreyButtonObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDLeaderboardObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDMenuObjects4Objects, false, runtimeScene, false);
}if (gdjs.Title_32ScreenCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Title_32ScreenCode.GDMainMenu_95TextObjects4 */
/* Reuse gdjs.Title_32ScreenCode.GDPlay_95TextObjects4 */
/* Reuse gdjs.Title_32ScreenCode.GDResetProgress_95TextObjects4 */
/* Reuse gdjs.Title_32ScreenCode.GDStartOver_95TextObjects4 */
/* Reuse gdjs.Title_32ScreenCode.GDSubmit_95TextObjects4 */
{for(var i = 0, len = gdjs.Title_32ScreenCode.GDPlay_95TextObjects4.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDPlay_95TextObjects4[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDMainMenu_95TextObjects4.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDMainMenu_95TextObjects4[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDResetProgress_95TextObjects4.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDResetProgress_95TextObjects4[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDStartOver_95TextObjects4.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDStartOver_95TextObjects4[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDSubmit_95TextObjects4.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDSubmit_95TextObjects4[i].setColor("255;255;255");
}
}}

}


};gdjs.Title_32ScreenCode.eventsList50 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("GreyButton"), gdjs.Title_32ScreenCode.GDGreyButtonObjects4);
gdjs.copyArray(runtimeScene.getObjects("Leaderboard"), gdjs.Title_32ScreenCode.GDLeaderboardObjects4);
gdjs.copyArray(runtimeScene.getObjects("Menu"), gdjs.Title_32ScreenCode.GDMenuObjects4);

gdjs.Title_32ScreenCode.condition0IsTrue_0.val = false;
{
gdjs.Title_32ScreenCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDGreyButtonObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDLeaderboardObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDMenuObjects4Objects, runtimeScene, true, true);
}if (gdjs.Title_32ScreenCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Title_32ScreenCode.GDGreyButtonObjects4 */
/* Reuse gdjs.Title_32ScreenCode.GDLeaderboardObjects4 */
/* Reuse gdjs.Title_32ScreenCode.GDMenuObjects4 */
{for(var i = 0, len = gdjs.Title_32ScreenCode.GDGreyButtonObjects4.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDGreyButtonObjects4[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDLeaderboardObjects4.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDLeaderboardObjects4[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDMenuObjects4.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDMenuObjects4[i].setColor("255;255;255");
}
}{for(var i = 0, len = gdjs.Title_32ScreenCode.GDGreyButtonObjects4.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDGreyButtonObjects4[i].enableEffect("Effect", false);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDLeaderboardObjects4.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDLeaderboardObjects4[i].enableEffect("Effect", false);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDMenuObjects4.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDMenuObjects4[i].enableEffect("Effect", false);
}
}
{ //Subevents
gdjs.Title_32ScreenCode.eventsList49(runtimeScene);} //End of subevents
}

}


};gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDGreyButtonObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDLeaderboardObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDMenuObjects4Objects = Hashtable.newFrom({"GreyButton": gdjs.Title_32ScreenCode.GDGreyButtonObjects4, "Leaderboard": gdjs.Title_32ScreenCode.GDLeaderboardObjects4, "Menu": gdjs.Title_32ScreenCode.GDMenuObjects4});
gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDPlay_9595TextObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDMainMenu_9595TextObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDResetProgress_9595TextObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDStartOver_9595TextObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDSubmit_9595TextObjects4Objects = Hashtable.newFrom({"Play_Text": gdjs.Title_32ScreenCode.GDPlay_95TextObjects4, "MainMenu_Text": gdjs.Title_32ScreenCode.GDMainMenu_95TextObjects4, "ResetProgress_Text": gdjs.Title_32ScreenCode.GDResetProgress_95TextObjects4, "StartOver_Text": gdjs.Title_32ScreenCode.GDStartOver_95TextObjects4, "Submit_Text": gdjs.Title_32ScreenCode.GDSubmit_95TextObjects4});
gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDGreyButtonObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDLeaderboardObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDMenuObjects4Objects = Hashtable.newFrom({"GreyButton": gdjs.Title_32ScreenCode.GDGreyButtonObjects4, "Leaderboard": gdjs.Title_32ScreenCode.GDLeaderboardObjects4, "Menu": gdjs.Title_32ScreenCode.GDMenuObjects4});
gdjs.Title_32ScreenCode.eventsList51 = function(runtimeScene) {

{

/* Reuse gdjs.Title_32ScreenCode.GDGreyButtonObjects4 */
/* Reuse gdjs.Title_32ScreenCode.GDLeaderboardObjects4 */
gdjs.copyArray(runtimeScene.getObjects("MainMenu_Text"), gdjs.Title_32ScreenCode.GDMainMenu_95TextObjects4);
/* Reuse gdjs.Title_32ScreenCode.GDMenuObjects4 */
gdjs.copyArray(runtimeScene.getObjects("Play_Text"), gdjs.Title_32ScreenCode.GDPlay_95TextObjects4);
gdjs.copyArray(runtimeScene.getObjects("ResetProgress_Text"), gdjs.Title_32ScreenCode.GDResetProgress_95TextObjects4);
gdjs.copyArray(runtimeScene.getObjects("StartOver_Text"), gdjs.Title_32ScreenCode.GDStartOver_95TextObjects4);
gdjs.copyArray(runtimeScene.getObjects("Submit_Text"), gdjs.Title_32ScreenCode.GDSubmit_95TextObjects4);

gdjs.Title_32ScreenCode.condition0IsTrue_0.val = false;
{
gdjs.Title_32ScreenCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDPlay_9595TextObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDMainMenu_9595TextObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDResetProgress_9595TextObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDStartOver_9595TextObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDSubmit_9595TextObjects4Objects, gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDGreyButtonObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDLeaderboardObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDMenuObjects4Objects, false, runtimeScene, false);
}if (gdjs.Title_32ScreenCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Title_32ScreenCode.GDMainMenu_95TextObjects4 */
/* Reuse gdjs.Title_32ScreenCode.GDPlay_95TextObjects4 */
/* Reuse gdjs.Title_32ScreenCode.GDResetProgress_95TextObjects4 */
/* Reuse gdjs.Title_32ScreenCode.GDStartOver_95TextObjects4 */
/* Reuse gdjs.Title_32ScreenCode.GDSubmit_95TextObjects4 */
{for(var i = 0, len = gdjs.Title_32ScreenCode.GDPlay_95TextObjects4.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDPlay_95TextObjects4[i].setColor("241;91;181");
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDMainMenu_95TextObjects4.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDMainMenu_95TextObjects4[i].setColor("241;91;181");
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDResetProgress_95TextObjects4.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDResetProgress_95TextObjects4[i].setColor("241;91;181");
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDStartOver_95TextObjects4.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDStartOver_95TextObjects4[i].setColor("241;91;181");
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDSubmit_95TextObjects4.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDSubmit_95TextObjects4[i].setColor("241;91;181");
}
}}

}


};gdjs.Title_32ScreenCode.eventsList52 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("GreyButton"), gdjs.Title_32ScreenCode.GDGreyButtonObjects4);
gdjs.copyArray(runtimeScene.getObjects("Leaderboard"), gdjs.Title_32ScreenCode.GDLeaderboardObjects4);
gdjs.copyArray(runtimeScene.getObjects("Menu"), gdjs.Title_32ScreenCode.GDMenuObjects4);

gdjs.Title_32ScreenCode.condition0IsTrue_0.val = false;
gdjs.Title_32ScreenCode.condition1IsTrue_0.val = false;
{
gdjs.Title_32ScreenCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDGreyButtonObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDLeaderboardObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDMenuObjects4Objects, runtimeScene, true, false);
}if ( gdjs.Title_32ScreenCode.condition0IsTrue_0.val ) {
{
{gdjs.Title_32ScreenCode.conditionTrue_1 = gdjs.Title_32ScreenCode.condition1IsTrue_0;
gdjs.Title_32ScreenCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11702508);
}
}}
if (gdjs.Title_32ScreenCode.condition1IsTrue_0.val) {
/* Reuse gdjs.Title_32ScreenCode.GDGreyButtonObjects4 */
/* Reuse gdjs.Title_32ScreenCode.GDLeaderboardObjects4 */
/* Reuse gdjs.Title_32ScreenCode.GDMenuObjects4 */
{for(var i = 0, len = gdjs.Title_32ScreenCode.GDGreyButtonObjects4.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDGreyButtonObjects4[i].enableEffect("Effect", true);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDLeaderboardObjects4.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDLeaderboardObjects4[i].enableEffect("Effect", true);
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDMenuObjects4.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDMenuObjects4[i].enableEffect("Effect", true);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\audio - BLLTImpt Hit Marker 07.aac", false, 15, 4);
}
{ //Subevents
gdjs.Title_32ScreenCode.eventsList51(runtimeScene);} //End of subevents
}

}


};gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDGreyButtonObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDLeaderboardObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDMenuObjects4Objects = Hashtable.newFrom({"GreyButton": gdjs.Title_32ScreenCode.GDGreyButtonObjects4, "Leaderboard": gdjs.Title_32ScreenCode.GDLeaderboardObjects4, "Menu": gdjs.Title_32ScreenCode.GDMenuObjects4});
gdjs.Title_32ScreenCode.eventsList53 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("GreyButton"), gdjs.Title_32ScreenCode.GDGreyButtonObjects4);
gdjs.copyArray(runtimeScene.getObjects("Leaderboard"), gdjs.Title_32ScreenCode.GDLeaderboardObjects4);
gdjs.copyArray(runtimeScene.getObjects("Menu"), gdjs.Title_32ScreenCode.GDMenuObjects4);

gdjs.Title_32ScreenCode.condition0IsTrue_0.val = false;
{
gdjs.Title_32ScreenCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDGreyButtonObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDLeaderboardObjects4ObjectsGDgdjs_46Title_9532ScreenCode_46GDMenuObjects4Objects, runtimeScene, true, false);
}if (gdjs.Title_32ScreenCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Title_32ScreenCode.GDGreyButtonObjects4 */
/* Reuse gdjs.Title_32ScreenCode.GDLeaderboardObjects4 */
/* Reuse gdjs.Title_32ScreenCode.GDMenuObjects4 */
{for(var i = 0, len = gdjs.Title_32ScreenCode.GDGreyButtonObjects4.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDGreyButtonObjects4[i].setColor("74;74;74");
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDLeaderboardObjects4.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDLeaderboardObjects4[i].setColor("74;74;74");
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDMenuObjects4.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDMenuObjects4[i].setColor("74;74;74");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\audio - BLLTImpt Hit Marker 07.aac", false, 40, 2);
}}

}


};gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDGreyButtonObjects3ObjectsGDgdjs_46Title_9532ScreenCode_46GDLeaderboardObjects3ObjectsGDgdjs_46Title_9532ScreenCode_46GDMenuObjects3Objects = Hashtable.newFrom({"GreyButton": gdjs.Title_32ScreenCode.GDGreyButtonObjects3, "Leaderboard": gdjs.Title_32ScreenCode.GDLeaderboardObjects3, "Menu": gdjs.Title_32ScreenCode.GDMenuObjects3});
gdjs.Title_32ScreenCode.eventsList54 = function(runtimeScene) {

{


gdjs.Title_32ScreenCode.condition0IsTrue_0.val = false;
gdjs.Title_32ScreenCode.condition1IsTrue_0.val = false;
{
gdjs.Title_32ScreenCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.Title_32ScreenCode.condition0IsTrue_0.val ) {
{
{gdjs.Title_32ScreenCode.conditionTrue_1 = gdjs.Title_32ScreenCode.condition1IsTrue_0;
gdjs.Title_32ScreenCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11704564);
}
}}
if (gdjs.Title_32ScreenCode.condition1IsTrue_0.val) {

{ //Subevents
gdjs.Title_32ScreenCode.eventsList53(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("GreyButton"), gdjs.Title_32ScreenCode.GDGreyButtonObjects3);
gdjs.copyArray(runtimeScene.getObjects("Leaderboard"), gdjs.Title_32ScreenCode.GDLeaderboardObjects3);
gdjs.copyArray(runtimeScene.getObjects("Menu"), gdjs.Title_32ScreenCode.GDMenuObjects3);

gdjs.Title_32ScreenCode.condition0IsTrue_0.val = false;
gdjs.Title_32ScreenCode.condition1IsTrue_0.val = false;
{
gdjs.Title_32ScreenCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.Title_32ScreenCode.condition0IsTrue_0.val ) {
{
gdjs.Title_32ScreenCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDGreyButtonObjects3ObjectsGDgdjs_46Title_9532ScreenCode_46GDLeaderboardObjects3ObjectsGDgdjs_46Title_9532ScreenCode_46GDMenuObjects3Objects, runtimeScene, true, false);
}}
if (gdjs.Title_32ScreenCode.condition1IsTrue_0.val) {
/* Reuse gdjs.Title_32ScreenCode.GDGreyButtonObjects3 */
/* Reuse gdjs.Title_32ScreenCode.GDLeaderboardObjects3 */
/* Reuse gdjs.Title_32ScreenCode.GDMenuObjects3 */
{for(var i = 0, len = gdjs.Title_32ScreenCode.GDGreyButtonObjects3.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDGreyButtonObjects3[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDLeaderboardObjects3.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDLeaderboardObjects3[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.Title_32ScreenCode.GDMenuObjects3.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDMenuObjects3[i].setColor("255;255;255");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\audio - BLLTImpt Hit Marker 07.aac", false, 40, 3);
}}

}


};gdjs.Title_32ScreenCode.eventsList55 = function(runtimeScene) {

{


gdjs.Title_32ScreenCode.eventsList50(runtimeScene);
}


{


gdjs.Title_32ScreenCode.eventsList52(runtimeScene);
}


{


gdjs.Title_32ScreenCode.eventsList54(runtimeScene);
}


};gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDGreyButtonObjects2Objects = Hashtable.newFrom({"GreyButton": gdjs.Title_32ScreenCode.GDGreyButtonObjects2});
gdjs.Title_32ScreenCode.eventsList56 = function(runtimeScene) {

{



}


{


gdjs.Title_32ScreenCode.eventsList55(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("GreyButton"), gdjs.Title_32ScreenCode.GDGreyButtonObjects2);

gdjs.Title_32ScreenCode.condition0IsTrue_0.val = false;
gdjs.Title_32ScreenCode.condition1IsTrue_0.val = false;
{
gdjs.Title_32ScreenCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDGreyButtonObjects2Objects, runtimeScene, true, false);
}if ( gdjs.Title_32ScreenCode.condition0IsTrue_0.val ) {
{
gdjs.Title_32ScreenCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}}
if (gdjs.Title_32ScreenCode.condition1IsTrue_0.val) {
{runtimeScene.getVariables().get("GameState").setString("StartGame");
}}

}


};gdjs.Title_32ScreenCode.asyncCallback11624460 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "PauseMenu");
}}
gdjs.Title_32ScreenCode.eventsList57 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.25), (runtimeScene) => (gdjs.Title_32ScreenCode.asyncCallback11624460(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Title_32ScreenCode.eventsList58 = function(runtimeScene) {

{


gdjs.Title_32ScreenCode.condition0IsTrue_0.val = false;
{
{gdjs.Title_32ScreenCode.conditionTrue_1 = gdjs.Title_32ScreenCode.condition0IsTrue_0;
gdjs.Title_32ScreenCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11623788);
}
}if (gdjs.Title_32ScreenCode.condition0IsTrue_0.val) {
}

}


{


gdjs.Title_32ScreenCode.condition0IsTrue_0.val = false;
{
gdjs.Title_32ScreenCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.Title_32ScreenCode.condition0IsTrue_0.val) {
{gdjs.evtTools.window.openURL("https://bit.ly/ball-cup-boom", runtimeScene);
}
{ //Subevents
gdjs.Title_32ScreenCode.eventsList57(runtimeScene);} //End of subevents
}

}


};gdjs.Title_32ScreenCode.eventsList59 = function(runtimeScene) {

{


gdjs.Title_32ScreenCode.condition0IsTrue_0.val = false;
{
{gdjs.Title_32ScreenCode.conditionTrue_1 = gdjs.Title_32ScreenCode.condition0IsTrue_0;
gdjs.Title_32ScreenCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11623188);
}
}if (gdjs.Title_32ScreenCode.condition0IsTrue_0.val) {
}

}


{


{

{ //Subevents
gdjs.Title_32ScreenCode.eventsList58(runtimeScene);} //End of subevents
}

}


};gdjs.Title_32ScreenCode.asyncCallback11626116 = function (runtimeScene, asyncObjectsList) {
}
gdjs.Title_32ScreenCode.eventsList60 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(9), (runtimeScene) => (gdjs.Title_32ScreenCode.asyncCallback11626116(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Title_32ScreenCode.asyncCallback11625268 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Title_32ScreenCode.eventsList60(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Title_32ScreenCode.eventsList61 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(9), (runtimeScene) => (gdjs.Title_32ScreenCode.asyncCallback11625268(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Title_32ScreenCode.eventsList62 = function(runtimeScene) {

{


gdjs.Title_32ScreenCode.condition0IsTrue_0.val = false;
{
{gdjs.Title_32ScreenCode.conditionTrue_1 = gdjs.Title_32ScreenCode.condition0IsTrue_0;
gdjs.Title_32ScreenCode.condition0IsTrue_1.val = false;
gdjs.Title_32ScreenCode.condition1IsTrue_1.val = false;
{
gdjs.Title_32ScreenCode.condition0IsTrue_1.val = gdjs.evtsExt__RepeatEveryXSeconds__Repeat.func(runtimeScene, "SpinLogo", 20, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if( gdjs.Title_32ScreenCode.condition0IsTrue_1.val ) {
    gdjs.Title_32ScreenCode.conditionTrue_1.val = true;
}
}
{
gdjs.Title_32ScreenCode.condition1IsTrue_1.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if( gdjs.Title_32ScreenCode.condition1IsTrue_1.val ) {
    gdjs.Title_32ScreenCode.conditionTrue_1.val = true;
}
}
{
}
}
}if (gdjs.Title_32ScreenCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Title_32ScreenCode.eventsList61(runtimeScene);} //End of subevents
}

}


};gdjs.Title_32ScreenCode.eventsList63 = function(runtimeScene) {

{



}


{


gdjs.Title_32ScreenCode.eventsList59(runtimeScene);
}


{


gdjs.Title_32ScreenCode.eventsList62(runtimeScene);
}


};gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDLeaderboardObjects2Objects = Hashtable.newFrom({"Leaderboard": gdjs.Title_32ScreenCode.GDLeaderboardObjects2});
gdjs.Title_32ScreenCode.asyncCallback11379604 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "ViewLeaderboards", false);
}}
gdjs.Title_32ScreenCode.eventsList64 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.25), (runtimeScene) => (gdjs.Title_32ScreenCode.asyncCallback11379604(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Title_32ScreenCode.eventsList65 = function(runtimeScene) {

{


gdjs.Title_32ScreenCode.condition0IsTrue_0.val = false;
{
{gdjs.Title_32ScreenCode.conditionTrue_1 = gdjs.Title_32ScreenCode.condition0IsTrue_0;
gdjs.Title_32ScreenCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11378700);
}
}if (gdjs.Title_32ScreenCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.Title_32ScreenCode.GDLeaderboardObjects2, gdjs.Title_32ScreenCode.GDLeaderboardObjects3);

gdjs.copyArray(runtimeScene.getObjects("ViewLeaderboards_Text"), gdjs.Title_32ScreenCode.GDViewLeaderboards_95TextObjects3);
{for(var i = 0, len = gdjs.Title_32ScreenCode.GDViewLeaderboards_95TextObjects3.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDViewLeaderboards_95TextObjects3[i].getBehavior("Tween").addObjectPositionYTween("SlideUp", (( gdjs.Title_32ScreenCode.GDLeaderboardObjects3.length === 0 ) ? 0 :gdjs.Title_32ScreenCode.GDLeaderboardObjects3[0].getPointY("")), "easeOutQuad", 250, false);
}
}}

}


{


gdjs.Title_32ScreenCode.condition0IsTrue_0.val = false;
{
gdjs.Title_32ScreenCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.Title_32ScreenCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Title_32ScreenCode.eventsList64(runtimeScene);} //End of subevents
}

}


};gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDLeaderboardObjects1Objects = Hashtable.newFrom({"Leaderboard": gdjs.Title_32ScreenCode.GDLeaderboardObjects1});
gdjs.Title_32ScreenCode.eventsList66 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Leaderboard"), gdjs.Title_32ScreenCode.GDLeaderboardObjects2);

gdjs.Title_32ScreenCode.condition0IsTrue_0.val = false;
{
gdjs.Title_32ScreenCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDLeaderboardObjects2Objects, runtimeScene, true, false);
}if (gdjs.Title_32ScreenCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Title_32ScreenCode.eventsList65(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Leaderboard"), gdjs.Title_32ScreenCode.GDLeaderboardObjects1);

gdjs.Title_32ScreenCode.condition0IsTrue_0.val = false;
gdjs.Title_32ScreenCode.condition1IsTrue_0.val = false;
{
gdjs.Title_32ScreenCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Title_32ScreenCode.mapOfGDgdjs_46Title_9532ScreenCode_46GDLeaderboardObjects1Objects, runtimeScene, true, true);
}if ( gdjs.Title_32ScreenCode.condition0IsTrue_0.val ) {
{
{gdjs.Title_32ScreenCode.conditionTrue_1 = gdjs.Title_32ScreenCode.condition1IsTrue_0;
gdjs.Title_32ScreenCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11379020);
}
}}
if (gdjs.Title_32ScreenCode.condition1IsTrue_0.val) {
/* Reuse gdjs.Title_32ScreenCode.GDLeaderboardObjects1 */
gdjs.copyArray(runtimeScene.getObjects("ViewLeaderboards_Text"), gdjs.Title_32ScreenCode.GDViewLeaderboards_95TextObjects1);
{for(var i = 0, len = gdjs.Title_32ScreenCode.GDViewLeaderboards_95TextObjects1.length ;i < len;++i) {
    gdjs.Title_32ScreenCode.GDViewLeaderboards_95TextObjects1[i].getBehavior("Tween").addObjectPositionYTween("SlideDown", (( gdjs.Title_32ScreenCode.GDLeaderboardObjects1.length === 0 ) ? 0 :gdjs.Title_32ScreenCode.GDLeaderboardObjects1[0].getPointY("")) + 128, "easeOutQuad", 250, false);
}
}}

}


};gdjs.Title_32ScreenCode.eventsList67 = function(runtimeScene) {

{


gdjs.Title_32ScreenCode.eventsList48(runtimeScene);
}


{


gdjs.Title_32ScreenCode.eventsList56(runtimeScene);
}


{


gdjs.Title_32ScreenCode.eventsList63(runtimeScene);
}


{


gdjs.Title_32ScreenCode.eventsList66(runtimeScene);
}


};gdjs.Title_32ScreenCode.eventsList68 = function(runtimeScene) {

{


gdjs.Title_32ScreenCode.eventsList3(runtimeScene);
}


{


gdjs.Title_32ScreenCode.eventsList36(runtimeScene);
}


{


gdjs.Title_32ScreenCode.eventsList44(runtimeScene);
}


{


gdjs.Title_32ScreenCode.eventsList67(runtimeScene);
}


};

gdjs.Title_32ScreenCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Title_32ScreenCode.GDBall_951Objects1.length = 0;
gdjs.Title_32ScreenCode.GDBall_951Objects2.length = 0;
gdjs.Title_32ScreenCode.GDBall_951Objects3.length = 0;
gdjs.Title_32ScreenCode.GDBall_951Objects4.length = 0;
gdjs.Title_32ScreenCode.GDBall_951Objects5.length = 0;
gdjs.Title_32ScreenCode.GDBall_951Objects6.length = 0;
gdjs.Title_32ScreenCode.GDBall_951Objects7.length = 0;
gdjs.Title_32ScreenCode.GDBall_952Objects1.length = 0;
gdjs.Title_32ScreenCode.GDBall_952Objects2.length = 0;
gdjs.Title_32ScreenCode.GDBall_952Objects3.length = 0;
gdjs.Title_32ScreenCode.GDBall_952Objects4.length = 0;
gdjs.Title_32ScreenCode.GDBall_952Objects5.length = 0;
gdjs.Title_32ScreenCode.GDBall_952Objects6.length = 0;
gdjs.Title_32ScreenCode.GDBall_952Objects7.length = 0;
gdjs.Title_32ScreenCode.GDBall_953Objects1.length = 0;
gdjs.Title_32ScreenCode.GDBall_953Objects2.length = 0;
gdjs.Title_32ScreenCode.GDBall_953Objects3.length = 0;
gdjs.Title_32ScreenCode.GDBall_953Objects4.length = 0;
gdjs.Title_32ScreenCode.GDBall_953Objects5.length = 0;
gdjs.Title_32ScreenCode.GDBall_953Objects6.length = 0;
gdjs.Title_32ScreenCode.GDBall_953Objects7.length = 0;
gdjs.Title_32ScreenCode.GDBall_954Objects1.length = 0;
gdjs.Title_32ScreenCode.GDBall_954Objects2.length = 0;
gdjs.Title_32ScreenCode.GDBall_954Objects3.length = 0;
gdjs.Title_32ScreenCode.GDBall_954Objects4.length = 0;
gdjs.Title_32ScreenCode.GDBall_954Objects5.length = 0;
gdjs.Title_32ScreenCode.GDBall_954Objects6.length = 0;
gdjs.Title_32ScreenCode.GDBall_954Objects7.length = 0;
gdjs.Title_32ScreenCode.GDBall_955Objects1.length = 0;
gdjs.Title_32ScreenCode.GDBall_955Objects2.length = 0;
gdjs.Title_32ScreenCode.GDBall_955Objects3.length = 0;
gdjs.Title_32ScreenCode.GDBall_955Objects4.length = 0;
gdjs.Title_32ScreenCode.GDBall_955Objects5.length = 0;
gdjs.Title_32ScreenCode.GDBall_955Objects6.length = 0;
gdjs.Title_32ScreenCode.GDBall_955Objects7.length = 0;
gdjs.Title_32ScreenCode.GDBall_956Objects1.length = 0;
gdjs.Title_32ScreenCode.GDBall_956Objects2.length = 0;
gdjs.Title_32ScreenCode.GDBall_956Objects3.length = 0;
gdjs.Title_32ScreenCode.GDBall_956Objects4.length = 0;
gdjs.Title_32ScreenCode.GDBall_956Objects5.length = 0;
gdjs.Title_32ScreenCode.GDBall_956Objects6.length = 0;
gdjs.Title_32ScreenCode.GDBall_956Objects7.length = 0;
gdjs.Title_32ScreenCode.GDGlassBreaking_95ParticlesObjects1.length = 0;
gdjs.Title_32ScreenCode.GDGlassBreaking_95ParticlesObjects2.length = 0;
gdjs.Title_32ScreenCode.GDGlassBreaking_95ParticlesObjects3.length = 0;
gdjs.Title_32ScreenCode.GDGlassBreaking_95ParticlesObjects4.length = 0;
gdjs.Title_32ScreenCode.GDGlassBreaking_95ParticlesObjects5.length = 0;
gdjs.Title_32ScreenCode.GDGlassBreaking_95ParticlesObjects6.length = 0;
gdjs.Title_32ScreenCode.GDGlassBreaking_95ParticlesObjects7.length = 0;
gdjs.Title_32ScreenCode.GDCupObjects1.length = 0;
gdjs.Title_32ScreenCode.GDCupObjects2.length = 0;
gdjs.Title_32ScreenCode.GDCupObjects3.length = 0;
gdjs.Title_32ScreenCode.GDCupObjects4.length = 0;
gdjs.Title_32ScreenCode.GDCupObjects5.length = 0;
gdjs.Title_32ScreenCode.GDCupObjects6.length = 0;
gdjs.Title_32ScreenCode.GDCupObjects7.length = 0;
gdjs.Title_32ScreenCode.GDCupFrontObjects1.length = 0;
gdjs.Title_32ScreenCode.GDCupFrontObjects2.length = 0;
gdjs.Title_32ScreenCode.GDCupFrontObjects3.length = 0;
gdjs.Title_32ScreenCode.GDCupFrontObjects4.length = 0;
gdjs.Title_32ScreenCode.GDCupFrontObjects5.length = 0;
gdjs.Title_32ScreenCode.GDCupFrontObjects6.length = 0;
gdjs.Title_32ScreenCode.GDCupFrontObjects7.length = 0;
gdjs.Title_32ScreenCode.GDCloud1Objects1.length = 0;
gdjs.Title_32ScreenCode.GDCloud1Objects2.length = 0;
gdjs.Title_32ScreenCode.GDCloud1Objects3.length = 0;
gdjs.Title_32ScreenCode.GDCloud1Objects4.length = 0;
gdjs.Title_32ScreenCode.GDCloud1Objects5.length = 0;
gdjs.Title_32ScreenCode.GDCloud1Objects6.length = 0;
gdjs.Title_32ScreenCode.GDCloud1Objects7.length = 0;
gdjs.Title_32ScreenCode.GDCloud2Objects1.length = 0;
gdjs.Title_32ScreenCode.GDCloud2Objects2.length = 0;
gdjs.Title_32ScreenCode.GDCloud2Objects3.length = 0;
gdjs.Title_32ScreenCode.GDCloud2Objects4.length = 0;
gdjs.Title_32ScreenCode.GDCloud2Objects5.length = 0;
gdjs.Title_32ScreenCode.GDCloud2Objects6.length = 0;
gdjs.Title_32ScreenCode.GDCloud2Objects7.length = 0;
gdjs.Title_32ScreenCode.GDCloud3Objects1.length = 0;
gdjs.Title_32ScreenCode.GDCloud3Objects2.length = 0;
gdjs.Title_32ScreenCode.GDCloud3Objects3.length = 0;
gdjs.Title_32ScreenCode.GDCloud3Objects4.length = 0;
gdjs.Title_32ScreenCode.GDCloud3Objects5.length = 0;
gdjs.Title_32ScreenCode.GDCloud3Objects6.length = 0;
gdjs.Title_32ScreenCode.GDCloud3Objects7.length = 0;
gdjs.Title_32ScreenCode.GDCloud4Objects1.length = 0;
gdjs.Title_32ScreenCode.GDCloud4Objects2.length = 0;
gdjs.Title_32ScreenCode.GDCloud4Objects3.length = 0;
gdjs.Title_32ScreenCode.GDCloud4Objects4.length = 0;
gdjs.Title_32ScreenCode.GDCloud4Objects5.length = 0;
gdjs.Title_32ScreenCode.GDCloud4Objects6.length = 0;
gdjs.Title_32ScreenCode.GDCloud4Objects7.length = 0;
gdjs.Title_32ScreenCode.GDEditInGDevelop_95TextObjects1.length = 0;
gdjs.Title_32ScreenCode.GDEditInGDevelop_95TextObjects2.length = 0;
gdjs.Title_32ScreenCode.GDEditInGDevelop_95TextObjects3.length = 0;
gdjs.Title_32ScreenCode.GDEditInGDevelop_95TextObjects4.length = 0;
gdjs.Title_32ScreenCode.GDEditInGDevelop_95TextObjects5.length = 0;
gdjs.Title_32ScreenCode.GDEditInGDevelop_95TextObjects6.length = 0;
gdjs.Title_32ScreenCode.GDEditInGDevelop_95TextObjects7.length = 0;
gdjs.Title_32ScreenCode.GDGreyButtonObjects1.length = 0;
gdjs.Title_32ScreenCode.GDGreyButtonObjects2.length = 0;
gdjs.Title_32ScreenCode.GDGreyButtonObjects3.length = 0;
gdjs.Title_32ScreenCode.GDGreyButtonObjects4.length = 0;
gdjs.Title_32ScreenCode.GDGreyButtonObjects5.length = 0;
gdjs.Title_32ScreenCode.GDGreyButtonObjects6.length = 0;
gdjs.Title_32ScreenCode.GDGreyButtonObjects7.length = 0;
gdjs.Title_32ScreenCode.GDCurrentLevel_95TextObjects1.length = 0;
gdjs.Title_32ScreenCode.GDCurrentLevel_95TextObjects2.length = 0;
gdjs.Title_32ScreenCode.GDCurrentLevel_95TextObjects3.length = 0;
gdjs.Title_32ScreenCode.GDCurrentLevel_95TextObjects4.length = 0;
gdjs.Title_32ScreenCode.GDCurrentLevel_95TextObjects5.length = 0;
gdjs.Title_32ScreenCode.GDCurrentLevel_95TextObjects6.length = 0;
gdjs.Title_32ScreenCode.GDCurrentLevel_95TextObjects7.length = 0;
gdjs.Title_32ScreenCode.GDMenuObjects1.length = 0;
gdjs.Title_32ScreenCode.GDMenuObjects2.length = 0;
gdjs.Title_32ScreenCode.GDMenuObjects3.length = 0;
gdjs.Title_32ScreenCode.GDMenuObjects4.length = 0;
gdjs.Title_32ScreenCode.GDMenuObjects5.length = 0;
gdjs.Title_32ScreenCode.GDMenuObjects6.length = 0;
gdjs.Title_32ScreenCode.GDMenuObjects7.length = 0;
gdjs.Title_32ScreenCode.GDGameState_95TextObjects1.length = 0;
gdjs.Title_32ScreenCode.GDGameState_95TextObjects2.length = 0;
gdjs.Title_32ScreenCode.GDGameState_95TextObjects3.length = 0;
gdjs.Title_32ScreenCode.GDGameState_95TextObjects4.length = 0;
gdjs.Title_32ScreenCode.GDGameState_95TextObjects5.length = 0;
gdjs.Title_32ScreenCode.GDGameState_95TextObjects6.length = 0;
gdjs.Title_32ScreenCode.GDGameState_95TextObjects7.length = 0;
gdjs.Title_32ScreenCode.GDMovesMade_95TextObjects1.length = 0;
gdjs.Title_32ScreenCode.GDMovesMade_95TextObjects2.length = 0;
gdjs.Title_32ScreenCode.GDMovesMade_95TextObjects3.length = 0;
gdjs.Title_32ScreenCode.GDMovesMade_95TextObjects4.length = 0;
gdjs.Title_32ScreenCode.GDMovesMade_95TextObjects5.length = 0;
gdjs.Title_32ScreenCode.GDMovesMade_95TextObjects6.length = 0;
gdjs.Title_32ScreenCode.GDMovesMade_95TextObjects7.length = 0;
gdjs.Title_32ScreenCode.GDTimeSpent_95TextObjects1.length = 0;
gdjs.Title_32ScreenCode.GDTimeSpent_95TextObjects2.length = 0;
gdjs.Title_32ScreenCode.GDTimeSpent_95TextObjects3.length = 0;
gdjs.Title_32ScreenCode.GDTimeSpent_95TextObjects4.length = 0;
gdjs.Title_32ScreenCode.GDTimeSpent_95TextObjects5.length = 0;
gdjs.Title_32ScreenCode.GDTimeSpent_95TextObjects6.length = 0;
gdjs.Title_32ScreenCode.GDTimeSpent_95TextObjects7.length = 0;
gdjs.Title_32ScreenCode.GDBallsInCup_95TextObjects1.length = 0;
gdjs.Title_32ScreenCode.GDBallsInCup_95TextObjects2.length = 0;
gdjs.Title_32ScreenCode.GDBallsInCup_95TextObjects3.length = 0;
gdjs.Title_32ScreenCode.GDBallsInCup_95TextObjects4.length = 0;
gdjs.Title_32ScreenCode.GDBallsInCup_95TextObjects5.length = 0;
gdjs.Title_32ScreenCode.GDBallsInCup_95TextObjects6.length = 0;
gdjs.Title_32ScreenCode.GDBallsInCup_95TextObjects7.length = 0;
gdjs.Title_32ScreenCode.GDPlay_95TextObjects1.length = 0;
gdjs.Title_32ScreenCode.GDPlay_95TextObjects2.length = 0;
gdjs.Title_32ScreenCode.GDPlay_95TextObjects3.length = 0;
gdjs.Title_32ScreenCode.GDPlay_95TextObjects4.length = 0;
gdjs.Title_32ScreenCode.GDPlay_95TextObjects5.length = 0;
gdjs.Title_32ScreenCode.GDPlay_95TextObjects6.length = 0;
gdjs.Title_32ScreenCode.GDPlay_95TextObjects7.length = 0;
gdjs.Title_32ScreenCode.GDLeaderboardObjects1.length = 0;
gdjs.Title_32ScreenCode.GDLeaderboardObjects2.length = 0;
gdjs.Title_32ScreenCode.GDLeaderboardObjects3.length = 0;
gdjs.Title_32ScreenCode.GDLeaderboardObjects4.length = 0;
gdjs.Title_32ScreenCode.GDLeaderboardObjects5.length = 0;
gdjs.Title_32ScreenCode.GDLeaderboardObjects6.length = 0;
gdjs.Title_32ScreenCode.GDLeaderboardObjects7.length = 0;
gdjs.Title_32ScreenCode.GDMainMenu_95TextObjects1.length = 0;
gdjs.Title_32ScreenCode.GDMainMenu_95TextObjects2.length = 0;
gdjs.Title_32ScreenCode.GDMainMenu_95TextObjects3.length = 0;
gdjs.Title_32ScreenCode.GDMainMenu_95TextObjects4.length = 0;
gdjs.Title_32ScreenCode.GDMainMenu_95TextObjects5.length = 0;
gdjs.Title_32ScreenCode.GDMainMenu_95TextObjects6.length = 0;
gdjs.Title_32ScreenCode.GDMainMenu_95TextObjects7.length = 0;
gdjs.Title_32ScreenCode.GDResetProgress_95TextObjects1.length = 0;
gdjs.Title_32ScreenCode.GDResetProgress_95TextObjects2.length = 0;
gdjs.Title_32ScreenCode.GDResetProgress_95TextObjects3.length = 0;
gdjs.Title_32ScreenCode.GDResetProgress_95TextObjects4.length = 0;
gdjs.Title_32ScreenCode.GDResetProgress_95TextObjects5.length = 0;
gdjs.Title_32ScreenCode.GDResetProgress_95TextObjects6.length = 0;
gdjs.Title_32ScreenCode.GDResetProgress_95TextObjects7.length = 0;
gdjs.Title_32ScreenCode.GDStartOver_95TextObjects1.length = 0;
gdjs.Title_32ScreenCode.GDStartOver_95TextObjects2.length = 0;
gdjs.Title_32ScreenCode.GDStartOver_95TextObjects3.length = 0;
gdjs.Title_32ScreenCode.GDStartOver_95TextObjects4.length = 0;
gdjs.Title_32ScreenCode.GDStartOver_95TextObjects5.length = 0;
gdjs.Title_32ScreenCode.GDStartOver_95TextObjects6.length = 0;
gdjs.Title_32ScreenCode.GDStartOver_95TextObjects7.length = 0;
gdjs.Title_32ScreenCode.GDSubmit_95TextObjects1.length = 0;
gdjs.Title_32ScreenCode.GDSubmit_95TextObjects2.length = 0;
gdjs.Title_32ScreenCode.GDSubmit_95TextObjects3.length = 0;
gdjs.Title_32ScreenCode.GDSubmit_95TextObjects4.length = 0;
gdjs.Title_32ScreenCode.GDSubmit_95TextObjects5.length = 0;
gdjs.Title_32ScreenCode.GDSubmit_95TextObjects6.length = 0;
gdjs.Title_32ScreenCode.GDSubmit_95TextObjects7.length = 0;
gdjs.Title_32ScreenCode.GDBall_95TextObjects1.length = 0;
gdjs.Title_32ScreenCode.GDBall_95TextObjects2.length = 0;
gdjs.Title_32ScreenCode.GDBall_95TextObjects3.length = 0;
gdjs.Title_32ScreenCode.GDBall_95TextObjects4.length = 0;
gdjs.Title_32ScreenCode.GDBall_95TextObjects5.length = 0;
gdjs.Title_32ScreenCode.GDBall_95TextObjects6.length = 0;
gdjs.Title_32ScreenCode.GDBall_95TextObjects7.length = 0;
gdjs.Title_32ScreenCode.GDViewLeaderboards_95TextObjects1.length = 0;
gdjs.Title_32ScreenCode.GDViewLeaderboards_95TextObjects2.length = 0;
gdjs.Title_32ScreenCode.GDViewLeaderboards_95TextObjects3.length = 0;
gdjs.Title_32ScreenCode.GDViewLeaderboards_95TextObjects4.length = 0;
gdjs.Title_32ScreenCode.GDViewLeaderboards_95TextObjects5.length = 0;
gdjs.Title_32ScreenCode.GDViewLeaderboards_95TextObjects6.length = 0;
gdjs.Title_32ScreenCode.GDViewLeaderboards_95TextObjects7.length = 0;
gdjs.Title_32ScreenCode.GDCup_95TextObjects1.length = 0;
gdjs.Title_32ScreenCode.GDCup_95TextObjects2.length = 0;
gdjs.Title_32ScreenCode.GDCup_95TextObjects3.length = 0;
gdjs.Title_32ScreenCode.GDCup_95TextObjects4.length = 0;
gdjs.Title_32ScreenCode.GDCup_95TextObjects5.length = 0;
gdjs.Title_32ScreenCode.GDCup_95TextObjects6.length = 0;
gdjs.Title_32ScreenCode.GDCup_95TextObjects7.length = 0;
gdjs.Title_32ScreenCode.GDBoom_95TextObjects1.length = 0;
gdjs.Title_32ScreenCode.GDBoom_95TextObjects2.length = 0;
gdjs.Title_32ScreenCode.GDBoom_95TextObjects3.length = 0;
gdjs.Title_32ScreenCode.GDBoom_95TextObjects4.length = 0;
gdjs.Title_32ScreenCode.GDBoom_95TextObjects5.length = 0;
gdjs.Title_32ScreenCode.GDBoom_95TextObjects6.length = 0;
gdjs.Title_32ScreenCode.GDBoom_95TextObjects7.length = 0;

gdjs.Title_32ScreenCode.eventsList68(runtimeScene);

return;

}

gdjs['Title_32ScreenCode'] = gdjs.Title_32ScreenCode;
