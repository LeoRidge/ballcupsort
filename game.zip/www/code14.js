gdjs.ScreenSaverCode = {};
gdjs.ScreenSaverCode.forEachCount0_3 = 0;

gdjs.ScreenSaverCode.forEachCount1_3 = 0;

gdjs.ScreenSaverCode.forEachCount2_3 = 0;

gdjs.ScreenSaverCode.forEachCount3_3 = 0;

gdjs.ScreenSaverCode.forEachCount4_3 = 0;

gdjs.ScreenSaverCode.forEachCount5_3 = 0;

gdjs.ScreenSaverCode.forEachIndex3 = 0;

gdjs.ScreenSaverCode.forEachObjects3 = [];

gdjs.ScreenSaverCode.forEachTotalCount3 = 0;

gdjs.ScreenSaverCode.repeatCount3 = 0;

gdjs.ScreenSaverCode.repeatCount4 = 0;

gdjs.ScreenSaverCode.repeatIndex3 = 0;

gdjs.ScreenSaverCode.repeatIndex4 = 0;

gdjs.ScreenSaverCode.GDBall_951Objects1= [];
gdjs.ScreenSaverCode.GDBall_951Objects2= [];
gdjs.ScreenSaverCode.GDBall_951Objects3= [];
gdjs.ScreenSaverCode.GDBall_951Objects4= [];
gdjs.ScreenSaverCode.GDBall_951Objects5= [];
gdjs.ScreenSaverCode.GDBall_951Objects6= [];
gdjs.ScreenSaverCode.GDBall_952Objects1= [];
gdjs.ScreenSaverCode.GDBall_952Objects2= [];
gdjs.ScreenSaverCode.GDBall_952Objects3= [];
gdjs.ScreenSaverCode.GDBall_952Objects4= [];
gdjs.ScreenSaverCode.GDBall_952Objects5= [];
gdjs.ScreenSaverCode.GDBall_952Objects6= [];
gdjs.ScreenSaverCode.GDBall_953Objects1= [];
gdjs.ScreenSaverCode.GDBall_953Objects2= [];
gdjs.ScreenSaverCode.GDBall_953Objects3= [];
gdjs.ScreenSaverCode.GDBall_953Objects4= [];
gdjs.ScreenSaverCode.GDBall_953Objects5= [];
gdjs.ScreenSaverCode.GDBall_953Objects6= [];
gdjs.ScreenSaverCode.GDBall_954Objects1= [];
gdjs.ScreenSaverCode.GDBall_954Objects2= [];
gdjs.ScreenSaverCode.GDBall_954Objects3= [];
gdjs.ScreenSaverCode.GDBall_954Objects4= [];
gdjs.ScreenSaverCode.GDBall_954Objects5= [];
gdjs.ScreenSaverCode.GDBall_954Objects6= [];
gdjs.ScreenSaverCode.GDBall_955Objects1= [];
gdjs.ScreenSaverCode.GDBall_955Objects2= [];
gdjs.ScreenSaverCode.GDBall_955Objects3= [];
gdjs.ScreenSaverCode.GDBall_955Objects4= [];
gdjs.ScreenSaverCode.GDBall_955Objects5= [];
gdjs.ScreenSaverCode.GDBall_955Objects6= [];
gdjs.ScreenSaverCode.GDBall_956Objects1= [];
gdjs.ScreenSaverCode.GDBall_956Objects2= [];
gdjs.ScreenSaverCode.GDBall_956Objects3= [];
gdjs.ScreenSaverCode.GDBall_956Objects4= [];
gdjs.ScreenSaverCode.GDBall_956Objects5= [];
gdjs.ScreenSaverCode.GDBall_956Objects6= [];
gdjs.ScreenSaverCode.GDGlassBreaking_95ParticlesObjects1= [];
gdjs.ScreenSaverCode.GDGlassBreaking_95ParticlesObjects2= [];
gdjs.ScreenSaverCode.GDGlassBreaking_95ParticlesObjects3= [];
gdjs.ScreenSaverCode.GDGlassBreaking_95ParticlesObjects4= [];
gdjs.ScreenSaverCode.GDGlassBreaking_95ParticlesObjects5= [];
gdjs.ScreenSaverCode.GDGlassBreaking_95ParticlesObjects6= [];
gdjs.ScreenSaverCode.GDCupObjects1= [];
gdjs.ScreenSaverCode.GDCupObjects2= [];
gdjs.ScreenSaverCode.GDCupObjects3= [];
gdjs.ScreenSaverCode.GDCupObjects4= [];
gdjs.ScreenSaverCode.GDCupObjects5= [];
gdjs.ScreenSaverCode.GDCupObjects6= [];
gdjs.ScreenSaverCode.GDCupFrontObjects1= [];
gdjs.ScreenSaverCode.GDCupFrontObjects2= [];
gdjs.ScreenSaverCode.GDCupFrontObjects3= [];
gdjs.ScreenSaverCode.GDCupFrontObjects4= [];
gdjs.ScreenSaverCode.GDCupFrontObjects5= [];
gdjs.ScreenSaverCode.GDCupFrontObjects6= [];
gdjs.ScreenSaverCode.GDCloud1Objects1= [];
gdjs.ScreenSaverCode.GDCloud1Objects2= [];
gdjs.ScreenSaverCode.GDCloud1Objects3= [];
gdjs.ScreenSaverCode.GDCloud1Objects4= [];
gdjs.ScreenSaverCode.GDCloud1Objects5= [];
gdjs.ScreenSaverCode.GDCloud1Objects6= [];
gdjs.ScreenSaverCode.GDCloud2Objects1= [];
gdjs.ScreenSaverCode.GDCloud2Objects2= [];
gdjs.ScreenSaverCode.GDCloud2Objects3= [];
gdjs.ScreenSaverCode.GDCloud2Objects4= [];
gdjs.ScreenSaverCode.GDCloud2Objects5= [];
gdjs.ScreenSaverCode.GDCloud2Objects6= [];
gdjs.ScreenSaverCode.GDCloud3Objects1= [];
gdjs.ScreenSaverCode.GDCloud3Objects2= [];
gdjs.ScreenSaverCode.GDCloud3Objects3= [];
gdjs.ScreenSaverCode.GDCloud3Objects4= [];
gdjs.ScreenSaverCode.GDCloud3Objects5= [];
gdjs.ScreenSaverCode.GDCloud3Objects6= [];
gdjs.ScreenSaverCode.GDCloud4Objects1= [];
gdjs.ScreenSaverCode.GDCloud4Objects2= [];
gdjs.ScreenSaverCode.GDCloud4Objects3= [];
gdjs.ScreenSaverCode.GDCloud4Objects4= [];
gdjs.ScreenSaverCode.GDCloud4Objects5= [];
gdjs.ScreenSaverCode.GDCloud4Objects6= [];
gdjs.ScreenSaverCode.GDEditInGDevelop_95TextObjects1= [];
gdjs.ScreenSaverCode.GDEditInGDevelop_95TextObjects2= [];
gdjs.ScreenSaverCode.GDEditInGDevelop_95TextObjects3= [];
gdjs.ScreenSaverCode.GDEditInGDevelop_95TextObjects4= [];
gdjs.ScreenSaverCode.GDEditInGDevelop_95TextObjects5= [];
gdjs.ScreenSaverCode.GDEditInGDevelop_95TextObjects6= [];
gdjs.ScreenSaverCode.GDGreyButtonObjects1= [];
gdjs.ScreenSaverCode.GDGreyButtonObjects2= [];
gdjs.ScreenSaverCode.GDGreyButtonObjects3= [];
gdjs.ScreenSaverCode.GDGreyButtonObjects4= [];
gdjs.ScreenSaverCode.GDGreyButtonObjects5= [];
gdjs.ScreenSaverCode.GDGreyButtonObjects6= [];
gdjs.ScreenSaverCode.GDCurrentLevel_95TextObjects1= [];
gdjs.ScreenSaverCode.GDCurrentLevel_95TextObjects2= [];
gdjs.ScreenSaverCode.GDCurrentLevel_95TextObjects3= [];
gdjs.ScreenSaverCode.GDCurrentLevel_95TextObjects4= [];
gdjs.ScreenSaverCode.GDCurrentLevel_95TextObjects5= [];
gdjs.ScreenSaverCode.GDCurrentLevel_95TextObjects6= [];
gdjs.ScreenSaverCode.GDMenuObjects1= [];
gdjs.ScreenSaverCode.GDMenuObjects2= [];
gdjs.ScreenSaverCode.GDMenuObjects3= [];
gdjs.ScreenSaverCode.GDMenuObjects4= [];
gdjs.ScreenSaverCode.GDMenuObjects5= [];
gdjs.ScreenSaverCode.GDMenuObjects6= [];
gdjs.ScreenSaverCode.GDGameState_95TextObjects1= [];
gdjs.ScreenSaverCode.GDGameState_95TextObjects2= [];
gdjs.ScreenSaverCode.GDGameState_95TextObjects3= [];
gdjs.ScreenSaverCode.GDGameState_95TextObjects4= [];
gdjs.ScreenSaverCode.GDGameState_95TextObjects5= [];
gdjs.ScreenSaverCode.GDGameState_95TextObjects6= [];
gdjs.ScreenSaverCode.GDMovesMade_95TextObjects1= [];
gdjs.ScreenSaverCode.GDMovesMade_95TextObjects2= [];
gdjs.ScreenSaverCode.GDMovesMade_95TextObjects3= [];
gdjs.ScreenSaverCode.GDMovesMade_95TextObjects4= [];
gdjs.ScreenSaverCode.GDMovesMade_95TextObjects5= [];
gdjs.ScreenSaverCode.GDMovesMade_95TextObjects6= [];
gdjs.ScreenSaverCode.GDTimeSpent_95TextObjects1= [];
gdjs.ScreenSaverCode.GDTimeSpent_95TextObjects2= [];
gdjs.ScreenSaverCode.GDTimeSpent_95TextObjects3= [];
gdjs.ScreenSaverCode.GDTimeSpent_95TextObjects4= [];
gdjs.ScreenSaverCode.GDTimeSpent_95TextObjects5= [];
gdjs.ScreenSaverCode.GDTimeSpent_95TextObjects6= [];
gdjs.ScreenSaverCode.GDBallsInCup_95TextObjects1= [];
gdjs.ScreenSaverCode.GDBallsInCup_95TextObjects2= [];
gdjs.ScreenSaverCode.GDBallsInCup_95TextObjects3= [];
gdjs.ScreenSaverCode.GDBallsInCup_95TextObjects4= [];
gdjs.ScreenSaverCode.GDBallsInCup_95TextObjects5= [];
gdjs.ScreenSaverCode.GDBallsInCup_95TextObjects6= [];
gdjs.ScreenSaverCode.GDPlay_95TextObjects1= [];
gdjs.ScreenSaverCode.GDPlay_95TextObjects2= [];
gdjs.ScreenSaverCode.GDPlay_95TextObjects3= [];
gdjs.ScreenSaverCode.GDPlay_95TextObjects4= [];
gdjs.ScreenSaverCode.GDPlay_95TextObjects5= [];
gdjs.ScreenSaverCode.GDPlay_95TextObjects6= [];
gdjs.ScreenSaverCode.GDLeaderboardObjects1= [];
gdjs.ScreenSaverCode.GDLeaderboardObjects2= [];
gdjs.ScreenSaverCode.GDLeaderboardObjects3= [];
gdjs.ScreenSaverCode.GDLeaderboardObjects4= [];
gdjs.ScreenSaverCode.GDLeaderboardObjects5= [];
gdjs.ScreenSaverCode.GDLeaderboardObjects6= [];
gdjs.ScreenSaverCode.GDMainMenu_95TextObjects1= [];
gdjs.ScreenSaverCode.GDMainMenu_95TextObjects2= [];
gdjs.ScreenSaverCode.GDMainMenu_95TextObjects3= [];
gdjs.ScreenSaverCode.GDMainMenu_95TextObjects4= [];
gdjs.ScreenSaverCode.GDMainMenu_95TextObjects5= [];
gdjs.ScreenSaverCode.GDMainMenu_95TextObjects6= [];
gdjs.ScreenSaverCode.GDResetProgress_95TextObjects1= [];
gdjs.ScreenSaverCode.GDResetProgress_95TextObjects2= [];
gdjs.ScreenSaverCode.GDResetProgress_95TextObjects3= [];
gdjs.ScreenSaverCode.GDResetProgress_95TextObjects4= [];
gdjs.ScreenSaverCode.GDResetProgress_95TextObjects5= [];
gdjs.ScreenSaverCode.GDResetProgress_95TextObjects6= [];
gdjs.ScreenSaverCode.GDStartOver_95TextObjects1= [];
gdjs.ScreenSaverCode.GDStartOver_95TextObjects2= [];
gdjs.ScreenSaverCode.GDStartOver_95TextObjects3= [];
gdjs.ScreenSaverCode.GDStartOver_95TextObjects4= [];
gdjs.ScreenSaverCode.GDStartOver_95TextObjects5= [];
gdjs.ScreenSaverCode.GDStartOver_95TextObjects6= [];
gdjs.ScreenSaverCode.GDSubmit_95TextObjects1= [];
gdjs.ScreenSaverCode.GDSubmit_95TextObjects2= [];
gdjs.ScreenSaverCode.GDSubmit_95TextObjects3= [];
gdjs.ScreenSaverCode.GDSubmit_95TextObjects4= [];
gdjs.ScreenSaverCode.GDSubmit_95TextObjects5= [];
gdjs.ScreenSaverCode.GDSubmit_95TextObjects6= [];
gdjs.ScreenSaverCode.GDResetWarning_95TextObjects1= [];
gdjs.ScreenSaverCode.GDResetWarning_95TextObjects2= [];
gdjs.ScreenSaverCode.GDResetWarning_95TextObjects3= [];
gdjs.ScreenSaverCode.GDResetWarning_95TextObjects4= [];
gdjs.ScreenSaverCode.GDResetWarning_95TextObjects5= [];
gdjs.ScreenSaverCode.GDResetWarning_95TextObjects6= [];
gdjs.ScreenSaverCode.GDPaused_95TextObjects1= [];
gdjs.ScreenSaverCode.GDPaused_95TextObjects2= [];
gdjs.ScreenSaverCode.GDPaused_95TextObjects3= [];
gdjs.ScreenSaverCode.GDPaused_95TextObjects4= [];
gdjs.ScreenSaverCode.GDPaused_95TextObjects5= [];
gdjs.ScreenSaverCode.GDPaused_95TextObjects6= [];
gdjs.ScreenSaverCode.GDBouncerGObjects1= [];
gdjs.ScreenSaverCode.GDBouncerGObjects2= [];
gdjs.ScreenSaverCode.GDBouncerGObjects3= [];
gdjs.ScreenSaverCode.GDBouncerGObjects4= [];
gdjs.ScreenSaverCode.GDBouncerGObjects5= [];
gdjs.ScreenSaverCode.GDBouncerGObjects6= [];
gdjs.ScreenSaverCode.GDGdevelopGLogoBlackObjects1= [];
gdjs.ScreenSaverCode.GDGdevelopGLogoBlackObjects2= [];
gdjs.ScreenSaverCode.GDGdevelopGLogoBlackObjects3= [];
gdjs.ScreenSaverCode.GDGdevelopGLogoBlackObjects4= [];
gdjs.ScreenSaverCode.GDGdevelopGLogoBlackObjects5= [];
gdjs.ScreenSaverCode.GDGdevelopGLogoBlackObjects6= [];

gdjs.ScreenSaverCode.conditionTrue_0 = {val:false};
gdjs.ScreenSaverCode.condition0IsTrue_0 = {val:false};
gdjs.ScreenSaverCode.condition1IsTrue_0 = {val:false};


gdjs.ScreenSaverCode.mapOfEmptyGDBall_951ObjectsEmptyGDBall_952ObjectsEmptyGDBall_954ObjectsEmptyGDBall_953ObjectsEmptyGDBall_955ObjectsEmptyGDBall_956Objects = Hashtable.newFrom({"Ball_1": [], "Ball_2": [], "Ball_4": [], "Ball_3": [], "Ball_5": [], "Ball_6": []});
gdjs.ScreenSaverCode.mapOfGDgdjs_46ScreenSaverCode_46GDBall_95951Objects3ObjectsGDgdjs_46ScreenSaverCode_46GDBall_95952Objects3ObjectsGDgdjs_46ScreenSaverCode_46GDBall_95954Objects3ObjectsGDgdjs_46ScreenSaverCode_46GDBall_95953Objects3ObjectsGDgdjs_46ScreenSaverCode_46GDBall_95955Objects3ObjectsGDgdjs_46ScreenSaverCode_46GDBall_95956Objects3Objects = Hashtable.newFrom({"Ball_1": gdjs.ScreenSaverCode.GDBall_951Objects3, "Ball_2": gdjs.ScreenSaverCode.GDBall_952Objects3, "Ball_4": gdjs.ScreenSaverCode.GDBall_954Objects3, "Ball_3": gdjs.ScreenSaverCode.GDBall_953Objects3, "Ball_5": gdjs.ScreenSaverCode.GDBall_955Objects3, "Ball_6": gdjs.ScreenSaverCode.GDBall_956Objects3});
gdjs.ScreenSaverCode.eventsList0 = function(runtimeScene) {

{


{
gdjs.ScreenSaverCode.GDBall_951Objects3.length = 0;

gdjs.ScreenSaverCode.GDBall_952Objects3.length = 0;

gdjs.ScreenSaverCode.GDBall_953Objects3.length = 0;

gdjs.ScreenSaverCode.GDBall_954Objects3.length = 0;

gdjs.ScreenSaverCode.GDBall_955Objects3.length = 0;

gdjs.ScreenSaverCode.GDBall_956Objects3.length = 0;

{gdjs.evtTools.object.createObjectFromGroupOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.ScreenSaverCode.mapOfGDgdjs_46ScreenSaverCode_46GDBall_95951Objects3ObjectsGDgdjs_46ScreenSaverCode_46GDBall_95952Objects3ObjectsGDgdjs_46ScreenSaverCode_46GDBall_95954Objects3ObjectsGDgdjs_46ScreenSaverCode_46GDBall_95953Objects3ObjectsGDgdjs_46ScreenSaverCode_46GDBall_95955Objects3ObjectsGDgdjs_46ScreenSaverCode_46GDBall_95956Objects3Objects, "Ball_" + gdjs.evtTools.common.toString(gdjs.randomInRange(1, 6)), gdjs.randomInRange(gdjs.evtTools.camera.getCameraBorderLeft(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraBorderRight(runtimeScene, "", 0)), gdjs.evtTools.camera.getCameraBorderBottom(runtimeScene, "", 0) + 32, "Balls");
}{for(var i = 0, len = gdjs.ScreenSaverCode.GDBall_951Objects3.length ;i < len;++i) {
    gdjs.ScreenSaverCode.GDBall_951Objects3[i].addPolarForce((gdjs.ScreenSaverCode.GDBall_951Objects3[i].getAngleToPosition(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0))), 700, 1);
}
for(var i = 0, len = gdjs.ScreenSaverCode.GDBall_952Objects3.length ;i < len;++i) {
    gdjs.ScreenSaverCode.GDBall_952Objects3[i].addPolarForce((gdjs.ScreenSaverCode.GDBall_952Objects3[i].getAngleToPosition(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0))), 700, 1);
}
for(var i = 0, len = gdjs.ScreenSaverCode.GDBall_954Objects3.length ;i < len;++i) {
    gdjs.ScreenSaverCode.GDBall_954Objects3[i].addPolarForce((gdjs.ScreenSaverCode.GDBall_954Objects3[i].getAngleToPosition(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0))), 700, 1);
}
for(var i = 0, len = gdjs.ScreenSaverCode.GDBall_953Objects3.length ;i < len;++i) {
    gdjs.ScreenSaverCode.GDBall_953Objects3[i].addPolarForce((gdjs.ScreenSaverCode.GDBall_953Objects3[i].getAngleToPosition(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0))), 700, 1);
}
for(var i = 0, len = gdjs.ScreenSaverCode.GDBall_955Objects3.length ;i < len;++i) {
    gdjs.ScreenSaverCode.GDBall_955Objects3[i].addPolarForce((gdjs.ScreenSaverCode.GDBall_955Objects3[i].getAngleToPosition(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0))), 700, 1);
}
for(var i = 0, len = gdjs.ScreenSaverCode.GDBall_956Objects3.length ;i < len;++i) {
    gdjs.ScreenSaverCode.GDBall_956Objects3[i].addPolarForce((gdjs.ScreenSaverCode.GDBall_956Objects3[i].getAngleToPosition(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0))), 700, 1);
}
}}

}


};gdjs.ScreenSaverCode.mapOfGDgdjs_46ScreenSaverCode_46GDBall_95951Objects3ObjectsGDgdjs_46ScreenSaverCode_46GDBall_95952Objects3ObjectsGDgdjs_46ScreenSaverCode_46GDBall_95954Objects3ObjectsGDgdjs_46ScreenSaverCode_46GDBall_95953Objects3ObjectsGDgdjs_46ScreenSaverCode_46GDBall_95955Objects3ObjectsGDgdjs_46ScreenSaverCode_46GDBall_95956Objects3Objects = Hashtable.newFrom({"Ball_1": gdjs.ScreenSaverCode.GDBall_951Objects3, "Ball_2": gdjs.ScreenSaverCode.GDBall_952Objects3, "Ball_4": gdjs.ScreenSaverCode.GDBall_954Objects3, "Ball_3": gdjs.ScreenSaverCode.GDBall_953Objects3, "Ball_5": gdjs.ScreenSaverCode.GDBall_955Objects3, "Ball_6": gdjs.ScreenSaverCode.GDBall_956Objects3});
gdjs.ScreenSaverCode.eventsList1 = function(runtimeScene) {

{


{
gdjs.ScreenSaverCode.GDBall_951Objects3.length = 0;

gdjs.ScreenSaverCode.GDBall_952Objects3.length = 0;

gdjs.ScreenSaverCode.GDBall_953Objects3.length = 0;

gdjs.ScreenSaverCode.GDBall_954Objects3.length = 0;

gdjs.ScreenSaverCode.GDBall_955Objects3.length = 0;

gdjs.ScreenSaverCode.GDBall_956Objects3.length = 0;

{gdjs.evtTools.object.createObjectFromGroupOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.ScreenSaverCode.mapOfGDgdjs_46ScreenSaverCode_46GDBall_95951Objects3ObjectsGDgdjs_46ScreenSaverCode_46GDBall_95952Objects3ObjectsGDgdjs_46ScreenSaverCode_46GDBall_95954Objects3ObjectsGDgdjs_46ScreenSaverCode_46GDBall_95953Objects3ObjectsGDgdjs_46ScreenSaverCode_46GDBall_95955Objects3ObjectsGDgdjs_46ScreenSaverCode_46GDBall_95956Objects3Objects, "Ball_" + gdjs.evtTools.common.toString(gdjs.randomInRange(1, 6)), gdjs.randomInRange(gdjs.evtTools.camera.getCameraBorderLeft(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraBorderRight(runtimeScene, "", 0)), gdjs.evtTools.camera.getCameraBorderTop(runtimeScene, "", 0) - 32, "Balls");
}{for(var i = 0, len = gdjs.ScreenSaverCode.GDBall_951Objects3.length ;i < len;++i) {
    gdjs.ScreenSaverCode.GDBall_951Objects3[i].addPolarForce((gdjs.ScreenSaverCode.GDBall_951Objects3[i].getAngleToPosition(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0))), 700, 1);
}
for(var i = 0, len = gdjs.ScreenSaverCode.GDBall_952Objects3.length ;i < len;++i) {
    gdjs.ScreenSaverCode.GDBall_952Objects3[i].addPolarForce((gdjs.ScreenSaverCode.GDBall_952Objects3[i].getAngleToPosition(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0))), 700, 1);
}
for(var i = 0, len = gdjs.ScreenSaverCode.GDBall_954Objects3.length ;i < len;++i) {
    gdjs.ScreenSaverCode.GDBall_954Objects3[i].addPolarForce((gdjs.ScreenSaverCode.GDBall_954Objects3[i].getAngleToPosition(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0))), 700, 1);
}
for(var i = 0, len = gdjs.ScreenSaverCode.GDBall_953Objects3.length ;i < len;++i) {
    gdjs.ScreenSaverCode.GDBall_953Objects3[i].addPolarForce((gdjs.ScreenSaverCode.GDBall_953Objects3[i].getAngleToPosition(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0))), 700, 1);
}
for(var i = 0, len = gdjs.ScreenSaverCode.GDBall_955Objects3.length ;i < len;++i) {
    gdjs.ScreenSaverCode.GDBall_955Objects3[i].addPolarForce((gdjs.ScreenSaverCode.GDBall_955Objects3[i].getAngleToPosition(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0))), 700, 1);
}
for(var i = 0, len = gdjs.ScreenSaverCode.GDBall_956Objects3.length ;i < len;++i) {
    gdjs.ScreenSaverCode.GDBall_956Objects3[i].addPolarForce((gdjs.ScreenSaverCode.GDBall_956Objects3[i].getAngleToPosition(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0))), 700, 1);
}
}}

}


};gdjs.ScreenSaverCode.mapOfGDgdjs_46ScreenSaverCode_46GDBall_95951Objects5ObjectsGDgdjs_46ScreenSaverCode_46GDBall_95952Objects5ObjectsGDgdjs_46ScreenSaverCode_46GDBall_95954Objects5ObjectsGDgdjs_46ScreenSaverCode_46GDBall_95953Objects5ObjectsGDgdjs_46ScreenSaverCode_46GDBall_95955Objects5ObjectsGDgdjs_46ScreenSaverCode_46GDBall_95956Objects5Objects = Hashtable.newFrom({"Ball_1": gdjs.ScreenSaverCode.GDBall_951Objects5, "Ball_2": gdjs.ScreenSaverCode.GDBall_952Objects5, "Ball_4": gdjs.ScreenSaverCode.GDBall_954Objects5, "Ball_3": gdjs.ScreenSaverCode.GDBall_953Objects5, "Ball_5": gdjs.ScreenSaverCode.GDBall_955Objects5, "Ball_6": gdjs.ScreenSaverCode.GDBall_956Objects5});
gdjs.ScreenSaverCode.eventsList2 = function(runtimeScene) {

{


{
gdjs.ScreenSaverCode.GDBall_951Objects5.length = 0;

gdjs.ScreenSaverCode.GDBall_952Objects5.length = 0;

gdjs.ScreenSaverCode.GDBall_953Objects5.length = 0;

gdjs.ScreenSaverCode.GDBall_954Objects5.length = 0;

gdjs.ScreenSaverCode.GDBall_955Objects5.length = 0;

gdjs.ScreenSaverCode.GDBall_956Objects5.length = 0;

{gdjs.evtTools.object.createObjectFromGroupOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.ScreenSaverCode.mapOfGDgdjs_46ScreenSaverCode_46GDBall_95951Objects5ObjectsGDgdjs_46ScreenSaverCode_46GDBall_95952Objects5ObjectsGDgdjs_46ScreenSaverCode_46GDBall_95954Objects5ObjectsGDgdjs_46ScreenSaverCode_46GDBall_95953Objects5ObjectsGDgdjs_46ScreenSaverCode_46GDBall_95955Objects5ObjectsGDgdjs_46ScreenSaverCode_46GDBall_95956Objects5Objects, "Ball_" + gdjs.evtTools.common.toString(gdjs.randomInRange(1, 6)), gdjs.evtTools.camera.getCameraBorderLeft(runtimeScene, "", 0), gdjs.randomInRange(gdjs.evtTools.camera.getCameraBorderTop(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraBorderBottom(runtimeScene, "", 0)), "Balls");
}{for(var i = 0, len = gdjs.ScreenSaverCode.GDBall_951Objects5.length ;i < len;++i) {
    gdjs.ScreenSaverCode.GDBall_951Objects5[i].addPolarForce((gdjs.ScreenSaverCode.GDBall_951Objects5[i].getAngleToPosition(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0))), 400, 1);
}
for(var i = 0, len = gdjs.ScreenSaverCode.GDBall_952Objects5.length ;i < len;++i) {
    gdjs.ScreenSaverCode.GDBall_952Objects5[i].addPolarForce((gdjs.ScreenSaverCode.GDBall_952Objects5[i].getAngleToPosition(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0))), 400, 1);
}
for(var i = 0, len = gdjs.ScreenSaverCode.GDBall_954Objects5.length ;i < len;++i) {
    gdjs.ScreenSaverCode.GDBall_954Objects5[i].addPolarForce((gdjs.ScreenSaverCode.GDBall_954Objects5[i].getAngleToPosition(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0))), 400, 1);
}
for(var i = 0, len = gdjs.ScreenSaverCode.GDBall_953Objects5.length ;i < len;++i) {
    gdjs.ScreenSaverCode.GDBall_953Objects5[i].addPolarForce((gdjs.ScreenSaverCode.GDBall_953Objects5[i].getAngleToPosition(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0))), 400, 1);
}
for(var i = 0, len = gdjs.ScreenSaverCode.GDBall_955Objects5.length ;i < len;++i) {
    gdjs.ScreenSaverCode.GDBall_955Objects5[i].addPolarForce((gdjs.ScreenSaverCode.GDBall_955Objects5[i].getAngleToPosition(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0))), 400, 1);
}
for(var i = 0, len = gdjs.ScreenSaverCode.GDBall_956Objects5.length ;i < len;++i) {
    gdjs.ScreenSaverCode.GDBall_956Objects5[i].addPolarForce((gdjs.ScreenSaverCode.GDBall_956Objects5[i].getAngleToPosition(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0))), 400, 1);
}
}}

}


};gdjs.ScreenSaverCode.eventsList3 = function(runtimeScene) {

{


gdjs.ScreenSaverCode.repeatCount4 = 2;
for(gdjs.ScreenSaverCode.repeatIndex4 = 0;gdjs.ScreenSaverCode.repeatIndex4 < gdjs.ScreenSaverCode.repeatCount4;++gdjs.ScreenSaverCode.repeatIndex4) {

if (true)
{

{ //Subevents: 
gdjs.ScreenSaverCode.eventsList2(runtimeScene);} //Subevents end.
}
}

}


};gdjs.ScreenSaverCode.mapOfGDgdjs_46ScreenSaverCode_46GDBall_95951Objects4ObjectsGDgdjs_46ScreenSaverCode_46GDBall_95952Objects4ObjectsGDgdjs_46ScreenSaverCode_46GDBall_95954Objects4ObjectsGDgdjs_46ScreenSaverCode_46GDBall_95953Objects4ObjectsGDgdjs_46ScreenSaverCode_46GDBall_95955Objects4ObjectsGDgdjs_46ScreenSaverCode_46GDBall_95956Objects4Objects = Hashtable.newFrom({"Ball_1": gdjs.ScreenSaverCode.GDBall_951Objects4, "Ball_2": gdjs.ScreenSaverCode.GDBall_952Objects4, "Ball_4": gdjs.ScreenSaverCode.GDBall_954Objects4, "Ball_3": gdjs.ScreenSaverCode.GDBall_953Objects4, "Ball_5": gdjs.ScreenSaverCode.GDBall_955Objects4, "Ball_6": gdjs.ScreenSaverCode.GDBall_956Objects4});
gdjs.ScreenSaverCode.eventsList4 = function(runtimeScene) {

{


{
gdjs.ScreenSaverCode.GDBall_951Objects4.length = 0;

gdjs.ScreenSaverCode.GDBall_952Objects4.length = 0;

gdjs.ScreenSaverCode.GDBall_953Objects4.length = 0;

gdjs.ScreenSaverCode.GDBall_954Objects4.length = 0;

gdjs.ScreenSaverCode.GDBall_955Objects4.length = 0;

gdjs.ScreenSaverCode.GDBall_956Objects4.length = 0;

{gdjs.evtTools.object.createObjectFromGroupOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.ScreenSaverCode.mapOfGDgdjs_46ScreenSaverCode_46GDBall_95951Objects4ObjectsGDgdjs_46ScreenSaverCode_46GDBall_95952Objects4ObjectsGDgdjs_46ScreenSaverCode_46GDBall_95954Objects4ObjectsGDgdjs_46ScreenSaverCode_46GDBall_95953Objects4ObjectsGDgdjs_46ScreenSaverCode_46GDBall_95955Objects4ObjectsGDgdjs_46ScreenSaverCode_46GDBall_95956Objects4Objects, "Ball_" + gdjs.evtTools.common.toString(gdjs.randomInRange(1, 6)), gdjs.evtTools.camera.getCameraBorderRight(runtimeScene, "", 0), gdjs.randomInRange(gdjs.evtTools.camera.getCameraBorderTop(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraBorderBottom(runtimeScene, "", 0)), "Balls");
}{for(var i = 0, len = gdjs.ScreenSaverCode.GDBall_951Objects4.length ;i < len;++i) {
    gdjs.ScreenSaverCode.GDBall_951Objects4[i].addPolarForce((gdjs.ScreenSaverCode.GDBall_951Objects4[i].getAngleToPosition(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0))), 400, 1);
}
for(var i = 0, len = gdjs.ScreenSaverCode.GDBall_952Objects4.length ;i < len;++i) {
    gdjs.ScreenSaverCode.GDBall_952Objects4[i].addPolarForce((gdjs.ScreenSaverCode.GDBall_952Objects4[i].getAngleToPosition(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0))), 400, 1);
}
for(var i = 0, len = gdjs.ScreenSaverCode.GDBall_954Objects4.length ;i < len;++i) {
    gdjs.ScreenSaverCode.GDBall_954Objects4[i].addPolarForce((gdjs.ScreenSaverCode.GDBall_954Objects4[i].getAngleToPosition(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0))), 400, 1);
}
for(var i = 0, len = gdjs.ScreenSaverCode.GDBall_953Objects4.length ;i < len;++i) {
    gdjs.ScreenSaverCode.GDBall_953Objects4[i].addPolarForce((gdjs.ScreenSaverCode.GDBall_953Objects4[i].getAngleToPosition(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0))), 400, 1);
}
for(var i = 0, len = gdjs.ScreenSaverCode.GDBall_955Objects4.length ;i < len;++i) {
    gdjs.ScreenSaverCode.GDBall_955Objects4[i].addPolarForce((gdjs.ScreenSaverCode.GDBall_955Objects4[i].getAngleToPosition(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0))), 400, 1);
}
for(var i = 0, len = gdjs.ScreenSaverCode.GDBall_956Objects4.length ;i < len;++i) {
    gdjs.ScreenSaverCode.GDBall_956Objects4[i].addPolarForce((gdjs.ScreenSaverCode.GDBall_956Objects4[i].getAngleToPosition(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0))), 400, 1);
}
}}

}


};gdjs.ScreenSaverCode.eventsList5 = function(runtimeScene) {

{


gdjs.ScreenSaverCode.repeatCount3 = 2;
for(gdjs.ScreenSaverCode.repeatIndex3 = 0;gdjs.ScreenSaverCode.repeatIndex3 < gdjs.ScreenSaverCode.repeatCount3;++gdjs.ScreenSaverCode.repeatIndex3) {

if (true)
{

{ //Subevents: 
gdjs.ScreenSaverCode.eventsList4(runtimeScene);} //Subevents end.
}
}

}


};gdjs.ScreenSaverCode.eventsList6 = function(runtimeScene) {

{


gdjs.ScreenSaverCode.eventsList0(runtimeScene);
}


{


gdjs.ScreenSaverCode.eventsList1(runtimeScene);
}


{


gdjs.ScreenSaverCode.eventsList3(runtimeScene);
}


{


gdjs.ScreenSaverCode.eventsList5(runtimeScene);
}


};gdjs.ScreenSaverCode.eventsList7 = function(runtimeScene) {

{


gdjs.ScreenSaverCode.condition0IsTrue_0.val = false;
{
gdjs.ScreenSaverCode.condition0IsTrue_0.val = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.ScreenSaverCode.mapOfEmptyGDBall_951ObjectsEmptyGDBall_952ObjectsEmptyGDBall_954ObjectsEmptyGDBall_953ObjectsEmptyGDBall_955ObjectsEmptyGDBall_956Objects) < 500;
}if (gdjs.ScreenSaverCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.ScreenSaverCode.eventsList6(runtimeScene);} //End of subevents
}

}


};gdjs.ScreenSaverCode.eventsList8 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("Ball_1"), gdjs.ScreenSaverCode.GDBall_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Ball_2"), gdjs.ScreenSaverCode.GDBall_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Ball_3"), gdjs.ScreenSaverCode.GDBall_953Objects2);
gdjs.copyArray(runtimeScene.getObjects("Ball_4"), gdjs.ScreenSaverCode.GDBall_954Objects2);
gdjs.copyArray(runtimeScene.getObjects("Ball_5"), gdjs.ScreenSaverCode.GDBall_955Objects2);
gdjs.copyArray(runtimeScene.getObjects("Ball_6"), gdjs.ScreenSaverCode.GDBall_956Objects2);
{for(var i = 0, len = gdjs.ScreenSaverCode.GDBall_951Objects2.length ;i < len;++i) {
    gdjs.ScreenSaverCode.GDBall_951Objects2[i].addPolarForce(180 + (gdjs.ScreenSaverCode.GDBall_951Objects2[i].getAngleToPosition(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0))), 10, 1);
}
for(var i = 0, len = gdjs.ScreenSaverCode.GDBall_952Objects2.length ;i < len;++i) {
    gdjs.ScreenSaverCode.GDBall_952Objects2[i].addPolarForce(180 + (gdjs.ScreenSaverCode.GDBall_952Objects2[i].getAngleToPosition(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0))), 10, 1);
}
for(var i = 0, len = gdjs.ScreenSaverCode.GDBall_954Objects2.length ;i < len;++i) {
    gdjs.ScreenSaverCode.GDBall_954Objects2[i].addPolarForce(180 + (gdjs.ScreenSaverCode.GDBall_954Objects2[i].getAngleToPosition(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0))), 10, 1);
}
for(var i = 0, len = gdjs.ScreenSaverCode.GDBall_953Objects2.length ;i < len;++i) {
    gdjs.ScreenSaverCode.GDBall_953Objects2[i].addPolarForce(180 + (gdjs.ScreenSaverCode.GDBall_953Objects2[i].getAngleToPosition(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0))), 10, 1);
}
for(var i = 0, len = gdjs.ScreenSaverCode.GDBall_955Objects2.length ;i < len;++i) {
    gdjs.ScreenSaverCode.GDBall_955Objects2[i].addPolarForce(180 + (gdjs.ScreenSaverCode.GDBall_955Objects2[i].getAngleToPosition(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0))), 10, 1);
}
for(var i = 0, len = gdjs.ScreenSaverCode.GDBall_956Objects2.length ;i < len;++i) {
    gdjs.ScreenSaverCode.GDBall_956Objects2[i].addPolarForce(180 + (gdjs.ScreenSaverCode.GDBall_956Objects2[i].getAngleToPosition(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0))), 10, 1);
}
}}

}


};gdjs.ScreenSaverCode.eventsList9 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Ball_1"), gdjs.ScreenSaverCode.GDBall_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Ball_2"), gdjs.ScreenSaverCode.GDBall_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Ball_3"), gdjs.ScreenSaverCode.GDBall_953Objects2);
gdjs.copyArray(runtimeScene.getObjects("Ball_4"), gdjs.ScreenSaverCode.GDBall_954Objects2);
gdjs.copyArray(runtimeScene.getObjects("Ball_5"), gdjs.ScreenSaverCode.GDBall_955Objects2);
gdjs.copyArray(runtimeScene.getObjects("Ball_6"), gdjs.ScreenSaverCode.GDBall_956Objects2);

gdjs.ScreenSaverCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.ScreenSaverCode.GDBall_951Objects2.length;i<l;++i) {
    if ( gdjs.ScreenSaverCode.GDBall_951Objects2[i].getY() > gdjs.evtTools.camera.getCameraBorderBottom(runtimeScene, "", 0) + 64 ) {
        gdjs.ScreenSaverCode.condition0IsTrue_0.val = true;
        gdjs.ScreenSaverCode.GDBall_951Objects2[k] = gdjs.ScreenSaverCode.GDBall_951Objects2[i];
        ++k;
    }
}
gdjs.ScreenSaverCode.GDBall_951Objects2.length = k;for(var i = 0, k = 0, l = gdjs.ScreenSaverCode.GDBall_952Objects2.length;i<l;++i) {
    if ( gdjs.ScreenSaverCode.GDBall_952Objects2[i].getY() > gdjs.evtTools.camera.getCameraBorderBottom(runtimeScene, "", 0) + 64 ) {
        gdjs.ScreenSaverCode.condition0IsTrue_0.val = true;
        gdjs.ScreenSaverCode.GDBall_952Objects2[k] = gdjs.ScreenSaverCode.GDBall_952Objects2[i];
        ++k;
    }
}
gdjs.ScreenSaverCode.GDBall_952Objects2.length = k;for(var i = 0, k = 0, l = gdjs.ScreenSaverCode.GDBall_954Objects2.length;i<l;++i) {
    if ( gdjs.ScreenSaverCode.GDBall_954Objects2[i].getY() > gdjs.evtTools.camera.getCameraBorderBottom(runtimeScene, "", 0) + 64 ) {
        gdjs.ScreenSaverCode.condition0IsTrue_0.val = true;
        gdjs.ScreenSaverCode.GDBall_954Objects2[k] = gdjs.ScreenSaverCode.GDBall_954Objects2[i];
        ++k;
    }
}
gdjs.ScreenSaverCode.GDBall_954Objects2.length = k;for(var i = 0, k = 0, l = gdjs.ScreenSaverCode.GDBall_953Objects2.length;i<l;++i) {
    if ( gdjs.ScreenSaverCode.GDBall_953Objects2[i].getY() > gdjs.evtTools.camera.getCameraBorderBottom(runtimeScene, "", 0) + 64 ) {
        gdjs.ScreenSaverCode.condition0IsTrue_0.val = true;
        gdjs.ScreenSaverCode.GDBall_953Objects2[k] = gdjs.ScreenSaverCode.GDBall_953Objects2[i];
        ++k;
    }
}
gdjs.ScreenSaverCode.GDBall_953Objects2.length = k;for(var i = 0, k = 0, l = gdjs.ScreenSaverCode.GDBall_955Objects2.length;i<l;++i) {
    if ( gdjs.ScreenSaverCode.GDBall_955Objects2[i].getY() > gdjs.evtTools.camera.getCameraBorderBottom(runtimeScene, "", 0) + 64 ) {
        gdjs.ScreenSaverCode.condition0IsTrue_0.val = true;
        gdjs.ScreenSaverCode.GDBall_955Objects2[k] = gdjs.ScreenSaverCode.GDBall_955Objects2[i];
        ++k;
    }
}
gdjs.ScreenSaverCode.GDBall_955Objects2.length = k;for(var i = 0, k = 0, l = gdjs.ScreenSaverCode.GDBall_956Objects2.length;i<l;++i) {
    if ( gdjs.ScreenSaverCode.GDBall_956Objects2[i].getY() > gdjs.evtTools.camera.getCameraBorderBottom(runtimeScene, "", 0) + 64 ) {
        gdjs.ScreenSaverCode.condition0IsTrue_0.val = true;
        gdjs.ScreenSaverCode.GDBall_956Objects2[k] = gdjs.ScreenSaverCode.GDBall_956Objects2[i];
        ++k;
    }
}
gdjs.ScreenSaverCode.GDBall_956Objects2.length = k;}if (gdjs.ScreenSaverCode.condition0IsTrue_0.val) {
/* Reuse gdjs.ScreenSaverCode.GDBall_951Objects2 */
/* Reuse gdjs.ScreenSaverCode.GDBall_952Objects2 */
/* Reuse gdjs.ScreenSaverCode.GDBall_953Objects2 */
/* Reuse gdjs.ScreenSaverCode.GDBall_954Objects2 */
/* Reuse gdjs.ScreenSaverCode.GDBall_955Objects2 */
/* Reuse gdjs.ScreenSaverCode.GDBall_956Objects2 */
{for(var i = 0, len = gdjs.ScreenSaverCode.GDBall_951Objects2.length ;i < len;++i) {
    gdjs.ScreenSaverCode.GDBall_951Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.ScreenSaverCode.GDBall_952Objects2.length ;i < len;++i) {
    gdjs.ScreenSaverCode.GDBall_952Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.ScreenSaverCode.GDBall_954Objects2.length ;i < len;++i) {
    gdjs.ScreenSaverCode.GDBall_954Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.ScreenSaverCode.GDBall_953Objects2.length ;i < len;++i) {
    gdjs.ScreenSaverCode.GDBall_953Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.ScreenSaverCode.GDBall_955Objects2.length ;i < len;++i) {
    gdjs.ScreenSaverCode.GDBall_955Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.ScreenSaverCode.GDBall_956Objects2.length ;i < len;++i) {
    gdjs.ScreenSaverCode.GDBall_956Objects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Ball_1"), gdjs.ScreenSaverCode.GDBall_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Ball_2"), gdjs.ScreenSaverCode.GDBall_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Ball_3"), gdjs.ScreenSaverCode.GDBall_953Objects2);
gdjs.copyArray(runtimeScene.getObjects("Ball_4"), gdjs.ScreenSaverCode.GDBall_954Objects2);
gdjs.copyArray(runtimeScene.getObjects("Ball_5"), gdjs.ScreenSaverCode.GDBall_955Objects2);
gdjs.copyArray(runtimeScene.getObjects("Ball_6"), gdjs.ScreenSaverCode.GDBall_956Objects2);

gdjs.ScreenSaverCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.ScreenSaverCode.GDBall_951Objects2.length;i<l;++i) {
    if ( gdjs.ScreenSaverCode.GDBall_951Objects2[i].getY() < gdjs.evtTools.camera.getCameraBorderTop(runtimeScene, "", 0) - 64 ) {
        gdjs.ScreenSaverCode.condition0IsTrue_0.val = true;
        gdjs.ScreenSaverCode.GDBall_951Objects2[k] = gdjs.ScreenSaverCode.GDBall_951Objects2[i];
        ++k;
    }
}
gdjs.ScreenSaverCode.GDBall_951Objects2.length = k;for(var i = 0, k = 0, l = gdjs.ScreenSaverCode.GDBall_952Objects2.length;i<l;++i) {
    if ( gdjs.ScreenSaverCode.GDBall_952Objects2[i].getY() < gdjs.evtTools.camera.getCameraBorderTop(runtimeScene, "", 0) - 64 ) {
        gdjs.ScreenSaverCode.condition0IsTrue_0.val = true;
        gdjs.ScreenSaverCode.GDBall_952Objects2[k] = gdjs.ScreenSaverCode.GDBall_952Objects2[i];
        ++k;
    }
}
gdjs.ScreenSaverCode.GDBall_952Objects2.length = k;for(var i = 0, k = 0, l = gdjs.ScreenSaverCode.GDBall_954Objects2.length;i<l;++i) {
    if ( gdjs.ScreenSaverCode.GDBall_954Objects2[i].getY() < gdjs.evtTools.camera.getCameraBorderTop(runtimeScene, "", 0) - 64 ) {
        gdjs.ScreenSaverCode.condition0IsTrue_0.val = true;
        gdjs.ScreenSaverCode.GDBall_954Objects2[k] = gdjs.ScreenSaverCode.GDBall_954Objects2[i];
        ++k;
    }
}
gdjs.ScreenSaverCode.GDBall_954Objects2.length = k;for(var i = 0, k = 0, l = gdjs.ScreenSaverCode.GDBall_953Objects2.length;i<l;++i) {
    if ( gdjs.ScreenSaverCode.GDBall_953Objects2[i].getY() < gdjs.evtTools.camera.getCameraBorderTop(runtimeScene, "", 0) - 64 ) {
        gdjs.ScreenSaverCode.condition0IsTrue_0.val = true;
        gdjs.ScreenSaverCode.GDBall_953Objects2[k] = gdjs.ScreenSaverCode.GDBall_953Objects2[i];
        ++k;
    }
}
gdjs.ScreenSaverCode.GDBall_953Objects2.length = k;for(var i = 0, k = 0, l = gdjs.ScreenSaverCode.GDBall_955Objects2.length;i<l;++i) {
    if ( gdjs.ScreenSaverCode.GDBall_955Objects2[i].getY() < gdjs.evtTools.camera.getCameraBorderTop(runtimeScene, "", 0) - 64 ) {
        gdjs.ScreenSaverCode.condition0IsTrue_0.val = true;
        gdjs.ScreenSaverCode.GDBall_955Objects2[k] = gdjs.ScreenSaverCode.GDBall_955Objects2[i];
        ++k;
    }
}
gdjs.ScreenSaverCode.GDBall_955Objects2.length = k;for(var i = 0, k = 0, l = gdjs.ScreenSaverCode.GDBall_956Objects2.length;i<l;++i) {
    if ( gdjs.ScreenSaverCode.GDBall_956Objects2[i].getY() < gdjs.evtTools.camera.getCameraBorderTop(runtimeScene, "", 0) - 64 ) {
        gdjs.ScreenSaverCode.condition0IsTrue_0.val = true;
        gdjs.ScreenSaverCode.GDBall_956Objects2[k] = gdjs.ScreenSaverCode.GDBall_956Objects2[i];
        ++k;
    }
}
gdjs.ScreenSaverCode.GDBall_956Objects2.length = k;}if (gdjs.ScreenSaverCode.condition0IsTrue_0.val) {
/* Reuse gdjs.ScreenSaverCode.GDBall_951Objects2 */
/* Reuse gdjs.ScreenSaverCode.GDBall_952Objects2 */
/* Reuse gdjs.ScreenSaverCode.GDBall_953Objects2 */
/* Reuse gdjs.ScreenSaverCode.GDBall_954Objects2 */
/* Reuse gdjs.ScreenSaverCode.GDBall_955Objects2 */
/* Reuse gdjs.ScreenSaverCode.GDBall_956Objects2 */
{for(var i = 0, len = gdjs.ScreenSaverCode.GDBall_951Objects2.length ;i < len;++i) {
    gdjs.ScreenSaverCode.GDBall_951Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.ScreenSaverCode.GDBall_952Objects2.length ;i < len;++i) {
    gdjs.ScreenSaverCode.GDBall_952Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.ScreenSaverCode.GDBall_954Objects2.length ;i < len;++i) {
    gdjs.ScreenSaverCode.GDBall_954Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.ScreenSaverCode.GDBall_953Objects2.length ;i < len;++i) {
    gdjs.ScreenSaverCode.GDBall_953Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.ScreenSaverCode.GDBall_955Objects2.length ;i < len;++i) {
    gdjs.ScreenSaverCode.GDBall_955Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.ScreenSaverCode.GDBall_956Objects2.length ;i < len;++i) {
    gdjs.ScreenSaverCode.GDBall_956Objects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Ball_1"), gdjs.ScreenSaverCode.GDBall_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Ball_2"), gdjs.ScreenSaverCode.GDBall_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Ball_3"), gdjs.ScreenSaverCode.GDBall_953Objects2);
gdjs.copyArray(runtimeScene.getObjects("Ball_4"), gdjs.ScreenSaverCode.GDBall_954Objects2);
gdjs.copyArray(runtimeScene.getObjects("Ball_5"), gdjs.ScreenSaverCode.GDBall_955Objects2);
gdjs.copyArray(runtimeScene.getObjects("Ball_6"), gdjs.ScreenSaverCode.GDBall_956Objects2);

gdjs.ScreenSaverCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.ScreenSaverCode.GDBall_951Objects2.length;i<l;++i) {
    if ( gdjs.ScreenSaverCode.GDBall_951Objects2[i].getX() < gdjs.evtTools.camera.getCameraBorderLeft(runtimeScene, "", 0) - 64 ) {
        gdjs.ScreenSaverCode.condition0IsTrue_0.val = true;
        gdjs.ScreenSaverCode.GDBall_951Objects2[k] = gdjs.ScreenSaverCode.GDBall_951Objects2[i];
        ++k;
    }
}
gdjs.ScreenSaverCode.GDBall_951Objects2.length = k;for(var i = 0, k = 0, l = gdjs.ScreenSaverCode.GDBall_952Objects2.length;i<l;++i) {
    if ( gdjs.ScreenSaverCode.GDBall_952Objects2[i].getX() < gdjs.evtTools.camera.getCameraBorderLeft(runtimeScene, "", 0) - 64 ) {
        gdjs.ScreenSaverCode.condition0IsTrue_0.val = true;
        gdjs.ScreenSaverCode.GDBall_952Objects2[k] = gdjs.ScreenSaverCode.GDBall_952Objects2[i];
        ++k;
    }
}
gdjs.ScreenSaverCode.GDBall_952Objects2.length = k;for(var i = 0, k = 0, l = gdjs.ScreenSaverCode.GDBall_954Objects2.length;i<l;++i) {
    if ( gdjs.ScreenSaverCode.GDBall_954Objects2[i].getX() < gdjs.evtTools.camera.getCameraBorderLeft(runtimeScene, "", 0) - 64 ) {
        gdjs.ScreenSaverCode.condition0IsTrue_0.val = true;
        gdjs.ScreenSaverCode.GDBall_954Objects2[k] = gdjs.ScreenSaverCode.GDBall_954Objects2[i];
        ++k;
    }
}
gdjs.ScreenSaverCode.GDBall_954Objects2.length = k;for(var i = 0, k = 0, l = gdjs.ScreenSaverCode.GDBall_953Objects2.length;i<l;++i) {
    if ( gdjs.ScreenSaverCode.GDBall_953Objects2[i].getX() < gdjs.evtTools.camera.getCameraBorderLeft(runtimeScene, "", 0) - 64 ) {
        gdjs.ScreenSaverCode.condition0IsTrue_0.val = true;
        gdjs.ScreenSaverCode.GDBall_953Objects2[k] = gdjs.ScreenSaverCode.GDBall_953Objects2[i];
        ++k;
    }
}
gdjs.ScreenSaverCode.GDBall_953Objects2.length = k;for(var i = 0, k = 0, l = gdjs.ScreenSaverCode.GDBall_955Objects2.length;i<l;++i) {
    if ( gdjs.ScreenSaverCode.GDBall_955Objects2[i].getX() < gdjs.evtTools.camera.getCameraBorderLeft(runtimeScene, "", 0) - 64 ) {
        gdjs.ScreenSaverCode.condition0IsTrue_0.val = true;
        gdjs.ScreenSaverCode.GDBall_955Objects2[k] = gdjs.ScreenSaverCode.GDBall_955Objects2[i];
        ++k;
    }
}
gdjs.ScreenSaverCode.GDBall_955Objects2.length = k;for(var i = 0, k = 0, l = gdjs.ScreenSaverCode.GDBall_956Objects2.length;i<l;++i) {
    if ( gdjs.ScreenSaverCode.GDBall_956Objects2[i].getX() < gdjs.evtTools.camera.getCameraBorderLeft(runtimeScene, "", 0) - 64 ) {
        gdjs.ScreenSaverCode.condition0IsTrue_0.val = true;
        gdjs.ScreenSaverCode.GDBall_956Objects2[k] = gdjs.ScreenSaverCode.GDBall_956Objects2[i];
        ++k;
    }
}
gdjs.ScreenSaverCode.GDBall_956Objects2.length = k;}if (gdjs.ScreenSaverCode.condition0IsTrue_0.val) {
/* Reuse gdjs.ScreenSaverCode.GDBall_951Objects2 */
/* Reuse gdjs.ScreenSaverCode.GDBall_952Objects2 */
/* Reuse gdjs.ScreenSaverCode.GDBall_953Objects2 */
/* Reuse gdjs.ScreenSaverCode.GDBall_954Objects2 */
/* Reuse gdjs.ScreenSaverCode.GDBall_955Objects2 */
/* Reuse gdjs.ScreenSaverCode.GDBall_956Objects2 */
{for(var i = 0, len = gdjs.ScreenSaverCode.GDBall_951Objects2.length ;i < len;++i) {
    gdjs.ScreenSaverCode.GDBall_951Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.ScreenSaverCode.GDBall_952Objects2.length ;i < len;++i) {
    gdjs.ScreenSaverCode.GDBall_952Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.ScreenSaverCode.GDBall_954Objects2.length ;i < len;++i) {
    gdjs.ScreenSaverCode.GDBall_954Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.ScreenSaverCode.GDBall_953Objects2.length ;i < len;++i) {
    gdjs.ScreenSaverCode.GDBall_953Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.ScreenSaverCode.GDBall_955Objects2.length ;i < len;++i) {
    gdjs.ScreenSaverCode.GDBall_955Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.ScreenSaverCode.GDBall_956Objects2.length ;i < len;++i) {
    gdjs.ScreenSaverCode.GDBall_956Objects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Ball_1"), gdjs.ScreenSaverCode.GDBall_951Objects1);
gdjs.copyArray(runtimeScene.getObjects("Ball_2"), gdjs.ScreenSaverCode.GDBall_952Objects1);
gdjs.copyArray(runtimeScene.getObjects("Ball_3"), gdjs.ScreenSaverCode.GDBall_953Objects1);
gdjs.copyArray(runtimeScene.getObjects("Ball_4"), gdjs.ScreenSaverCode.GDBall_954Objects1);
gdjs.copyArray(runtimeScene.getObjects("Ball_5"), gdjs.ScreenSaverCode.GDBall_955Objects1);
gdjs.copyArray(runtimeScene.getObjects("Ball_6"), gdjs.ScreenSaverCode.GDBall_956Objects1);

gdjs.ScreenSaverCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.ScreenSaverCode.GDBall_951Objects1.length;i<l;++i) {
    if ( gdjs.ScreenSaverCode.GDBall_951Objects1[i].getX() > gdjs.evtTools.camera.getCameraBorderRight(runtimeScene, "", 0) + 64 ) {
        gdjs.ScreenSaverCode.condition0IsTrue_0.val = true;
        gdjs.ScreenSaverCode.GDBall_951Objects1[k] = gdjs.ScreenSaverCode.GDBall_951Objects1[i];
        ++k;
    }
}
gdjs.ScreenSaverCode.GDBall_951Objects1.length = k;for(var i = 0, k = 0, l = gdjs.ScreenSaverCode.GDBall_952Objects1.length;i<l;++i) {
    if ( gdjs.ScreenSaverCode.GDBall_952Objects1[i].getX() > gdjs.evtTools.camera.getCameraBorderRight(runtimeScene, "", 0) + 64 ) {
        gdjs.ScreenSaverCode.condition0IsTrue_0.val = true;
        gdjs.ScreenSaverCode.GDBall_952Objects1[k] = gdjs.ScreenSaverCode.GDBall_952Objects1[i];
        ++k;
    }
}
gdjs.ScreenSaverCode.GDBall_952Objects1.length = k;for(var i = 0, k = 0, l = gdjs.ScreenSaverCode.GDBall_954Objects1.length;i<l;++i) {
    if ( gdjs.ScreenSaverCode.GDBall_954Objects1[i].getX() > gdjs.evtTools.camera.getCameraBorderRight(runtimeScene, "", 0) + 64 ) {
        gdjs.ScreenSaverCode.condition0IsTrue_0.val = true;
        gdjs.ScreenSaverCode.GDBall_954Objects1[k] = gdjs.ScreenSaverCode.GDBall_954Objects1[i];
        ++k;
    }
}
gdjs.ScreenSaverCode.GDBall_954Objects1.length = k;for(var i = 0, k = 0, l = gdjs.ScreenSaverCode.GDBall_953Objects1.length;i<l;++i) {
    if ( gdjs.ScreenSaverCode.GDBall_953Objects1[i].getX() > gdjs.evtTools.camera.getCameraBorderRight(runtimeScene, "", 0) + 64 ) {
        gdjs.ScreenSaverCode.condition0IsTrue_0.val = true;
        gdjs.ScreenSaverCode.GDBall_953Objects1[k] = gdjs.ScreenSaverCode.GDBall_953Objects1[i];
        ++k;
    }
}
gdjs.ScreenSaverCode.GDBall_953Objects1.length = k;for(var i = 0, k = 0, l = gdjs.ScreenSaverCode.GDBall_955Objects1.length;i<l;++i) {
    if ( gdjs.ScreenSaverCode.GDBall_955Objects1[i].getX() > gdjs.evtTools.camera.getCameraBorderRight(runtimeScene, "", 0) + 64 ) {
        gdjs.ScreenSaverCode.condition0IsTrue_0.val = true;
        gdjs.ScreenSaverCode.GDBall_955Objects1[k] = gdjs.ScreenSaverCode.GDBall_955Objects1[i];
        ++k;
    }
}
gdjs.ScreenSaverCode.GDBall_955Objects1.length = k;for(var i = 0, k = 0, l = gdjs.ScreenSaverCode.GDBall_956Objects1.length;i<l;++i) {
    if ( gdjs.ScreenSaverCode.GDBall_956Objects1[i].getX() > gdjs.evtTools.camera.getCameraBorderRight(runtimeScene, "", 0) + 64 ) {
        gdjs.ScreenSaverCode.condition0IsTrue_0.val = true;
        gdjs.ScreenSaverCode.GDBall_956Objects1[k] = gdjs.ScreenSaverCode.GDBall_956Objects1[i];
        ++k;
    }
}
gdjs.ScreenSaverCode.GDBall_956Objects1.length = k;}if (gdjs.ScreenSaverCode.condition0IsTrue_0.val) {
/* Reuse gdjs.ScreenSaverCode.GDBall_951Objects1 */
/* Reuse gdjs.ScreenSaverCode.GDBall_952Objects1 */
/* Reuse gdjs.ScreenSaverCode.GDBall_953Objects1 */
/* Reuse gdjs.ScreenSaverCode.GDBall_954Objects1 */
/* Reuse gdjs.ScreenSaverCode.GDBall_955Objects1 */
/* Reuse gdjs.ScreenSaverCode.GDBall_956Objects1 */
{for(var i = 0, len = gdjs.ScreenSaverCode.GDBall_951Objects1.length ;i < len;++i) {
    gdjs.ScreenSaverCode.GDBall_951Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.ScreenSaverCode.GDBall_952Objects1.length ;i < len;++i) {
    gdjs.ScreenSaverCode.GDBall_952Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.ScreenSaverCode.GDBall_954Objects1.length ;i < len;++i) {
    gdjs.ScreenSaverCode.GDBall_954Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.ScreenSaverCode.GDBall_953Objects1.length ;i < len;++i) {
    gdjs.ScreenSaverCode.GDBall_953Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.ScreenSaverCode.GDBall_955Objects1.length ;i < len;++i) {
    gdjs.ScreenSaverCode.GDBall_955Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.ScreenSaverCode.GDBall_956Objects1.length ;i < len;++i) {
    gdjs.ScreenSaverCode.GDBall_956Objects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.ScreenSaverCode.eventsList10 = function(runtimeScene) {

{


gdjs.ScreenSaverCode.eventsList7(runtimeScene);
}


{


gdjs.ScreenSaverCode.eventsList8(runtimeScene);
}


{


gdjs.ScreenSaverCode.eventsList9(runtimeScene);
}


};gdjs.ScreenSaverCode.mapOfGDgdjs_46ScreenSaverCode_46GDBall_95951Objects4ObjectsGDgdjs_46ScreenSaverCode_46GDBall_95952Objects4ObjectsGDgdjs_46ScreenSaverCode_46GDBall_95954Objects4ObjectsGDgdjs_46ScreenSaverCode_46GDBall_95953Objects4ObjectsGDgdjs_46ScreenSaverCode_46GDBall_95955Objects4ObjectsGDgdjs_46ScreenSaverCode_46GDBall_95956Objects4Objects = Hashtable.newFrom({"Ball_1": gdjs.ScreenSaverCode.GDBall_951Objects4, "Ball_2": gdjs.ScreenSaverCode.GDBall_952Objects4, "Ball_4": gdjs.ScreenSaverCode.GDBall_954Objects4, "Ball_3": gdjs.ScreenSaverCode.GDBall_953Objects4, "Ball_5": gdjs.ScreenSaverCode.GDBall_955Objects4, "Ball_6": gdjs.ScreenSaverCode.GDBall_956Objects4});
gdjs.ScreenSaverCode.mapOfGDgdjs_46ScreenSaverCode_46GDBouncerGObjects4ObjectsGDgdjs_46ScreenSaverCode_46GDGdevelopGLogoBlackObjects4Objects = Hashtable.newFrom({"BouncerG": gdjs.ScreenSaverCode.GDBouncerGObjects4, "GdevelopGLogoBlack": gdjs.ScreenSaverCode.GDGdevelopGLogoBlackObjects4});
gdjs.ScreenSaverCode.eventsList11 = function(runtimeScene) {

{


{
gdjs.copyArray(gdjs.ScreenSaverCode.GDBall_951Objects4, gdjs.ScreenSaverCode.GDBall_951Objects5);

gdjs.copyArray(gdjs.ScreenSaverCode.GDBall_952Objects4, gdjs.ScreenSaverCode.GDBall_952Objects5);

gdjs.copyArray(gdjs.ScreenSaverCode.GDBall_953Objects4, gdjs.ScreenSaverCode.GDBall_953Objects5);

gdjs.copyArray(gdjs.ScreenSaverCode.GDBall_954Objects4, gdjs.ScreenSaverCode.GDBall_954Objects5);

gdjs.copyArray(gdjs.ScreenSaverCode.GDBall_955Objects4, gdjs.ScreenSaverCode.GDBall_955Objects5);

gdjs.copyArray(gdjs.ScreenSaverCode.GDBall_956Objects4, gdjs.ScreenSaverCode.GDBall_956Objects5);

gdjs.copyArray(gdjs.ScreenSaverCode.GDBouncerGObjects4, gdjs.ScreenSaverCode.GDBouncerGObjects5);

gdjs.copyArray(gdjs.ScreenSaverCode.GDGdevelopGLogoBlackObjects4, gdjs.ScreenSaverCode.GDGdevelopGLogoBlackObjects5);

{for(var i = 0, len = gdjs.ScreenSaverCode.GDBall_951Objects5.length ;i < len;++i) {
    gdjs.ScreenSaverCode.GDBall_951Objects5[i].addForceTowardObject((gdjs.ScreenSaverCode.GDBouncerGObjects5.length !== 0 ? gdjs.ScreenSaverCode.GDBouncerGObjects5[0] : (gdjs.ScreenSaverCode.GDGdevelopGLogoBlackObjects5.length !== 0 ? gdjs.ScreenSaverCode.GDGdevelopGLogoBlackObjects5[0] : null)), -(200), 1);
}
for(var i = 0, len = gdjs.ScreenSaverCode.GDBall_952Objects5.length ;i < len;++i) {
    gdjs.ScreenSaverCode.GDBall_952Objects5[i].addForceTowardObject((gdjs.ScreenSaverCode.GDBouncerGObjects5.length !== 0 ? gdjs.ScreenSaverCode.GDBouncerGObjects5[0] : (gdjs.ScreenSaverCode.GDGdevelopGLogoBlackObjects5.length !== 0 ? gdjs.ScreenSaverCode.GDGdevelopGLogoBlackObjects5[0] : null)), -(200), 1);
}
for(var i = 0, len = gdjs.ScreenSaverCode.GDBall_954Objects5.length ;i < len;++i) {
    gdjs.ScreenSaverCode.GDBall_954Objects5[i].addForceTowardObject((gdjs.ScreenSaverCode.GDBouncerGObjects5.length !== 0 ? gdjs.ScreenSaverCode.GDBouncerGObjects5[0] : (gdjs.ScreenSaverCode.GDGdevelopGLogoBlackObjects5.length !== 0 ? gdjs.ScreenSaverCode.GDGdevelopGLogoBlackObjects5[0] : null)), -(200), 1);
}
for(var i = 0, len = gdjs.ScreenSaverCode.GDBall_953Objects5.length ;i < len;++i) {
    gdjs.ScreenSaverCode.GDBall_953Objects5[i].addForceTowardObject((gdjs.ScreenSaverCode.GDBouncerGObjects5.length !== 0 ? gdjs.ScreenSaverCode.GDBouncerGObjects5[0] : (gdjs.ScreenSaverCode.GDGdevelopGLogoBlackObjects5.length !== 0 ? gdjs.ScreenSaverCode.GDGdevelopGLogoBlackObjects5[0] : null)), -(200), 1);
}
for(var i = 0, len = gdjs.ScreenSaverCode.GDBall_955Objects5.length ;i < len;++i) {
    gdjs.ScreenSaverCode.GDBall_955Objects5[i].addForceTowardObject((gdjs.ScreenSaverCode.GDBouncerGObjects5.length !== 0 ? gdjs.ScreenSaverCode.GDBouncerGObjects5[0] : (gdjs.ScreenSaverCode.GDGdevelopGLogoBlackObjects5.length !== 0 ? gdjs.ScreenSaverCode.GDGdevelopGLogoBlackObjects5[0] : null)), -(200), 1);
}
for(var i = 0, len = gdjs.ScreenSaverCode.GDBall_956Objects5.length ;i < len;++i) {
    gdjs.ScreenSaverCode.GDBall_956Objects5[i].addForceTowardObject((gdjs.ScreenSaverCode.GDBouncerGObjects5.length !== 0 ? gdjs.ScreenSaverCode.GDBouncerGObjects5[0] : (gdjs.ScreenSaverCode.GDGdevelopGLogoBlackObjects5.length !== 0 ? gdjs.ScreenSaverCode.GDGdevelopGLogoBlackObjects5[0] : null)), -(200), 1);
}
}}

}


{


{
/* Reuse gdjs.ScreenSaverCode.GDBall_951Objects4 */
/* Reuse gdjs.ScreenSaverCode.GDBall_952Objects4 */
/* Reuse gdjs.ScreenSaverCode.GDBall_953Objects4 */
/* Reuse gdjs.ScreenSaverCode.GDBall_954Objects4 */
/* Reuse gdjs.ScreenSaverCode.GDBall_955Objects4 */
/* Reuse gdjs.ScreenSaverCode.GDBall_956Objects4 */
/* Reuse gdjs.ScreenSaverCode.GDBouncerGObjects4 */
/* Reuse gdjs.ScreenSaverCode.GDGdevelopGLogoBlackObjects4 */
{for(var i = 0, len = gdjs.ScreenSaverCode.GDBouncerGObjects4.length ;i < len;++i) {
    gdjs.ScreenSaverCode.GDBouncerGObjects4[i].addForceTowardObject((gdjs.ScreenSaverCode.GDBall_951Objects4.length !== 0 ? gdjs.ScreenSaverCode.GDBall_951Objects4[0] : (gdjs.ScreenSaverCode.GDBall_952Objects4.length !== 0 ? gdjs.ScreenSaverCode.GDBall_952Objects4[0] : (gdjs.ScreenSaverCode.GDBall_954Objects4.length !== 0 ? gdjs.ScreenSaverCode.GDBall_954Objects4[0] : (gdjs.ScreenSaverCode.GDBall_953Objects4.length !== 0 ? gdjs.ScreenSaverCode.GDBall_953Objects4[0] : (gdjs.ScreenSaverCode.GDBall_955Objects4.length !== 0 ? gdjs.ScreenSaverCode.GDBall_955Objects4[0] : (gdjs.ScreenSaverCode.GDBall_956Objects4.length !== 0 ? gdjs.ScreenSaverCode.GDBall_956Objects4[0] : null)))))), -(200), 1);
}
for(var i = 0, len = gdjs.ScreenSaverCode.GDGdevelopGLogoBlackObjects4.length ;i < len;++i) {
    gdjs.ScreenSaverCode.GDGdevelopGLogoBlackObjects4[i].addForceTowardObject((gdjs.ScreenSaverCode.GDBall_951Objects4.length !== 0 ? gdjs.ScreenSaverCode.GDBall_951Objects4[0] : (gdjs.ScreenSaverCode.GDBall_952Objects4.length !== 0 ? gdjs.ScreenSaverCode.GDBall_952Objects4[0] : (gdjs.ScreenSaverCode.GDBall_954Objects4.length !== 0 ? gdjs.ScreenSaverCode.GDBall_954Objects4[0] : (gdjs.ScreenSaverCode.GDBall_953Objects4.length !== 0 ? gdjs.ScreenSaverCode.GDBall_953Objects4[0] : (gdjs.ScreenSaverCode.GDBall_955Objects4.length !== 0 ? gdjs.ScreenSaverCode.GDBall_955Objects4[0] : (gdjs.ScreenSaverCode.GDBall_956Objects4.length !== 0 ? gdjs.ScreenSaverCode.GDBall_956Objects4[0] : null)))))), -(200), 1);
}
}}

}


};gdjs.ScreenSaverCode.eventsList12 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.ScreenSaverCode.GDBall_951Objects3, gdjs.ScreenSaverCode.GDBall_951Objects4);

gdjs.copyArray(gdjs.ScreenSaverCode.GDBall_952Objects3, gdjs.ScreenSaverCode.GDBall_952Objects4);

gdjs.copyArray(gdjs.ScreenSaverCode.GDBall_953Objects3, gdjs.ScreenSaverCode.GDBall_953Objects4);

gdjs.copyArray(gdjs.ScreenSaverCode.GDBall_954Objects3, gdjs.ScreenSaverCode.GDBall_954Objects4);

gdjs.copyArray(gdjs.ScreenSaverCode.GDBall_955Objects3, gdjs.ScreenSaverCode.GDBall_955Objects4);

gdjs.copyArray(gdjs.ScreenSaverCode.GDBall_956Objects3, gdjs.ScreenSaverCode.GDBall_956Objects4);

gdjs.copyArray(runtimeScene.getObjects("BouncerG"), gdjs.ScreenSaverCode.GDBouncerGObjects4);
gdjs.copyArray(runtimeScene.getObjects("GdevelopGLogoBlack"), gdjs.ScreenSaverCode.GDGdevelopGLogoBlackObjects4);

gdjs.ScreenSaverCode.condition0IsTrue_0.val = false;
{
gdjs.ScreenSaverCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ScreenSaverCode.mapOfGDgdjs_46ScreenSaverCode_46GDBall_95951Objects4ObjectsGDgdjs_46ScreenSaverCode_46GDBall_95952Objects4ObjectsGDgdjs_46ScreenSaverCode_46GDBall_95954Objects4ObjectsGDgdjs_46ScreenSaverCode_46GDBall_95953Objects4ObjectsGDgdjs_46ScreenSaverCode_46GDBall_95955Objects4ObjectsGDgdjs_46ScreenSaverCode_46GDBall_95956Objects4Objects, gdjs.ScreenSaverCode.mapOfGDgdjs_46ScreenSaverCode_46GDBouncerGObjects4ObjectsGDgdjs_46ScreenSaverCode_46GDGdevelopGLogoBlackObjects4Objects, false, runtimeScene, false);
}if (gdjs.ScreenSaverCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.ScreenSaverCode.eventsList11(runtimeScene);} //End of subevents
}

}


};gdjs.ScreenSaverCode.eventsList13 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Ball_1"), gdjs.ScreenSaverCode.GDBall_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Ball_2"), gdjs.ScreenSaverCode.GDBall_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Ball_3"), gdjs.ScreenSaverCode.GDBall_953Objects2);
gdjs.copyArray(runtimeScene.getObjects("Ball_4"), gdjs.ScreenSaverCode.GDBall_954Objects2);
gdjs.copyArray(runtimeScene.getObjects("Ball_5"), gdjs.ScreenSaverCode.GDBall_955Objects2);
gdjs.copyArray(runtimeScene.getObjects("Ball_6"), gdjs.ScreenSaverCode.GDBall_956Objects2);

gdjs.ScreenSaverCode.forEachTotalCount3 = 0;
gdjs.ScreenSaverCode.forEachObjects3.length = 0;
gdjs.ScreenSaverCode.forEachCount0_3 = gdjs.ScreenSaverCode.GDBall_951Objects2.length;
gdjs.ScreenSaverCode.forEachTotalCount3 += gdjs.ScreenSaverCode.forEachCount0_3;
gdjs.ScreenSaverCode.forEachObjects3.push.apply(gdjs.ScreenSaverCode.forEachObjects3,gdjs.ScreenSaverCode.GDBall_951Objects2);
gdjs.ScreenSaverCode.forEachCount1_3 = gdjs.ScreenSaverCode.GDBall_952Objects2.length;
gdjs.ScreenSaverCode.forEachTotalCount3 += gdjs.ScreenSaverCode.forEachCount1_3;
gdjs.ScreenSaverCode.forEachObjects3.push.apply(gdjs.ScreenSaverCode.forEachObjects3,gdjs.ScreenSaverCode.GDBall_952Objects2);
gdjs.ScreenSaverCode.forEachCount2_3 = gdjs.ScreenSaverCode.GDBall_954Objects2.length;
gdjs.ScreenSaverCode.forEachTotalCount3 += gdjs.ScreenSaverCode.forEachCount2_3;
gdjs.ScreenSaverCode.forEachObjects3.push.apply(gdjs.ScreenSaverCode.forEachObjects3,gdjs.ScreenSaverCode.GDBall_954Objects2);
gdjs.ScreenSaverCode.forEachCount3_3 = gdjs.ScreenSaverCode.GDBall_953Objects2.length;
gdjs.ScreenSaverCode.forEachTotalCount3 += gdjs.ScreenSaverCode.forEachCount3_3;
gdjs.ScreenSaverCode.forEachObjects3.push.apply(gdjs.ScreenSaverCode.forEachObjects3,gdjs.ScreenSaverCode.GDBall_953Objects2);
gdjs.ScreenSaverCode.forEachCount4_3 = gdjs.ScreenSaverCode.GDBall_955Objects2.length;
gdjs.ScreenSaverCode.forEachTotalCount3 += gdjs.ScreenSaverCode.forEachCount4_3;
gdjs.ScreenSaverCode.forEachObjects3.push.apply(gdjs.ScreenSaverCode.forEachObjects3,gdjs.ScreenSaverCode.GDBall_955Objects2);
gdjs.ScreenSaverCode.forEachCount5_3 = gdjs.ScreenSaverCode.GDBall_956Objects2.length;
gdjs.ScreenSaverCode.forEachTotalCount3 += gdjs.ScreenSaverCode.forEachCount5_3;
gdjs.ScreenSaverCode.forEachObjects3.push.apply(gdjs.ScreenSaverCode.forEachObjects3,gdjs.ScreenSaverCode.GDBall_956Objects2);
for(gdjs.ScreenSaverCode.forEachIndex3 = 0;gdjs.ScreenSaverCode.forEachIndex3 < gdjs.ScreenSaverCode.forEachTotalCount3;++gdjs.ScreenSaverCode.forEachIndex3) {
gdjs.ScreenSaverCode.GDBall_951Objects3.length = 0;

gdjs.ScreenSaverCode.GDBall_952Objects3.length = 0;

gdjs.ScreenSaverCode.GDBall_953Objects3.length = 0;

gdjs.ScreenSaverCode.GDBall_954Objects3.length = 0;

gdjs.ScreenSaverCode.GDBall_955Objects3.length = 0;

gdjs.ScreenSaverCode.GDBall_956Objects3.length = 0;


if (gdjs.ScreenSaverCode.forEachIndex3 < gdjs.ScreenSaverCode.forEachCount0_3) {
    gdjs.ScreenSaverCode.GDBall_951Objects3.push(gdjs.ScreenSaverCode.forEachObjects3[gdjs.ScreenSaverCode.forEachIndex3]);
}
else if (gdjs.ScreenSaverCode.forEachIndex3 < gdjs.ScreenSaverCode.forEachCount0_3+gdjs.ScreenSaverCode.forEachCount1_3) {
    gdjs.ScreenSaverCode.GDBall_952Objects3.push(gdjs.ScreenSaverCode.forEachObjects3[gdjs.ScreenSaverCode.forEachIndex3]);
}
else if (gdjs.ScreenSaverCode.forEachIndex3 < gdjs.ScreenSaverCode.forEachCount0_3+gdjs.ScreenSaverCode.forEachCount1_3+gdjs.ScreenSaverCode.forEachCount2_3) {
    gdjs.ScreenSaverCode.GDBall_954Objects3.push(gdjs.ScreenSaverCode.forEachObjects3[gdjs.ScreenSaverCode.forEachIndex3]);
}
else if (gdjs.ScreenSaverCode.forEachIndex3 < gdjs.ScreenSaverCode.forEachCount0_3+gdjs.ScreenSaverCode.forEachCount1_3+gdjs.ScreenSaverCode.forEachCount2_3+gdjs.ScreenSaverCode.forEachCount3_3) {
    gdjs.ScreenSaverCode.GDBall_953Objects3.push(gdjs.ScreenSaverCode.forEachObjects3[gdjs.ScreenSaverCode.forEachIndex3]);
}
else if (gdjs.ScreenSaverCode.forEachIndex3 < gdjs.ScreenSaverCode.forEachCount0_3+gdjs.ScreenSaverCode.forEachCount1_3+gdjs.ScreenSaverCode.forEachCount2_3+gdjs.ScreenSaverCode.forEachCount3_3+gdjs.ScreenSaverCode.forEachCount4_3) {
    gdjs.ScreenSaverCode.GDBall_955Objects3.push(gdjs.ScreenSaverCode.forEachObjects3[gdjs.ScreenSaverCode.forEachIndex3]);
}
else if (gdjs.ScreenSaverCode.forEachIndex3 < gdjs.ScreenSaverCode.forEachCount0_3+gdjs.ScreenSaverCode.forEachCount1_3+gdjs.ScreenSaverCode.forEachCount2_3+gdjs.ScreenSaverCode.forEachCount3_3+gdjs.ScreenSaverCode.forEachCount4_3+gdjs.ScreenSaverCode.forEachCount5_3) {
    gdjs.ScreenSaverCode.GDBall_956Objects3.push(gdjs.ScreenSaverCode.forEachObjects3[gdjs.ScreenSaverCode.forEachIndex3]);
}
if (true) {

{ //Subevents: 
gdjs.ScreenSaverCode.eventsList12(runtimeScene);} //Subevents end.
}
}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("BouncerG"), gdjs.ScreenSaverCode.GDBouncerGObjects1);
gdjs.copyArray(runtimeScene.getObjects("GdevelopGLogoBlack"), gdjs.ScreenSaverCode.GDGdevelopGLogoBlackObjects1);
{for(var i = 0, len = gdjs.ScreenSaverCode.GDBouncerGObjects1.length ;i < len;++i) {
    gdjs.ScreenSaverCode.GDBouncerGObjects1[i].addPolarForce(90, 4, 1);
}
for(var i = 0, len = gdjs.ScreenSaverCode.GDGdevelopGLogoBlackObjects1.length ;i < len;++i) {
    gdjs.ScreenSaverCode.GDGdevelopGLogoBlackObjects1[i].addPolarForce(90, 4, 1);
}
}}

}


};gdjs.ScreenSaverCode.eventsList14 = function(runtimeScene) {

{


gdjs.ScreenSaverCode.eventsList10(runtimeScene);
}


{


gdjs.ScreenSaverCode.eventsList13(runtimeScene);
}


};

gdjs.ScreenSaverCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.ScreenSaverCode.GDBall_951Objects1.length = 0;
gdjs.ScreenSaverCode.GDBall_951Objects2.length = 0;
gdjs.ScreenSaverCode.GDBall_951Objects3.length = 0;
gdjs.ScreenSaverCode.GDBall_951Objects4.length = 0;
gdjs.ScreenSaverCode.GDBall_951Objects5.length = 0;
gdjs.ScreenSaverCode.GDBall_951Objects6.length = 0;
gdjs.ScreenSaverCode.GDBall_952Objects1.length = 0;
gdjs.ScreenSaverCode.GDBall_952Objects2.length = 0;
gdjs.ScreenSaverCode.GDBall_952Objects3.length = 0;
gdjs.ScreenSaverCode.GDBall_952Objects4.length = 0;
gdjs.ScreenSaverCode.GDBall_952Objects5.length = 0;
gdjs.ScreenSaverCode.GDBall_952Objects6.length = 0;
gdjs.ScreenSaverCode.GDBall_953Objects1.length = 0;
gdjs.ScreenSaverCode.GDBall_953Objects2.length = 0;
gdjs.ScreenSaverCode.GDBall_953Objects3.length = 0;
gdjs.ScreenSaverCode.GDBall_953Objects4.length = 0;
gdjs.ScreenSaverCode.GDBall_953Objects5.length = 0;
gdjs.ScreenSaverCode.GDBall_953Objects6.length = 0;
gdjs.ScreenSaverCode.GDBall_954Objects1.length = 0;
gdjs.ScreenSaverCode.GDBall_954Objects2.length = 0;
gdjs.ScreenSaverCode.GDBall_954Objects3.length = 0;
gdjs.ScreenSaverCode.GDBall_954Objects4.length = 0;
gdjs.ScreenSaverCode.GDBall_954Objects5.length = 0;
gdjs.ScreenSaverCode.GDBall_954Objects6.length = 0;
gdjs.ScreenSaverCode.GDBall_955Objects1.length = 0;
gdjs.ScreenSaverCode.GDBall_955Objects2.length = 0;
gdjs.ScreenSaverCode.GDBall_955Objects3.length = 0;
gdjs.ScreenSaverCode.GDBall_955Objects4.length = 0;
gdjs.ScreenSaverCode.GDBall_955Objects5.length = 0;
gdjs.ScreenSaverCode.GDBall_955Objects6.length = 0;
gdjs.ScreenSaverCode.GDBall_956Objects1.length = 0;
gdjs.ScreenSaverCode.GDBall_956Objects2.length = 0;
gdjs.ScreenSaverCode.GDBall_956Objects3.length = 0;
gdjs.ScreenSaverCode.GDBall_956Objects4.length = 0;
gdjs.ScreenSaverCode.GDBall_956Objects5.length = 0;
gdjs.ScreenSaverCode.GDBall_956Objects6.length = 0;
gdjs.ScreenSaverCode.GDGlassBreaking_95ParticlesObjects1.length = 0;
gdjs.ScreenSaverCode.GDGlassBreaking_95ParticlesObjects2.length = 0;
gdjs.ScreenSaverCode.GDGlassBreaking_95ParticlesObjects3.length = 0;
gdjs.ScreenSaverCode.GDGlassBreaking_95ParticlesObjects4.length = 0;
gdjs.ScreenSaverCode.GDGlassBreaking_95ParticlesObjects5.length = 0;
gdjs.ScreenSaverCode.GDGlassBreaking_95ParticlesObjects6.length = 0;
gdjs.ScreenSaverCode.GDCupObjects1.length = 0;
gdjs.ScreenSaverCode.GDCupObjects2.length = 0;
gdjs.ScreenSaverCode.GDCupObjects3.length = 0;
gdjs.ScreenSaverCode.GDCupObjects4.length = 0;
gdjs.ScreenSaverCode.GDCupObjects5.length = 0;
gdjs.ScreenSaverCode.GDCupObjects6.length = 0;
gdjs.ScreenSaverCode.GDCupFrontObjects1.length = 0;
gdjs.ScreenSaverCode.GDCupFrontObjects2.length = 0;
gdjs.ScreenSaverCode.GDCupFrontObjects3.length = 0;
gdjs.ScreenSaverCode.GDCupFrontObjects4.length = 0;
gdjs.ScreenSaverCode.GDCupFrontObjects5.length = 0;
gdjs.ScreenSaverCode.GDCupFrontObjects6.length = 0;
gdjs.ScreenSaverCode.GDCloud1Objects1.length = 0;
gdjs.ScreenSaverCode.GDCloud1Objects2.length = 0;
gdjs.ScreenSaverCode.GDCloud1Objects3.length = 0;
gdjs.ScreenSaverCode.GDCloud1Objects4.length = 0;
gdjs.ScreenSaverCode.GDCloud1Objects5.length = 0;
gdjs.ScreenSaverCode.GDCloud1Objects6.length = 0;
gdjs.ScreenSaverCode.GDCloud2Objects1.length = 0;
gdjs.ScreenSaverCode.GDCloud2Objects2.length = 0;
gdjs.ScreenSaverCode.GDCloud2Objects3.length = 0;
gdjs.ScreenSaverCode.GDCloud2Objects4.length = 0;
gdjs.ScreenSaverCode.GDCloud2Objects5.length = 0;
gdjs.ScreenSaverCode.GDCloud2Objects6.length = 0;
gdjs.ScreenSaverCode.GDCloud3Objects1.length = 0;
gdjs.ScreenSaverCode.GDCloud3Objects2.length = 0;
gdjs.ScreenSaverCode.GDCloud3Objects3.length = 0;
gdjs.ScreenSaverCode.GDCloud3Objects4.length = 0;
gdjs.ScreenSaverCode.GDCloud3Objects5.length = 0;
gdjs.ScreenSaverCode.GDCloud3Objects6.length = 0;
gdjs.ScreenSaverCode.GDCloud4Objects1.length = 0;
gdjs.ScreenSaverCode.GDCloud4Objects2.length = 0;
gdjs.ScreenSaverCode.GDCloud4Objects3.length = 0;
gdjs.ScreenSaverCode.GDCloud4Objects4.length = 0;
gdjs.ScreenSaverCode.GDCloud4Objects5.length = 0;
gdjs.ScreenSaverCode.GDCloud4Objects6.length = 0;
gdjs.ScreenSaverCode.GDEditInGDevelop_95TextObjects1.length = 0;
gdjs.ScreenSaverCode.GDEditInGDevelop_95TextObjects2.length = 0;
gdjs.ScreenSaverCode.GDEditInGDevelop_95TextObjects3.length = 0;
gdjs.ScreenSaverCode.GDEditInGDevelop_95TextObjects4.length = 0;
gdjs.ScreenSaverCode.GDEditInGDevelop_95TextObjects5.length = 0;
gdjs.ScreenSaverCode.GDEditInGDevelop_95TextObjects6.length = 0;
gdjs.ScreenSaverCode.GDGreyButtonObjects1.length = 0;
gdjs.ScreenSaverCode.GDGreyButtonObjects2.length = 0;
gdjs.ScreenSaverCode.GDGreyButtonObjects3.length = 0;
gdjs.ScreenSaverCode.GDGreyButtonObjects4.length = 0;
gdjs.ScreenSaverCode.GDGreyButtonObjects5.length = 0;
gdjs.ScreenSaverCode.GDGreyButtonObjects6.length = 0;
gdjs.ScreenSaverCode.GDCurrentLevel_95TextObjects1.length = 0;
gdjs.ScreenSaverCode.GDCurrentLevel_95TextObjects2.length = 0;
gdjs.ScreenSaverCode.GDCurrentLevel_95TextObjects3.length = 0;
gdjs.ScreenSaverCode.GDCurrentLevel_95TextObjects4.length = 0;
gdjs.ScreenSaverCode.GDCurrentLevel_95TextObjects5.length = 0;
gdjs.ScreenSaverCode.GDCurrentLevel_95TextObjects6.length = 0;
gdjs.ScreenSaverCode.GDMenuObjects1.length = 0;
gdjs.ScreenSaverCode.GDMenuObjects2.length = 0;
gdjs.ScreenSaverCode.GDMenuObjects3.length = 0;
gdjs.ScreenSaverCode.GDMenuObjects4.length = 0;
gdjs.ScreenSaverCode.GDMenuObjects5.length = 0;
gdjs.ScreenSaverCode.GDMenuObjects6.length = 0;
gdjs.ScreenSaverCode.GDGameState_95TextObjects1.length = 0;
gdjs.ScreenSaverCode.GDGameState_95TextObjects2.length = 0;
gdjs.ScreenSaverCode.GDGameState_95TextObjects3.length = 0;
gdjs.ScreenSaverCode.GDGameState_95TextObjects4.length = 0;
gdjs.ScreenSaverCode.GDGameState_95TextObjects5.length = 0;
gdjs.ScreenSaverCode.GDGameState_95TextObjects6.length = 0;
gdjs.ScreenSaverCode.GDMovesMade_95TextObjects1.length = 0;
gdjs.ScreenSaverCode.GDMovesMade_95TextObjects2.length = 0;
gdjs.ScreenSaverCode.GDMovesMade_95TextObjects3.length = 0;
gdjs.ScreenSaverCode.GDMovesMade_95TextObjects4.length = 0;
gdjs.ScreenSaverCode.GDMovesMade_95TextObjects5.length = 0;
gdjs.ScreenSaverCode.GDMovesMade_95TextObjects6.length = 0;
gdjs.ScreenSaverCode.GDTimeSpent_95TextObjects1.length = 0;
gdjs.ScreenSaverCode.GDTimeSpent_95TextObjects2.length = 0;
gdjs.ScreenSaverCode.GDTimeSpent_95TextObjects3.length = 0;
gdjs.ScreenSaverCode.GDTimeSpent_95TextObjects4.length = 0;
gdjs.ScreenSaverCode.GDTimeSpent_95TextObjects5.length = 0;
gdjs.ScreenSaverCode.GDTimeSpent_95TextObjects6.length = 0;
gdjs.ScreenSaverCode.GDBallsInCup_95TextObjects1.length = 0;
gdjs.ScreenSaverCode.GDBallsInCup_95TextObjects2.length = 0;
gdjs.ScreenSaverCode.GDBallsInCup_95TextObjects3.length = 0;
gdjs.ScreenSaverCode.GDBallsInCup_95TextObjects4.length = 0;
gdjs.ScreenSaverCode.GDBallsInCup_95TextObjects5.length = 0;
gdjs.ScreenSaverCode.GDBallsInCup_95TextObjects6.length = 0;
gdjs.ScreenSaverCode.GDPlay_95TextObjects1.length = 0;
gdjs.ScreenSaverCode.GDPlay_95TextObjects2.length = 0;
gdjs.ScreenSaverCode.GDPlay_95TextObjects3.length = 0;
gdjs.ScreenSaverCode.GDPlay_95TextObjects4.length = 0;
gdjs.ScreenSaverCode.GDPlay_95TextObjects5.length = 0;
gdjs.ScreenSaverCode.GDPlay_95TextObjects6.length = 0;
gdjs.ScreenSaverCode.GDLeaderboardObjects1.length = 0;
gdjs.ScreenSaverCode.GDLeaderboardObjects2.length = 0;
gdjs.ScreenSaverCode.GDLeaderboardObjects3.length = 0;
gdjs.ScreenSaverCode.GDLeaderboardObjects4.length = 0;
gdjs.ScreenSaverCode.GDLeaderboardObjects5.length = 0;
gdjs.ScreenSaverCode.GDLeaderboardObjects6.length = 0;
gdjs.ScreenSaverCode.GDMainMenu_95TextObjects1.length = 0;
gdjs.ScreenSaverCode.GDMainMenu_95TextObjects2.length = 0;
gdjs.ScreenSaverCode.GDMainMenu_95TextObjects3.length = 0;
gdjs.ScreenSaverCode.GDMainMenu_95TextObjects4.length = 0;
gdjs.ScreenSaverCode.GDMainMenu_95TextObjects5.length = 0;
gdjs.ScreenSaverCode.GDMainMenu_95TextObjects6.length = 0;
gdjs.ScreenSaverCode.GDResetProgress_95TextObjects1.length = 0;
gdjs.ScreenSaverCode.GDResetProgress_95TextObjects2.length = 0;
gdjs.ScreenSaverCode.GDResetProgress_95TextObjects3.length = 0;
gdjs.ScreenSaverCode.GDResetProgress_95TextObjects4.length = 0;
gdjs.ScreenSaverCode.GDResetProgress_95TextObjects5.length = 0;
gdjs.ScreenSaverCode.GDResetProgress_95TextObjects6.length = 0;
gdjs.ScreenSaverCode.GDStartOver_95TextObjects1.length = 0;
gdjs.ScreenSaverCode.GDStartOver_95TextObjects2.length = 0;
gdjs.ScreenSaverCode.GDStartOver_95TextObjects3.length = 0;
gdjs.ScreenSaverCode.GDStartOver_95TextObjects4.length = 0;
gdjs.ScreenSaverCode.GDStartOver_95TextObjects5.length = 0;
gdjs.ScreenSaverCode.GDStartOver_95TextObjects6.length = 0;
gdjs.ScreenSaverCode.GDSubmit_95TextObjects1.length = 0;
gdjs.ScreenSaverCode.GDSubmit_95TextObjects2.length = 0;
gdjs.ScreenSaverCode.GDSubmit_95TextObjects3.length = 0;
gdjs.ScreenSaverCode.GDSubmit_95TextObjects4.length = 0;
gdjs.ScreenSaverCode.GDSubmit_95TextObjects5.length = 0;
gdjs.ScreenSaverCode.GDSubmit_95TextObjects6.length = 0;
gdjs.ScreenSaverCode.GDResetWarning_95TextObjects1.length = 0;
gdjs.ScreenSaverCode.GDResetWarning_95TextObjects2.length = 0;
gdjs.ScreenSaverCode.GDResetWarning_95TextObjects3.length = 0;
gdjs.ScreenSaverCode.GDResetWarning_95TextObjects4.length = 0;
gdjs.ScreenSaverCode.GDResetWarning_95TextObjects5.length = 0;
gdjs.ScreenSaverCode.GDResetWarning_95TextObjects6.length = 0;
gdjs.ScreenSaverCode.GDPaused_95TextObjects1.length = 0;
gdjs.ScreenSaverCode.GDPaused_95TextObjects2.length = 0;
gdjs.ScreenSaverCode.GDPaused_95TextObjects3.length = 0;
gdjs.ScreenSaverCode.GDPaused_95TextObjects4.length = 0;
gdjs.ScreenSaverCode.GDPaused_95TextObjects5.length = 0;
gdjs.ScreenSaverCode.GDPaused_95TextObjects6.length = 0;
gdjs.ScreenSaverCode.GDBouncerGObjects1.length = 0;
gdjs.ScreenSaverCode.GDBouncerGObjects2.length = 0;
gdjs.ScreenSaverCode.GDBouncerGObjects3.length = 0;
gdjs.ScreenSaverCode.GDBouncerGObjects4.length = 0;
gdjs.ScreenSaverCode.GDBouncerGObjects5.length = 0;
gdjs.ScreenSaverCode.GDBouncerGObjects6.length = 0;
gdjs.ScreenSaverCode.GDGdevelopGLogoBlackObjects1.length = 0;
gdjs.ScreenSaverCode.GDGdevelopGLogoBlackObjects2.length = 0;
gdjs.ScreenSaverCode.GDGdevelopGLogoBlackObjects3.length = 0;
gdjs.ScreenSaverCode.GDGdevelopGLogoBlackObjects4.length = 0;
gdjs.ScreenSaverCode.GDGdevelopGLogoBlackObjects5.length = 0;
gdjs.ScreenSaverCode.GDGdevelopGLogoBlackObjects6.length = 0;

gdjs.ScreenSaverCode.eventsList14(runtimeScene);

return;

}

gdjs['ScreenSaverCode'] = gdjs.ScreenSaverCode;
