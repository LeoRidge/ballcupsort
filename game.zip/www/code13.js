gdjs.ViewLeaderboardsCode = {};
gdjs.ViewLeaderboardsCode.GDGreyButtonObjects1_1final = [];

gdjs.ViewLeaderboardsCode.GDGreyButtonObjects2_3final = [];

gdjs.ViewLeaderboardsCode.GDMenuObjects1_1final = [];

gdjs.ViewLeaderboardsCode.GDMenuObjects2_3final = [];

gdjs.ViewLeaderboardsCode.GDPlay_95TextObjects1_1final = [];

gdjs.ViewLeaderboardsCode.GDBall_951Objects1= [];
gdjs.ViewLeaderboardsCode.GDBall_951Objects2= [];
gdjs.ViewLeaderboardsCode.GDBall_951Objects3= [];
gdjs.ViewLeaderboardsCode.GDBall_952Objects1= [];
gdjs.ViewLeaderboardsCode.GDBall_952Objects2= [];
gdjs.ViewLeaderboardsCode.GDBall_952Objects3= [];
gdjs.ViewLeaderboardsCode.GDBall_953Objects1= [];
gdjs.ViewLeaderboardsCode.GDBall_953Objects2= [];
gdjs.ViewLeaderboardsCode.GDBall_953Objects3= [];
gdjs.ViewLeaderboardsCode.GDBall_954Objects1= [];
gdjs.ViewLeaderboardsCode.GDBall_954Objects2= [];
gdjs.ViewLeaderboardsCode.GDBall_954Objects3= [];
gdjs.ViewLeaderboardsCode.GDBall_955Objects1= [];
gdjs.ViewLeaderboardsCode.GDBall_955Objects2= [];
gdjs.ViewLeaderboardsCode.GDBall_955Objects3= [];
gdjs.ViewLeaderboardsCode.GDBall_956Objects1= [];
gdjs.ViewLeaderboardsCode.GDBall_956Objects2= [];
gdjs.ViewLeaderboardsCode.GDBall_956Objects3= [];
gdjs.ViewLeaderboardsCode.GDGlassBreaking_95ParticlesObjects1= [];
gdjs.ViewLeaderboardsCode.GDGlassBreaking_95ParticlesObjects2= [];
gdjs.ViewLeaderboardsCode.GDGlassBreaking_95ParticlesObjects3= [];
gdjs.ViewLeaderboardsCode.GDCupObjects1= [];
gdjs.ViewLeaderboardsCode.GDCupObjects2= [];
gdjs.ViewLeaderboardsCode.GDCupObjects3= [];
gdjs.ViewLeaderboardsCode.GDCupFrontObjects1= [];
gdjs.ViewLeaderboardsCode.GDCupFrontObjects2= [];
gdjs.ViewLeaderboardsCode.GDCupFrontObjects3= [];
gdjs.ViewLeaderboardsCode.GDCloud1Objects1= [];
gdjs.ViewLeaderboardsCode.GDCloud1Objects2= [];
gdjs.ViewLeaderboardsCode.GDCloud1Objects3= [];
gdjs.ViewLeaderboardsCode.GDCloud2Objects1= [];
gdjs.ViewLeaderboardsCode.GDCloud2Objects2= [];
gdjs.ViewLeaderboardsCode.GDCloud2Objects3= [];
gdjs.ViewLeaderboardsCode.GDCloud3Objects1= [];
gdjs.ViewLeaderboardsCode.GDCloud3Objects2= [];
gdjs.ViewLeaderboardsCode.GDCloud3Objects3= [];
gdjs.ViewLeaderboardsCode.GDCloud4Objects1= [];
gdjs.ViewLeaderboardsCode.GDCloud4Objects2= [];
gdjs.ViewLeaderboardsCode.GDCloud4Objects3= [];
gdjs.ViewLeaderboardsCode.GDEditInGDevelop_95TextObjects1= [];
gdjs.ViewLeaderboardsCode.GDEditInGDevelop_95TextObjects2= [];
gdjs.ViewLeaderboardsCode.GDEditInGDevelop_95TextObjects3= [];
gdjs.ViewLeaderboardsCode.GDGreyButtonObjects1= [];
gdjs.ViewLeaderboardsCode.GDGreyButtonObjects2= [];
gdjs.ViewLeaderboardsCode.GDGreyButtonObjects3= [];
gdjs.ViewLeaderboardsCode.GDCurrentLevel_95TextObjects1= [];
gdjs.ViewLeaderboardsCode.GDCurrentLevel_95TextObjects2= [];
gdjs.ViewLeaderboardsCode.GDCurrentLevel_95TextObjects3= [];
gdjs.ViewLeaderboardsCode.GDMenuObjects1= [];
gdjs.ViewLeaderboardsCode.GDMenuObjects2= [];
gdjs.ViewLeaderboardsCode.GDMenuObjects3= [];
gdjs.ViewLeaderboardsCode.GDGameState_95TextObjects1= [];
gdjs.ViewLeaderboardsCode.GDGameState_95TextObjects2= [];
gdjs.ViewLeaderboardsCode.GDGameState_95TextObjects3= [];
gdjs.ViewLeaderboardsCode.GDMovesMade_95TextObjects1= [];
gdjs.ViewLeaderboardsCode.GDMovesMade_95TextObjects2= [];
gdjs.ViewLeaderboardsCode.GDMovesMade_95TextObjects3= [];
gdjs.ViewLeaderboardsCode.GDTimeSpent_95TextObjects1= [];
gdjs.ViewLeaderboardsCode.GDTimeSpent_95TextObjects2= [];
gdjs.ViewLeaderboardsCode.GDTimeSpent_95TextObjects3= [];
gdjs.ViewLeaderboardsCode.GDBallsInCup_95TextObjects1= [];
gdjs.ViewLeaderboardsCode.GDBallsInCup_95TextObjects2= [];
gdjs.ViewLeaderboardsCode.GDBallsInCup_95TextObjects3= [];
gdjs.ViewLeaderboardsCode.GDPlay_95TextObjects1= [];
gdjs.ViewLeaderboardsCode.GDPlay_95TextObjects2= [];
gdjs.ViewLeaderboardsCode.GDPlay_95TextObjects3= [];
gdjs.ViewLeaderboardsCode.GDLeaderboardObjects1= [];
gdjs.ViewLeaderboardsCode.GDLeaderboardObjects2= [];
gdjs.ViewLeaderboardsCode.GDLeaderboardObjects3= [];
gdjs.ViewLeaderboardsCode.GDMainMenu_95TextObjects1= [];
gdjs.ViewLeaderboardsCode.GDMainMenu_95TextObjects2= [];
gdjs.ViewLeaderboardsCode.GDMainMenu_95TextObjects3= [];
gdjs.ViewLeaderboardsCode.GDResetProgress_95TextObjects1= [];
gdjs.ViewLeaderboardsCode.GDResetProgress_95TextObjects2= [];
gdjs.ViewLeaderboardsCode.GDResetProgress_95TextObjects3= [];
gdjs.ViewLeaderboardsCode.GDStartOver_95TextObjects1= [];
gdjs.ViewLeaderboardsCode.GDStartOver_95TextObjects2= [];
gdjs.ViewLeaderboardsCode.GDStartOver_95TextObjects3= [];
gdjs.ViewLeaderboardsCode.GDSubmit_95TextObjects1= [];
gdjs.ViewLeaderboardsCode.GDSubmit_95TextObjects2= [];
gdjs.ViewLeaderboardsCode.GDSubmit_95TextObjects3= [];
gdjs.ViewLeaderboardsCode.GDFastestTime_95TextObjects1= [];
gdjs.ViewLeaderboardsCode.GDFastestTime_95TextObjects2= [];
gdjs.ViewLeaderboardsCode.GDFastestTime_95TextObjects3= [];
gdjs.ViewLeaderboardsCode.GDFewestMoves_95TextObjects1= [];
gdjs.ViewLeaderboardsCode.GDFewestMoves_95TextObjects2= [];
gdjs.ViewLeaderboardsCode.GDFewestMoves_95TextObjects3= [];
gdjs.ViewLeaderboardsCode.GDViewLeaderboards_95TextObjects1= [];
gdjs.ViewLeaderboardsCode.GDViewLeaderboards_95TextObjects2= [];
gdjs.ViewLeaderboardsCode.GDViewLeaderboards_95TextObjects3= [];

gdjs.ViewLeaderboardsCode.conditionTrue_0 = {val:false};
gdjs.ViewLeaderboardsCode.condition0IsTrue_0 = {val:false};
gdjs.ViewLeaderboardsCode.condition1IsTrue_0 = {val:false};
gdjs.ViewLeaderboardsCode.condition2IsTrue_0 = {val:false};
gdjs.ViewLeaderboardsCode.condition3IsTrue_0 = {val:false};
gdjs.ViewLeaderboardsCode.conditionTrue_1 = {val:false};
gdjs.ViewLeaderboardsCode.condition0IsTrue_1 = {val:false};
gdjs.ViewLeaderboardsCode.condition1IsTrue_1 = {val:false};
gdjs.ViewLeaderboardsCode.condition2IsTrue_1 = {val:false};
gdjs.ViewLeaderboardsCode.condition3IsTrue_1 = {val:false};
gdjs.ViewLeaderboardsCode.conditionTrue_2 = {val:false};
gdjs.ViewLeaderboardsCode.condition0IsTrue_2 = {val:false};
gdjs.ViewLeaderboardsCode.condition1IsTrue_2 = {val:false};
gdjs.ViewLeaderboardsCode.condition2IsTrue_2 = {val:false};
gdjs.ViewLeaderboardsCode.condition3IsTrue_2 = {val:false};
gdjs.ViewLeaderboardsCode.conditionTrue_3 = {val:false};
gdjs.ViewLeaderboardsCode.condition0IsTrue_3 = {val:false};
gdjs.ViewLeaderboardsCode.condition1IsTrue_3 = {val:false};
gdjs.ViewLeaderboardsCode.condition2IsTrue_3 = {val:false};
gdjs.ViewLeaderboardsCode.condition3IsTrue_3 = {val:false};


gdjs.ViewLeaderboardsCode.mapOfGDgdjs_46ViewLeaderboardsCode_46GDGreyButtonObjects2ObjectsGDgdjs_46ViewLeaderboardsCode_46GDLeaderboardObjects2ObjectsGDgdjs_46ViewLeaderboardsCode_46GDMenuObjects2Objects = Hashtable.newFrom({"GreyButton": gdjs.ViewLeaderboardsCode.GDGreyButtonObjects2, "Leaderboard": gdjs.ViewLeaderboardsCode.GDLeaderboardObjects2, "Menu": gdjs.ViewLeaderboardsCode.GDMenuObjects2});
gdjs.ViewLeaderboardsCode.mapOfGDgdjs_46ViewLeaderboardsCode_46GDPlay_9595TextObjects2ObjectsGDgdjs_46ViewLeaderboardsCode_46GDMainMenu_9595TextObjects2ObjectsGDgdjs_46ViewLeaderboardsCode_46GDResetProgress_9595TextObjects2ObjectsGDgdjs_46ViewLeaderboardsCode_46GDStartOver_9595TextObjects2ObjectsGDgdjs_46ViewLeaderboardsCode_46GDSubmit_9595TextObjects2Objects = Hashtable.newFrom({"Play_Text": gdjs.ViewLeaderboardsCode.GDPlay_95TextObjects2, "MainMenu_Text": gdjs.ViewLeaderboardsCode.GDMainMenu_95TextObjects2, "ResetProgress_Text": gdjs.ViewLeaderboardsCode.GDResetProgress_95TextObjects2, "StartOver_Text": gdjs.ViewLeaderboardsCode.GDStartOver_95TextObjects2, "Submit_Text": gdjs.ViewLeaderboardsCode.GDSubmit_95TextObjects2});
gdjs.ViewLeaderboardsCode.mapOfGDgdjs_46ViewLeaderboardsCode_46GDGreyButtonObjects2ObjectsGDgdjs_46ViewLeaderboardsCode_46GDLeaderboardObjects2ObjectsGDgdjs_46ViewLeaderboardsCode_46GDMenuObjects2Objects = Hashtable.newFrom({"GreyButton": gdjs.ViewLeaderboardsCode.GDGreyButtonObjects2, "Leaderboard": gdjs.ViewLeaderboardsCode.GDLeaderboardObjects2, "Menu": gdjs.ViewLeaderboardsCode.GDMenuObjects2});
gdjs.ViewLeaderboardsCode.eventsList0 = function(runtimeScene) {

{

/* Reuse gdjs.ViewLeaderboardsCode.GDGreyButtonObjects2 */
/* Reuse gdjs.ViewLeaderboardsCode.GDLeaderboardObjects2 */
gdjs.copyArray(runtimeScene.getObjects("MainMenu_Text"), gdjs.ViewLeaderboardsCode.GDMainMenu_95TextObjects2);
/* Reuse gdjs.ViewLeaderboardsCode.GDMenuObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Play_Text"), gdjs.ViewLeaderboardsCode.GDPlay_95TextObjects2);
gdjs.copyArray(runtimeScene.getObjects("ResetProgress_Text"), gdjs.ViewLeaderboardsCode.GDResetProgress_95TextObjects2);
gdjs.copyArray(runtimeScene.getObjects("StartOver_Text"), gdjs.ViewLeaderboardsCode.GDStartOver_95TextObjects2);
gdjs.copyArray(runtimeScene.getObjects("Submit_Text"), gdjs.ViewLeaderboardsCode.GDSubmit_95TextObjects2);

gdjs.ViewLeaderboardsCode.condition0IsTrue_0.val = false;
{
gdjs.ViewLeaderboardsCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ViewLeaderboardsCode.mapOfGDgdjs_46ViewLeaderboardsCode_46GDPlay_9595TextObjects2ObjectsGDgdjs_46ViewLeaderboardsCode_46GDMainMenu_9595TextObjects2ObjectsGDgdjs_46ViewLeaderboardsCode_46GDResetProgress_9595TextObjects2ObjectsGDgdjs_46ViewLeaderboardsCode_46GDStartOver_9595TextObjects2ObjectsGDgdjs_46ViewLeaderboardsCode_46GDSubmit_9595TextObjects2Objects, gdjs.ViewLeaderboardsCode.mapOfGDgdjs_46ViewLeaderboardsCode_46GDGreyButtonObjects2ObjectsGDgdjs_46ViewLeaderboardsCode_46GDLeaderboardObjects2ObjectsGDgdjs_46ViewLeaderboardsCode_46GDMenuObjects2Objects, false, runtimeScene, false);
}if (gdjs.ViewLeaderboardsCode.condition0IsTrue_0.val) {
/* Reuse gdjs.ViewLeaderboardsCode.GDMainMenu_95TextObjects2 */
/* Reuse gdjs.ViewLeaderboardsCode.GDPlay_95TextObjects2 */
/* Reuse gdjs.ViewLeaderboardsCode.GDResetProgress_95TextObjects2 */
/* Reuse gdjs.ViewLeaderboardsCode.GDStartOver_95TextObjects2 */
/* Reuse gdjs.ViewLeaderboardsCode.GDSubmit_95TextObjects2 */
{for(var i = 0, len = gdjs.ViewLeaderboardsCode.GDPlay_95TextObjects2.length ;i < len;++i) {
    gdjs.ViewLeaderboardsCode.GDPlay_95TextObjects2[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.ViewLeaderboardsCode.GDMainMenu_95TextObjects2.length ;i < len;++i) {
    gdjs.ViewLeaderboardsCode.GDMainMenu_95TextObjects2[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.ViewLeaderboardsCode.GDResetProgress_95TextObjects2.length ;i < len;++i) {
    gdjs.ViewLeaderboardsCode.GDResetProgress_95TextObjects2[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.ViewLeaderboardsCode.GDStartOver_95TextObjects2.length ;i < len;++i) {
    gdjs.ViewLeaderboardsCode.GDStartOver_95TextObjects2[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.ViewLeaderboardsCode.GDSubmit_95TextObjects2.length ;i < len;++i) {
    gdjs.ViewLeaderboardsCode.GDSubmit_95TextObjects2[i].setColor("255;255;255");
}
}}

}


};gdjs.ViewLeaderboardsCode.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("GreyButton"), gdjs.ViewLeaderboardsCode.GDGreyButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Leaderboard"), gdjs.ViewLeaderboardsCode.GDLeaderboardObjects2);
gdjs.copyArray(runtimeScene.getObjects("Menu"), gdjs.ViewLeaderboardsCode.GDMenuObjects2);

gdjs.ViewLeaderboardsCode.condition0IsTrue_0.val = false;
{
gdjs.ViewLeaderboardsCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.ViewLeaderboardsCode.mapOfGDgdjs_46ViewLeaderboardsCode_46GDGreyButtonObjects2ObjectsGDgdjs_46ViewLeaderboardsCode_46GDLeaderboardObjects2ObjectsGDgdjs_46ViewLeaderboardsCode_46GDMenuObjects2Objects, runtimeScene, true, true);
}if (gdjs.ViewLeaderboardsCode.condition0IsTrue_0.val) {
/* Reuse gdjs.ViewLeaderboardsCode.GDGreyButtonObjects2 */
/* Reuse gdjs.ViewLeaderboardsCode.GDLeaderboardObjects2 */
/* Reuse gdjs.ViewLeaderboardsCode.GDMenuObjects2 */
{for(var i = 0, len = gdjs.ViewLeaderboardsCode.GDGreyButtonObjects2.length ;i < len;++i) {
    gdjs.ViewLeaderboardsCode.GDGreyButtonObjects2[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.ViewLeaderboardsCode.GDLeaderboardObjects2.length ;i < len;++i) {
    gdjs.ViewLeaderboardsCode.GDLeaderboardObjects2[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.ViewLeaderboardsCode.GDMenuObjects2.length ;i < len;++i) {
    gdjs.ViewLeaderboardsCode.GDMenuObjects2[i].setColor("255;255;255");
}
}{for(var i = 0, len = gdjs.ViewLeaderboardsCode.GDGreyButtonObjects2.length ;i < len;++i) {
    gdjs.ViewLeaderboardsCode.GDGreyButtonObjects2[i].enableEffect("Effect", false);
}
for(var i = 0, len = gdjs.ViewLeaderboardsCode.GDLeaderboardObjects2.length ;i < len;++i) {
    gdjs.ViewLeaderboardsCode.GDLeaderboardObjects2[i].enableEffect("Effect", false);
}
for(var i = 0, len = gdjs.ViewLeaderboardsCode.GDMenuObjects2.length ;i < len;++i) {
    gdjs.ViewLeaderboardsCode.GDMenuObjects2[i].enableEffect("Effect", false);
}
}
{ //Subevents
gdjs.ViewLeaderboardsCode.eventsList0(runtimeScene);} //End of subevents
}

}


};gdjs.ViewLeaderboardsCode.mapOfGDgdjs_46ViewLeaderboardsCode_46GDGreyButtonObjects2ObjectsGDgdjs_46ViewLeaderboardsCode_46GDLeaderboardObjects2ObjectsGDgdjs_46ViewLeaderboardsCode_46GDMenuObjects2Objects = Hashtable.newFrom({"GreyButton": gdjs.ViewLeaderboardsCode.GDGreyButtonObjects2, "Leaderboard": gdjs.ViewLeaderboardsCode.GDLeaderboardObjects2, "Menu": gdjs.ViewLeaderboardsCode.GDMenuObjects2});
gdjs.ViewLeaderboardsCode.mapOfGDgdjs_46ViewLeaderboardsCode_46GDPlay_9595TextObjects2ObjectsGDgdjs_46ViewLeaderboardsCode_46GDMainMenu_9595TextObjects2ObjectsGDgdjs_46ViewLeaderboardsCode_46GDResetProgress_9595TextObjects2ObjectsGDgdjs_46ViewLeaderboardsCode_46GDStartOver_9595TextObjects2ObjectsGDgdjs_46ViewLeaderboardsCode_46GDSubmit_9595TextObjects2Objects = Hashtable.newFrom({"Play_Text": gdjs.ViewLeaderboardsCode.GDPlay_95TextObjects2, "MainMenu_Text": gdjs.ViewLeaderboardsCode.GDMainMenu_95TextObjects2, "ResetProgress_Text": gdjs.ViewLeaderboardsCode.GDResetProgress_95TextObjects2, "StartOver_Text": gdjs.ViewLeaderboardsCode.GDStartOver_95TextObjects2, "Submit_Text": gdjs.ViewLeaderboardsCode.GDSubmit_95TextObjects2});
gdjs.ViewLeaderboardsCode.mapOfGDgdjs_46ViewLeaderboardsCode_46GDGreyButtonObjects2ObjectsGDgdjs_46ViewLeaderboardsCode_46GDLeaderboardObjects2ObjectsGDgdjs_46ViewLeaderboardsCode_46GDMenuObjects2Objects = Hashtable.newFrom({"GreyButton": gdjs.ViewLeaderboardsCode.GDGreyButtonObjects2, "Leaderboard": gdjs.ViewLeaderboardsCode.GDLeaderboardObjects2, "Menu": gdjs.ViewLeaderboardsCode.GDMenuObjects2});
gdjs.ViewLeaderboardsCode.eventsList2 = function(runtimeScene) {

{

/* Reuse gdjs.ViewLeaderboardsCode.GDGreyButtonObjects2 */
/* Reuse gdjs.ViewLeaderboardsCode.GDLeaderboardObjects2 */
gdjs.copyArray(runtimeScene.getObjects("MainMenu_Text"), gdjs.ViewLeaderboardsCode.GDMainMenu_95TextObjects2);
/* Reuse gdjs.ViewLeaderboardsCode.GDMenuObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Play_Text"), gdjs.ViewLeaderboardsCode.GDPlay_95TextObjects2);
gdjs.copyArray(runtimeScene.getObjects("ResetProgress_Text"), gdjs.ViewLeaderboardsCode.GDResetProgress_95TextObjects2);
gdjs.copyArray(runtimeScene.getObjects("StartOver_Text"), gdjs.ViewLeaderboardsCode.GDStartOver_95TextObjects2);
gdjs.copyArray(runtimeScene.getObjects("Submit_Text"), gdjs.ViewLeaderboardsCode.GDSubmit_95TextObjects2);

gdjs.ViewLeaderboardsCode.condition0IsTrue_0.val = false;
{
gdjs.ViewLeaderboardsCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ViewLeaderboardsCode.mapOfGDgdjs_46ViewLeaderboardsCode_46GDPlay_9595TextObjects2ObjectsGDgdjs_46ViewLeaderboardsCode_46GDMainMenu_9595TextObjects2ObjectsGDgdjs_46ViewLeaderboardsCode_46GDResetProgress_9595TextObjects2ObjectsGDgdjs_46ViewLeaderboardsCode_46GDStartOver_9595TextObjects2ObjectsGDgdjs_46ViewLeaderboardsCode_46GDSubmit_9595TextObjects2Objects, gdjs.ViewLeaderboardsCode.mapOfGDgdjs_46ViewLeaderboardsCode_46GDGreyButtonObjects2ObjectsGDgdjs_46ViewLeaderboardsCode_46GDLeaderboardObjects2ObjectsGDgdjs_46ViewLeaderboardsCode_46GDMenuObjects2Objects, false, runtimeScene, false);
}if (gdjs.ViewLeaderboardsCode.condition0IsTrue_0.val) {
/* Reuse gdjs.ViewLeaderboardsCode.GDMainMenu_95TextObjects2 */
/* Reuse gdjs.ViewLeaderboardsCode.GDPlay_95TextObjects2 */
/* Reuse gdjs.ViewLeaderboardsCode.GDResetProgress_95TextObjects2 */
/* Reuse gdjs.ViewLeaderboardsCode.GDStartOver_95TextObjects2 */
/* Reuse gdjs.ViewLeaderboardsCode.GDSubmit_95TextObjects2 */
{for(var i = 0, len = gdjs.ViewLeaderboardsCode.GDPlay_95TextObjects2.length ;i < len;++i) {
    gdjs.ViewLeaderboardsCode.GDPlay_95TextObjects2[i].setColor("241;91;181");
}
for(var i = 0, len = gdjs.ViewLeaderboardsCode.GDMainMenu_95TextObjects2.length ;i < len;++i) {
    gdjs.ViewLeaderboardsCode.GDMainMenu_95TextObjects2[i].setColor("241;91;181");
}
for(var i = 0, len = gdjs.ViewLeaderboardsCode.GDResetProgress_95TextObjects2.length ;i < len;++i) {
    gdjs.ViewLeaderboardsCode.GDResetProgress_95TextObjects2[i].setColor("241;91;181");
}
for(var i = 0, len = gdjs.ViewLeaderboardsCode.GDStartOver_95TextObjects2.length ;i < len;++i) {
    gdjs.ViewLeaderboardsCode.GDStartOver_95TextObjects2[i].setColor("241;91;181");
}
for(var i = 0, len = gdjs.ViewLeaderboardsCode.GDSubmit_95TextObjects2.length ;i < len;++i) {
    gdjs.ViewLeaderboardsCode.GDSubmit_95TextObjects2[i].setColor("241;91;181");
}
}}

}


};gdjs.ViewLeaderboardsCode.eventsList3 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("GreyButton"), gdjs.ViewLeaderboardsCode.GDGreyButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Leaderboard"), gdjs.ViewLeaderboardsCode.GDLeaderboardObjects2);
gdjs.copyArray(runtimeScene.getObjects("Menu"), gdjs.ViewLeaderboardsCode.GDMenuObjects2);

gdjs.ViewLeaderboardsCode.condition0IsTrue_0.val = false;
gdjs.ViewLeaderboardsCode.condition1IsTrue_0.val = false;
{
gdjs.ViewLeaderboardsCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.ViewLeaderboardsCode.mapOfGDgdjs_46ViewLeaderboardsCode_46GDGreyButtonObjects2ObjectsGDgdjs_46ViewLeaderboardsCode_46GDLeaderboardObjects2ObjectsGDgdjs_46ViewLeaderboardsCode_46GDMenuObjects2Objects, runtimeScene, true, false);
}if ( gdjs.ViewLeaderboardsCode.condition0IsTrue_0.val ) {
{
{gdjs.ViewLeaderboardsCode.conditionTrue_1 = gdjs.ViewLeaderboardsCode.condition1IsTrue_0;
gdjs.ViewLeaderboardsCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11702508);
}
}}
if (gdjs.ViewLeaderboardsCode.condition1IsTrue_0.val) {
/* Reuse gdjs.ViewLeaderboardsCode.GDGreyButtonObjects2 */
/* Reuse gdjs.ViewLeaderboardsCode.GDLeaderboardObjects2 */
/* Reuse gdjs.ViewLeaderboardsCode.GDMenuObjects2 */
{for(var i = 0, len = gdjs.ViewLeaderboardsCode.GDGreyButtonObjects2.length ;i < len;++i) {
    gdjs.ViewLeaderboardsCode.GDGreyButtonObjects2[i].enableEffect("Effect", true);
}
for(var i = 0, len = gdjs.ViewLeaderboardsCode.GDLeaderboardObjects2.length ;i < len;++i) {
    gdjs.ViewLeaderboardsCode.GDLeaderboardObjects2[i].enableEffect("Effect", true);
}
for(var i = 0, len = gdjs.ViewLeaderboardsCode.GDMenuObjects2.length ;i < len;++i) {
    gdjs.ViewLeaderboardsCode.GDMenuObjects2[i].enableEffect("Effect", true);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\audio - BLLTImpt Hit Marker 07.aac", false, 15, 4);
}
{ //Subevents
gdjs.ViewLeaderboardsCode.eventsList2(runtimeScene);} //End of subevents
}

}


};gdjs.ViewLeaderboardsCode.mapOfGDgdjs_46ViewLeaderboardsCode_46GDGreyButtonObjects2ObjectsGDgdjs_46ViewLeaderboardsCode_46GDLeaderboardObjects2ObjectsGDgdjs_46ViewLeaderboardsCode_46GDMenuObjects2Objects = Hashtable.newFrom({"GreyButton": gdjs.ViewLeaderboardsCode.GDGreyButtonObjects2, "Leaderboard": gdjs.ViewLeaderboardsCode.GDLeaderboardObjects2, "Menu": gdjs.ViewLeaderboardsCode.GDMenuObjects2});
gdjs.ViewLeaderboardsCode.eventsList4 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("GreyButton"), gdjs.ViewLeaderboardsCode.GDGreyButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Leaderboard"), gdjs.ViewLeaderboardsCode.GDLeaderboardObjects2);
gdjs.copyArray(runtimeScene.getObjects("Menu"), gdjs.ViewLeaderboardsCode.GDMenuObjects2);

gdjs.ViewLeaderboardsCode.condition0IsTrue_0.val = false;
{
gdjs.ViewLeaderboardsCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.ViewLeaderboardsCode.mapOfGDgdjs_46ViewLeaderboardsCode_46GDGreyButtonObjects2ObjectsGDgdjs_46ViewLeaderboardsCode_46GDLeaderboardObjects2ObjectsGDgdjs_46ViewLeaderboardsCode_46GDMenuObjects2Objects, runtimeScene, true, false);
}if (gdjs.ViewLeaderboardsCode.condition0IsTrue_0.val) {
/* Reuse gdjs.ViewLeaderboardsCode.GDGreyButtonObjects2 */
/* Reuse gdjs.ViewLeaderboardsCode.GDLeaderboardObjects2 */
/* Reuse gdjs.ViewLeaderboardsCode.GDMenuObjects2 */
{for(var i = 0, len = gdjs.ViewLeaderboardsCode.GDGreyButtonObjects2.length ;i < len;++i) {
    gdjs.ViewLeaderboardsCode.GDGreyButtonObjects2[i].setColor("74;74;74");
}
for(var i = 0, len = gdjs.ViewLeaderboardsCode.GDLeaderboardObjects2.length ;i < len;++i) {
    gdjs.ViewLeaderboardsCode.GDLeaderboardObjects2[i].setColor("74;74;74");
}
for(var i = 0, len = gdjs.ViewLeaderboardsCode.GDMenuObjects2.length ;i < len;++i) {
    gdjs.ViewLeaderboardsCode.GDMenuObjects2[i].setColor("74;74;74");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\audio - BLLTImpt Hit Marker 07.aac", false, 40, 2);
}}

}


};gdjs.ViewLeaderboardsCode.mapOfGDgdjs_46ViewLeaderboardsCode_46GDGreyButtonObjects1ObjectsGDgdjs_46ViewLeaderboardsCode_46GDLeaderboardObjects1ObjectsGDgdjs_46ViewLeaderboardsCode_46GDMenuObjects1Objects = Hashtable.newFrom({"GreyButton": gdjs.ViewLeaderboardsCode.GDGreyButtonObjects1, "Leaderboard": gdjs.ViewLeaderboardsCode.GDLeaderboardObjects1, "Menu": gdjs.ViewLeaderboardsCode.GDMenuObjects1});
gdjs.ViewLeaderboardsCode.eventsList5 = function(runtimeScene) {

{


gdjs.ViewLeaderboardsCode.condition0IsTrue_0.val = false;
gdjs.ViewLeaderboardsCode.condition1IsTrue_0.val = false;
{
gdjs.ViewLeaderboardsCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.ViewLeaderboardsCode.condition0IsTrue_0.val ) {
{
{gdjs.ViewLeaderboardsCode.conditionTrue_1 = gdjs.ViewLeaderboardsCode.condition1IsTrue_0;
gdjs.ViewLeaderboardsCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11704564);
}
}}
if (gdjs.ViewLeaderboardsCode.condition1IsTrue_0.val) {

{ //Subevents
gdjs.ViewLeaderboardsCode.eventsList4(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("GreyButton"), gdjs.ViewLeaderboardsCode.GDGreyButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("Leaderboard"), gdjs.ViewLeaderboardsCode.GDLeaderboardObjects1);
gdjs.copyArray(runtimeScene.getObjects("Menu"), gdjs.ViewLeaderboardsCode.GDMenuObjects1);

gdjs.ViewLeaderboardsCode.condition0IsTrue_0.val = false;
gdjs.ViewLeaderboardsCode.condition1IsTrue_0.val = false;
{
gdjs.ViewLeaderboardsCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.ViewLeaderboardsCode.condition0IsTrue_0.val ) {
{
gdjs.ViewLeaderboardsCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.ViewLeaderboardsCode.mapOfGDgdjs_46ViewLeaderboardsCode_46GDGreyButtonObjects1ObjectsGDgdjs_46ViewLeaderboardsCode_46GDLeaderboardObjects1ObjectsGDgdjs_46ViewLeaderboardsCode_46GDMenuObjects1Objects, runtimeScene, true, false);
}}
if (gdjs.ViewLeaderboardsCode.condition1IsTrue_0.val) {
/* Reuse gdjs.ViewLeaderboardsCode.GDGreyButtonObjects1 */
/* Reuse gdjs.ViewLeaderboardsCode.GDLeaderboardObjects1 */
/* Reuse gdjs.ViewLeaderboardsCode.GDMenuObjects1 */
{for(var i = 0, len = gdjs.ViewLeaderboardsCode.GDGreyButtonObjects1.length ;i < len;++i) {
    gdjs.ViewLeaderboardsCode.GDGreyButtonObjects1[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.ViewLeaderboardsCode.GDLeaderboardObjects1.length ;i < len;++i) {
    gdjs.ViewLeaderboardsCode.GDLeaderboardObjects1[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.ViewLeaderboardsCode.GDMenuObjects1.length ;i < len;++i) {
    gdjs.ViewLeaderboardsCode.GDMenuObjects1[i].setColor("255;255;255");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\audio - BLLTImpt Hit Marker 07.aac", false, 40, 3);
}}

}


};gdjs.ViewLeaderboardsCode.eventsList6 = function(runtimeScene) {

{


gdjs.ViewLeaderboardsCode.eventsList1(runtimeScene);
}


{


gdjs.ViewLeaderboardsCode.eventsList3(runtimeScene);
}


{


gdjs.ViewLeaderboardsCode.eventsList5(runtimeScene);
}


};gdjs.ViewLeaderboardsCode.eventsList7 = function(runtimeScene) {

{


gdjs.ViewLeaderboardsCode.condition0IsTrue_0.val = false;
{
gdjs.ViewLeaderboardsCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.ViewLeaderboardsCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("ViewLeaderboards_Text"), gdjs.ViewLeaderboardsCode.GDViewLeaderboards_95TextObjects1);
{for(var i = 0, len = gdjs.ViewLeaderboardsCode.GDViewLeaderboards_95TextObjects1.length ;i < len;++i) {
    gdjs.ViewLeaderboardsCode.GDViewLeaderboards_95TextObjects1[i].setTextAlignment("center");
}
}}

}


};gdjs.ViewLeaderboardsCode.mapOfGDgdjs_46ViewLeaderboardsCode_46GDGreyButtonObjects3Objects = Hashtable.newFrom({"GreyButton": gdjs.ViewLeaderboardsCode.GDGreyButtonObjects3});
gdjs.ViewLeaderboardsCode.mapOfGDgdjs_46ViewLeaderboardsCode_46GDMenuObjects3Objects = Hashtable.newFrom({"Menu": gdjs.ViewLeaderboardsCode.GDMenuObjects3});
gdjs.ViewLeaderboardsCode.mapOfGDgdjs_46ViewLeaderboardsCode_46GDPlay_9595TextObjects2Objects = Hashtable.newFrom({"Play_Text": gdjs.ViewLeaderboardsCode.GDPlay_95TextObjects2});
gdjs.ViewLeaderboardsCode.mapOfGDgdjs_46ViewLeaderboardsCode_46GDGreyButtonObjects2Objects = Hashtable.newFrom({"GreyButton": gdjs.ViewLeaderboardsCode.GDGreyButtonObjects2});
gdjs.ViewLeaderboardsCode.eventsList8 = function(runtimeScene) {

{

gdjs.ViewLeaderboardsCode.GDGreyButtonObjects1.length = 0;

gdjs.ViewLeaderboardsCode.GDMenuObjects1.length = 0;

gdjs.ViewLeaderboardsCode.GDPlay_95TextObjects1.length = 0;


gdjs.ViewLeaderboardsCode.condition0IsTrue_0.val = false;
{
{gdjs.ViewLeaderboardsCode.conditionTrue_1 = gdjs.ViewLeaderboardsCode.condition0IsTrue_0;
gdjs.ViewLeaderboardsCode.GDGreyButtonObjects1_1final.length = 0;gdjs.ViewLeaderboardsCode.GDMenuObjects1_1final.length = 0;gdjs.ViewLeaderboardsCode.GDPlay_95TextObjects1_1final.length = 0;gdjs.ViewLeaderboardsCode.condition0IsTrue_1.val = false;
gdjs.ViewLeaderboardsCode.condition1IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("Play_Text"), gdjs.ViewLeaderboardsCode.GDPlay_95TextObjects2);
gdjs.ViewLeaderboardsCode.GDGreyButtonObjects2.length = 0;

gdjs.ViewLeaderboardsCode.GDMenuObjects2.length = 0;

{gdjs.ViewLeaderboardsCode.conditionTrue_2 = gdjs.ViewLeaderboardsCode.condition0IsTrue_1;
gdjs.ViewLeaderboardsCode.condition0IsTrue_2.val = false;
gdjs.ViewLeaderboardsCode.condition1IsTrue_2.val = false;
gdjs.ViewLeaderboardsCode.condition2IsTrue_2.val = false;
{
gdjs.ViewLeaderboardsCode.condition0IsTrue_2.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.ViewLeaderboardsCode.condition0IsTrue_2.val ) {
{
{gdjs.ViewLeaderboardsCode.conditionTrue_3 = gdjs.ViewLeaderboardsCode.condition1IsTrue_2;
gdjs.ViewLeaderboardsCode.GDGreyButtonObjects2_3final.length = 0;gdjs.ViewLeaderboardsCode.GDMenuObjects2_3final.length = 0;gdjs.ViewLeaderboardsCode.condition0IsTrue_3.val = false;
gdjs.ViewLeaderboardsCode.condition1IsTrue_3.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("GreyButton"), gdjs.ViewLeaderboardsCode.GDGreyButtonObjects3);
gdjs.ViewLeaderboardsCode.condition0IsTrue_3.val = gdjs.evtTools.input.cursorOnObject(gdjs.ViewLeaderboardsCode.mapOfGDgdjs_46ViewLeaderboardsCode_46GDGreyButtonObjects3Objects, runtimeScene, true, false);
if( gdjs.ViewLeaderboardsCode.condition0IsTrue_3.val ) {
    gdjs.ViewLeaderboardsCode.conditionTrue_3.val = true;
    for(var j = 0, jLen = gdjs.ViewLeaderboardsCode.GDGreyButtonObjects3.length;j<jLen;++j) {
        if ( gdjs.ViewLeaderboardsCode.GDGreyButtonObjects2_3final.indexOf(gdjs.ViewLeaderboardsCode.GDGreyButtonObjects3[j]) === -1 )
            gdjs.ViewLeaderboardsCode.GDGreyButtonObjects2_3final.push(gdjs.ViewLeaderboardsCode.GDGreyButtonObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Menu"), gdjs.ViewLeaderboardsCode.GDMenuObjects3);
gdjs.ViewLeaderboardsCode.condition1IsTrue_3.val = gdjs.evtTools.input.cursorOnObject(gdjs.ViewLeaderboardsCode.mapOfGDgdjs_46ViewLeaderboardsCode_46GDMenuObjects3Objects, runtimeScene, true, false);
if( gdjs.ViewLeaderboardsCode.condition1IsTrue_3.val ) {
    gdjs.ViewLeaderboardsCode.conditionTrue_3.val = true;
    for(var j = 0, jLen = gdjs.ViewLeaderboardsCode.GDMenuObjects3.length;j<jLen;++j) {
        if ( gdjs.ViewLeaderboardsCode.GDMenuObjects2_3final.indexOf(gdjs.ViewLeaderboardsCode.GDMenuObjects3[j]) === -1 )
            gdjs.ViewLeaderboardsCode.GDMenuObjects2_3final.push(gdjs.ViewLeaderboardsCode.GDMenuObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.ViewLeaderboardsCode.GDGreyButtonObjects2_3final, gdjs.ViewLeaderboardsCode.GDGreyButtonObjects2);
gdjs.copyArray(gdjs.ViewLeaderboardsCode.GDMenuObjects2_3final, gdjs.ViewLeaderboardsCode.GDMenuObjects2);
}
}
}if ( gdjs.ViewLeaderboardsCode.condition1IsTrue_2.val ) {
{
gdjs.ViewLeaderboardsCode.condition2IsTrue_2.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ViewLeaderboardsCode.mapOfGDgdjs_46ViewLeaderboardsCode_46GDPlay_9595TextObjects2Objects, gdjs.ViewLeaderboardsCode.mapOfGDgdjs_46ViewLeaderboardsCode_46GDGreyButtonObjects2Objects, false, runtimeScene, false);
}}
}
gdjs.ViewLeaderboardsCode.conditionTrue_2.val = true && gdjs.ViewLeaderboardsCode.condition0IsTrue_2.val && gdjs.ViewLeaderboardsCode.condition1IsTrue_2.val && gdjs.ViewLeaderboardsCode.condition2IsTrue_2.val;
}
if( gdjs.ViewLeaderboardsCode.condition0IsTrue_1.val ) {
    gdjs.ViewLeaderboardsCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.ViewLeaderboardsCode.GDGreyButtonObjects2.length;j<jLen;++j) {
        if ( gdjs.ViewLeaderboardsCode.GDGreyButtonObjects1_1final.indexOf(gdjs.ViewLeaderboardsCode.GDGreyButtonObjects2[j]) === -1 )
            gdjs.ViewLeaderboardsCode.GDGreyButtonObjects1_1final.push(gdjs.ViewLeaderboardsCode.GDGreyButtonObjects2[j]);
    }
    for(var j = 0, jLen = gdjs.ViewLeaderboardsCode.GDMenuObjects2.length;j<jLen;++j) {
        if ( gdjs.ViewLeaderboardsCode.GDMenuObjects1_1final.indexOf(gdjs.ViewLeaderboardsCode.GDMenuObjects2[j]) === -1 )
            gdjs.ViewLeaderboardsCode.GDMenuObjects1_1final.push(gdjs.ViewLeaderboardsCode.GDMenuObjects2[j]);
    }
    for(var j = 0, jLen = gdjs.ViewLeaderboardsCode.GDPlay_95TextObjects2.length;j<jLen;++j) {
        if ( gdjs.ViewLeaderboardsCode.GDPlay_95TextObjects1_1final.indexOf(gdjs.ViewLeaderboardsCode.GDPlay_95TextObjects2[j]) === -1 )
            gdjs.ViewLeaderboardsCode.GDPlay_95TextObjects1_1final.push(gdjs.ViewLeaderboardsCode.GDPlay_95TextObjects2[j]);
    }
}
}
{
gdjs.ViewLeaderboardsCode.condition1IsTrue_1.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Escape");
if( gdjs.ViewLeaderboardsCode.condition1IsTrue_1.val ) {
    gdjs.ViewLeaderboardsCode.conditionTrue_1.val = true;
}
}
{
gdjs.copyArray(gdjs.ViewLeaderboardsCode.GDGreyButtonObjects1_1final, gdjs.ViewLeaderboardsCode.GDGreyButtonObjects1);
gdjs.copyArray(gdjs.ViewLeaderboardsCode.GDMenuObjects1_1final, gdjs.ViewLeaderboardsCode.GDMenuObjects1);
gdjs.copyArray(gdjs.ViewLeaderboardsCode.GDPlay_95TextObjects1_1final, gdjs.ViewLeaderboardsCode.GDPlay_95TextObjects1);
}
}
}if (gdjs.ViewLeaderboardsCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.popScene(runtimeScene);
}}

}


};gdjs.ViewLeaderboardsCode.mapOfGDgdjs_46ViewLeaderboardsCode_46GDGreyButtonObjects1Objects = Hashtable.newFrom({"GreyButton": gdjs.ViewLeaderboardsCode.GDGreyButtonObjects1});
gdjs.ViewLeaderboardsCode.mapOfGDgdjs_46ViewLeaderboardsCode_46GDMainMenu_9595TextObjects1Objects = Hashtable.newFrom({"MainMenu_Text": gdjs.ViewLeaderboardsCode.GDMainMenu_95TextObjects1});
gdjs.ViewLeaderboardsCode.mapOfGDgdjs_46ViewLeaderboardsCode_46GDGreyButtonObjects1Objects = Hashtable.newFrom({"GreyButton": gdjs.ViewLeaderboardsCode.GDGreyButtonObjects1});
gdjs.ViewLeaderboardsCode.asyncCallback11569972 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Title Screen", false);
}}
gdjs.ViewLeaderboardsCode.eventsList9 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.ViewLeaderboardsCode.asyncCallback11569972(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.ViewLeaderboardsCode.eventsList10 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("GreyButton"), gdjs.ViewLeaderboardsCode.GDGreyButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("MainMenu_Text"), gdjs.ViewLeaderboardsCode.GDMainMenu_95TextObjects1);

gdjs.ViewLeaderboardsCode.condition0IsTrue_0.val = false;
gdjs.ViewLeaderboardsCode.condition1IsTrue_0.val = false;
gdjs.ViewLeaderboardsCode.condition2IsTrue_0.val = false;
{
gdjs.ViewLeaderboardsCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.ViewLeaderboardsCode.condition0IsTrue_0.val ) {
{
gdjs.ViewLeaderboardsCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.ViewLeaderboardsCode.mapOfGDgdjs_46ViewLeaderboardsCode_46GDGreyButtonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.ViewLeaderboardsCode.condition1IsTrue_0.val ) {
{
gdjs.ViewLeaderboardsCode.condition2IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ViewLeaderboardsCode.mapOfGDgdjs_46ViewLeaderboardsCode_46GDMainMenu_9595TextObjects1Objects, gdjs.ViewLeaderboardsCode.mapOfGDgdjs_46ViewLeaderboardsCode_46GDGreyButtonObjects1Objects, false, runtimeScene, false);
}}
}
if (gdjs.ViewLeaderboardsCode.condition2IsTrue_0.val) {

{ //Subevents
gdjs.ViewLeaderboardsCode.eventsList9(runtimeScene);} //End of subevents
}

}


};gdjs.ViewLeaderboardsCode.mapOfGDgdjs_46ViewLeaderboardsCode_46GDGreyButtonObjects1Objects = Hashtable.newFrom({"GreyButton": gdjs.ViewLeaderboardsCode.GDGreyButtonObjects1});
gdjs.ViewLeaderboardsCode.mapOfGDgdjs_46ViewLeaderboardsCode_46GDFewestMoves_9595TextObjects2Objects = Hashtable.newFrom({"FewestMoves_Text": gdjs.ViewLeaderboardsCode.GDFewestMoves_95TextObjects2});
gdjs.ViewLeaderboardsCode.mapOfGDgdjs_46ViewLeaderboardsCode_46GDGreyButtonObjects2Objects = Hashtable.newFrom({"GreyButton": gdjs.ViewLeaderboardsCode.GDGreyButtonObjects2});
gdjs.ViewLeaderboardsCode.asyncCallback11572252 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.leaderboards.displayLeaderboard(runtimeScene, "77688ec1-5415-49c3-90cd-6e3d51bc9b44", true);
}}
gdjs.ViewLeaderboardsCode.eventsList11 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.25), (runtimeScene) => (gdjs.ViewLeaderboardsCode.asyncCallback11572252(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.ViewLeaderboardsCode.mapOfGDgdjs_46ViewLeaderboardsCode_46GDFastestTime_9595TextObjects1Objects = Hashtable.newFrom({"FastestTime_Text": gdjs.ViewLeaderboardsCode.GDFastestTime_95TextObjects1});
gdjs.ViewLeaderboardsCode.mapOfGDgdjs_46ViewLeaderboardsCode_46GDGreyButtonObjects1Objects = Hashtable.newFrom({"GreyButton": gdjs.ViewLeaderboardsCode.GDGreyButtonObjects1});
gdjs.ViewLeaderboardsCode.asyncCallback11574180 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.leaderboards.displayLeaderboard(runtimeScene, "eced0c01-aecc-4839-bc86-73cd218ddfc2", true);
}}
gdjs.ViewLeaderboardsCode.eventsList12 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.25), (runtimeScene) => (gdjs.ViewLeaderboardsCode.asyncCallback11574180(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.ViewLeaderboardsCode.eventsList13 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("FewestMoves_Text"), gdjs.ViewLeaderboardsCode.GDFewestMoves_95TextObjects2);
gdjs.copyArray(gdjs.ViewLeaderboardsCode.GDGreyButtonObjects1, gdjs.ViewLeaderboardsCode.GDGreyButtonObjects2);


gdjs.ViewLeaderboardsCode.condition0IsTrue_0.val = false;
{
gdjs.ViewLeaderboardsCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ViewLeaderboardsCode.mapOfGDgdjs_46ViewLeaderboardsCode_46GDFewestMoves_9595TextObjects2Objects, gdjs.ViewLeaderboardsCode.mapOfGDgdjs_46ViewLeaderboardsCode_46GDGreyButtonObjects2Objects, false, runtimeScene, false);
}if (gdjs.ViewLeaderboardsCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.ViewLeaderboardsCode.eventsList11(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("FastestTime_Text"), gdjs.ViewLeaderboardsCode.GDFastestTime_95TextObjects1);
/* Reuse gdjs.ViewLeaderboardsCode.GDGreyButtonObjects1 */

gdjs.ViewLeaderboardsCode.condition0IsTrue_0.val = false;
{
gdjs.ViewLeaderboardsCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ViewLeaderboardsCode.mapOfGDgdjs_46ViewLeaderboardsCode_46GDFastestTime_9595TextObjects1Objects, gdjs.ViewLeaderboardsCode.mapOfGDgdjs_46ViewLeaderboardsCode_46GDGreyButtonObjects1Objects, false, runtimeScene, false);
}if (gdjs.ViewLeaderboardsCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.ViewLeaderboardsCode.eventsList12(runtimeScene);} //End of subevents
}

}


};gdjs.ViewLeaderboardsCode.eventsList14 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("GreyButton"), gdjs.ViewLeaderboardsCode.GDGreyButtonObjects1);

gdjs.ViewLeaderboardsCode.condition0IsTrue_0.val = false;
gdjs.ViewLeaderboardsCode.condition1IsTrue_0.val = false;
{
gdjs.ViewLeaderboardsCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.ViewLeaderboardsCode.condition0IsTrue_0.val ) {
{
gdjs.ViewLeaderboardsCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.ViewLeaderboardsCode.mapOfGDgdjs_46ViewLeaderboardsCode_46GDGreyButtonObjects1Objects, runtimeScene, true, false);
}}
if (gdjs.ViewLeaderboardsCode.condition1IsTrue_0.val) {

{ //Subevents
gdjs.ViewLeaderboardsCode.eventsList13(runtimeScene);} //End of subevents
}

}


};gdjs.ViewLeaderboardsCode.eventsList15 = function(runtimeScene) {

{



}


{


gdjs.ViewLeaderboardsCode.eventsList6(runtimeScene);
}


{


gdjs.ViewLeaderboardsCode.eventsList7(runtimeScene);
}


{


gdjs.ViewLeaderboardsCode.eventsList8(runtimeScene);
}


{


gdjs.ViewLeaderboardsCode.eventsList10(runtimeScene);
}


{


gdjs.ViewLeaderboardsCode.eventsList14(runtimeScene);
}


};

gdjs.ViewLeaderboardsCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.ViewLeaderboardsCode.GDBall_951Objects1.length = 0;
gdjs.ViewLeaderboardsCode.GDBall_951Objects2.length = 0;
gdjs.ViewLeaderboardsCode.GDBall_951Objects3.length = 0;
gdjs.ViewLeaderboardsCode.GDBall_952Objects1.length = 0;
gdjs.ViewLeaderboardsCode.GDBall_952Objects2.length = 0;
gdjs.ViewLeaderboardsCode.GDBall_952Objects3.length = 0;
gdjs.ViewLeaderboardsCode.GDBall_953Objects1.length = 0;
gdjs.ViewLeaderboardsCode.GDBall_953Objects2.length = 0;
gdjs.ViewLeaderboardsCode.GDBall_953Objects3.length = 0;
gdjs.ViewLeaderboardsCode.GDBall_954Objects1.length = 0;
gdjs.ViewLeaderboardsCode.GDBall_954Objects2.length = 0;
gdjs.ViewLeaderboardsCode.GDBall_954Objects3.length = 0;
gdjs.ViewLeaderboardsCode.GDBall_955Objects1.length = 0;
gdjs.ViewLeaderboardsCode.GDBall_955Objects2.length = 0;
gdjs.ViewLeaderboardsCode.GDBall_955Objects3.length = 0;
gdjs.ViewLeaderboardsCode.GDBall_956Objects1.length = 0;
gdjs.ViewLeaderboardsCode.GDBall_956Objects2.length = 0;
gdjs.ViewLeaderboardsCode.GDBall_956Objects3.length = 0;
gdjs.ViewLeaderboardsCode.GDGlassBreaking_95ParticlesObjects1.length = 0;
gdjs.ViewLeaderboardsCode.GDGlassBreaking_95ParticlesObjects2.length = 0;
gdjs.ViewLeaderboardsCode.GDGlassBreaking_95ParticlesObjects3.length = 0;
gdjs.ViewLeaderboardsCode.GDCupObjects1.length = 0;
gdjs.ViewLeaderboardsCode.GDCupObjects2.length = 0;
gdjs.ViewLeaderboardsCode.GDCupObjects3.length = 0;
gdjs.ViewLeaderboardsCode.GDCupFrontObjects1.length = 0;
gdjs.ViewLeaderboardsCode.GDCupFrontObjects2.length = 0;
gdjs.ViewLeaderboardsCode.GDCupFrontObjects3.length = 0;
gdjs.ViewLeaderboardsCode.GDCloud1Objects1.length = 0;
gdjs.ViewLeaderboardsCode.GDCloud1Objects2.length = 0;
gdjs.ViewLeaderboardsCode.GDCloud1Objects3.length = 0;
gdjs.ViewLeaderboardsCode.GDCloud2Objects1.length = 0;
gdjs.ViewLeaderboardsCode.GDCloud2Objects2.length = 0;
gdjs.ViewLeaderboardsCode.GDCloud2Objects3.length = 0;
gdjs.ViewLeaderboardsCode.GDCloud3Objects1.length = 0;
gdjs.ViewLeaderboardsCode.GDCloud3Objects2.length = 0;
gdjs.ViewLeaderboardsCode.GDCloud3Objects3.length = 0;
gdjs.ViewLeaderboardsCode.GDCloud4Objects1.length = 0;
gdjs.ViewLeaderboardsCode.GDCloud4Objects2.length = 0;
gdjs.ViewLeaderboardsCode.GDCloud4Objects3.length = 0;
gdjs.ViewLeaderboardsCode.GDEditInGDevelop_95TextObjects1.length = 0;
gdjs.ViewLeaderboardsCode.GDEditInGDevelop_95TextObjects2.length = 0;
gdjs.ViewLeaderboardsCode.GDEditInGDevelop_95TextObjects3.length = 0;
gdjs.ViewLeaderboardsCode.GDGreyButtonObjects1.length = 0;
gdjs.ViewLeaderboardsCode.GDGreyButtonObjects2.length = 0;
gdjs.ViewLeaderboardsCode.GDGreyButtonObjects3.length = 0;
gdjs.ViewLeaderboardsCode.GDCurrentLevel_95TextObjects1.length = 0;
gdjs.ViewLeaderboardsCode.GDCurrentLevel_95TextObjects2.length = 0;
gdjs.ViewLeaderboardsCode.GDCurrentLevel_95TextObjects3.length = 0;
gdjs.ViewLeaderboardsCode.GDMenuObjects1.length = 0;
gdjs.ViewLeaderboardsCode.GDMenuObjects2.length = 0;
gdjs.ViewLeaderboardsCode.GDMenuObjects3.length = 0;
gdjs.ViewLeaderboardsCode.GDGameState_95TextObjects1.length = 0;
gdjs.ViewLeaderboardsCode.GDGameState_95TextObjects2.length = 0;
gdjs.ViewLeaderboardsCode.GDGameState_95TextObjects3.length = 0;
gdjs.ViewLeaderboardsCode.GDMovesMade_95TextObjects1.length = 0;
gdjs.ViewLeaderboardsCode.GDMovesMade_95TextObjects2.length = 0;
gdjs.ViewLeaderboardsCode.GDMovesMade_95TextObjects3.length = 0;
gdjs.ViewLeaderboardsCode.GDTimeSpent_95TextObjects1.length = 0;
gdjs.ViewLeaderboardsCode.GDTimeSpent_95TextObjects2.length = 0;
gdjs.ViewLeaderboardsCode.GDTimeSpent_95TextObjects3.length = 0;
gdjs.ViewLeaderboardsCode.GDBallsInCup_95TextObjects1.length = 0;
gdjs.ViewLeaderboardsCode.GDBallsInCup_95TextObjects2.length = 0;
gdjs.ViewLeaderboardsCode.GDBallsInCup_95TextObjects3.length = 0;
gdjs.ViewLeaderboardsCode.GDPlay_95TextObjects1.length = 0;
gdjs.ViewLeaderboardsCode.GDPlay_95TextObjects2.length = 0;
gdjs.ViewLeaderboardsCode.GDPlay_95TextObjects3.length = 0;
gdjs.ViewLeaderboardsCode.GDLeaderboardObjects1.length = 0;
gdjs.ViewLeaderboardsCode.GDLeaderboardObjects2.length = 0;
gdjs.ViewLeaderboardsCode.GDLeaderboardObjects3.length = 0;
gdjs.ViewLeaderboardsCode.GDMainMenu_95TextObjects1.length = 0;
gdjs.ViewLeaderboardsCode.GDMainMenu_95TextObjects2.length = 0;
gdjs.ViewLeaderboardsCode.GDMainMenu_95TextObjects3.length = 0;
gdjs.ViewLeaderboardsCode.GDResetProgress_95TextObjects1.length = 0;
gdjs.ViewLeaderboardsCode.GDResetProgress_95TextObjects2.length = 0;
gdjs.ViewLeaderboardsCode.GDResetProgress_95TextObjects3.length = 0;
gdjs.ViewLeaderboardsCode.GDStartOver_95TextObjects1.length = 0;
gdjs.ViewLeaderboardsCode.GDStartOver_95TextObjects2.length = 0;
gdjs.ViewLeaderboardsCode.GDStartOver_95TextObjects3.length = 0;
gdjs.ViewLeaderboardsCode.GDSubmit_95TextObjects1.length = 0;
gdjs.ViewLeaderboardsCode.GDSubmit_95TextObjects2.length = 0;
gdjs.ViewLeaderboardsCode.GDSubmit_95TextObjects3.length = 0;
gdjs.ViewLeaderboardsCode.GDFastestTime_95TextObjects1.length = 0;
gdjs.ViewLeaderboardsCode.GDFastestTime_95TextObjects2.length = 0;
gdjs.ViewLeaderboardsCode.GDFastestTime_95TextObjects3.length = 0;
gdjs.ViewLeaderboardsCode.GDFewestMoves_95TextObjects1.length = 0;
gdjs.ViewLeaderboardsCode.GDFewestMoves_95TextObjects2.length = 0;
gdjs.ViewLeaderboardsCode.GDFewestMoves_95TextObjects3.length = 0;
gdjs.ViewLeaderboardsCode.GDViewLeaderboards_95TextObjects1.length = 0;
gdjs.ViewLeaderboardsCode.GDViewLeaderboards_95TextObjects2.length = 0;
gdjs.ViewLeaderboardsCode.GDViewLeaderboards_95TextObjects3.length = 0;

gdjs.ViewLeaderboardsCode.eventsList15(runtimeScene);

return;

}

gdjs['ViewLeaderboardsCode'] = gdjs.ViewLeaderboardsCode;
