gdjs.Level_324Code = {};
gdjs.Level_324Code.GDBall_951Objects3_1final = [];

gdjs.Level_324Code.GDBall_952Objects3_1final = [];

gdjs.Level_324Code.GDBall_953Objects3_1final = [];

gdjs.Level_324Code.GDBall_954Objects3_1final = [];

gdjs.Level_324Code.GDBall_955Objects3_1final = [];

gdjs.Level_324Code.GDBall_956Objects3_1final = [];

gdjs.Level_324Code.GDCupFrontObjects3_1final = [];

gdjs.Level_324Code.GDMenuObjects3_1final = [];

gdjs.Level_324Code.forEachIndex4 = 0;

gdjs.Level_324Code.forEachIndex5 = 0;

gdjs.Level_324Code.forEachObjects4 = [];

gdjs.Level_324Code.forEachObjects5 = [];

gdjs.Level_324Code.forEachTemporary4 = null;

gdjs.Level_324Code.forEachTemporary5 = null;

gdjs.Level_324Code.forEachTotalCount4 = 0;

gdjs.Level_324Code.forEachTotalCount5 = 0;

gdjs.Level_324Code.GDBall_951Objects1= [];
gdjs.Level_324Code.GDBall_951Objects2= [];
gdjs.Level_324Code.GDBall_951Objects3= [];
gdjs.Level_324Code.GDBall_951Objects4= [];
gdjs.Level_324Code.GDBall_951Objects5= [];
gdjs.Level_324Code.GDBall_951Objects6= [];
gdjs.Level_324Code.GDBall_951Objects7= [];
gdjs.Level_324Code.GDBall_951Objects8= [];
gdjs.Level_324Code.GDBall_951Objects9= [];
gdjs.Level_324Code.GDBall_952Objects1= [];
gdjs.Level_324Code.GDBall_952Objects2= [];
gdjs.Level_324Code.GDBall_952Objects3= [];
gdjs.Level_324Code.GDBall_952Objects4= [];
gdjs.Level_324Code.GDBall_952Objects5= [];
gdjs.Level_324Code.GDBall_952Objects6= [];
gdjs.Level_324Code.GDBall_952Objects7= [];
gdjs.Level_324Code.GDBall_952Objects8= [];
gdjs.Level_324Code.GDBall_952Objects9= [];
gdjs.Level_324Code.GDBall_953Objects1= [];
gdjs.Level_324Code.GDBall_953Objects2= [];
gdjs.Level_324Code.GDBall_953Objects3= [];
gdjs.Level_324Code.GDBall_953Objects4= [];
gdjs.Level_324Code.GDBall_953Objects5= [];
gdjs.Level_324Code.GDBall_953Objects6= [];
gdjs.Level_324Code.GDBall_953Objects7= [];
gdjs.Level_324Code.GDBall_953Objects8= [];
gdjs.Level_324Code.GDBall_953Objects9= [];
gdjs.Level_324Code.GDBall_954Objects1= [];
gdjs.Level_324Code.GDBall_954Objects2= [];
gdjs.Level_324Code.GDBall_954Objects3= [];
gdjs.Level_324Code.GDBall_954Objects4= [];
gdjs.Level_324Code.GDBall_954Objects5= [];
gdjs.Level_324Code.GDBall_954Objects6= [];
gdjs.Level_324Code.GDBall_954Objects7= [];
gdjs.Level_324Code.GDBall_954Objects8= [];
gdjs.Level_324Code.GDBall_954Objects9= [];
gdjs.Level_324Code.GDBall_955Objects1= [];
gdjs.Level_324Code.GDBall_955Objects2= [];
gdjs.Level_324Code.GDBall_955Objects3= [];
gdjs.Level_324Code.GDBall_955Objects4= [];
gdjs.Level_324Code.GDBall_955Objects5= [];
gdjs.Level_324Code.GDBall_955Objects6= [];
gdjs.Level_324Code.GDBall_955Objects7= [];
gdjs.Level_324Code.GDBall_955Objects8= [];
gdjs.Level_324Code.GDBall_955Objects9= [];
gdjs.Level_324Code.GDBall_956Objects1= [];
gdjs.Level_324Code.GDBall_956Objects2= [];
gdjs.Level_324Code.GDBall_956Objects3= [];
gdjs.Level_324Code.GDBall_956Objects4= [];
gdjs.Level_324Code.GDBall_956Objects5= [];
gdjs.Level_324Code.GDBall_956Objects6= [];
gdjs.Level_324Code.GDBall_956Objects7= [];
gdjs.Level_324Code.GDBall_956Objects8= [];
gdjs.Level_324Code.GDBall_956Objects9= [];
gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects1= [];
gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects2= [];
gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects3= [];
gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects4= [];
gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects5= [];
gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects6= [];
gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects7= [];
gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects8= [];
gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects9= [];
gdjs.Level_324Code.GDCupObjects1= [];
gdjs.Level_324Code.GDCupObjects2= [];
gdjs.Level_324Code.GDCupObjects3= [];
gdjs.Level_324Code.GDCupObjects4= [];
gdjs.Level_324Code.GDCupObjects5= [];
gdjs.Level_324Code.GDCupObjects6= [];
gdjs.Level_324Code.GDCupObjects7= [];
gdjs.Level_324Code.GDCupObjects8= [];
gdjs.Level_324Code.GDCupObjects9= [];
gdjs.Level_324Code.GDCupFrontObjects1= [];
gdjs.Level_324Code.GDCupFrontObjects2= [];
gdjs.Level_324Code.GDCupFrontObjects3= [];
gdjs.Level_324Code.GDCupFrontObjects4= [];
gdjs.Level_324Code.GDCupFrontObjects5= [];
gdjs.Level_324Code.GDCupFrontObjects6= [];
gdjs.Level_324Code.GDCupFrontObjects7= [];
gdjs.Level_324Code.GDCupFrontObjects8= [];
gdjs.Level_324Code.GDCupFrontObjects9= [];
gdjs.Level_324Code.GDCloud1Objects1= [];
gdjs.Level_324Code.GDCloud1Objects2= [];
gdjs.Level_324Code.GDCloud1Objects3= [];
gdjs.Level_324Code.GDCloud1Objects4= [];
gdjs.Level_324Code.GDCloud1Objects5= [];
gdjs.Level_324Code.GDCloud1Objects6= [];
gdjs.Level_324Code.GDCloud1Objects7= [];
gdjs.Level_324Code.GDCloud1Objects8= [];
gdjs.Level_324Code.GDCloud1Objects9= [];
gdjs.Level_324Code.GDCloud2Objects1= [];
gdjs.Level_324Code.GDCloud2Objects2= [];
gdjs.Level_324Code.GDCloud2Objects3= [];
gdjs.Level_324Code.GDCloud2Objects4= [];
gdjs.Level_324Code.GDCloud2Objects5= [];
gdjs.Level_324Code.GDCloud2Objects6= [];
gdjs.Level_324Code.GDCloud2Objects7= [];
gdjs.Level_324Code.GDCloud2Objects8= [];
gdjs.Level_324Code.GDCloud2Objects9= [];
gdjs.Level_324Code.GDCloud3Objects1= [];
gdjs.Level_324Code.GDCloud3Objects2= [];
gdjs.Level_324Code.GDCloud3Objects3= [];
gdjs.Level_324Code.GDCloud3Objects4= [];
gdjs.Level_324Code.GDCloud3Objects5= [];
gdjs.Level_324Code.GDCloud3Objects6= [];
gdjs.Level_324Code.GDCloud3Objects7= [];
gdjs.Level_324Code.GDCloud3Objects8= [];
gdjs.Level_324Code.GDCloud3Objects9= [];
gdjs.Level_324Code.GDCloud4Objects1= [];
gdjs.Level_324Code.GDCloud4Objects2= [];
gdjs.Level_324Code.GDCloud4Objects3= [];
gdjs.Level_324Code.GDCloud4Objects4= [];
gdjs.Level_324Code.GDCloud4Objects5= [];
gdjs.Level_324Code.GDCloud4Objects6= [];
gdjs.Level_324Code.GDCloud4Objects7= [];
gdjs.Level_324Code.GDCloud4Objects8= [];
gdjs.Level_324Code.GDCloud4Objects9= [];
gdjs.Level_324Code.GDEditInGDevelop_95TextObjects1= [];
gdjs.Level_324Code.GDEditInGDevelop_95TextObjects2= [];
gdjs.Level_324Code.GDEditInGDevelop_95TextObjects3= [];
gdjs.Level_324Code.GDEditInGDevelop_95TextObjects4= [];
gdjs.Level_324Code.GDEditInGDevelop_95TextObjects5= [];
gdjs.Level_324Code.GDEditInGDevelop_95TextObjects6= [];
gdjs.Level_324Code.GDEditInGDevelop_95TextObjects7= [];
gdjs.Level_324Code.GDEditInGDevelop_95TextObjects8= [];
gdjs.Level_324Code.GDEditInGDevelop_95TextObjects9= [];
gdjs.Level_324Code.GDGreyButtonObjects1= [];
gdjs.Level_324Code.GDGreyButtonObjects2= [];
gdjs.Level_324Code.GDGreyButtonObjects3= [];
gdjs.Level_324Code.GDGreyButtonObjects4= [];
gdjs.Level_324Code.GDGreyButtonObjects5= [];
gdjs.Level_324Code.GDGreyButtonObjects6= [];
gdjs.Level_324Code.GDGreyButtonObjects7= [];
gdjs.Level_324Code.GDGreyButtonObjects8= [];
gdjs.Level_324Code.GDGreyButtonObjects9= [];
gdjs.Level_324Code.GDCurrentLevel_95TextObjects1= [];
gdjs.Level_324Code.GDCurrentLevel_95TextObjects2= [];
gdjs.Level_324Code.GDCurrentLevel_95TextObjects3= [];
gdjs.Level_324Code.GDCurrentLevel_95TextObjects4= [];
gdjs.Level_324Code.GDCurrentLevel_95TextObjects5= [];
gdjs.Level_324Code.GDCurrentLevel_95TextObjects6= [];
gdjs.Level_324Code.GDCurrentLevel_95TextObjects7= [];
gdjs.Level_324Code.GDCurrentLevel_95TextObjects8= [];
gdjs.Level_324Code.GDCurrentLevel_95TextObjects9= [];
gdjs.Level_324Code.GDMenuObjects1= [];
gdjs.Level_324Code.GDMenuObjects2= [];
gdjs.Level_324Code.GDMenuObjects3= [];
gdjs.Level_324Code.GDMenuObjects4= [];
gdjs.Level_324Code.GDMenuObjects5= [];
gdjs.Level_324Code.GDMenuObjects6= [];
gdjs.Level_324Code.GDMenuObjects7= [];
gdjs.Level_324Code.GDMenuObjects8= [];
gdjs.Level_324Code.GDMenuObjects9= [];
gdjs.Level_324Code.GDGameState_95TextObjects1= [];
gdjs.Level_324Code.GDGameState_95TextObjects2= [];
gdjs.Level_324Code.GDGameState_95TextObjects3= [];
gdjs.Level_324Code.GDGameState_95TextObjects4= [];
gdjs.Level_324Code.GDGameState_95TextObjects5= [];
gdjs.Level_324Code.GDGameState_95TextObjects6= [];
gdjs.Level_324Code.GDGameState_95TextObjects7= [];
gdjs.Level_324Code.GDGameState_95TextObjects8= [];
gdjs.Level_324Code.GDGameState_95TextObjects9= [];
gdjs.Level_324Code.GDMovesMade_95TextObjects1= [];
gdjs.Level_324Code.GDMovesMade_95TextObjects2= [];
gdjs.Level_324Code.GDMovesMade_95TextObjects3= [];
gdjs.Level_324Code.GDMovesMade_95TextObjects4= [];
gdjs.Level_324Code.GDMovesMade_95TextObjects5= [];
gdjs.Level_324Code.GDMovesMade_95TextObjects6= [];
gdjs.Level_324Code.GDMovesMade_95TextObjects7= [];
gdjs.Level_324Code.GDMovesMade_95TextObjects8= [];
gdjs.Level_324Code.GDMovesMade_95TextObjects9= [];
gdjs.Level_324Code.GDTimeSpent_95TextObjects1= [];
gdjs.Level_324Code.GDTimeSpent_95TextObjects2= [];
gdjs.Level_324Code.GDTimeSpent_95TextObjects3= [];
gdjs.Level_324Code.GDTimeSpent_95TextObjects4= [];
gdjs.Level_324Code.GDTimeSpent_95TextObjects5= [];
gdjs.Level_324Code.GDTimeSpent_95TextObjects6= [];
gdjs.Level_324Code.GDTimeSpent_95TextObjects7= [];
gdjs.Level_324Code.GDTimeSpent_95TextObjects8= [];
gdjs.Level_324Code.GDTimeSpent_95TextObjects9= [];
gdjs.Level_324Code.GDBallsInCup_95TextObjects1= [];
gdjs.Level_324Code.GDBallsInCup_95TextObjects2= [];
gdjs.Level_324Code.GDBallsInCup_95TextObjects3= [];
gdjs.Level_324Code.GDBallsInCup_95TextObjects4= [];
gdjs.Level_324Code.GDBallsInCup_95TextObjects5= [];
gdjs.Level_324Code.GDBallsInCup_95TextObjects6= [];
gdjs.Level_324Code.GDBallsInCup_95TextObjects7= [];
gdjs.Level_324Code.GDBallsInCup_95TextObjects8= [];
gdjs.Level_324Code.GDBallsInCup_95TextObjects9= [];
gdjs.Level_324Code.GDPlay_95TextObjects1= [];
gdjs.Level_324Code.GDPlay_95TextObjects2= [];
gdjs.Level_324Code.GDPlay_95TextObjects3= [];
gdjs.Level_324Code.GDPlay_95TextObjects4= [];
gdjs.Level_324Code.GDPlay_95TextObjects5= [];
gdjs.Level_324Code.GDPlay_95TextObjects6= [];
gdjs.Level_324Code.GDPlay_95TextObjects7= [];
gdjs.Level_324Code.GDPlay_95TextObjects8= [];
gdjs.Level_324Code.GDPlay_95TextObjects9= [];
gdjs.Level_324Code.GDLeaderboardObjects1= [];
gdjs.Level_324Code.GDLeaderboardObjects2= [];
gdjs.Level_324Code.GDLeaderboardObjects3= [];
gdjs.Level_324Code.GDLeaderboardObjects4= [];
gdjs.Level_324Code.GDLeaderboardObjects5= [];
gdjs.Level_324Code.GDLeaderboardObjects6= [];
gdjs.Level_324Code.GDLeaderboardObjects7= [];
gdjs.Level_324Code.GDLeaderboardObjects8= [];
gdjs.Level_324Code.GDLeaderboardObjects9= [];
gdjs.Level_324Code.GDMainMenu_95TextObjects1= [];
gdjs.Level_324Code.GDMainMenu_95TextObjects2= [];
gdjs.Level_324Code.GDMainMenu_95TextObjects3= [];
gdjs.Level_324Code.GDMainMenu_95TextObjects4= [];
gdjs.Level_324Code.GDMainMenu_95TextObjects5= [];
gdjs.Level_324Code.GDMainMenu_95TextObjects6= [];
gdjs.Level_324Code.GDMainMenu_95TextObjects7= [];
gdjs.Level_324Code.GDMainMenu_95TextObjects8= [];
gdjs.Level_324Code.GDMainMenu_95TextObjects9= [];
gdjs.Level_324Code.GDResetProgress_95TextObjects1= [];
gdjs.Level_324Code.GDResetProgress_95TextObjects2= [];
gdjs.Level_324Code.GDResetProgress_95TextObjects3= [];
gdjs.Level_324Code.GDResetProgress_95TextObjects4= [];
gdjs.Level_324Code.GDResetProgress_95TextObjects5= [];
gdjs.Level_324Code.GDResetProgress_95TextObjects6= [];
gdjs.Level_324Code.GDResetProgress_95TextObjects7= [];
gdjs.Level_324Code.GDResetProgress_95TextObjects8= [];
gdjs.Level_324Code.GDResetProgress_95TextObjects9= [];
gdjs.Level_324Code.GDStartOver_95TextObjects1= [];
gdjs.Level_324Code.GDStartOver_95TextObjects2= [];
gdjs.Level_324Code.GDStartOver_95TextObjects3= [];
gdjs.Level_324Code.GDStartOver_95TextObjects4= [];
gdjs.Level_324Code.GDStartOver_95TextObjects5= [];
gdjs.Level_324Code.GDStartOver_95TextObjects6= [];
gdjs.Level_324Code.GDStartOver_95TextObjects7= [];
gdjs.Level_324Code.GDStartOver_95TextObjects8= [];
gdjs.Level_324Code.GDStartOver_95TextObjects9= [];
gdjs.Level_324Code.GDSubmit_95TextObjects1= [];
gdjs.Level_324Code.GDSubmit_95TextObjects2= [];
gdjs.Level_324Code.GDSubmit_95TextObjects3= [];
gdjs.Level_324Code.GDSubmit_95TextObjects4= [];
gdjs.Level_324Code.GDSubmit_95TextObjects5= [];
gdjs.Level_324Code.GDSubmit_95TextObjects6= [];
gdjs.Level_324Code.GDSubmit_95TextObjects7= [];
gdjs.Level_324Code.GDSubmit_95TextObjects8= [];
gdjs.Level_324Code.GDSubmit_95TextObjects9= [];
gdjs.Level_324Code.GDBallsInCup_95TextObjects1= [];
gdjs.Level_324Code.GDBallsInCup_95TextObjects2= [];
gdjs.Level_324Code.GDBallsInCup_95TextObjects3= [];
gdjs.Level_324Code.GDBallsInCup_95TextObjects4= [];
gdjs.Level_324Code.GDBallsInCup_95TextObjects5= [];
gdjs.Level_324Code.GDBallsInCup_95TextObjects6= [];
gdjs.Level_324Code.GDBallsInCup_95TextObjects7= [];
gdjs.Level_324Code.GDBallsInCup_95TextObjects8= [];
gdjs.Level_324Code.GDBallsInCup_95TextObjects9= [];

gdjs.Level_324Code.conditionTrue_0 = {val:false};
gdjs.Level_324Code.condition0IsTrue_0 = {val:false};
gdjs.Level_324Code.condition1IsTrue_0 = {val:false};
gdjs.Level_324Code.condition2IsTrue_0 = {val:false};
gdjs.Level_324Code.condition3IsTrue_0 = {val:false};
gdjs.Level_324Code.condition4IsTrue_0 = {val:false};
gdjs.Level_324Code.conditionTrue_1 = {val:false};
gdjs.Level_324Code.condition0IsTrue_1 = {val:false};
gdjs.Level_324Code.condition1IsTrue_1 = {val:false};
gdjs.Level_324Code.condition2IsTrue_1 = {val:false};
gdjs.Level_324Code.condition3IsTrue_1 = {val:false};
gdjs.Level_324Code.condition4IsTrue_1 = {val:false};
gdjs.Level_324Code.conditionTrue_2 = {val:false};
gdjs.Level_324Code.condition0IsTrue_2 = {val:false};
gdjs.Level_324Code.condition1IsTrue_2 = {val:false};
gdjs.Level_324Code.condition2IsTrue_2 = {val:false};
gdjs.Level_324Code.condition3IsTrue_2 = {val:false};
gdjs.Level_324Code.condition4IsTrue_2 = {val:false};


gdjs.Level_324Code.eventsList0 = function(runtimeScene) {

{


{
{gdjs.evtTools.storage.readNumberFromJSONFile("BallCupBoom", "PlayTimer", runtimeScene, runtimeScene.getVariables().get("PlayTimer"));
}{gdjs.evtTools.storage.readNumberFromJSONFile("BallCupBoom", "MovesMade", runtimeScene, runtimeScene.getVariables().get("MovesMade"));
}{gdjs.evtTools.storage.readNumberFromJSONFile("BallCupBoom", "CurrentLevel", runtimeScene, runtimeScene.getVariables().get("CurrentLevel"));
}}

}


};gdjs.Level_324Code.eventsList1 = function(runtimeScene) {

{


{
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "PlayTimer");
}{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "PlayTimer");
}}

}


};gdjs.Level_324Code.eventsList2 = function(runtimeScene) {

{


{
{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "Shared UI", 0, 0);
}}

}


{


{
{gdjs.evtTools.camera.hideLayer(runtimeScene, "Debugging");
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("CurrentLevel_Text"), gdjs.Level_324Code.GDCurrentLevel_95TextObjects5);
gdjs.copyArray(runtimeScene.getObjects("MovesMade_Text"), gdjs.Level_324Code.GDMovesMade_95TextObjects5);
{for(var i = 0, len = gdjs.Level_324Code.GDCurrentLevel_95TextObjects5.length ;i < len;++i) {
    gdjs.Level_324Code.GDCurrentLevel_95TextObjects5[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("CurrentLevel"))));
}
}{for(var i = 0, len = gdjs.Level_324Code.GDCurrentLevel_95TextObjects5.length ;i < len;++i) {
    gdjs.Level_324Code.GDCurrentLevel_95TextObjects5[i].setCenterXInScene(gdjs.evtTools.camera.getCameraX(runtimeScene, (gdjs.Level_324Code.GDCurrentLevel_95TextObjects5[i].getLayer()), 0));
}
}{for(var i = 0, len = gdjs.Level_324Code.GDMovesMade_95TextObjects5.length ;i < len;++i) {
    gdjs.Level_324Code.GDMovesMade_95TextObjects5[i].setString("Moves: " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MovesMade"))));
}
}}

}


{


gdjs.Level_324Code.eventsList1(runtimeScene);
}


};gdjs.Level_324Code.eventsList3 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("Cloud1"), gdjs.Level_324Code.GDCloud1Objects4);
gdjs.copyArray(runtimeScene.getObjects("Cloud2"), gdjs.Level_324Code.GDCloud2Objects4);
gdjs.copyArray(runtimeScene.getObjects("Cloud3"), gdjs.Level_324Code.GDCloud3Objects4);
gdjs.copyArray(runtimeScene.getObjects("Cloud4"), gdjs.Level_324Code.GDCloud4Objects4);
{for(var i = 0, len = gdjs.Level_324Code.GDCloud1Objects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDCloud1Objects4[i].addPolarForce(180, gdjs.randomInRange(5, 10), 1);
}
for(var i = 0, len = gdjs.Level_324Code.GDCloud2Objects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDCloud2Objects4[i].addPolarForce(180, gdjs.randomInRange(5, 10), 1);
}
for(var i = 0, len = gdjs.Level_324Code.GDCloud3Objects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDCloud3Objects4[i].addPolarForce(180, gdjs.randomInRange(5, 10), 1);
}
for(var i = 0, len = gdjs.Level_324Code.GDCloud4Objects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDCloud4Objects4[i].addPolarForce(180, gdjs.randomInRange(5, 10), 1);
}
}{for(var i = 0, len = gdjs.Level_324Code.GDCloud1Objects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDCloud1Objects4[i].setOpacity(gdjs.randomInRange(128, 196));
}
for(var i = 0, len = gdjs.Level_324Code.GDCloud2Objects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDCloud2Objects4[i].setOpacity(gdjs.randomInRange(128, 196));
}
for(var i = 0, len = gdjs.Level_324Code.GDCloud3Objects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDCloud3Objects4[i].setOpacity(gdjs.randomInRange(128, 196));
}
for(var i = 0, len = gdjs.Level_324Code.GDCloud4Objects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDCloud4Objects4[i].setOpacity(gdjs.randomInRange(128, 196));
}
}}

}


};gdjs.Level_324Code.eventsList4 = function(runtimeScene) {

{


{
{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "Clouds", 0, 0);
}
{ //Subevents
gdjs.Level_324Code.eventsList3(runtimeScene);} //End of subevents
}

}


};gdjs.Level_324Code.eventsList5 = function(runtimeScene) {

{



}


{


{
{gdjs.evtTools.camera.setCameraX(runtimeScene, gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) - (gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0) + 0), "", 0);
}}

}


{



}


{


{
{gdjs.evtTools.tween.tweenCamera(runtimeScene, "SlideCameraIn", gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) + gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0), "", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) * 1000, "easeOutBack");
}}

}


};gdjs.Level_324Code.asyncCallback11636468 = function (runtimeScene, asyncObjectsList) {
{runtimeScene.getVariables().get("GameState").setString("Idle");
}}
gdjs.Level_324Code.eventsList6 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0))), (runtimeScene) => (gdjs.Level_324Code.asyncCallback11636468(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_324Code.eventsList7 = function(runtimeScene) {

{


{
{runtimeScene.getVariables().get("StartingZoom").setNumber(0.65);
}{gdjs.evtTools.camera.setCameraZoom(runtimeScene, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("StartingZoom")), "", 0);
}}

}


{


gdjs.Level_324Code.eventsList5(runtimeScene);
}


{


{

{ //Subevents
gdjs.Level_324Code.eventsList6(runtimeScene);} //End of subevents
}

}


};gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupFrontObjects5Objects = Hashtable.newFrom({"CupFront": gdjs.Level_324Code.GDCupFrontObjects5});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupObjects5Objects = Hashtable.newFrom({"Cup": gdjs.Level_324Code.GDCupObjects5});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDBall_95951Objects6ObjectsGDgdjs_46Level_95324Code_46GDBall_95952Objects6ObjectsGDgdjs_46Level_95324Code_46GDBall_95954Objects6ObjectsGDgdjs_46Level_95324Code_46GDBall_95953Objects6ObjectsGDgdjs_46Level_95324Code_46GDBall_95955Objects6ObjectsGDgdjs_46Level_95324Code_46GDBall_95956Objects6Objects = Hashtable.newFrom({"Ball_1": gdjs.Level_324Code.GDBall_951Objects6, "Ball_2": gdjs.Level_324Code.GDBall_952Objects6, "Ball_4": gdjs.Level_324Code.GDBall_954Objects6, "Ball_3": gdjs.Level_324Code.GDBall_953Objects6, "Ball_5": gdjs.Level_324Code.GDBall_955Objects6, "Ball_6": gdjs.Level_324Code.GDBall_956Objects6});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupObjects6Objects = Hashtable.newFrom({"Cup": gdjs.Level_324Code.GDCupObjects6});
gdjs.Level_324Code.eventsList8 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Ball_1"), gdjs.Level_324Code.GDBall_951Objects6);
gdjs.copyArray(runtimeScene.getObjects("Ball_2"), gdjs.Level_324Code.GDBall_952Objects6);
gdjs.copyArray(runtimeScene.getObjects("Ball_3"), gdjs.Level_324Code.GDBall_953Objects6);
gdjs.copyArray(runtimeScene.getObjects("Ball_4"), gdjs.Level_324Code.GDBall_954Objects6);
gdjs.copyArray(runtimeScene.getObjects("Ball_5"), gdjs.Level_324Code.GDBall_955Objects6);
gdjs.copyArray(runtimeScene.getObjects("Ball_6"), gdjs.Level_324Code.GDBall_956Objects6);
gdjs.copyArray(gdjs.Level_324Code.GDCupObjects5, gdjs.Level_324Code.GDCupObjects6);


gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDBall_95951Objects6ObjectsGDgdjs_46Level_95324Code_46GDBall_95952Objects6ObjectsGDgdjs_46Level_95324Code_46GDBall_95954Objects6ObjectsGDgdjs_46Level_95324Code_46GDBall_95953Objects6ObjectsGDgdjs_46Level_95324Code_46GDBall_95955Objects6ObjectsGDgdjs_46Level_95324Code_46GDBall_95956Objects6Objects, gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupObjects6Objects, false, runtimeScene, true);
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_324Code.GDBall_951Objects6 */
/* Reuse gdjs.Level_324Code.GDBall_952Objects6 */
/* Reuse gdjs.Level_324Code.GDBall_953Objects6 */
/* Reuse gdjs.Level_324Code.GDBall_954Objects6 */
/* Reuse gdjs.Level_324Code.GDBall_955Objects6 */
/* Reuse gdjs.Level_324Code.GDBall_956Objects6 */
/* Reuse gdjs.Level_324Code.GDCupObjects6 */
{for(var i = 0, len = gdjs.Level_324Code.GDBall_951Objects6.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_951Objects6[i].setCenterXInScene((( gdjs.Level_324Code.GDCupObjects6.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects6[0].getCenterXInScene()));
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_952Objects6.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_952Objects6[i].setCenterXInScene((( gdjs.Level_324Code.GDCupObjects6.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects6[0].getCenterXInScene()));
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_954Objects6.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_954Objects6[i].setCenterXInScene((( gdjs.Level_324Code.GDCupObjects6.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects6[0].getCenterXInScene()));
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_953Objects6.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_953Objects6[i].setCenterXInScene((( gdjs.Level_324Code.GDCupObjects6.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects6[0].getCenterXInScene()));
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_955Objects6.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_955Objects6[i].setCenterXInScene((( gdjs.Level_324Code.GDCupObjects6.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects6[0].getCenterXInScene()));
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_956Objects6.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_956Objects6[i].setCenterXInScene((( gdjs.Level_324Code.GDCupObjects6.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects6[0].getCenterXInScene()));
}
}}

}


};gdjs.Level_324Code.eventsList9 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Cup"), gdjs.Level_324Code.GDCupObjects4);

for(gdjs.Level_324Code.forEachIndex5 = 0;gdjs.Level_324Code.forEachIndex5 < gdjs.Level_324Code.GDCupObjects4.length;++gdjs.Level_324Code.forEachIndex5) {
gdjs.Level_324Code.GDCupFrontObjects5.length = 0;

gdjs.Level_324Code.GDCupObjects5.length = 0;


gdjs.Level_324Code.forEachTemporary5 = gdjs.Level_324Code.GDCupObjects4[gdjs.Level_324Code.forEachIndex5];
gdjs.Level_324Code.GDCupObjects5.push(gdjs.Level_324Code.forEachTemporary5);
if (true) {
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupFrontObjects5Objects, (( gdjs.Level_324Code.GDCupObjects5.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects5[0].getPointX("")), (( gdjs.Level_324Code.GDCupObjects5.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects5[0].getPointY("")), "FrontCups");
}{for(var i = 0, len = gdjs.Level_324Code.GDCupFrontObjects5.length ;i < len;++i) {
    gdjs.Level_324Code.GDCupFrontObjects5[i].setHeight((( gdjs.Level_324Code.GDCupObjects5.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects5[0].getHeight()));
}
}{for(var i = 0, len = gdjs.Level_324Code.GDCupFrontObjects5.length ;i < len;++i) {
    gdjs.Level_324Code.GDCupFrontObjects5[i].setWidth((( gdjs.Level_324Code.GDCupObjects5.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects5[0].getWidth()));
}
}{for(var i = 0, len = gdjs.Level_324Code.GDCupFrontObjects5.length ;i < len;++i) {
    gdjs.Level_324Code.GDCupFrontObjects5[i].setOpacity(64);
}
}{for(var i = 0, len = gdjs.Level_324Code.GDCupFrontObjects5.length ;i < len;++i) {
    gdjs.Level_324Code.GDCupFrontObjects5[i].getBehavior("Sticker").Stick(gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupObjects5Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents: 
gdjs.Level_324Code.eventsList8(runtimeScene);} //Subevents end.
}
}

}


};gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDBall_95951Objects5ObjectsGDgdjs_46Level_95324Code_46GDBall_95952Objects5ObjectsGDgdjs_46Level_95324Code_46GDBall_95954Objects5ObjectsGDgdjs_46Level_95324Code_46GDBall_95953Objects5ObjectsGDgdjs_46Level_95324Code_46GDBall_95955Objects5ObjectsGDgdjs_46Level_95324Code_46GDBall_95956Objects5Objects = Hashtable.newFrom({"Ball_1": gdjs.Level_324Code.GDBall_951Objects5, "Ball_2": gdjs.Level_324Code.GDBall_952Objects5, "Ball_4": gdjs.Level_324Code.GDBall_954Objects5, "Ball_3": gdjs.Level_324Code.GDBall_953Objects5, "Ball_5": gdjs.Level_324Code.GDBall_955Objects5, "Ball_6": gdjs.Level_324Code.GDBall_956Objects5});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupObjects5Objects = Hashtable.newFrom({"Cup": gdjs.Level_324Code.GDCupObjects5});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDBall_95951Objects5ObjectsGDgdjs_46Level_95324Code_46GDBall_95952Objects5ObjectsGDgdjs_46Level_95324Code_46GDBall_95954Objects5ObjectsGDgdjs_46Level_95324Code_46GDBall_95953Objects5ObjectsGDgdjs_46Level_95324Code_46GDBall_95955Objects5ObjectsGDgdjs_46Level_95324Code_46GDBall_95956Objects5Objects = Hashtable.newFrom({"Ball_1": gdjs.Level_324Code.GDBall_951Objects5, "Ball_2": gdjs.Level_324Code.GDBall_952Objects5, "Ball_4": gdjs.Level_324Code.GDBall_954Objects5, "Ball_3": gdjs.Level_324Code.GDBall_953Objects5, "Ball_5": gdjs.Level_324Code.GDBall_955Objects5, "Ball_6": gdjs.Level_324Code.GDBall_956Objects5});
gdjs.Level_324Code.eventsList10 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Ball_1"), gdjs.Level_324Code.GDBall_951Objects5);
gdjs.copyArray(runtimeScene.getObjects("Ball_2"), gdjs.Level_324Code.GDBall_952Objects5);
gdjs.copyArray(runtimeScene.getObjects("Ball_3"), gdjs.Level_324Code.GDBall_953Objects5);
gdjs.copyArray(runtimeScene.getObjects("Ball_4"), gdjs.Level_324Code.GDBall_954Objects5);
gdjs.copyArray(runtimeScene.getObjects("Ball_5"), gdjs.Level_324Code.GDBall_955Objects5);
gdjs.copyArray(runtimeScene.getObjects("Ball_6"), gdjs.Level_324Code.GDBall_956Objects5);
gdjs.copyArray(gdjs.Level_324Code.GDCupObjects4, gdjs.Level_324Code.GDCupObjects5);


gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDBall_95951Objects5ObjectsGDgdjs_46Level_95324Code_46GDBall_95952Objects5ObjectsGDgdjs_46Level_95324Code_46GDBall_95954Objects5ObjectsGDgdjs_46Level_95324Code_46GDBall_95953Objects5ObjectsGDgdjs_46Level_95324Code_46GDBall_95955Objects5ObjectsGDgdjs_46Level_95324Code_46GDBall_95956Objects5Objects, gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupObjects5Objects, false, runtimeScene, true);
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_324Code.GDCupObjects5 */
{for(var i = 0, len = gdjs.Level_324Code.GDCupObjects5.length ;i < len;++i) {
    gdjs.Level_324Code.GDCupObjects5[i].returnVariable(gdjs.Level_324Code.GDCupObjects5[i].getVariables().get("Balls")).setNumber(gdjs.evtTools.object.getPickedInstancesCount(gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDBall_95951Objects5ObjectsGDgdjs_46Level_95324Code_46GDBall_95952Objects5ObjectsGDgdjs_46Level_95324Code_46GDBall_95954Objects5ObjectsGDgdjs_46Level_95324Code_46GDBall_95953Objects5ObjectsGDgdjs_46Level_95324Code_46GDBall_95955Objects5ObjectsGDgdjs_46Level_95324Code_46GDBall_95956Objects5Objects));
}
}}

}


};gdjs.Level_324Code.eventsList11 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Cup"), gdjs.Level_324Code.GDCupObjects3);

for(gdjs.Level_324Code.forEachIndex4 = 0;gdjs.Level_324Code.forEachIndex4 < gdjs.Level_324Code.GDCupObjects3.length;++gdjs.Level_324Code.forEachIndex4) {
gdjs.Level_324Code.GDCupObjects4.length = 0;


gdjs.Level_324Code.forEachTemporary4 = gdjs.Level_324Code.GDCupObjects3[gdjs.Level_324Code.forEachIndex4];
gdjs.Level_324Code.GDCupObjects4.push(gdjs.Level_324Code.forEachTemporary4);
if (true) {

{ //Subevents: 
gdjs.Level_324Code.eventsList10(runtimeScene);} //Subevents end.
}
}

}


};gdjs.Level_324Code.eventsList12 = function(runtimeScene) {

{


gdjs.Level_324Code.eventsList0(runtimeScene);
}


{


gdjs.Level_324Code.eventsList2(runtimeScene);
}


{


gdjs.Level_324Code.eventsList4(runtimeScene);
}


{



}


{


gdjs.Level_324Code.eventsList7(runtimeScene);
}


{



}


{


{
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "ExplosionDelay");
}}

}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("Cup"), gdjs.Level_324Code.GDCupObjects4);
{runtimeScene.getVariables().get("PickupBall_Duration").setNumber(125);
}{runtimeScene.getVariables().get("MoveBall_Duration").setNumber(150);
}{runtimeScene.getVariables().get("DropBall_Duration").setNumber(150);
}{for(var i = 0, len = gdjs.Level_324Code.GDCupObjects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDCupObjects4[i].setOpacity(128);
}
}{runtimeScene.getVariables().get("MaxBallsPerCup").setNumber(4);
}}

}


{


gdjs.Level_324Code.eventsList9(runtimeScene);
}


{


gdjs.Level_324Code.eventsList11(runtimeScene);
}


};gdjs.Level_324Code.eventsList13 = function(runtimeScene) {

{


gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Level_324Code.eventsList12(runtimeScene);} //End of subevents
}

}


};gdjs.Level_324Code.eventsList14 = function(runtimeScene) {

{


gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
{gdjs.Level_324Code.conditionTrue_1 = gdjs.Level_324Code.condition0IsTrue_0;
gdjs.Level_324Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11644052);
}
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Cup"), gdjs.Level_324Code.GDCupObjects4);
{for(var i = 0, len = gdjs.Level_324Code.GDCupObjects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDCupObjects4[i].setVariableBoolean(gdjs.Level_324Code.GDCupObjects4[i].getVariables().get("StartingCup"), false);
}
}}

}


};gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupObjects3Objects = Hashtable.newFrom({"Cup": gdjs.Level_324Code.GDCupObjects3});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDBall_95951Objects3ObjectsGDgdjs_46Level_95324Code_46GDBall_95952Objects3ObjectsGDgdjs_46Level_95324Code_46GDBall_95954Objects3ObjectsGDgdjs_46Level_95324Code_46GDBall_95953Objects3ObjectsGDgdjs_46Level_95324Code_46GDBall_95955Objects3ObjectsGDgdjs_46Level_95324Code_46GDBall_95956Objects3Objects = Hashtable.newFrom({"Ball_1": gdjs.Level_324Code.GDBall_951Objects3, "Ball_2": gdjs.Level_324Code.GDBall_952Objects3, "Ball_4": gdjs.Level_324Code.GDBall_954Objects3, "Ball_3": gdjs.Level_324Code.GDBall_953Objects3, "Ball_5": gdjs.Level_324Code.GDBall_955Objects3, "Ball_6": gdjs.Level_324Code.GDBall_956Objects3});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupObjects3Objects = Hashtable.newFrom({"Cup": gdjs.Level_324Code.GDCupObjects3});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDBall_95951Objects3ObjectsGDgdjs_46Level_95324Code_46GDBall_95952Objects3ObjectsGDgdjs_46Level_95324Code_46GDBall_95954Objects3ObjectsGDgdjs_46Level_95324Code_46GDBall_95953Objects3ObjectsGDgdjs_46Level_95324Code_46GDBall_95955Objects3ObjectsGDgdjs_46Level_95324Code_46GDBall_95956Objects3Objects = Hashtable.newFrom({"Ball_1": gdjs.Level_324Code.GDBall_951Objects3, "Ball_2": gdjs.Level_324Code.GDBall_952Objects3, "Ball_4": gdjs.Level_324Code.GDBall_954Objects3, "Ball_3": gdjs.Level_324Code.GDBall_953Objects3, "Ball_5": gdjs.Level_324Code.GDBall_955Objects3, "Ball_6": gdjs.Level_324Code.GDBall_956Objects3});
gdjs.Level_324Code.eventsList15 = function(runtimeScene, asyncObjectsList) {

{


gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
{runtimeScene.getVariables().get("GameState").setString("DraggingBall");
}}

}


{


gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = !(gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left"));
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
{runtimeScene.getVariables().get("GameState").setString("BallFloating");
}}

}


};gdjs.Level_324Code.asyncCallback11650660 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Level_324Code.eventsList15(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Level_324Code.eventsList16 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("PickupBall_Duration")) / 1000), (runtimeScene) => (gdjs.Level_324Code.asyncCallback11650660(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_324Code.eventsList17 = function(runtimeScene) {

{


{

{ //Subevents
gdjs.Level_324Code.eventsList16(runtimeScene);} //End of subevents
}

}


};gdjs.Level_324Code.eventsList18 = function(runtimeScene) {

{


{
{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\Nikolay Overchenko - Whoosh, cartoon, whirring 2.aac", false, 20, gdjs.randomFloatInRange(1.5, 1.7));
}{gdjs.deviceVibration.startVibration(25);
}}

}


{



}


{


gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerPaused(runtimeScene, "PlayTimer");
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.unpauseTimer(runtimeScene, "PlayTimer");
}}

}


{


gdjs.Level_324Code.eventsList17(runtimeScene);
}


};gdjs.Level_324Code.eventsList19 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Ball_1"), gdjs.Level_324Code.GDBall_951Objects3);
gdjs.copyArray(runtimeScene.getObjects("Ball_2"), gdjs.Level_324Code.GDBall_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Ball_3"), gdjs.Level_324Code.GDBall_953Objects3);
gdjs.copyArray(runtimeScene.getObjects("Ball_4"), gdjs.Level_324Code.GDBall_954Objects3);
gdjs.copyArray(runtimeScene.getObjects("Ball_5"), gdjs.Level_324Code.GDBall_955Objects3);
gdjs.copyArray(runtimeScene.getObjects("Ball_6"), gdjs.Level_324Code.GDBall_956Objects3);
gdjs.copyArray(runtimeScene.getObjects("Cup"), gdjs.Level_324Code.GDCupObjects3);

gdjs.Level_324Code.condition0IsTrue_0.val = false;
gdjs.Level_324Code.condition1IsTrue_0.val = false;
gdjs.Level_324Code.condition2IsTrue_0.val = false;
gdjs.Level_324Code.condition3IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupObjects3Objects, runtimeScene, true, false);
}if ( gdjs.Level_324Code.condition0IsTrue_0.val ) {
{
gdjs.Level_324Code.condition1IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDBall_95951Objects3ObjectsGDgdjs_46Level_95324Code_46GDBall_95952Objects3ObjectsGDgdjs_46Level_95324Code_46GDBall_95954Objects3ObjectsGDgdjs_46Level_95324Code_46GDBall_95953Objects3ObjectsGDgdjs_46Level_95324Code_46GDBall_95955Objects3ObjectsGDgdjs_46Level_95324Code_46GDBall_95956Objects3Objects, gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupObjects3Objects, false, runtimeScene, true);
}if ( gdjs.Level_324Code.condition1IsTrue_0.val ) {
{
gdjs.Level_324Code.condition2IsTrue_0.val = gdjs.evtTools.object.pickNearestObject(gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDBall_95951Objects3ObjectsGDgdjs_46Level_95324Code_46GDBall_95952Objects3ObjectsGDgdjs_46Level_95324Code_46GDBall_95954Objects3ObjectsGDgdjs_46Level_95324Code_46GDBall_95953Objects3ObjectsGDgdjs_46Level_95324Code_46GDBall_95955Objects3ObjectsGDgdjs_46Level_95324Code_46GDBall_95956Objects3Objects, (( gdjs.Level_324Code.GDCupObjects3.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects3[0].getCenterXInScene()), (( gdjs.Level_324Code.GDCupObjects3.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects3[0].getAABBTop()), false);
}if ( gdjs.Level_324Code.condition2IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level_324Code.GDBall_951Objects3.length;i<l;++i) {
    if ( !(gdjs.Level_324Code.GDBall_951Objects3[i].getBehavior("Tween").isPlaying("PickupBall")) ) {
        gdjs.Level_324Code.condition3IsTrue_0.val = true;
        gdjs.Level_324Code.GDBall_951Objects3[k] = gdjs.Level_324Code.GDBall_951Objects3[i];
        ++k;
    }
}
gdjs.Level_324Code.GDBall_951Objects3.length = k;for(var i = 0, k = 0, l = gdjs.Level_324Code.GDBall_952Objects3.length;i<l;++i) {
    if ( !(gdjs.Level_324Code.GDBall_952Objects3[i].getBehavior("Tween").isPlaying("PickupBall")) ) {
        gdjs.Level_324Code.condition3IsTrue_0.val = true;
        gdjs.Level_324Code.GDBall_952Objects3[k] = gdjs.Level_324Code.GDBall_952Objects3[i];
        ++k;
    }
}
gdjs.Level_324Code.GDBall_952Objects3.length = k;for(var i = 0, k = 0, l = gdjs.Level_324Code.GDBall_954Objects3.length;i<l;++i) {
    if ( !(gdjs.Level_324Code.GDBall_954Objects3[i].getBehavior("Tween").isPlaying("PickupBall")) ) {
        gdjs.Level_324Code.condition3IsTrue_0.val = true;
        gdjs.Level_324Code.GDBall_954Objects3[k] = gdjs.Level_324Code.GDBall_954Objects3[i];
        ++k;
    }
}
gdjs.Level_324Code.GDBall_954Objects3.length = k;for(var i = 0, k = 0, l = gdjs.Level_324Code.GDBall_953Objects3.length;i<l;++i) {
    if ( !(gdjs.Level_324Code.GDBall_953Objects3[i].getBehavior("Tween").isPlaying("PickupBall")) ) {
        gdjs.Level_324Code.condition3IsTrue_0.val = true;
        gdjs.Level_324Code.GDBall_953Objects3[k] = gdjs.Level_324Code.GDBall_953Objects3[i];
        ++k;
    }
}
gdjs.Level_324Code.GDBall_953Objects3.length = k;for(var i = 0, k = 0, l = gdjs.Level_324Code.GDBall_955Objects3.length;i<l;++i) {
    if ( !(gdjs.Level_324Code.GDBall_955Objects3[i].getBehavior("Tween").isPlaying("PickupBall")) ) {
        gdjs.Level_324Code.condition3IsTrue_0.val = true;
        gdjs.Level_324Code.GDBall_955Objects3[k] = gdjs.Level_324Code.GDBall_955Objects3[i];
        ++k;
    }
}
gdjs.Level_324Code.GDBall_955Objects3.length = k;for(var i = 0, k = 0, l = gdjs.Level_324Code.GDBall_956Objects3.length;i<l;++i) {
    if ( !(gdjs.Level_324Code.GDBall_956Objects3[i].getBehavior("Tween").isPlaying("PickupBall")) ) {
        gdjs.Level_324Code.condition3IsTrue_0.val = true;
        gdjs.Level_324Code.GDBall_956Objects3[k] = gdjs.Level_324Code.GDBall_956Objects3[i];
        ++k;
    }
}
gdjs.Level_324Code.GDBall_956Objects3.length = k;}}
}
}
if (gdjs.Level_324Code.condition3IsTrue_0.val) {
/* Reuse gdjs.Level_324Code.GDBall_951Objects3 */
/* Reuse gdjs.Level_324Code.GDBall_952Objects3 */
/* Reuse gdjs.Level_324Code.GDBall_953Objects3 */
/* Reuse gdjs.Level_324Code.GDBall_954Objects3 */
/* Reuse gdjs.Level_324Code.GDBall_955Objects3 */
/* Reuse gdjs.Level_324Code.GDBall_956Objects3 */
/* Reuse gdjs.Level_324Code.GDCupObjects3 */
{for(var i = 0, len = gdjs.Level_324Code.GDBall_951Objects3.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_951Objects3[i].getBehavior("Tween").addObjectPositionYTween("PickupBall", (( gdjs.Level_324Code.GDCupObjects3.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects3[0].getPointY("")) - 1.1 * (gdjs.Level_324Code.GDBall_951Objects3[i].getHeight()), "easeInQuad", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("PickupBall_Duration")), false);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_952Objects3.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_952Objects3[i].getBehavior("Tween").addObjectPositionYTween("PickupBall", (( gdjs.Level_324Code.GDCupObjects3.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects3[0].getPointY("")) - 1.1 * (gdjs.Level_324Code.GDBall_952Objects3[i].getHeight()), "easeInQuad", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("PickupBall_Duration")), false);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_954Objects3.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_954Objects3[i].getBehavior("Tween").addObjectPositionYTween("PickupBall", (( gdjs.Level_324Code.GDCupObjects3.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects3[0].getPointY("")) - 1.1 * (gdjs.Level_324Code.GDBall_954Objects3[i].getHeight()), "easeInQuad", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("PickupBall_Duration")), false);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_953Objects3.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_953Objects3[i].getBehavior("Tween").addObjectPositionYTween("PickupBall", (( gdjs.Level_324Code.GDCupObjects3.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects3[0].getPointY("")) - 1.1 * (gdjs.Level_324Code.GDBall_953Objects3[i].getHeight()), "easeInQuad", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("PickupBall_Duration")), false);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_955Objects3.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_955Objects3[i].getBehavior("Tween").addObjectPositionYTween("PickupBall", (( gdjs.Level_324Code.GDCupObjects3.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects3[0].getPointY("")) - 1.1 * (gdjs.Level_324Code.GDBall_955Objects3[i].getHeight()), "easeInQuad", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("PickupBall_Duration")), false);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_956Objects3.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_956Objects3[i].getBehavior("Tween").addObjectPositionYTween("PickupBall", (( gdjs.Level_324Code.GDCupObjects3.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects3[0].getPointY("")) - 1.1 * (gdjs.Level_324Code.GDBall_956Objects3[i].getHeight()), "easeInQuad", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("PickupBall_Duration")), false);
}
}{for(var i = 0, len = gdjs.Level_324Code.GDBall_951Objects3.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_951Objects3[i].setVariableBoolean(gdjs.Level_324Code.GDBall_951Objects3[i].getVariables().get("PickedUp"), true);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_952Objects3.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_952Objects3[i].setVariableBoolean(gdjs.Level_324Code.GDBall_952Objects3[i].getVariables().get("PickedUp"), true);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_954Objects3.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_954Objects3[i].setVariableBoolean(gdjs.Level_324Code.GDBall_954Objects3[i].getVariables().get("PickedUp"), true);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_953Objects3.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_953Objects3[i].setVariableBoolean(gdjs.Level_324Code.GDBall_953Objects3[i].getVariables().get("PickedUp"), true);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_955Objects3.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_955Objects3[i].setVariableBoolean(gdjs.Level_324Code.GDBall_955Objects3[i].getVariables().get("PickedUp"), true);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_956Objects3.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_956Objects3[i].setVariableBoolean(gdjs.Level_324Code.GDBall_956Objects3[i].getVariables().get("PickedUp"), true);
}
}{for(var i = 0, len = gdjs.Level_324Code.GDCupObjects3.length ;i < len;++i) {
    gdjs.Level_324Code.GDCupObjects3[i].setVariableBoolean(gdjs.Level_324Code.GDCupObjects3[i].getVariables().get("StartingCup"), true);
}
}{for(var i = 0, len = gdjs.Level_324Code.GDCupObjects3.length ;i < len;++i) {
    gdjs.Level_324Code.GDCupObjects3[i].returnVariable(gdjs.Level_324Code.GDCupObjects3[i].getVariables().get("Balls")).sub(1);
}
}{runtimeScene.getVariables().get("HoverOffsetX").setNumber(gdjs.evtTools.input.getMouseX(runtimeScene, "", 0) - (( gdjs.Level_324Code.GDCupObjects3.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects3[0].getCenterXInScene()));
}{runtimeScene.getVariables().get("HoverOffsetY").setNumber(gdjs.evtTools.input.getMouseY(runtimeScene, "", 0) - (( gdjs.Level_324Code.GDCupObjects3.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects3[0].getAABBTop()) + 1.1 * (( gdjs.Level_324Code.GDBall_956Objects3.length === 0 ) ? (( gdjs.Level_324Code.GDBall_955Objects3.length === 0 ) ? (( gdjs.Level_324Code.GDBall_953Objects3.length === 0 ) ? (( gdjs.Level_324Code.GDBall_954Objects3.length === 0 ) ? (( gdjs.Level_324Code.GDBall_952Objects3.length === 0 ) ? (( gdjs.Level_324Code.GDBall_951Objects3.length === 0 ) ? 0 :gdjs.Level_324Code.GDBall_951Objects3[0].getHeight()) :gdjs.Level_324Code.GDBall_952Objects3[0].getHeight()) :gdjs.Level_324Code.GDBall_954Objects3[0].getHeight()) :gdjs.Level_324Code.GDBall_953Objects3[0].getHeight()) :gdjs.Level_324Code.GDBall_955Objects3[0].getHeight()) :gdjs.Level_324Code.GDBall_956Objects3[0].getHeight()));
}{for(var i = 0, len = gdjs.Level_324Code.GDBall_951Objects3.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_951Objects3[i].setLayer("FrontCups");
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_952Objects3.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_952Objects3[i].setLayer("FrontCups");
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_954Objects3.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_954Objects3[i].setLayer("FrontCups");
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_953Objects3.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_953Objects3[i].setLayer("FrontCups");
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_955Objects3.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_955Objects3[i].setLayer("FrontCups");
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_956Objects3.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_956Objects3[i].setLayer("FrontCups");
}
}
{ //Subevents
gdjs.Level_324Code.eventsList18(runtimeScene);} //End of subevents
}

}


};gdjs.Level_324Code.eventsList20 = function(runtimeScene) {

{


gdjs.Level_324Code.condition0IsTrue_0.val = false;
gdjs.Level_324Code.condition1IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.Level_324Code.condition0IsTrue_0.val ) {
{
{gdjs.Level_324Code.conditionTrue_1 = gdjs.Level_324Code.condition1IsTrue_0;
gdjs.Level_324Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11644908);
}
}}
if (gdjs.Level_324Code.condition1IsTrue_0.val) {

{ //Subevents
gdjs.Level_324Code.eventsList19(runtimeScene);} //End of subevents
}

}


};gdjs.Level_324Code.eventsList21 = function(runtimeScene) {

{


gdjs.Level_324Code.eventsList14(runtimeScene);
}


{


gdjs.Level_324Code.eventsList20(runtimeScene);
}


};gdjs.Level_324Code.eventsList22 = function(runtimeScene) {

{


gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("GameState")) == "Idle";
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Level_324Code.eventsList21(runtimeScene);} //End of subevents
}

}


};gdjs.Level_324Code.eventsList23 = function(runtimeScene) {

{


gdjs.Level_324Code.condition0IsTrue_0.val = false;
gdjs.Level_324Code.condition1IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.Level_324Code.condition0IsTrue_0.val ) {
{
{gdjs.Level_324Code.conditionTrue_1 = gdjs.Level_324Code.condition1IsTrue_0;
gdjs.Level_324Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11652748);
}
}}
if (gdjs.Level_324Code.condition1IsTrue_0.val) {
{runtimeScene.getVariables().get("GameState").setString("DroppingBall");
}}

}


};gdjs.Level_324Code.eventsList24 = function(runtimeScene) {

{


gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("GameState")) == "BallFloating";
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Level_324Code.eventsList23(runtimeScene);} //End of subevents
}

}


};gdjs.Level_324Code.eventsList25 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Ball_1"), gdjs.Level_324Code.GDBall_951Objects4);
gdjs.copyArray(runtimeScene.getObjects("Ball_2"), gdjs.Level_324Code.GDBall_952Objects4);
gdjs.copyArray(runtimeScene.getObjects("Ball_3"), gdjs.Level_324Code.GDBall_953Objects4);
gdjs.copyArray(runtimeScene.getObjects("Ball_4"), gdjs.Level_324Code.GDBall_954Objects4);
gdjs.copyArray(runtimeScene.getObjects("Ball_5"), gdjs.Level_324Code.GDBall_955Objects4);
gdjs.copyArray(runtimeScene.getObjects("Ball_6"), gdjs.Level_324Code.GDBall_956Objects4);

gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_324Code.GDBall_951Objects4.length;i<l;++i) {
    if ( gdjs.Level_324Code.GDBall_951Objects4[i].getVariableBoolean(gdjs.Level_324Code.GDBall_951Objects4[i].getVariables().get("PickedUp"), true) ) {
        gdjs.Level_324Code.condition0IsTrue_0.val = true;
        gdjs.Level_324Code.GDBall_951Objects4[k] = gdjs.Level_324Code.GDBall_951Objects4[i];
        ++k;
    }
}
gdjs.Level_324Code.GDBall_951Objects4.length = k;for(var i = 0, k = 0, l = gdjs.Level_324Code.GDBall_952Objects4.length;i<l;++i) {
    if ( gdjs.Level_324Code.GDBall_952Objects4[i].getVariableBoolean(gdjs.Level_324Code.GDBall_952Objects4[i].getVariables().get("PickedUp"), true) ) {
        gdjs.Level_324Code.condition0IsTrue_0.val = true;
        gdjs.Level_324Code.GDBall_952Objects4[k] = gdjs.Level_324Code.GDBall_952Objects4[i];
        ++k;
    }
}
gdjs.Level_324Code.GDBall_952Objects4.length = k;for(var i = 0, k = 0, l = gdjs.Level_324Code.GDBall_954Objects4.length;i<l;++i) {
    if ( gdjs.Level_324Code.GDBall_954Objects4[i].getVariableBoolean(gdjs.Level_324Code.GDBall_954Objects4[i].getVariables().get("PickedUp"), true) ) {
        gdjs.Level_324Code.condition0IsTrue_0.val = true;
        gdjs.Level_324Code.GDBall_954Objects4[k] = gdjs.Level_324Code.GDBall_954Objects4[i];
        ++k;
    }
}
gdjs.Level_324Code.GDBall_954Objects4.length = k;for(var i = 0, k = 0, l = gdjs.Level_324Code.GDBall_953Objects4.length;i<l;++i) {
    if ( gdjs.Level_324Code.GDBall_953Objects4[i].getVariableBoolean(gdjs.Level_324Code.GDBall_953Objects4[i].getVariables().get("PickedUp"), true) ) {
        gdjs.Level_324Code.condition0IsTrue_0.val = true;
        gdjs.Level_324Code.GDBall_953Objects4[k] = gdjs.Level_324Code.GDBall_953Objects4[i];
        ++k;
    }
}
gdjs.Level_324Code.GDBall_953Objects4.length = k;for(var i = 0, k = 0, l = gdjs.Level_324Code.GDBall_955Objects4.length;i<l;++i) {
    if ( gdjs.Level_324Code.GDBall_955Objects4[i].getVariableBoolean(gdjs.Level_324Code.GDBall_955Objects4[i].getVariables().get("PickedUp"), true) ) {
        gdjs.Level_324Code.condition0IsTrue_0.val = true;
        gdjs.Level_324Code.GDBall_955Objects4[k] = gdjs.Level_324Code.GDBall_955Objects4[i];
        ++k;
    }
}
gdjs.Level_324Code.GDBall_955Objects4.length = k;for(var i = 0, k = 0, l = gdjs.Level_324Code.GDBall_956Objects4.length;i<l;++i) {
    if ( gdjs.Level_324Code.GDBall_956Objects4[i].getVariableBoolean(gdjs.Level_324Code.GDBall_956Objects4[i].getVariables().get("PickedUp"), true) ) {
        gdjs.Level_324Code.condition0IsTrue_0.val = true;
        gdjs.Level_324Code.GDBall_956Objects4[k] = gdjs.Level_324Code.GDBall_956Objects4[i];
        ++k;
    }
}
gdjs.Level_324Code.GDBall_956Objects4.length = k;}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_324Code.GDBall_951Objects4 */
/* Reuse gdjs.Level_324Code.GDBall_952Objects4 */
/* Reuse gdjs.Level_324Code.GDBall_953Objects4 */
/* Reuse gdjs.Level_324Code.GDBall_954Objects4 */
/* Reuse gdjs.Level_324Code.GDBall_955Objects4 */
/* Reuse gdjs.Level_324Code.GDBall_956Objects4 */
{for(var i = 0, len = gdjs.Level_324Code.GDBall_951Objects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_951Objects4[i].setPosition(gdjs.evtTools.common.lerp((gdjs.Level_324Code.GDBall_951Objects4[i].getPointX("")), gdjs.evtTools.input.getMouseX(runtimeScene, "", 0) - gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("HoverOffsetX")), 0.3),gdjs.evtTools.common.lerp((gdjs.Level_324Code.GDBall_951Objects4[i].getPointY("")), gdjs.evtTools.input.getMouseY(runtimeScene, "", 0) - gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("HoverOffsetY")), 0.3));
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_952Objects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_952Objects4[i].setPosition(gdjs.evtTools.common.lerp((gdjs.Level_324Code.GDBall_952Objects4[i].getPointX("")), gdjs.evtTools.input.getMouseX(runtimeScene, "", 0) - gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("HoverOffsetX")), 0.3),gdjs.evtTools.common.lerp((gdjs.Level_324Code.GDBall_952Objects4[i].getPointY("")), gdjs.evtTools.input.getMouseY(runtimeScene, "", 0) - gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("HoverOffsetY")), 0.3));
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_954Objects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_954Objects4[i].setPosition(gdjs.evtTools.common.lerp((gdjs.Level_324Code.GDBall_954Objects4[i].getPointX("")), gdjs.evtTools.input.getMouseX(runtimeScene, "", 0) - gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("HoverOffsetX")), 0.3),gdjs.evtTools.common.lerp((gdjs.Level_324Code.GDBall_954Objects4[i].getPointY("")), gdjs.evtTools.input.getMouseY(runtimeScene, "", 0) - gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("HoverOffsetY")), 0.3));
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_953Objects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_953Objects4[i].setPosition(gdjs.evtTools.common.lerp((gdjs.Level_324Code.GDBall_953Objects4[i].getPointX("")), gdjs.evtTools.input.getMouseX(runtimeScene, "", 0) - gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("HoverOffsetX")), 0.3),gdjs.evtTools.common.lerp((gdjs.Level_324Code.GDBall_953Objects4[i].getPointY("")), gdjs.evtTools.input.getMouseY(runtimeScene, "", 0) - gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("HoverOffsetY")), 0.3));
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_955Objects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_955Objects4[i].setPosition(gdjs.evtTools.common.lerp((gdjs.Level_324Code.GDBall_955Objects4[i].getPointX("")), gdjs.evtTools.input.getMouseX(runtimeScene, "", 0) - gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("HoverOffsetX")), 0.3),gdjs.evtTools.common.lerp((gdjs.Level_324Code.GDBall_955Objects4[i].getPointY("")), gdjs.evtTools.input.getMouseY(runtimeScene, "", 0) - gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("HoverOffsetY")), 0.3));
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_956Objects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_956Objects4[i].setPosition(gdjs.evtTools.common.lerp((gdjs.Level_324Code.GDBall_956Objects4[i].getPointX("")), gdjs.evtTools.input.getMouseX(runtimeScene, "", 0) - gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("HoverOffsetX")), 0.3),gdjs.evtTools.common.lerp((gdjs.Level_324Code.GDBall_956Objects4[i].getPointY("")), gdjs.evtTools.input.getMouseY(runtimeScene, "", 0) - gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("HoverOffsetY")), 0.3));
}
}}

}


{


gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
{runtimeScene.getVariables().get("GameState").setString("DroppingBall");
}}

}


};gdjs.Level_324Code.eventsList26 = function(runtimeScene) {

{


gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("GameState")) == "DraggingBall";
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Level_324Code.eventsList25(runtimeScene);} //End of subevents
}

}


};gdjs.Level_324Code.eventsList27 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("Cup"), gdjs.Level_324Code.GDCupObjects4);
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().get("ValidDropLocation"), false);
}{for(var i = 0, len = gdjs.Level_324Code.GDCupObjects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDCupObjects4[i].setVariableBoolean(gdjs.Level_324Code.GDCupObjects4[i].getVariables().get("DropTarget"), false);
}
}}

}


};gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDBall_95951Objects6ObjectsGDgdjs_46Level_95324Code_46GDBall_95952Objects6ObjectsGDgdjs_46Level_95324Code_46GDBall_95954Objects6ObjectsGDgdjs_46Level_95324Code_46GDBall_95953Objects6ObjectsGDgdjs_46Level_95324Code_46GDBall_95955Objects6ObjectsGDgdjs_46Level_95324Code_46GDBall_95956Objects6Objects = Hashtable.newFrom({"Ball_1": gdjs.Level_324Code.GDBall_951Objects6, "Ball_2": gdjs.Level_324Code.GDBall_952Objects6, "Ball_4": gdjs.Level_324Code.GDBall_954Objects6, "Ball_3": gdjs.Level_324Code.GDBall_953Objects6, "Ball_5": gdjs.Level_324Code.GDBall_955Objects6, "Ball_6": gdjs.Level_324Code.GDBall_956Objects6});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupObjects6Objects = Hashtable.newFrom({"Cup": gdjs.Level_324Code.GDCupObjects6});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupObjects5Objects = Hashtable.newFrom({"Cup": gdjs.Level_324Code.GDCupObjects5});
gdjs.Level_324Code.eventsList28 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Level_324Code.GDBall_951Objects4, gdjs.Level_324Code.GDBall_951Objects6);

gdjs.copyArray(gdjs.Level_324Code.GDBall_952Objects4, gdjs.Level_324Code.GDBall_952Objects6);

gdjs.copyArray(gdjs.Level_324Code.GDBall_953Objects4, gdjs.Level_324Code.GDBall_953Objects6);

gdjs.copyArray(gdjs.Level_324Code.GDBall_954Objects4, gdjs.Level_324Code.GDBall_954Objects6);

gdjs.copyArray(gdjs.Level_324Code.GDBall_955Objects4, gdjs.Level_324Code.GDBall_955Objects6);

gdjs.copyArray(gdjs.Level_324Code.GDBall_956Objects4, gdjs.Level_324Code.GDBall_956Objects6);

gdjs.copyArray(gdjs.Level_324Code.GDCupObjects5, gdjs.Level_324Code.GDCupObjects6);


gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDBall_95951Objects6ObjectsGDgdjs_46Level_95324Code_46GDBall_95952Objects6ObjectsGDgdjs_46Level_95324Code_46GDBall_95954Objects6ObjectsGDgdjs_46Level_95324Code_46GDBall_95953Objects6ObjectsGDgdjs_46Level_95324Code_46GDBall_95955Objects6ObjectsGDgdjs_46Level_95324Code_46GDBall_95956Objects6Objects, gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupObjects6Objects, false, runtimeScene, true);
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_324Code.GDCupObjects6 */
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().get("ValidDropLocation"), true);
}{for(var i = 0, len = gdjs.Level_324Code.GDCupObjects6.length ;i < len;++i) {
    gdjs.Level_324Code.GDCupObjects6[i].setVariableBoolean(gdjs.Level_324Code.GDCupObjects6[i].getVariables().get("DropTarget"), true);
}
}}

}


{



}


{

/* Reuse gdjs.Level_324Code.GDCupObjects5 */

gdjs.Level_324Code.condition0IsTrue_0.val = false;
gdjs.Level_324Code.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_324Code.GDCupObjects5.length;i<l;++i) {
    if ( gdjs.Level_324Code.GDCupObjects5[i].getVariableBoolean(gdjs.Level_324Code.GDCupObjects5[i].getVariables().get("DropTarget"), false) ) {
        gdjs.Level_324Code.condition0IsTrue_0.val = true;
        gdjs.Level_324Code.GDCupObjects5[k] = gdjs.Level_324Code.GDCupObjects5[i];
        ++k;
    }
}
gdjs.Level_324Code.GDCupObjects5.length = k;}if ( gdjs.Level_324Code.condition0IsTrue_0.val ) {
{
gdjs.Level_324Code.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupObjects5Objects, runtimeScene, true, false);
}}
if (gdjs.Level_324Code.condition1IsTrue_0.val) {
/* Reuse gdjs.Level_324Code.GDCupObjects5 */
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().get("ValidDropLocation"), true);
}{for(var i = 0, len = gdjs.Level_324Code.GDCupObjects5.length ;i < len;++i) {
    gdjs.Level_324Code.GDCupObjects5[i].setVariableBoolean(gdjs.Level_324Code.GDCupObjects5[i].getVariables().get("DropTarget"), true);
}
}}

}


};gdjs.Level_324Code.eventsList29 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Cup"), gdjs.Level_324Code.GDCupObjects5);

gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_324Code.GDCupObjects5.length;i<l;++i) {
    if ( gdjs.Level_324Code.GDCupObjects5[i].getVariableNumber(gdjs.Level_324Code.GDCupObjects5[i].getVariables().get("Balls")) < gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MaxBallsPerCup")) ) {
        gdjs.Level_324Code.condition0IsTrue_0.val = true;
        gdjs.Level_324Code.GDCupObjects5[k] = gdjs.Level_324Code.GDCupObjects5[i];
        ++k;
    }
}
gdjs.Level_324Code.GDCupObjects5.length = k;}if (gdjs.Level_324Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Level_324Code.eventsList28(runtimeScene);} //End of subevents
}

}


};gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupObjects5Objects = Hashtable.newFrom({"Cup": gdjs.Level_324Code.GDCupObjects5});
gdjs.Level_324Code.asyncCallback11621716 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Ball_1"), gdjs.Level_324Code.GDBall_951Objects6);

gdjs.copyArray(asyncObjectsList.getObjects("Ball_2"), gdjs.Level_324Code.GDBall_952Objects6);

gdjs.copyArray(asyncObjectsList.getObjects("Ball_3"), gdjs.Level_324Code.GDBall_953Objects6);

gdjs.copyArray(asyncObjectsList.getObjects("Ball_4"), gdjs.Level_324Code.GDBall_954Objects6);

gdjs.copyArray(asyncObjectsList.getObjects("Ball_5"), gdjs.Level_324Code.GDBall_955Objects6);

gdjs.copyArray(asyncObjectsList.getObjects("Ball_6"), gdjs.Level_324Code.GDBall_956Objects6);

gdjs.copyArray(asyncObjectsList.getObjects("Cup"), gdjs.Level_324Code.GDCupObjects6);

{for(var i = 0, len = gdjs.Level_324Code.GDBall_951Objects6.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_951Objects6[i].setLayer("Balls");
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_952Objects6.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_952Objects6[i].setLayer("Balls");
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_954Objects6.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_954Objects6[i].setLayer("Balls");
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_953Objects6.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_953Objects6[i].setLayer("Balls");
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_955Objects6.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_955Objects6[i].setLayer("Balls");
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_956Objects6.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_956Objects6[i].setLayer("Balls");
}
}{for(var i = 0, len = gdjs.Level_324Code.GDBall_951Objects6.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_951Objects6[i].getBehavior("Tween").addObjectPositionTween("DropBall", (( gdjs.Level_324Code.GDCupObjects6.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects6[0].getCenterXInScene()), (( gdjs.Level_324Code.GDCupObjects6.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects6[0].getPointY("")) + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MaxBallsPerCup")) - (gdjs.RuntimeObject.getVariableNumber(((gdjs.Level_324Code.GDCupObjects6.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Level_324Code.GDCupObjects6[0].getVariables()).get("Balls"))) - 1) * (gdjs.Level_324Code.GDBall_951Objects6[i].getHeight()), "linear", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("DropBall_Duration")), false);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_952Objects6.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_952Objects6[i].getBehavior("Tween").addObjectPositionTween("DropBall", (( gdjs.Level_324Code.GDCupObjects6.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects6[0].getCenterXInScene()), (( gdjs.Level_324Code.GDCupObjects6.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects6[0].getPointY("")) + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MaxBallsPerCup")) - (gdjs.RuntimeObject.getVariableNumber(((gdjs.Level_324Code.GDCupObjects6.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Level_324Code.GDCupObjects6[0].getVariables()).get("Balls"))) - 1) * (gdjs.Level_324Code.GDBall_952Objects6[i].getHeight()), "linear", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("DropBall_Duration")), false);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_954Objects6.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_954Objects6[i].getBehavior("Tween").addObjectPositionTween("DropBall", (( gdjs.Level_324Code.GDCupObjects6.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects6[0].getCenterXInScene()), (( gdjs.Level_324Code.GDCupObjects6.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects6[0].getPointY("")) + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MaxBallsPerCup")) - (gdjs.RuntimeObject.getVariableNumber(((gdjs.Level_324Code.GDCupObjects6.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Level_324Code.GDCupObjects6[0].getVariables()).get("Balls"))) - 1) * (gdjs.Level_324Code.GDBall_954Objects6[i].getHeight()), "linear", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("DropBall_Duration")), false);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_953Objects6.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_953Objects6[i].getBehavior("Tween").addObjectPositionTween("DropBall", (( gdjs.Level_324Code.GDCupObjects6.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects6[0].getCenterXInScene()), (( gdjs.Level_324Code.GDCupObjects6.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects6[0].getPointY("")) + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MaxBallsPerCup")) - (gdjs.RuntimeObject.getVariableNumber(((gdjs.Level_324Code.GDCupObjects6.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Level_324Code.GDCupObjects6[0].getVariables()).get("Balls"))) - 1) * (gdjs.Level_324Code.GDBall_953Objects6[i].getHeight()), "linear", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("DropBall_Duration")), false);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_955Objects6.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_955Objects6[i].getBehavior("Tween").addObjectPositionTween("DropBall", (( gdjs.Level_324Code.GDCupObjects6.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects6[0].getCenterXInScene()), (( gdjs.Level_324Code.GDCupObjects6.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects6[0].getPointY("")) + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MaxBallsPerCup")) - (gdjs.RuntimeObject.getVariableNumber(((gdjs.Level_324Code.GDCupObjects6.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Level_324Code.GDCupObjects6[0].getVariables()).get("Balls"))) - 1) * (gdjs.Level_324Code.GDBall_955Objects6[i].getHeight()), "linear", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("DropBall_Duration")), false);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_956Objects6.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_956Objects6[i].getBehavior("Tween").addObjectPositionTween("DropBall", (( gdjs.Level_324Code.GDCupObjects6.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects6[0].getCenterXInScene()), (( gdjs.Level_324Code.GDCupObjects6.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects6[0].getPointY("")) + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MaxBallsPerCup")) - (gdjs.RuntimeObject.getVariableNumber(((gdjs.Level_324Code.GDCupObjects6.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Level_324Code.GDCupObjects6[0].getVariables()).get("Balls"))) - 1) * (gdjs.Level_324Code.GDBall_956Objects6[i].getHeight()), "linear", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("DropBall_Duration")), false);
}
}{for(var i = 0, len = gdjs.Level_324Code.GDCupObjects6.length ;i < len;++i) {
    gdjs.Level_324Code.GDCupObjects6[i].returnVariable(gdjs.Level_324Code.GDCupObjects6[i].getVariables().get("Balls")).add(1);
}
}}
gdjs.Level_324Code.eventsList30 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Level_324Code.GDBall_951Objects5) asyncObjectsList.addObject("Ball_1", obj);
for (const obj of gdjs.Level_324Code.GDBall_952Objects5) asyncObjectsList.addObject("Ball_2", obj);
for (const obj of gdjs.Level_324Code.GDBall_953Objects5) asyncObjectsList.addObject("Ball_3", obj);
for (const obj of gdjs.Level_324Code.GDBall_954Objects5) asyncObjectsList.addObject("Ball_4", obj);
for (const obj of gdjs.Level_324Code.GDBall_955Objects5) asyncObjectsList.addObject("Ball_5", obj);
for (const obj of gdjs.Level_324Code.GDBall_956Objects5) asyncObjectsList.addObject("Ball_6", obj);
for (const obj of gdjs.Level_324Code.GDCupObjects5) asyncObjectsList.addObject("Cup", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MoveBall_Duration")) / 1000), (runtimeScene) => (gdjs.Level_324Code.asyncCallback11621716(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_324Code.eventsList31 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Level_324Code.GDCupObjects5, gdjs.Level_324Code.GDCupObjects6);


gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_324Code.GDCupObjects6.length;i<l;++i) {
    if ( gdjs.Level_324Code.GDCupObjects6[i].getVariableBoolean(gdjs.Level_324Code.GDCupObjects6[i].getVariables().get("StartingCup"), false) ) {
        gdjs.Level_324Code.condition0IsTrue_0.val = true;
        gdjs.Level_324Code.GDCupObjects6[k] = gdjs.Level_324Code.GDCupObjects6[i];
        ++k;
    }
}
gdjs.Level_324Code.GDCupObjects6.length = k;}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("MovesMade_Text"), gdjs.Level_324Code.GDMovesMade_95TextObjects6);
{runtimeScene.getVariables().get("MovesMade").add(1);
}{for(var i = 0, len = gdjs.Level_324Code.GDMovesMade_95TextObjects6.length ;i < len;++i) {
    gdjs.Level_324Code.GDMovesMade_95TextObjects6[i].setString("Moves: " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MovesMade"))));
}
}}

}


{



}


{


{
gdjs.copyArray(gdjs.Level_324Code.GDBall_951Objects4, gdjs.Level_324Code.GDBall_951Objects5);

gdjs.copyArray(gdjs.Level_324Code.GDBall_952Objects4, gdjs.Level_324Code.GDBall_952Objects5);

gdjs.copyArray(gdjs.Level_324Code.GDBall_953Objects4, gdjs.Level_324Code.GDBall_953Objects5);

gdjs.copyArray(gdjs.Level_324Code.GDBall_954Objects4, gdjs.Level_324Code.GDBall_954Objects5);

gdjs.copyArray(gdjs.Level_324Code.GDBall_955Objects4, gdjs.Level_324Code.GDBall_955Objects5);

gdjs.copyArray(gdjs.Level_324Code.GDBall_956Objects4, gdjs.Level_324Code.GDBall_956Objects5);

/* Reuse gdjs.Level_324Code.GDCupObjects5 */
{for(var i = 0, len = gdjs.Level_324Code.GDBall_951Objects5.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_951Objects5[i].getBehavior("Tween").addObjectPositionTween("MoveBall", (( gdjs.Level_324Code.GDCupObjects5.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects5[0].getCenterXInScene()), (( gdjs.Level_324Code.GDCupObjects5.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects5[0].getPointY("")) - (1.5 * (gdjs.Level_324Code.GDBall_951Objects5[i].getHeight())), "linear", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MoveBall_Duration")), false);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_952Objects5.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_952Objects5[i].getBehavior("Tween").addObjectPositionTween("MoveBall", (( gdjs.Level_324Code.GDCupObjects5.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects5[0].getCenterXInScene()), (( gdjs.Level_324Code.GDCupObjects5.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects5[0].getPointY("")) - (1.5 * (gdjs.Level_324Code.GDBall_952Objects5[i].getHeight())), "linear", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MoveBall_Duration")), false);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_954Objects5.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_954Objects5[i].getBehavior("Tween").addObjectPositionTween("MoveBall", (( gdjs.Level_324Code.GDCupObjects5.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects5[0].getCenterXInScene()), (( gdjs.Level_324Code.GDCupObjects5.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects5[0].getPointY("")) - (1.5 * (gdjs.Level_324Code.GDBall_954Objects5[i].getHeight())), "linear", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MoveBall_Duration")), false);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_953Objects5.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_953Objects5[i].getBehavior("Tween").addObjectPositionTween("MoveBall", (( gdjs.Level_324Code.GDCupObjects5.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects5[0].getCenterXInScene()), (( gdjs.Level_324Code.GDCupObjects5.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects5[0].getPointY("")) - (1.5 * (gdjs.Level_324Code.GDBall_953Objects5[i].getHeight())), "linear", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MoveBall_Duration")), false);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_955Objects5.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_955Objects5[i].getBehavior("Tween").addObjectPositionTween("MoveBall", (( gdjs.Level_324Code.GDCupObjects5.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects5[0].getCenterXInScene()), (( gdjs.Level_324Code.GDCupObjects5.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects5[0].getPointY("")) - (1.5 * (gdjs.Level_324Code.GDBall_955Objects5[i].getHeight())), "linear", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MoveBall_Duration")), false);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_956Objects5.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_956Objects5[i].getBehavior("Tween").addObjectPositionTween("MoveBall", (( gdjs.Level_324Code.GDCupObjects5.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects5[0].getCenterXInScene()), (( gdjs.Level_324Code.GDCupObjects5.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects5[0].getPointY("")) - (1.5 * (gdjs.Level_324Code.GDBall_956Objects5[i].getHeight())), "linear", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MoveBall_Duration")), false);
}
}{gdjs.deviceVibration.startVibration(25);
}
{ //Subevents
gdjs.Level_324Code.eventsList30(runtimeScene);} //End of subevents
}

}


};gdjs.Level_324Code.eventsList32 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Cup"), gdjs.Level_324Code.GDCupObjects5);

gdjs.Level_324Code.condition0IsTrue_0.val = false;
gdjs.Level_324Code.condition1IsTrue_0.val = false;
gdjs.Level_324Code.condition2IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getVariables().get("ValidDropLocation"), true);
}if ( gdjs.Level_324Code.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level_324Code.GDCupObjects5.length;i<l;++i) {
    if ( gdjs.Level_324Code.GDCupObjects5[i].getVariableBoolean(gdjs.Level_324Code.GDCupObjects5[i].getVariables().get("DropTarget"), true) ) {
        gdjs.Level_324Code.condition1IsTrue_0.val = true;
        gdjs.Level_324Code.GDCupObjects5[k] = gdjs.Level_324Code.GDCupObjects5[i];
        ++k;
    }
}
gdjs.Level_324Code.GDCupObjects5.length = k;}if ( gdjs.Level_324Code.condition1IsTrue_0.val ) {
{
gdjs.Level_324Code.condition2IsTrue_0.val = gdjs.evtTools.object.pickNearestObject(gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupObjects5Objects, 0, 0, false);
}}
}
if (gdjs.Level_324Code.condition2IsTrue_0.val) {

{ //Subevents
gdjs.Level_324Code.eventsList31(runtimeScene);} //End of subevents
}

}


};gdjs.Level_324Code.asyncCallback11621717 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Ball_1"), gdjs.Level_324Code.GDBall_951Objects5);

gdjs.copyArray(asyncObjectsList.getObjects("Ball_2"), gdjs.Level_324Code.GDBall_952Objects5);

gdjs.copyArray(asyncObjectsList.getObjects("Ball_3"), gdjs.Level_324Code.GDBall_953Objects5);

gdjs.copyArray(asyncObjectsList.getObjects("Ball_4"), gdjs.Level_324Code.GDBall_954Objects5);

gdjs.copyArray(asyncObjectsList.getObjects("Ball_5"), gdjs.Level_324Code.GDBall_955Objects5);

gdjs.copyArray(asyncObjectsList.getObjects("Ball_6"), gdjs.Level_324Code.GDBall_956Objects5);

gdjs.copyArray(asyncObjectsList.getObjects("Cup"), gdjs.Level_324Code.GDCupObjects5);

{for(var i = 0, len = gdjs.Level_324Code.GDBall_951Objects5.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_951Objects5[i].setLayer("Balls");
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_952Objects5.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_952Objects5[i].setLayer("Balls");
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_954Objects5.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_954Objects5[i].setLayer("Balls");
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_953Objects5.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_953Objects5[i].setLayer("Balls");
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_955Objects5.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_955Objects5[i].setLayer("Balls");
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_956Objects5.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_956Objects5[i].setLayer("Balls");
}
}{for(var i = 0, len = gdjs.Level_324Code.GDBall_951Objects5.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_951Objects5[i].getBehavior("Tween").addObjectPositionTween("DropBall", (( gdjs.Level_324Code.GDCupObjects5.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects5[0].getCenterXInScene()), (( gdjs.Level_324Code.GDCupObjects5.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects5[0].getPointY("")) + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MaxBallsPerCup")) - (gdjs.RuntimeObject.getVariableNumber(((gdjs.Level_324Code.GDCupObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Level_324Code.GDCupObjects5[0].getVariables()).get("Balls"))) - 1) * (gdjs.Level_324Code.GDBall_951Objects5[i].getHeight()), "linear", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("DropBall_Duration")), false);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_952Objects5.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_952Objects5[i].getBehavior("Tween").addObjectPositionTween("DropBall", (( gdjs.Level_324Code.GDCupObjects5.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects5[0].getCenterXInScene()), (( gdjs.Level_324Code.GDCupObjects5.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects5[0].getPointY("")) + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MaxBallsPerCup")) - (gdjs.RuntimeObject.getVariableNumber(((gdjs.Level_324Code.GDCupObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Level_324Code.GDCupObjects5[0].getVariables()).get("Balls"))) - 1) * (gdjs.Level_324Code.GDBall_952Objects5[i].getHeight()), "linear", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("DropBall_Duration")), false);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_954Objects5.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_954Objects5[i].getBehavior("Tween").addObjectPositionTween("DropBall", (( gdjs.Level_324Code.GDCupObjects5.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects5[0].getCenterXInScene()), (( gdjs.Level_324Code.GDCupObjects5.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects5[0].getPointY("")) + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MaxBallsPerCup")) - (gdjs.RuntimeObject.getVariableNumber(((gdjs.Level_324Code.GDCupObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Level_324Code.GDCupObjects5[0].getVariables()).get("Balls"))) - 1) * (gdjs.Level_324Code.GDBall_954Objects5[i].getHeight()), "linear", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("DropBall_Duration")), false);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_953Objects5.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_953Objects5[i].getBehavior("Tween").addObjectPositionTween("DropBall", (( gdjs.Level_324Code.GDCupObjects5.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects5[0].getCenterXInScene()), (( gdjs.Level_324Code.GDCupObjects5.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects5[0].getPointY("")) + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MaxBallsPerCup")) - (gdjs.RuntimeObject.getVariableNumber(((gdjs.Level_324Code.GDCupObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Level_324Code.GDCupObjects5[0].getVariables()).get("Balls"))) - 1) * (gdjs.Level_324Code.GDBall_953Objects5[i].getHeight()), "linear", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("DropBall_Duration")), false);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_955Objects5.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_955Objects5[i].getBehavior("Tween").addObjectPositionTween("DropBall", (( gdjs.Level_324Code.GDCupObjects5.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects5[0].getCenterXInScene()), (( gdjs.Level_324Code.GDCupObjects5.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects5[0].getPointY("")) + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MaxBallsPerCup")) - (gdjs.RuntimeObject.getVariableNumber(((gdjs.Level_324Code.GDCupObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Level_324Code.GDCupObjects5[0].getVariables()).get("Balls"))) - 1) * (gdjs.Level_324Code.GDBall_955Objects5[i].getHeight()), "linear", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("DropBall_Duration")), false);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_956Objects5.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_956Objects5[i].getBehavior("Tween").addObjectPositionTween("DropBall", (( gdjs.Level_324Code.GDCupObjects5.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects5[0].getCenterXInScene()), (( gdjs.Level_324Code.GDCupObjects5.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects5[0].getPointY("")) + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MaxBallsPerCup")) - (gdjs.RuntimeObject.getVariableNumber(((gdjs.Level_324Code.GDCupObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Level_324Code.GDCupObjects5[0].getVariables()).get("Balls"))) - 1) * (gdjs.Level_324Code.GDBall_956Objects5[i].getHeight()), "linear", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("DropBall_Duration")), false);
}
}{for(var i = 0, len = gdjs.Level_324Code.GDCupObjects5.length ;i < len;++i) {
    gdjs.Level_324Code.GDCupObjects5[i].returnVariable(gdjs.Level_324Code.GDCupObjects5[i].getVariables().get("Balls")).add(1);
}
}}
gdjs.Level_324Code.eventsList33 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Level_324Code.GDBall_951Objects4) asyncObjectsList.addObject("Ball_1", obj);
for (const obj of gdjs.Level_324Code.GDBall_952Objects4) asyncObjectsList.addObject("Ball_2", obj);
for (const obj of gdjs.Level_324Code.GDBall_953Objects4) asyncObjectsList.addObject("Ball_3", obj);
for (const obj of gdjs.Level_324Code.GDBall_954Objects4) asyncObjectsList.addObject("Ball_4", obj);
for (const obj of gdjs.Level_324Code.GDBall_955Objects4) asyncObjectsList.addObject("Ball_5", obj);
for (const obj of gdjs.Level_324Code.GDBall_956Objects4) asyncObjectsList.addObject("Ball_6", obj);
for (const obj of gdjs.Level_324Code.GDCupObjects4) asyncObjectsList.addObject("Cup", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MoveBall_Duration")) / 1000), (runtimeScene) => (gdjs.Level_324Code.asyncCallback11621717(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_324Code.eventsList34 = function(runtimeScene) {

{



}


{


{
/* Reuse gdjs.Level_324Code.GDBall_951Objects4 */
/* Reuse gdjs.Level_324Code.GDBall_952Objects4 */
/* Reuse gdjs.Level_324Code.GDBall_953Objects4 */
/* Reuse gdjs.Level_324Code.GDBall_954Objects4 */
/* Reuse gdjs.Level_324Code.GDBall_955Objects4 */
/* Reuse gdjs.Level_324Code.GDBall_956Objects4 */
/* Reuse gdjs.Level_324Code.GDCupObjects4 */
{for(var i = 0, len = gdjs.Level_324Code.GDBall_951Objects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_951Objects4[i].getBehavior("Tween").addObjectPositionTween("MoveBall", (( gdjs.Level_324Code.GDCupObjects4.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects4[0].getCenterXInScene()), (( gdjs.Level_324Code.GDCupObjects4.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects4[0].getPointY("")) - (1.5 * (gdjs.Level_324Code.GDBall_951Objects4[i].getHeight())), "linear", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MoveBall_Duration")), false);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_952Objects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_952Objects4[i].getBehavior("Tween").addObjectPositionTween("MoveBall", (( gdjs.Level_324Code.GDCupObjects4.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects4[0].getCenterXInScene()), (( gdjs.Level_324Code.GDCupObjects4.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects4[0].getPointY("")) - (1.5 * (gdjs.Level_324Code.GDBall_952Objects4[i].getHeight())), "linear", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MoveBall_Duration")), false);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_954Objects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_954Objects4[i].getBehavior("Tween").addObjectPositionTween("MoveBall", (( gdjs.Level_324Code.GDCupObjects4.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects4[0].getCenterXInScene()), (( gdjs.Level_324Code.GDCupObjects4.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects4[0].getPointY("")) - (1.5 * (gdjs.Level_324Code.GDBall_954Objects4[i].getHeight())), "linear", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MoveBall_Duration")), false);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_953Objects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_953Objects4[i].getBehavior("Tween").addObjectPositionTween("MoveBall", (( gdjs.Level_324Code.GDCupObjects4.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects4[0].getCenterXInScene()), (( gdjs.Level_324Code.GDCupObjects4.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects4[0].getPointY("")) - (1.5 * (gdjs.Level_324Code.GDBall_953Objects4[i].getHeight())), "linear", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MoveBall_Duration")), false);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_955Objects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_955Objects4[i].getBehavior("Tween").addObjectPositionTween("MoveBall", (( gdjs.Level_324Code.GDCupObjects4.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects4[0].getCenterXInScene()), (( gdjs.Level_324Code.GDCupObjects4.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects4[0].getPointY("")) - (1.5 * (gdjs.Level_324Code.GDBall_955Objects4[i].getHeight())), "linear", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MoveBall_Duration")), false);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_956Objects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_956Objects4[i].getBehavior("Tween").addObjectPositionTween("MoveBall", (( gdjs.Level_324Code.GDCupObjects4.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects4[0].getCenterXInScene()), (( gdjs.Level_324Code.GDCupObjects4.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects4[0].getPointY("")) - (1.5 * (gdjs.Level_324Code.GDBall_956Objects4[i].getHeight())), "linear", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MoveBall_Duration")), false);
}
}{gdjs.deviceVibration.startVibration(25);
}
{ //Subevents
gdjs.Level_324Code.eventsList33(runtimeScene);} //End of subevents
}

}


};gdjs.Level_324Code.eventsList35 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Cup"), gdjs.Level_324Code.GDCupObjects4);

gdjs.Level_324Code.condition0IsTrue_0.val = false;
gdjs.Level_324Code.condition1IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getVariables().get("ValidDropLocation"), false);
}if ( gdjs.Level_324Code.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level_324Code.GDCupObjects4.length;i<l;++i) {
    if ( gdjs.Level_324Code.GDCupObjects4[i].getVariableBoolean(gdjs.Level_324Code.GDCupObjects4[i].getVariables().get("StartingCup"), true) ) {
        gdjs.Level_324Code.condition1IsTrue_0.val = true;
        gdjs.Level_324Code.GDCupObjects4[k] = gdjs.Level_324Code.GDCupObjects4[i];
        ++k;
    }
}
gdjs.Level_324Code.GDCupObjects4.length = k;}}
if (gdjs.Level_324Code.condition1IsTrue_0.val) {

{ //Subevents
gdjs.Level_324Code.eventsList34(runtimeScene);} //End of subevents
}

}


};gdjs.Level_324Code.eventsList36 = function(runtimeScene) {

{


gdjs.Level_324Code.eventsList29(runtimeScene);
}


{


gdjs.Level_324Code.eventsList32(runtimeScene);
}


{


gdjs.Level_324Code.eventsList35(runtimeScene);
}


};gdjs.Level_324Code.eventsList37 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("Ball_1"), gdjs.Level_324Code.GDBall_951Objects4);
gdjs.copyArray(runtimeScene.getObjects("Ball_2"), gdjs.Level_324Code.GDBall_952Objects4);
gdjs.copyArray(runtimeScene.getObjects("Ball_3"), gdjs.Level_324Code.GDBall_953Objects4);
gdjs.copyArray(runtimeScene.getObjects("Ball_4"), gdjs.Level_324Code.GDBall_954Objects4);
gdjs.copyArray(runtimeScene.getObjects("Ball_5"), gdjs.Level_324Code.GDBall_955Objects4);
gdjs.copyArray(runtimeScene.getObjects("Ball_6"), gdjs.Level_324Code.GDBall_956Objects4);
{for(var i = 0, len = gdjs.Level_324Code.GDBall_951Objects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_951Objects4[i].setVariableBoolean(gdjs.Level_324Code.GDBall_951Objects4[i].getVariables().get("PickedUp"), false);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_952Objects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_952Objects4[i].setVariableBoolean(gdjs.Level_324Code.GDBall_952Objects4[i].getVariables().get("PickedUp"), false);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_954Objects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_954Objects4[i].setVariableBoolean(gdjs.Level_324Code.GDBall_954Objects4[i].getVariables().get("PickedUp"), false);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_953Objects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_953Objects4[i].setVariableBoolean(gdjs.Level_324Code.GDBall_953Objects4[i].getVariables().get("PickedUp"), false);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_955Objects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_955Objects4[i].setVariableBoolean(gdjs.Level_324Code.GDBall_955Objects4[i].getVariables().get("PickedUp"), false);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_956Objects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_956Objects4[i].setVariableBoolean(gdjs.Level_324Code.GDBall_956Objects4[i].getVariables().get("PickedUp"), false);
}
}}

}


};gdjs.Level_324Code.asyncCallback11665788 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\audio - BLLTImpt Hit Marker 07.aac", false, 40, gdjs.randomFloatInRange(0.9, 1.1));
}{gdjs.deviceVibration.startVibration(25);
}{runtimeScene.getVariables().get("GameState").setString("CheckIfComplete");
}}
gdjs.Level_324Code.eventsList38 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait((gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MoveBall_Duration")) + gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("DropBall_Duration"))) / 1000), (runtimeScene) => (gdjs.Level_324Code.asyncCallback11665788(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_324Code.eventsList39 = function(runtimeScene) {

{


gdjs.Level_324Code.eventsList37(runtimeScene);
}


{


{

{ //Subevents
gdjs.Level_324Code.eventsList38(runtimeScene);} //End of subevents
}

}


};gdjs.Level_324Code.eventsList40 = function(runtimeScene) {

{


gdjs.Level_324Code.eventsList27(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("Ball_1"), gdjs.Level_324Code.GDBall_951Objects4);
gdjs.copyArray(runtimeScene.getObjects("Ball_2"), gdjs.Level_324Code.GDBall_952Objects4);
gdjs.copyArray(runtimeScene.getObjects("Ball_3"), gdjs.Level_324Code.GDBall_953Objects4);
gdjs.copyArray(runtimeScene.getObjects("Ball_4"), gdjs.Level_324Code.GDBall_954Objects4);
gdjs.copyArray(runtimeScene.getObjects("Ball_5"), gdjs.Level_324Code.GDBall_955Objects4);
gdjs.copyArray(runtimeScene.getObjects("Ball_6"), gdjs.Level_324Code.GDBall_956Objects4);

gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_324Code.GDBall_951Objects4.length;i<l;++i) {
    if ( gdjs.Level_324Code.GDBall_951Objects4[i].getVariableBoolean(gdjs.Level_324Code.GDBall_951Objects4[i].getVariables().get("PickedUp"), true) ) {
        gdjs.Level_324Code.condition0IsTrue_0.val = true;
        gdjs.Level_324Code.GDBall_951Objects4[k] = gdjs.Level_324Code.GDBall_951Objects4[i];
        ++k;
    }
}
gdjs.Level_324Code.GDBall_951Objects4.length = k;for(var i = 0, k = 0, l = gdjs.Level_324Code.GDBall_952Objects4.length;i<l;++i) {
    if ( gdjs.Level_324Code.GDBall_952Objects4[i].getVariableBoolean(gdjs.Level_324Code.GDBall_952Objects4[i].getVariables().get("PickedUp"), true) ) {
        gdjs.Level_324Code.condition0IsTrue_0.val = true;
        gdjs.Level_324Code.GDBall_952Objects4[k] = gdjs.Level_324Code.GDBall_952Objects4[i];
        ++k;
    }
}
gdjs.Level_324Code.GDBall_952Objects4.length = k;for(var i = 0, k = 0, l = gdjs.Level_324Code.GDBall_954Objects4.length;i<l;++i) {
    if ( gdjs.Level_324Code.GDBall_954Objects4[i].getVariableBoolean(gdjs.Level_324Code.GDBall_954Objects4[i].getVariables().get("PickedUp"), true) ) {
        gdjs.Level_324Code.condition0IsTrue_0.val = true;
        gdjs.Level_324Code.GDBall_954Objects4[k] = gdjs.Level_324Code.GDBall_954Objects4[i];
        ++k;
    }
}
gdjs.Level_324Code.GDBall_954Objects4.length = k;for(var i = 0, k = 0, l = gdjs.Level_324Code.GDBall_953Objects4.length;i<l;++i) {
    if ( gdjs.Level_324Code.GDBall_953Objects4[i].getVariableBoolean(gdjs.Level_324Code.GDBall_953Objects4[i].getVariables().get("PickedUp"), true) ) {
        gdjs.Level_324Code.condition0IsTrue_0.val = true;
        gdjs.Level_324Code.GDBall_953Objects4[k] = gdjs.Level_324Code.GDBall_953Objects4[i];
        ++k;
    }
}
gdjs.Level_324Code.GDBall_953Objects4.length = k;for(var i = 0, k = 0, l = gdjs.Level_324Code.GDBall_955Objects4.length;i<l;++i) {
    if ( gdjs.Level_324Code.GDBall_955Objects4[i].getVariableBoolean(gdjs.Level_324Code.GDBall_955Objects4[i].getVariables().get("PickedUp"), true) ) {
        gdjs.Level_324Code.condition0IsTrue_0.val = true;
        gdjs.Level_324Code.GDBall_955Objects4[k] = gdjs.Level_324Code.GDBall_955Objects4[i];
        ++k;
    }
}
gdjs.Level_324Code.GDBall_955Objects4.length = k;for(var i = 0, k = 0, l = gdjs.Level_324Code.GDBall_956Objects4.length;i<l;++i) {
    if ( gdjs.Level_324Code.GDBall_956Objects4[i].getVariableBoolean(gdjs.Level_324Code.GDBall_956Objects4[i].getVariables().get("PickedUp"), true) ) {
        gdjs.Level_324Code.condition0IsTrue_0.val = true;
        gdjs.Level_324Code.GDBall_956Objects4[k] = gdjs.Level_324Code.GDBall_956Objects4[i];
        ++k;
    }
}
gdjs.Level_324Code.GDBall_956Objects4.length = k;}if (gdjs.Level_324Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Level_324Code.eventsList36(runtimeScene);} //End of subevents
}

}


{


gdjs.Level_324Code.eventsList39(runtimeScene);
}


};gdjs.Level_324Code.eventsList41 = function(runtimeScene) {

{


gdjs.Level_324Code.condition0IsTrue_0.val = false;
gdjs.Level_324Code.condition1IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("GameState")) == "DroppingBall";
}if ( gdjs.Level_324Code.condition0IsTrue_0.val ) {
{
{gdjs.Level_324Code.conditionTrue_1 = gdjs.Level_324Code.condition1IsTrue_0;
gdjs.Level_324Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11656212);
}
}}
if (gdjs.Level_324Code.condition1IsTrue_0.val) {

{ //Subevents
gdjs.Level_324Code.eventsList40(runtimeScene);} //End of subevents
}

}


};gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDBall_95951Objects6Objects = Hashtable.newFrom({"Ball_1": gdjs.Level_324Code.GDBall_951Objects6});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupObjects6Objects = Hashtable.newFrom({"Cup": gdjs.Level_324Code.GDCupObjects6});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDBall_95951Objects6Objects = Hashtable.newFrom({"Ball_1": gdjs.Level_324Code.GDBall_951Objects6});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGlassBreaking_9595ParticlesObjects7Objects = Hashtable.newFrom({"GlassBreaking_Particles": gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects7});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGlassBreaking_9595ParticlesObjects7Objects = Hashtable.newFrom({"GlassBreaking_Particles": gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects7});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGlassBreaking_9595ParticlesObjects7Objects = Hashtable.newFrom({"GlassBreaking_Particles": gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects7});
gdjs.Level_324Code.eventsList42 = function(runtimeScene) {

{



}


{


{
{gdjs.evtsExt__CameraShake__CameraShake.func(runtimeScene, 20, 20, "", 0, 0.4, 0, 0, 0.10, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{



}


{


{
gdjs.copyArray(gdjs.Level_324Code.GDCupObjects6, gdjs.Level_324Code.GDCupObjects7);

gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects7.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGlassBreaking_9595ParticlesObjects7Objects, (( gdjs.Level_324Code.GDCupObjects7.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects7[0].getCenterXInScene()), (( gdjs.Level_324Code.GDCupObjects7.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects7[0].getPointY("")) + (( gdjs.Level_324Code.GDCupObjects7.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects7[0].getHeight()) * 0.25, "FrontCups");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGlassBreaking_9595ParticlesObjects7Objects, (( gdjs.Level_324Code.GDCupObjects7.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects7[0].getCenterXInScene()), (( gdjs.Level_324Code.GDCupObjects7.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects7[0].getPointY("")) + (( gdjs.Level_324Code.GDCupObjects7.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects7[0].getHeight()) * 0.50, "FrontCups");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGlassBreaking_9595ParticlesObjects7Objects, (( gdjs.Level_324Code.GDCupObjects7.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects7[0].getCenterXInScene()), (( gdjs.Level_324Code.GDCupObjects7.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects7[0].getPointY("")) + (( gdjs.Level_324Code.GDCupObjects7.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects7[0].getHeight()) * 0.75, "FrontCups");
}{for(var i = 0, len = gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects7.length ;i < len;++i) {
    gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects7[i].setZOrder((( gdjs.Level_324Code.GDCupObjects7.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects7[0].getZOrder()) + 1);
}
}}

}


};gdjs.Level_324Code.asyncCallback11583260 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\audio - Glass,Bottle,Break,Smash,Messy.aac", false, 20, 1);
}}
gdjs.Level_324Code.eventsList43 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.100), (runtimeScene) => (gdjs.Level_324Code.asyncCallback11583260(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_324Code.eventsList44 = function(runtimeScene) {

{



}


{


{
{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\Generdyn - 13.aac", false, 50, 1.3);
}
{ //Subevents
gdjs.Level_324Code.eventsList43(runtimeScene);} //End of subevents
}

}


{



}


{


gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
{gdjs.Level_324Code.conditionTrue_1 = gdjs.Level_324Code.condition0IsTrue_0;
gdjs.Level_324Code.conditionTrue_1.val = (gdjs.randomInRange(1, 2) == 1);
}
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\audio - Hit Rock Debris RBD 02.aac", false, 50, 1);
}}

}


{


gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
{gdjs.Level_324Code.conditionTrue_1 = gdjs.Level_324Code.condition0IsTrue_0;
gdjs.Level_324Code.conditionTrue_1.val = (gdjs.randomInRange(1, 2) == 1);
}
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\audio - Glass,Shards,Smash,Medium Impact,Lots of Large Shards.aac", false, 20, 1);
}}

}


};gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDBall_95951Objects7ObjectsGDgdjs_46Level_95324Code_46GDBall_95952Objects7ObjectsGDgdjs_46Level_95324Code_46GDBall_95954Objects7ObjectsGDgdjs_46Level_95324Code_46GDBall_95953Objects7ObjectsGDgdjs_46Level_95324Code_46GDBall_95955Objects7ObjectsGDgdjs_46Level_95324Code_46GDBall_95956Objects7Objects = Hashtable.newFrom({"Ball_1": gdjs.Level_324Code.GDBall_951Objects7, "Ball_2": gdjs.Level_324Code.GDBall_952Objects7, "Ball_4": gdjs.Level_324Code.GDBall_954Objects7, "Ball_3": gdjs.Level_324Code.GDBall_953Objects7, "Ball_5": gdjs.Level_324Code.GDBall_955Objects7, "Ball_6": gdjs.Level_324Code.GDBall_956Objects7});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupObjects7Objects = Hashtable.newFrom({"Cup": gdjs.Level_324Code.GDCupObjects7});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupFrontObjects6Objects = Hashtable.newFrom({"CupFront": gdjs.Level_324Code.GDCupFrontObjects6});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupObjects6Objects = Hashtable.newFrom({"Cup": gdjs.Level_324Code.GDCupObjects6});
gdjs.Level_324Code.eventsList45 = function(runtimeScene) {

{


{
/* Reuse gdjs.Level_324Code.GDCupObjects6 */
{for(var i = 0, len = gdjs.Level_324Code.GDCupObjects6.length ;i < len;++i) {
    gdjs.Level_324Code.GDCupObjects6[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.Level_324Code.eventsList46 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Level_324Code.GDBall_951Objects6, gdjs.Level_324Code.GDBall_951Objects7);

gdjs.copyArray(runtimeScene.getObjects("Ball_2"), gdjs.Level_324Code.GDBall_952Objects7);
gdjs.copyArray(runtimeScene.getObjects("Ball_3"), gdjs.Level_324Code.GDBall_953Objects7);
gdjs.copyArray(runtimeScene.getObjects("Ball_4"), gdjs.Level_324Code.GDBall_954Objects7);
gdjs.copyArray(runtimeScene.getObjects("Ball_5"), gdjs.Level_324Code.GDBall_955Objects7);
gdjs.copyArray(runtimeScene.getObjects("Ball_6"), gdjs.Level_324Code.GDBall_956Objects7);
gdjs.copyArray(gdjs.Level_324Code.GDCupObjects6, gdjs.Level_324Code.GDCupObjects7);


gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDBall_95951Objects7ObjectsGDgdjs_46Level_95324Code_46GDBall_95952Objects7ObjectsGDgdjs_46Level_95324Code_46GDBall_95954Objects7ObjectsGDgdjs_46Level_95324Code_46GDBall_95953Objects7ObjectsGDgdjs_46Level_95324Code_46GDBall_95955Objects7ObjectsGDgdjs_46Level_95324Code_46GDBall_95956Objects7Objects, gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupObjects7Objects, false, runtimeScene, false);
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_324Code.GDBall_951Objects7 */
/* Reuse gdjs.Level_324Code.GDBall_952Objects7 */
/* Reuse gdjs.Level_324Code.GDBall_953Objects7 */
/* Reuse gdjs.Level_324Code.GDBall_954Objects7 */
/* Reuse gdjs.Level_324Code.GDBall_955Objects7 */
/* Reuse gdjs.Level_324Code.GDBall_956Objects7 */
{for(var i = 0, len = gdjs.Level_324Code.GDBall_951Objects7.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_951Objects7[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_952Objects7.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_952Objects7[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_954Objects7.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_954Objects7[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_953Objects7.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_953Objects7[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_955Objects7.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_955Objects7[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_956Objects7.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_956Objects7[i].deleteFromScene(runtimeScene);
}
}}

}


{

/* Reuse gdjs.Level_324Code.GDCupObjects6 */
gdjs.copyArray(runtimeScene.getObjects("CupFront"), gdjs.Level_324Code.GDCupFrontObjects6);

gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtsExt__Sticker__IsStuck.func(runtimeScene, gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupFrontObjects6Objects, "Sticker", gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupObjects6Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_324Code.GDCupFrontObjects6 */
{for(var i = 0, len = gdjs.Level_324Code.GDCupFrontObjects6.length ;i < len;++i) {
    gdjs.Level_324Code.GDCupFrontObjects6[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.Level_324Code.eventsList45(runtimeScene);} //End of subevents
}

}


};gdjs.Level_324Code.eventsList47 = function(runtimeScene) {

{



}


{


gdjs.Level_324Code.eventsList42(runtimeScene);
}


{


gdjs.Level_324Code.eventsList44(runtimeScene);
}


{


gdjs.Level_324Code.eventsList46(runtimeScene);
}


};gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDBall_95952Objects6Objects = Hashtable.newFrom({"Ball_2": gdjs.Level_324Code.GDBall_952Objects6});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupObjects6Objects = Hashtable.newFrom({"Cup": gdjs.Level_324Code.GDCupObjects6});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDBall_95952Objects6Objects = Hashtable.newFrom({"Ball_2": gdjs.Level_324Code.GDBall_952Objects6});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGlassBreaking_9595ParticlesObjects7Objects = Hashtable.newFrom({"GlassBreaking_Particles": gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects7});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGlassBreaking_9595ParticlesObjects7Objects = Hashtable.newFrom({"GlassBreaking_Particles": gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects7});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGlassBreaking_9595ParticlesObjects7Objects = Hashtable.newFrom({"GlassBreaking_Particles": gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects7});
gdjs.Level_324Code.eventsList48 = function(runtimeScene) {

{



}


{


{
{gdjs.evtsExt__CameraShake__CameraShake.func(runtimeScene, 20, 20, "", 0, 0.4, 0, 0, 0.10, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{



}


{


{
gdjs.copyArray(gdjs.Level_324Code.GDCupObjects6, gdjs.Level_324Code.GDCupObjects7);

gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects7.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGlassBreaking_9595ParticlesObjects7Objects, (( gdjs.Level_324Code.GDCupObjects7.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects7[0].getCenterXInScene()), (( gdjs.Level_324Code.GDCupObjects7.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects7[0].getPointY("")) + (( gdjs.Level_324Code.GDCupObjects7.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects7[0].getHeight()) * 0.25, "FrontCups");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGlassBreaking_9595ParticlesObjects7Objects, (( gdjs.Level_324Code.GDCupObjects7.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects7[0].getCenterXInScene()), (( gdjs.Level_324Code.GDCupObjects7.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects7[0].getPointY("")) + (( gdjs.Level_324Code.GDCupObjects7.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects7[0].getHeight()) * 0.50, "FrontCups");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGlassBreaking_9595ParticlesObjects7Objects, (( gdjs.Level_324Code.GDCupObjects7.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects7[0].getCenterXInScene()), (( gdjs.Level_324Code.GDCupObjects7.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects7[0].getPointY("")) + (( gdjs.Level_324Code.GDCupObjects7.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects7[0].getHeight()) * 0.75, "FrontCups");
}{for(var i = 0, len = gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects7.length ;i < len;++i) {
    gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects7[i].setZOrder((( gdjs.Level_324Code.GDCupObjects7.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects7[0].getZOrder()) + 1);
}
}}

}


};gdjs.Level_324Code.asyncCallback11583261 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\audio - Glass,Bottle,Break,Smash,Messy.aac", false, 20, 1);
}}
gdjs.Level_324Code.eventsList49 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.100), (runtimeScene) => (gdjs.Level_324Code.asyncCallback11583261(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_324Code.eventsList50 = function(runtimeScene) {

{



}


{


{
{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\Generdyn - 13.aac", false, 50, 1.3);
}
{ //Subevents
gdjs.Level_324Code.eventsList49(runtimeScene);} //End of subevents
}

}


{



}


{


gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
{gdjs.Level_324Code.conditionTrue_1 = gdjs.Level_324Code.condition0IsTrue_0;
gdjs.Level_324Code.conditionTrue_1.val = (gdjs.randomInRange(1, 2) == 1);
}
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\audio - Hit Rock Debris RBD 02.aac", false, 50, 1);
}}

}


{


gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
{gdjs.Level_324Code.conditionTrue_1 = gdjs.Level_324Code.condition0IsTrue_0;
gdjs.Level_324Code.conditionTrue_1.val = (gdjs.randomInRange(1, 2) == 1);
}
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\audio - Glass,Shards,Smash,Medium Impact,Lots of Large Shards.aac", false, 20, 1);
}}

}


};gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDBall_95951Objects7ObjectsGDgdjs_46Level_95324Code_46GDBall_95952Objects7ObjectsGDgdjs_46Level_95324Code_46GDBall_95954Objects7ObjectsGDgdjs_46Level_95324Code_46GDBall_95953Objects7ObjectsGDgdjs_46Level_95324Code_46GDBall_95955Objects7ObjectsGDgdjs_46Level_95324Code_46GDBall_95956Objects7Objects = Hashtable.newFrom({"Ball_1": gdjs.Level_324Code.GDBall_951Objects7, "Ball_2": gdjs.Level_324Code.GDBall_952Objects7, "Ball_4": gdjs.Level_324Code.GDBall_954Objects7, "Ball_3": gdjs.Level_324Code.GDBall_953Objects7, "Ball_5": gdjs.Level_324Code.GDBall_955Objects7, "Ball_6": gdjs.Level_324Code.GDBall_956Objects7});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupObjects7Objects = Hashtable.newFrom({"Cup": gdjs.Level_324Code.GDCupObjects7});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupFrontObjects6Objects = Hashtable.newFrom({"CupFront": gdjs.Level_324Code.GDCupFrontObjects6});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupObjects6Objects = Hashtable.newFrom({"Cup": gdjs.Level_324Code.GDCupObjects6});
gdjs.Level_324Code.eventsList51 = function(runtimeScene) {

{


{
/* Reuse gdjs.Level_324Code.GDCupObjects6 */
{for(var i = 0, len = gdjs.Level_324Code.GDCupObjects6.length ;i < len;++i) {
    gdjs.Level_324Code.GDCupObjects6[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.Level_324Code.eventsList52 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Ball_1"), gdjs.Level_324Code.GDBall_951Objects7);
gdjs.copyArray(gdjs.Level_324Code.GDBall_952Objects6, gdjs.Level_324Code.GDBall_952Objects7);

gdjs.copyArray(runtimeScene.getObjects("Ball_3"), gdjs.Level_324Code.GDBall_953Objects7);
gdjs.copyArray(runtimeScene.getObjects("Ball_4"), gdjs.Level_324Code.GDBall_954Objects7);
gdjs.copyArray(runtimeScene.getObjects("Ball_5"), gdjs.Level_324Code.GDBall_955Objects7);
gdjs.copyArray(runtimeScene.getObjects("Ball_6"), gdjs.Level_324Code.GDBall_956Objects7);
gdjs.copyArray(gdjs.Level_324Code.GDCupObjects6, gdjs.Level_324Code.GDCupObjects7);


gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDBall_95951Objects7ObjectsGDgdjs_46Level_95324Code_46GDBall_95952Objects7ObjectsGDgdjs_46Level_95324Code_46GDBall_95954Objects7ObjectsGDgdjs_46Level_95324Code_46GDBall_95953Objects7ObjectsGDgdjs_46Level_95324Code_46GDBall_95955Objects7ObjectsGDgdjs_46Level_95324Code_46GDBall_95956Objects7Objects, gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupObjects7Objects, false, runtimeScene, false);
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_324Code.GDBall_951Objects7 */
/* Reuse gdjs.Level_324Code.GDBall_952Objects7 */
/* Reuse gdjs.Level_324Code.GDBall_953Objects7 */
/* Reuse gdjs.Level_324Code.GDBall_954Objects7 */
/* Reuse gdjs.Level_324Code.GDBall_955Objects7 */
/* Reuse gdjs.Level_324Code.GDBall_956Objects7 */
{for(var i = 0, len = gdjs.Level_324Code.GDBall_951Objects7.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_951Objects7[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_952Objects7.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_952Objects7[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_954Objects7.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_954Objects7[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_953Objects7.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_953Objects7[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_955Objects7.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_955Objects7[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_956Objects7.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_956Objects7[i].deleteFromScene(runtimeScene);
}
}}

}


{

/* Reuse gdjs.Level_324Code.GDCupObjects6 */
gdjs.copyArray(runtimeScene.getObjects("CupFront"), gdjs.Level_324Code.GDCupFrontObjects6);

gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtsExt__Sticker__IsStuck.func(runtimeScene, gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupFrontObjects6Objects, "Sticker", gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupObjects6Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_324Code.GDCupFrontObjects6 */
{for(var i = 0, len = gdjs.Level_324Code.GDCupFrontObjects6.length ;i < len;++i) {
    gdjs.Level_324Code.GDCupFrontObjects6[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.Level_324Code.eventsList51(runtimeScene);} //End of subevents
}

}


};gdjs.Level_324Code.eventsList53 = function(runtimeScene) {

{



}


{


gdjs.Level_324Code.eventsList48(runtimeScene);
}


{


gdjs.Level_324Code.eventsList50(runtimeScene);
}


{


gdjs.Level_324Code.eventsList52(runtimeScene);
}


};gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDBall_95953Objects6Objects = Hashtable.newFrom({"Ball_3": gdjs.Level_324Code.GDBall_953Objects6});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupObjects6Objects = Hashtable.newFrom({"Cup": gdjs.Level_324Code.GDCupObjects6});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDBall_95953Objects6Objects = Hashtable.newFrom({"Ball_3": gdjs.Level_324Code.GDBall_953Objects6});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGlassBreaking_9595ParticlesObjects7Objects = Hashtable.newFrom({"GlassBreaking_Particles": gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects7});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGlassBreaking_9595ParticlesObjects7Objects = Hashtable.newFrom({"GlassBreaking_Particles": gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects7});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGlassBreaking_9595ParticlesObjects7Objects = Hashtable.newFrom({"GlassBreaking_Particles": gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects7});
gdjs.Level_324Code.eventsList54 = function(runtimeScene) {

{



}


{


{
{gdjs.evtsExt__CameraShake__CameraShake.func(runtimeScene, 20, 20, "", 0, 0.4, 0, 0, 0.10, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{



}


{


{
gdjs.copyArray(gdjs.Level_324Code.GDCupObjects6, gdjs.Level_324Code.GDCupObjects7);

gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects7.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGlassBreaking_9595ParticlesObjects7Objects, (( gdjs.Level_324Code.GDCupObjects7.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects7[0].getCenterXInScene()), (( gdjs.Level_324Code.GDCupObjects7.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects7[0].getPointY("")) + (( gdjs.Level_324Code.GDCupObjects7.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects7[0].getHeight()) * 0.25, "FrontCups");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGlassBreaking_9595ParticlesObjects7Objects, (( gdjs.Level_324Code.GDCupObjects7.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects7[0].getCenterXInScene()), (( gdjs.Level_324Code.GDCupObjects7.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects7[0].getPointY("")) + (( gdjs.Level_324Code.GDCupObjects7.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects7[0].getHeight()) * 0.50, "FrontCups");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGlassBreaking_9595ParticlesObjects7Objects, (( gdjs.Level_324Code.GDCupObjects7.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects7[0].getCenterXInScene()), (( gdjs.Level_324Code.GDCupObjects7.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects7[0].getPointY("")) + (( gdjs.Level_324Code.GDCupObjects7.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects7[0].getHeight()) * 0.75, "FrontCups");
}{for(var i = 0, len = gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects7.length ;i < len;++i) {
    gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects7[i].setZOrder((( gdjs.Level_324Code.GDCupObjects7.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects7[0].getZOrder()) + 1);
}
}}

}


};gdjs.Level_324Code.asyncCallback11583262 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\audio - Glass,Bottle,Break,Smash,Messy.aac", false, 20, 1);
}}
gdjs.Level_324Code.eventsList55 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.100), (runtimeScene) => (gdjs.Level_324Code.asyncCallback11583262(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_324Code.eventsList56 = function(runtimeScene) {

{



}


{


{
{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\Generdyn - 13.aac", false, 50, 1.3);
}
{ //Subevents
gdjs.Level_324Code.eventsList55(runtimeScene);} //End of subevents
}

}


{



}


{


gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
{gdjs.Level_324Code.conditionTrue_1 = gdjs.Level_324Code.condition0IsTrue_0;
gdjs.Level_324Code.conditionTrue_1.val = (gdjs.randomInRange(1, 2) == 1);
}
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\audio - Hit Rock Debris RBD 02.aac", false, 50, 1);
}}

}


{


gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
{gdjs.Level_324Code.conditionTrue_1 = gdjs.Level_324Code.condition0IsTrue_0;
gdjs.Level_324Code.conditionTrue_1.val = (gdjs.randomInRange(1, 2) == 1);
}
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\audio - Glass,Shards,Smash,Medium Impact,Lots of Large Shards.aac", false, 20, 1);
}}

}


};gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDBall_95951Objects7ObjectsGDgdjs_46Level_95324Code_46GDBall_95952Objects7ObjectsGDgdjs_46Level_95324Code_46GDBall_95954Objects7ObjectsGDgdjs_46Level_95324Code_46GDBall_95953Objects7ObjectsGDgdjs_46Level_95324Code_46GDBall_95955Objects7ObjectsGDgdjs_46Level_95324Code_46GDBall_95956Objects7Objects = Hashtable.newFrom({"Ball_1": gdjs.Level_324Code.GDBall_951Objects7, "Ball_2": gdjs.Level_324Code.GDBall_952Objects7, "Ball_4": gdjs.Level_324Code.GDBall_954Objects7, "Ball_3": gdjs.Level_324Code.GDBall_953Objects7, "Ball_5": gdjs.Level_324Code.GDBall_955Objects7, "Ball_6": gdjs.Level_324Code.GDBall_956Objects7});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupObjects7Objects = Hashtable.newFrom({"Cup": gdjs.Level_324Code.GDCupObjects7});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupFrontObjects6Objects = Hashtable.newFrom({"CupFront": gdjs.Level_324Code.GDCupFrontObjects6});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupObjects6Objects = Hashtable.newFrom({"Cup": gdjs.Level_324Code.GDCupObjects6});
gdjs.Level_324Code.eventsList57 = function(runtimeScene) {

{


{
/* Reuse gdjs.Level_324Code.GDCupObjects6 */
{for(var i = 0, len = gdjs.Level_324Code.GDCupObjects6.length ;i < len;++i) {
    gdjs.Level_324Code.GDCupObjects6[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.Level_324Code.eventsList58 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Ball_1"), gdjs.Level_324Code.GDBall_951Objects7);
gdjs.copyArray(runtimeScene.getObjects("Ball_2"), gdjs.Level_324Code.GDBall_952Objects7);
gdjs.copyArray(gdjs.Level_324Code.GDBall_953Objects6, gdjs.Level_324Code.GDBall_953Objects7);

gdjs.copyArray(runtimeScene.getObjects("Ball_4"), gdjs.Level_324Code.GDBall_954Objects7);
gdjs.copyArray(runtimeScene.getObjects("Ball_5"), gdjs.Level_324Code.GDBall_955Objects7);
gdjs.copyArray(runtimeScene.getObjects("Ball_6"), gdjs.Level_324Code.GDBall_956Objects7);
gdjs.copyArray(gdjs.Level_324Code.GDCupObjects6, gdjs.Level_324Code.GDCupObjects7);


gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDBall_95951Objects7ObjectsGDgdjs_46Level_95324Code_46GDBall_95952Objects7ObjectsGDgdjs_46Level_95324Code_46GDBall_95954Objects7ObjectsGDgdjs_46Level_95324Code_46GDBall_95953Objects7ObjectsGDgdjs_46Level_95324Code_46GDBall_95955Objects7ObjectsGDgdjs_46Level_95324Code_46GDBall_95956Objects7Objects, gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupObjects7Objects, false, runtimeScene, false);
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_324Code.GDBall_951Objects7 */
/* Reuse gdjs.Level_324Code.GDBall_952Objects7 */
/* Reuse gdjs.Level_324Code.GDBall_953Objects7 */
/* Reuse gdjs.Level_324Code.GDBall_954Objects7 */
/* Reuse gdjs.Level_324Code.GDBall_955Objects7 */
/* Reuse gdjs.Level_324Code.GDBall_956Objects7 */
{for(var i = 0, len = gdjs.Level_324Code.GDBall_951Objects7.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_951Objects7[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_952Objects7.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_952Objects7[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_954Objects7.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_954Objects7[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_953Objects7.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_953Objects7[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_955Objects7.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_955Objects7[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_956Objects7.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_956Objects7[i].deleteFromScene(runtimeScene);
}
}}

}


{

/* Reuse gdjs.Level_324Code.GDCupObjects6 */
gdjs.copyArray(runtimeScene.getObjects("CupFront"), gdjs.Level_324Code.GDCupFrontObjects6);

gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtsExt__Sticker__IsStuck.func(runtimeScene, gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupFrontObjects6Objects, "Sticker", gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupObjects6Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_324Code.GDCupFrontObjects6 */
{for(var i = 0, len = gdjs.Level_324Code.GDCupFrontObjects6.length ;i < len;++i) {
    gdjs.Level_324Code.GDCupFrontObjects6[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.Level_324Code.eventsList57(runtimeScene);} //End of subevents
}

}


};gdjs.Level_324Code.eventsList59 = function(runtimeScene) {

{



}


{


gdjs.Level_324Code.eventsList54(runtimeScene);
}


{


gdjs.Level_324Code.eventsList56(runtimeScene);
}


{


gdjs.Level_324Code.eventsList58(runtimeScene);
}


};gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDBall_95954Objects6Objects = Hashtable.newFrom({"Ball_4": gdjs.Level_324Code.GDBall_954Objects6});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupObjects6Objects = Hashtable.newFrom({"Cup": gdjs.Level_324Code.GDCupObjects6});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDBall_95954Objects6Objects = Hashtable.newFrom({"Ball_4": gdjs.Level_324Code.GDBall_954Objects6});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGlassBreaking_9595ParticlesObjects7Objects = Hashtable.newFrom({"GlassBreaking_Particles": gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects7});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGlassBreaking_9595ParticlesObjects7Objects = Hashtable.newFrom({"GlassBreaking_Particles": gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects7});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGlassBreaking_9595ParticlesObjects7Objects = Hashtable.newFrom({"GlassBreaking_Particles": gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects7});
gdjs.Level_324Code.eventsList60 = function(runtimeScene) {

{



}


{


{
{gdjs.evtsExt__CameraShake__CameraShake.func(runtimeScene, 20, 20, "", 0, 0.4, 0, 0, 0.10, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{



}


{


{
gdjs.copyArray(gdjs.Level_324Code.GDCupObjects6, gdjs.Level_324Code.GDCupObjects7);

gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects7.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGlassBreaking_9595ParticlesObjects7Objects, (( gdjs.Level_324Code.GDCupObjects7.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects7[0].getCenterXInScene()), (( gdjs.Level_324Code.GDCupObjects7.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects7[0].getPointY("")) + (( gdjs.Level_324Code.GDCupObjects7.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects7[0].getHeight()) * 0.25, "FrontCups");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGlassBreaking_9595ParticlesObjects7Objects, (( gdjs.Level_324Code.GDCupObjects7.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects7[0].getCenterXInScene()), (( gdjs.Level_324Code.GDCupObjects7.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects7[0].getPointY("")) + (( gdjs.Level_324Code.GDCupObjects7.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects7[0].getHeight()) * 0.50, "FrontCups");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGlassBreaking_9595ParticlesObjects7Objects, (( gdjs.Level_324Code.GDCupObjects7.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects7[0].getCenterXInScene()), (( gdjs.Level_324Code.GDCupObjects7.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects7[0].getPointY("")) + (( gdjs.Level_324Code.GDCupObjects7.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects7[0].getHeight()) * 0.75, "FrontCups");
}{for(var i = 0, len = gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects7.length ;i < len;++i) {
    gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects7[i].setZOrder((( gdjs.Level_324Code.GDCupObjects7.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects7[0].getZOrder()) + 1);
}
}}

}


};gdjs.Level_324Code.asyncCallback11583263 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\audio - Glass,Bottle,Break,Smash,Messy.aac", false, 20, 1);
}}
gdjs.Level_324Code.eventsList61 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.100), (runtimeScene) => (gdjs.Level_324Code.asyncCallback11583263(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_324Code.eventsList62 = function(runtimeScene) {

{



}


{


{
{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\Generdyn - 13.aac", false, 50, 1.3);
}
{ //Subevents
gdjs.Level_324Code.eventsList61(runtimeScene);} //End of subevents
}

}


{



}


{


gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
{gdjs.Level_324Code.conditionTrue_1 = gdjs.Level_324Code.condition0IsTrue_0;
gdjs.Level_324Code.conditionTrue_1.val = (gdjs.randomInRange(1, 2) == 1);
}
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\audio - Hit Rock Debris RBD 02.aac", false, 50, 1);
}}

}


{


gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
{gdjs.Level_324Code.conditionTrue_1 = gdjs.Level_324Code.condition0IsTrue_0;
gdjs.Level_324Code.conditionTrue_1.val = (gdjs.randomInRange(1, 2) == 1);
}
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\audio - Glass,Shards,Smash,Medium Impact,Lots of Large Shards.aac", false, 20, 1);
}}

}


};gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDBall_95951Objects7ObjectsGDgdjs_46Level_95324Code_46GDBall_95952Objects7ObjectsGDgdjs_46Level_95324Code_46GDBall_95954Objects7ObjectsGDgdjs_46Level_95324Code_46GDBall_95953Objects7ObjectsGDgdjs_46Level_95324Code_46GDBall_95955Objects7ObjectsGDgdjs_46Level_95324Code_46GDBall_95956Objects7Objects = Hashtable.newFrom({"Ball_1": gdjs.Level_324Code.GDBall_951Objects7, "Ball_2": gdjs.Level_324Code.GDBall_952Objects7, "Ball_4": gdjs.Level_324Code.GDBall_954Objects7, "Ball_3": gdjs.Level_324Code.GDBall_953Objects7, "Ball_5": gdjs.Level_324Code.GDBall_955Objects7, "Ball_6": gdjs.Level_324Code.GDBall_956Objects7});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupObjects7Objects = Hashtable.newFrom({"Cup": gdjs.Level_324Code.GDCupObjects7});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupFrontObjects6Objects = Hashtable.newFrom({"CupFront": gdjs.Level_324Code.GDCupFrontObjects6});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupObjects6Objects = Hashtable.newFrom({"Cup": gdjs.Level_324Code.GDCupObjects6});
gdjs.Level_324Code.eventsList63 = function(runtimeScene) {

{


{
/* Reuse gdjs.Level_324Code.GDCupObjects6 */
{for(var i = 0, len = gdjs.Level_324Code.GDCupObjects6.length ;i < len;++i) {
    gdjs.Level_324Code.GDCupObjects6[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.Level_324Code.eventsList64 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Ball_1"), gdjs.Level_324Code.GDBall_951Objects7);
gdjs.copyArray(runtimeScene.getObjects("Ball_2"), gdjs.Level_324Code.GDBall_952Objects7);
gdjs.copyArray(runtimeScene.getObjects("Ball_3"), gdjs.Level_324Code.GDBall_953Objects7);
gdjs.copyArray(gdjs.Level_324Code.GDBall_954Objects6, gdjs.Level_324Code.GDBall_954Objects7);

gdjs.copyArray(runtimeScene.getObjects("Ball_5"), gdjs.Level_324Code.GDBall_955Objects7);
gdjs.copyArray(runtimeScene.getObjects("Ball_6"), gdjs.Level_324Code.GDBall_956Objects7);
gdjs.copyArray(gdjs.Level_324Code.GDCupObjects6, gdjs.Level_324Code.GDCupObjects7);


gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDBall_95951Objects7ObjectsGDgdjs_46Level_95324Code_46GDBall_95952Objects7ObjectsGDgdjs_46Level_95324Code_46GDBall_95954Objects7ObjectsGDgdjs_46Level_95324Code_46GDBall_95953Objects7ObjectsGDgdjs_46Level_95324Code_46GDBall_95955Objects7ObjectsGDgdjs_46Level_95324Code_46GDBall_95956Objects7Objects, gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupObjects7Objects, false, runtimeScene, false);
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_324Code.GDBall_951Objects7 */
/* Reuse gdjs.Level_324Code.GDBall_952Objects7 */
/* Reuse gdjs.Level_324Code.GDBall_953Objects7 */
/* Reuse gdjs.Level_324Code.GDBall_954Objects7 */
/* Reuse gdjs.Level_324Code.GDBall_955Objects7 */
/* Reuse gdjs.Level_324Code.GDBall_956Objects7 */
{for(var i = 0, len = gdjs.Level_324Code.GDBall_951Objects7.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_951Objects7[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_952Objects7.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_952Objects7[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_954Objects7.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_954Objects7[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_953Objects7.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_953Objects7[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_955Objects7.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_955Objects7[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_956Objects7.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_956Objects7[i].deleteFromScene(runtimeScene);
}
}}

}


{

/* Reuse gdjs.Level_324Code.GDCupObjects6 */
gdjs.copyArray(runtimeScene.getObjects("CupFront"), gdjs.Level_324Code.GDCupFrontObjects6);

gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtsExt__Sticker__IsStuck.func(runtimeScene, gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupFrontObjects6Objects, "Sticker", gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupObjects6Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_324Code.GDCupFrontObjects6 */
{for(var i = 0, len = gdjs.Level_324Code.GDCupFrontObjects6.length ;i < len;++i) {
    gdjs.Level_324Code.GDCupFrontObjects6[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.Level_324Code.eventsList63(runtimeScene);} //End of subevents
}

}


};gdjs.Level_324Code.eventsList65 = function(runtimeScene) {

{



}


{


gdjs.Level_324Code.eventsList60(runtimeScene);
}


{


gdjs.Level_324Code.eventsList62(runtimeScene);
}


{


gdjs.Level_324Code.eventsList64(runtimeScene);
}


};gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDBall_95955Objects6Objects = Hashtable.newFrom({"Ball_5": gdjs.Level_324Code.GDBall_955Objects6});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupObjects6Objects = Hashtable.newFrom({"Cup": gdjs.Level_324Code.GDCupObjects6});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDBall_95955Objects6Objects = Hashtable.newFrom({"Ball_5": gdjs.Level_324Code.GDBall_955Objects6});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGlassBreaking_9595ParticlesObjects7Objects = Hashtable.newFrom({"GlassBreaking_Particles": gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects7});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGlassBreaking_9595ParticlesObjects7Objects = Hashtable.newFrom({"GlassBreaking_Particles": gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects7});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGlassBreaking_9595ParticlesObjects7Objects = Hashtable.newFrom({"GlassBreaking_Particles": gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects7});
gdjs.Level_324Code.eventsList66 = function(runtimeScene) {

{



}


{


{
{gdjs.evtsExt__CameraShake__CameraShake.func(runtimeScene, 20, 20, "", 0, 0.4, 0, 0, 0.10, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{



}


{


{
gdjs.copyArray(gdjs.Level_324Code.GDCupObjects6, gdjs.Level_324Code.GDCupObjects7);

gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects7.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGlassBreaking_9595ParticlesObjects7Objects, (( gdjs.Level_324Code.GDCupObjects7.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects7[0].getCenterXInScene()), (( gdjs.Level_324Code.GDCupObjects7.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects7[0].getPointY("")) + (( gdjs.Level_324Code.GDCupObjects7.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects7[0].getHeight()) * 0.25, "FrontCups");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGlassBreaking_9595ParticlesObjects7Objects, (( gdjs.Level_324Code.GDCupObjects7.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects7[0].getCenterXInScene()), (( gdjs.Level_324Code.GDCupObjects7.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects7[0].getPointY("")) + (( gdjs.Level_324Code.GDCupObjects7.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects7[0].getHeight()) * 0.50, "FrontCups");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGlassBreaking_9595ParticlesObjects7Objects, (( gdjs.Level_324Code.GDCupObjects7.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects7[0].getCenterXInScene()), (( gdjs.Level_324Code.GDCupObjects7.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects7[0].getPointY("")) + (( gdjs.Level_324Code.GDCupObjects7.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects7[0].getHeight()) * 0.75, "FrontCups");
}{for(var i = 0, len = gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects7.length ;i < len;++i) {
    gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects7[i].setZOrder((( gdjs.Level_324Code.GDCupObjects7.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects7[0].getZOrder()) + 1);
}
}}

}


};gdjs.Level_324Code.asyncCallback11583264 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\audio - Glass,Bottle,Break,Smash,Messy.aac", false, 20, 1);
}}
gdjs.Level_324Code.eventsList67 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.100), (runtimeScene) => (gdjs.Level_324Code.asyncCallback11583264(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_324Code.eventsList68 = function(runtimeScene) {

{



}


{


{
{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\Generdyn - 13.aac", false, 50, 1.3);
}
{ //Subevents
gdjs.Level_324Code.eventsList67(runtimeScene);} //End of subevents
}

}


{



}


{


gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
{gdjs.Level_324Code.conditionTrue_1 = gdjs.Level_324Code.condition0IsTrue_0;
gdjs.Level_324Code.conditionTrue_1.val = (gdjs.randomInRange(1, 2) == 1);
}
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\audio - Hit Rock Debris RBD 02.aac", false, 50, 1);
}}

}


{


gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
{gdjs.Level_324Code.conditionTrue_1 = gdjs.Level_324Code.condition0IsTrue_0;
gdjs.Level_324Code.conditionTrue_1.val = (gdjs.randomInRange(1, 2) == 1);
}
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\audio - Glass,Shards,Smash,Medium Impact,Lots of Large Shards.aac", false, 20, 1);
}}

}


};gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDBall_95951Objects7ObjectsGDgdjs_46Level_95324Code_46GDBall_95952Objects7ObjectsGDgdjs_46Level_95324Code_46GDBall_95954Objects7ObjectsGDgdjs_46Level_95324Code_46GDBall_95953Objects7ObjectsGDgdjs_46Level_95324Code_46GDBall_95955Objects7ObjectsGDgdjs_46Level_95324Code_46GDBall_95956Objects7Objects = Hashtable.newFrom({"Ball_1": gdjs.Level_324Code.GDBall_951Objects7, "Ball_2": gdjs.Level_324Code.GDBall_952Objects7, "Ball_4": gdjs.Level_324Code.GDBall_954Objects7, "Ball_3": gdjs.Level_324Code.GDBall_953Objects7, "Ball_5": gdjs.Level_324Code.GDBall_955Objects7, "Ball_6": gdjs.Level_324Code.GDBall_956Objects7});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupObjects7Objects = Hashtable.newFrom({"Cup": gdjs.Level_324Code.GDCupObjects7});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupFrontObjects6Objects = Hashtable.newFrom({"CupFront": gdjs.Level_324Code.GDCupFrontObjects6});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupObjects6Objects = Hashtable.newFrom({"Cup": gdjs.Level_324Code.GDCupObjects6});
gdjs.Level_324Code.eventsList69 = function(runtimeScene) {

{


{
/* Reuse gdjs.Level_324Code.GDCupObjects6 */
{for(var i = 0, len = gdjs.Level_324Code.GDCupObjects6.length ;i < len;++i) {
    gdjs.Level_324Code.GDCupObjects6[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.Level_324Code.eventsList70 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Ball_1"), gdjs.Level_324Code.GDBall_951Objects7);
gdjs.copyArray(runtimeScene.getObjects("Ball_2"), gdjs.Level_324Code.GDBall_952Objects7);
gdjs.copyArray(runtimeScene.getObjects("Ball_3"), gdjs.Level_324Code.GDBall_953Objects7);
gdjs.copyArray(runtimeScene.getObjects("Ball_4"), gdjs.Level_324Code.GDBall_954Objects7);
gdjs.copyArray(gdjs.Level_324Code.GDBall_955Objects6, gdjs.Level_324Code.GDBall_955Objects7);

gdjs.copyArray(runtimeScene.getObjects("Ball_6"), gdjs.Level_324Code.GDBall_956Objects7);
gdjs.copyArray(gdjs.Level_324Code.GDCupObjects6, gdjs.Level_324Code.GDCupObjects7);


gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDBall_95951Objects7ObjectsGDgdjs_46Level_95324Code_46GDBall_95952Objects7ObjectsGDgdjs_46Level_95324Code_46GDBall_95954Objects7ObjectsGDgdjs_46Level_95324Code_46GDBall_95953Objects7ObjectsGDgdjs_46Level_95324Code_46GDBall_95955Objects7ObjectsGDgdjs_46Level_95324Code_46GDBall_95956Objects7Objects, gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupObjects7Objects, false, runtimeScene, false);
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_324Code.GDBall_951Objects7 */
/* Reuse gdjs.Level_324Code.GDBall_952Objects7 */
/* Reuse gdjs.Level_324Code.GDBall_953Objects7 */
/* Reuse gdjs.Level_324Code.GDBall_954Objects7 */
/* Reuse gdjs.Level_324Code.GDBall_955Objects7 */
/* Reuse gdjs.Level_324Code.GDBall_956Objects7 */
{for(var i = 0, len = gdjs.Level_324Code.GDBall_951Objects7.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_951Objects7[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_952Objects7.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_952Objects7[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_954Objects7.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_954Objects7[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_953Objects7.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_953Objects7[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_955Objects7.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_955Objects7[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_956Objects7.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_956Objects7[i].deleteFromScene(runtimeScene);
}
}}

}


{

/* Reuse gdjs.Level_324Code.GDCupObjects6 */
gdjs.copyArray(runtimeScene.getObjects("CupFront"), gdjs.Level_324Code.GDCupFrontObjects6);

gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtsExt__Sticker__IsStuck.func(runtimeScene, gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupFrontObjects6Objects, "Sticker", gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupObjects6Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_324Code.GDCupFrontObjects6 */
{for(var i = 0, len = gdjs.Level_324Code.GDCupFrontObjects6.length ;i < len;++i) {
    gdjs.Level_324Code.GDCupFrontObjects6[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.Level_324Code.eventsList69(runtimeScene);} //End of subevents
}

}


};gdjs.Level_324Code.eventsList71 = function(runtimeScene) {

{



}


{


gdjs.Level_324Code.eventsList66(runtimeScene);
}


{


gdjs.Level_324Code.eventsList68(runtimeScene);
}


{


gdjs.Level_324Code.eventsList70(runtimeScene);
}


};gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDBall_95956Objects6Objects = Hashtable.newFrom({"Ball_6": gdjs.Level_324Code.GDBall_956Objects6});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupObjects6Objects = Hashtable.newFrom({"Cup": gdjs.Level_324Code.GDCupObjects6});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDBall_95956Objects6Objects = Hashtable.newFrom({"Ball_6": gdjs.Level_324Code.GDBall_956Objects6});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGlassBreaking_9595ParticlesObjects7Objects = Hashtable.newFrom({"GlassBreaking_Particles": gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects7});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGlassBreaking_9595ParticlesObjects7Objects = Hashtable.newFrom({"GlassBreaking_Particles": gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects7});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGlassBreaking_9595ParticlesObjects7Objects = Hashtable.newFrom({"GlassBreaking_Particles": gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects7});
gdjs.Level_324Code.eventsList72 = function(runtimeScene) {

{



}


{


{
{gdjs.evtsExt__CameraShake__CameraShake.func(runtimeScene, 20, 20, "", 0, 0.4, 0, 0, 0.10, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{



}


{


{
gdjs.copyArray(gdjs.Level_324Code.GDCupObjects6, gdjs.Level_324Code.GDCupObjects7);

gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects7.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGlassBreaking_9595ParticlesObjects7Objects, (( gdjs.Level_324Code.GDCupObjects7.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects7[0].getCenterXInScene()), (( gdjs.Level_324Code.GDCupObjects7.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects7[0].getPointY("")) + (( gdjs.Level_324Code.GDCupObjects7.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects7[0].getHeight()) * 0.25, "FrontCups");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGlassBreaking_9595ParticlesObjects7Objects, (( gdjs.Level_324Code.GDCupObjects7.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects7[0].getCenterXInScene()), (( gdjs.Level_324Code.GDCupObjects7.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects7[0].getPointY("")) + (( gdjs.Level_324Code.GDCupObjects7.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects7[0].getHeight()) * 0.50, "FrontCups");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGlassBreaking_9595ParticlesObjects7Objects, (( gdjs.Level_324Code.GDCupObjects7.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects7[0].getCenterXInScene()), (( gdjs.Level_324Code.GDCupObjects7.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects7[0].getPointY("")) + (( gdjs.Level_324Code.GDCupObjects7.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects7[0].getHeight()) * 0.75, "FrontCups");
}{for(var i = 0, len = gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects7.length ;i < len;++i) {
    gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects7[i].setZOrder((( gdjs.Level_324Code.GDCupObjects7.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects7[0].getZOrder()) + 1);
}
}}

}


};gdjs.Level_324Code.asyncCallback11583265 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\audio - Glass,Bottle,Break,Smash,Messy.aac", false, 20, 1);
}}
gdjs.Level_324Code.eventsList73 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.100), (runtimeScene) => (gdjs.Level_324Code.asyncCallback11583265(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_324Code.eventsList74 = function(runtimeScene) {

{



}


{


{
{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\Generdyn - 13.aac", false, 50, 1.3);
}
{ //Subevents
gdjs.Level_324Code.eventsList73(runtimeScene);} //End of subevents
}

}


{



}


{


gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
{gdjs.Level_324Code.conditionTrue_1 = gdjs.Level_324Code.condition0IsTrue_0;
gdjs.Level_324Code.conditionTrue_1.val = (gdjs.randomInRange(1, 2) == 1);
}
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\audio - Hit Rock Debris RBD 02.aac", false, 50, 1);
}}

}


{


gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
{gdjs.Level_324Code.conditionTrue_1 = gdjs.Level_324Code.condition0IsTrue_0;
gdjs.Level_324Code.conditionTrue_1.val = (gdjs.randomInRange(1, 2) == 1);
}
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\audio - Glass,Shards,Smash,Medium Impact,Lots of Large Shards.aac", false, 20, 1);
}}

}


};gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDBall_95951Objects7ObjectsGDgdjs_46Level_95324Code_46GDBall_95952Objects7ObjectsGDgdjs_46Level_95324Code_46GDBall_95954Objects7ObjectsGDgdjs_46Level_95324Code_46GDBall_95953Objects7ObjectsGDgdjs_46Level_95324Code_46GDBall_95955Objects7ObjectsGDgdjs_46Level_95324Code_46GDBall_95956Objects7Objects = Hashtable.newFrom({"Ball_1": gdjs.Level_324Code.GDBall_951Objects7, "Ball_2": gdjs.Level_324Code.GDBall_952Objects7, "Ball_4": gdjs.Level_324Code.GDBall_954Objects7, "Ball_3": gdjs.Level_324Code.GDBall_953Objects7, "Ball_5": gdjs.Level_324Code.GDBall_955Objects7, "Ball_6": gdjs.Level_324Code.GDBall_956Objects7});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupObjects7Objects = Hashtable.newFrom({"Cup": gdjs.Level_324Code.GDCupObjects7});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupFrontObjects6Objects = Hashtable.newFrom({"CupFront": gdjs.Level_324Code.GDCupFrontObjects6});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupObjects6Objects = Hashtable.newFrom({"Cup": gdjs.Level_324Code.GDCupObjects6});
gdjs.Level_324Code.eventsList75 = function(runtimeScene) {

{


{
/* Reuse gdjs.Level_324Code.GDCupObjects6 */
{for(var i = 0, len = gdjs.Level_324Code.GDCupObjects6.length ;i < len;++i) {
    gdjs.Level_324Code.GDCupObjects6[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.Level_324Code.eventsList76 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Ball_1"), gdjs.Level_324Code.GDBall_951Objects7);
gdjs.copyArray(runtimeScene.getObjects("Ball_2"), gdjs.Level_324Code.GDBall_952Objects7);
gdjs.copyArray(runtimeScene.getObjects("Ball_3"), gdjs.Level_324Code.GDBall_953Objects7);
gdjs.copyArray(runtimeScene.getObjects("Ball_4"), gdjs.Level_324Code.GDBall_954Objects7);
gdjs.copyArray(runtimeScene.getObjects("Ball_5"), gdjs.Level_324Code.GDBall_955Objects7);
gdjs.copyArray(gdjs.Level_324Code.GDBall_956Objects6, gdjs.Level_324Code.GDBall_956Objects7);

gdjs.copyArray(gdjs.Level_324Code.GDCupObjects6, gdjs.Level_324Code.GDCupObjects7);


gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDBall_95951Objects7ObjectsGDgdjs_46Level_95324Code_46GDBall_95952Objects7ObjectsGDgdjs_46Level_95324Code_46GDBall_95954Objects7ObjectsGDgdjs_46Level_95324Code_46GDBall_95953Objects7ObjectsGDgdjs_46Level_95324Code_46GDBall_95955Objects7ObjectsGDgdjs_46Level_95324Code_46GDBall_95956Objects7Objects, gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupObjects7Objects, false, runtimeScene, false);
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_324Code.GDBall_951Objects7 */
/* Reuse gdjs.Level_324Code.GDBall_952Objects7 */
/* Reuse gdjs.Level_324Code.GDBall_953Objects7 */
/* Reuse gdjs.Level_324Code.GDBall_954Objects7 */
/* Reuse gdjs.Level_324Code.GDBall_955Objects7 */
/* Reuse gdjs.Level_324Code.GDBall_956Objects7 */
{for(var i = 0, len = gdjs.Level_324Code.GDBall_951Objects7.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_951Objects7[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_952Objects7.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_952Objects7[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_954Objects7.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_954Objects7[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_953Objects7.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_953Objects7[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_955Objects7.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_955Objects7[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_956Objects7.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_956Objects7[i].deleteFromScene(runtimeScene);
}
}}

}


{

/* Reuse gdjs.Level_324Code.GDCupObjects6 */
gdjs.copyArray(runtimeScene.getObjects("CupFront"), gdjs.Level_324Code.GDCupFrontObjects6);

gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtsExt__Sticker__IsStuck.func(runtimeScene, gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupFrontObjects6Objects, "Sticker", gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupObjects6Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_324Code.GDCupFrontObjects6 */
{for(var i = 0, len = gdjs.Level_324Code.GDCupFrontObjects6.length ;i < len;++i) {
    gdjs.Level_324Code.GDCupFrontObjects6[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.Level_324Code.eventsList75(runtimeScene);} //End of subevents
}

}


};gdjs.Level_324Code.eventsList77 = function(runtimeScene) {

{



}


{


gdjs.Level_324Code.eventsList72(runtimeScene);
}


{


gdjs.Level_324Code.eventsList74(runtimeScene);
}


{


gdjs.Level_324Code.eventsList76(runtimeScene);
}


};gdjs.Level_324Code.eventsList78 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Ball_1"), gdjs.Level_324Code.GDBall_951Objects6);
gdjs.copyArray(gdjs.Level_324Code.GDCupObjects5, gdjs.Level_324Code.GDCupObjects6);


gdjs.Level_324Code.condition0IsTrue_0.val = false;
gdjs.Level_324Code.condition1IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDBall_95951Objects6Objects, gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupObjects6Objects, false, runtimeScene, false);
}if ( gdjs.Level_324Code.condition0IsTrue_0.val ) {
{
{gdjs.Level_324Code.conditionTrue_1 = gdjs.Level_324Code.condition1IsTrue_0;
gdjs.Level_324Code.conditionTrue_1.val = (gdjs.evtTools.object.getPickedInstancesCount(gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDBall_95951Objects6Objects) == gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MaxBallsPerCup")));
}
}}
if (gdjs.Level_324Code.condition1IsTrue_0.val) {

{ //Subevents
gdjs.Level_324Code.eventsList47(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Ball_2"), gdjs.Level_324Code.GDBall_952Objects6);
gdjs.copyArray(gdjs.Level_324Code.GDCupObjects5, gdjs.Level_324Code.GDCupObjects6);


gdjs.Level_324Code.condition0IsTrue_0.val = false;
gdjs.Level_324Code.condition1IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDBall_95952Objects6Objects, gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupObjects6Objects, false, runtimeScene, false);
}if ( gdjs.Level_324Code.condition0IsTrue_0.val ) {
{
{gdjs.Level_324Code.conditionTrue_1 = gdjs.Level_324Code.condition1IsTrue_0;
gdjs.Level_324Code.conditionTrue_1.val = (gdjs.evtTools.object.getPickedInstancesCount(gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDBall_95952Objects6Objects) == gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MaxBallsPerCup")));
}
}}
if (gdjs.Level_324Code.condition1IsTrue_0.val) {

{ //Subevents
gdjs.Level_324Code.eventsList53(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Ball_3"), gdjs.Level_324Code.GDBall_953Objects6);
gdjs.copyArray(gdjs.Level_324Code.GDCupObjects5, gdjs.Level_324Code.GDCupObjects6);


gdjs.Level_324Code.condition0IsTrue_0.val = false;
gdjs.Level_324Code.condition1IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDBall_95953Objects6Objects, gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupObjects6Objects, false, runtimeScene, false);
}if ( gdjs.Level_324Code.condition0IsTrue_0.val ) {
{
{gdjs.Level_324Code.conditionTrue_1 = gdjs.Level_324Code.condition1IsTrue_0;
gdjs.Level_324Code.conditionTrue_1.val = (gdjs.evtTools.object.getPickedInstancesCount(gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDBall_95953Objects6Objects) == gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MaxBallsPerCup")));
}
}}
if (gdjs.Level_324Code.condition1IsTrue_0.val) {

{ //Subevents
gdjs.Level_324Code.eventsList59(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Ball_4"), gdjs.Level_324Code.GDBall_954Objects6);
gdjs.copyArray(gdjs.Level_324Code.GDCupObjects5, gdjs.Level_324Code.GDCupObjects6);


gdjs.Level_324Code.condition0IsTrue_0.val = false;
gdjs.Level_324Code.condition1IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDBall_95954Objects6Objects, gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupObjects6Objects, false, runtimeScene, false);
}if ( gdjs.Level_324Code.condition0IsTrue_0.val ) {
{
{gdjs.Level_324Code.conditionTrue_1 = gdjs.Level_324Code.condition1IsTrue_0;
gdjs.Level_324Code.conditionTrue_1.val = (gdjs.evtTools.object.getPickedInstancesCount(gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDBall_95954Objects6Objects) == gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MaxBallsPerCup")));
}
}}
if (gdjs.Level_324Code.condition1IsTrue_0.val) {

{ //Subevents
gdjs.Level_324Code.eventsList65(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Ball_5"), gdjs.Level_324Code.GDBall_955Objects6);
gdjs.copyArray(gdjs.Level_324Code.GDCupObjects5, gdjs.Level_324Code.GDCupObjects6);


gdjs.Level_324Code.condition0IsTrue_0.val = false;
gdjs.Level_324Code.condition1IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDBall_95955Objects6Objects, gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupObjects6Objects, false, runtimeScene, false);
}if ( gdjs.Level_324Code.condition0IsTrue_0.val ) {
{
{gdjs.Level_324Code.conditionTrue_1 = gdjs.Level_324Code.condition1IsTrue_0;
gdjs.Level_324Code.conditionTrue_1.val = (gdjs.evtTools.object.getPickedInstancesCount(gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDBall_95955Objects6Objects) == gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MaxBallsPerCup")));
}
}}
if (gdjs.Level_324Code.condition1IsTrue_0.val) {

{ //Subevents
gdjs.Level_324Code.eventsList71(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Ball_6"), gdjs.Level_324Code.GDBall_956Objects6);
gdjs.copyArray(gdjs.Level_324Code.GDCupObjects5, gdjs.Level_324Code.GDCupObjects6);


gdjs.Level_324Code.condition0IsTrue_0.val = false;
gdjs.Level_324Code.condition1IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDBall_95956Objects6Objects, gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupObjects6Objects, false, runtimeScene, false);
}if ( gdjs.Level_324Code.condition0IsTrue_0.val ) {
{
{gdjs.Level_324Code.conditionTrue_1 = gdjs.Level_324Code.condition1IsTrue_0;
gdjs.Level_324Code.conditionTrue_1.val = (gdjs.evtTools.object.getPickedInstancesCount(gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDBall_95956Objects6Objects) == gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MaxBallsPerCup")));
}
}}
if (gdjs.Level_324Code.condition1IsTrue_0.val) {

{ //Subevents
gdjs.Level_324Code.eventsList77(runtimeScene);} //End of subevents
}

}


};gdjs.Level_324Code.eventsList79 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Cup"), gdjs.Level_324Code.GDCupObjects4);

for(gdjs.Level_324Code.forEachIndex5 = 0;gdjs.Level_324Code.forEachIndex5 < gdjs.Level_324Code.GDCupObjects4.length;++gdjs.Level_324Code.forEachIndex5) {
gdjs.Level_324Code.GDCupObjects5.length = 0;


gdjs.Level_324Code.forEachTemporary5 = gdjs.Level_324Code.GDCupObjects4[gdjs.Level_324Code.forEachIndex5];
gdjs.Level_324Code.GDCupObjects5.push(gdjs.Level_324Code.forEachTemporary5);
if (true) {

{ //Subevents: 
gdjs.Level_324Code.eventsList78(runtimeScene);} //Subevents end.
}
}

}


};gdjs.Level_324Code.mapOfEmptyGDBall_951ObjectsEmptyGDBall_952ObjectsEmptyGDBall_954ObjectsEmptyGDBall_953ObjectsEmptyGDBall_955ObjectsEmptyGDBall_956Objects = Hashtable.newFrom({"Ball_1": [], "Ball_2": [], "Ball_4": [], "Ball_3": [], "Ball_5": [], "Ball_6": []});
gdjs.Level_324Code.eventsList80 = function(runtimeScene) {

{


gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_324Code.mapOfEmptyGDBall_951ObjectsEmptyGDBall_952ObjectsEmptyGDBall_954ObjectsEmptyGDBall_953ObjectsEmptyGDBall_955ObjectsEmptyGDBall_956Objects) != 0;
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
{runtimeScene.getVariables().get("GameState").setString("Idle");
}}

}


};gdjs.Level_324Code.mapOfEmptyGDBall_951ObjectsEmptyGDBall_952ObjectsEmptyGDBall_954ObjectsEmptyGDBall_953ObjectsEmptyGDBall_955ObjectsEmptyGDBall_956Objects = Hashtable.newFrom({"Ball_1": [], "Ball_2": [], "Ball_4": [], "Ball_3": [], "Ball_5": [], "Ball_6": []});
gdjs.Level_324Code.mapOfEmptyGDCupObjects = Hashtable.newFrom({"Cup": []});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupObjects4Objects = Hashtable.newFrom({"Cup": gdjs.Level_324Code.GDCupObjects4});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGlassBreaking_9595ParticlesObjects5Objects = Hashtable.newFrom({"GlassBreaking_Particles": gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects5});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGlassBreaking_9595ParticlesObjects5Objects = Hashtable.newFrom({"GlassBreaking_Particles": gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects5});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGlassBreaking_9595ParticlesObjects5Objects = Hashtable.newFrom({"GlassBreaking_Particles": gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects5});
gdjs.Level_324Code.eventsList81 = function(runtimeScene) {

{



}


{


{
{gdjs.evtsExt__CameraShake__CameraShake.func(runtimeScene, 20, 20, "", 0, 0.4, 0, 0, 0.10, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{



}


{


{
gdjs.copyArray(gdjs.Level_324Code.GDCupObjects4, gdjs.Level_324Code.GDCupObjects5);

gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGlassBreaking_9595ParticlesObjects5Objects, (( gdjs.Level_324Code.GDCupObjects5.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects5[0].getCenterXInScene()), (( gdjs.Level_324Code.GDCupObjects5.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects5[0].getPointY("")) + (( gdjs.Level_324Code.GDCupObjects5.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects5[0].getHeight()) * 0.25, "FrontCups");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGlassBreaking_9595ParticlesObjects5Objects, (( gdjs.Level_324Code.GDCupObjects5.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects5[0].getCenterXInScene()), (( gdjs.Level_324Code.GDCupObjects5.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects5[0].getPointY("")) + (( gdjs.Level_324Code.GDCupObjects5.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects5[0].getHeight()) * 0.50, "FrontCups");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGlassBreaking_9595ParticlesObjects5Objects, (( gdjs.Level_324Code.GDCupObjects5.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects5[0].getCenterXInScene()), (( gdjs.Level_324Code.GDCupObjects5.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects5[0].getPointY("")) + (( gdjs.Level_324Code.GDCupObjects5.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects5[0].getHeight()) * 0.75, "FrontCups");
}{for(var i = 0, len = gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects5.length ;i < len;++i) {
    gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects5[i].setZOrder((( gdjs.Level_324Code.GDCupObjects5.length === 0 ) ? 0 :gdjs.Level_324Code.GDCupObjects5[0].getZOrder()) + 1);
}
}}

}


};gdjs.Level_324Code.asyncCallback11583266 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\audio - Glass,Bottle,Break,Smash,Messy.aac", false, 20, 1);
}}
gdjs.Level_324Code.eventsList82 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.100), (runtimeScene) => (gdjs.Level_324Code.asyncCallback11583266(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_324Code.eventsList83 = function(runtimeScene) {

{



}


{


{
{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\Generdyn - 13.aac", false, 50, 1.3);
}
{ //Subevents
gdjs.Level_324Code.eventsList82(runtimeScene);} //End of subevents
}

}


{



}


{


gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
{gdjs.Level_324Code.conditionTrue_1 = gdjs.Level_324Code.condition0IsTrue_0;
gdjs.Level_324Code.conditionTrue_1.val = (gdjs.randomInRange(1, 2) == 1);
}
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\audio - Hit Rock Debris RBD 02.aac", false, 50, 1);
}}

}


{


gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
{gdjs.Level_324Code.conditionTrue_1 = gdjs.Level_324Code.condition0IsTrue_0;
gdjs.Level_324Code.conditionTrue_1.val = (gdjs.randomInRange(1, 2) == 1);
}
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\audio - Glass,Shards,Smash,Medium Impact,Lots of Large Shards.aac", false, 20, 1);
}}

}


};gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDBall_95951Objects5ObjectsGDgdjs_46Level_95324Code_46GDBall_95952Objects5ObjectsGDgdjs_46Level_95324Code_46GDBall_95954Objects5ObjectsGDgdjs_46Level_95324Code_46GDBall_95953Objects5ObjectsGDgdjs_46Level_95324Code_46GDBall_95955Objects5ObjectsGDgdjs_46Level_95324Code_46GDBall_95956Objects5Objects = Hashtable.newFrom({"Ball_1": gdjs.Level_324Code.GDBall_951Objects5, "Ball_2": gdjs.Level_324Code.GDBall_952Objects5, "Ball_4": gdjs.Level_324Code.GDBall_954Objects5, "Ball_3": gdjs.Level_324Code.GDBall_953Objects5, "Ball_5": gdjs.Level_324Code.GDBall_955Objects5, "Ball_6": gdjs.Level_324Code.GDBall_956Objects5});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupObjects5Objects = Hashtable.newFrom({"Cup": gdjs.Level_324Code.GDCupObjects5});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupFrontObjects4Objects = Hashtable.newFrom({"CupFront": gdjs.Level_324Code.GDCupFrontObjects4});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupObjects4Objects = Hashtable.newFrom({"Cup": gdjs.Level_324Code.GDCupObjects4});
gdjs.Level_324Code.eventsList84 = function(runtimeScene) {

{


{
/* Reuse gdjs.Level_324Code.GDCupObjects4 */
{for(var i = 0, len = gdjs.Level_324Code.GDCupObjects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDCupObjects4[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.Level_324Code.eventsList85 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Ball_1"), gdjs.Level_324Code.GDBall_951Objects5);
gdjs.copyArray(runtimeScene.getObjects("Ball_2"), gdjs.Level_324Code.GDBall_952Objects5);
gdjs.copyArray(runtimeScene.getObjects("Ball_3"), gdjs.Level_324Code.GDBall_953Objects5);
gdjs.copyArray(runtimeScene.getObjects("Ball_4"), gdjs.Level_324Code.GDBall_954Objects5);
gdjs.copyArray(runtimeScene.getObjects("Ball_5"), gdjs.Level_324Code.GDBall_955Objects5);
gdjs.copyArray(runtimeScene.getObjects("Ball_6"), gdjs.Level_324Code.GDBall_956Objects5);
gdjs.copyArray(gdjs.Level_324Code.GDCupObjects4, gdjs.Level_324Code.GDCupObjects5);


gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDBall_95951Objects5ObjectsGDgdjs_46Level_95324Code_46GDBall_95952Objects5ObjectsGDgdjs_46Level_95324Code_46GDBall_95954Objects5ObjectsGDgdjs_46Level_95324Code_46GDBall_95953Objects5ObjectsGDgdjs_46Level_95324Code_46GDBall_95955Objects5ObjectsGDgdjs_46Level_95324Code_46GDBall_95956Objects5Objects, gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupObjects5Objects, false, runtimeScene, false);
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_324Code.GDBall_951Objects5 */
/* Reuse gdjs.Level_324Code.GDBall_952Objects5 */
/* Reuse gdjs.Level_324Code.GDBall_953Objects5 */
/* Reuse gdjs.Level_324Code.GDBall_954Objects5 */
/* Reuse gdjs.Level_324Code.GDBall_955Objects5 */
/* Reuse gdjs.Level_324Code.GDBall_956Objects5 */
{for(var i = 0, len = gdjs.Level_324Code.GDBall_951Objects5.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_951Objects5[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_952Objects5.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_952Objects5[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_954Objects5.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_954Objects5[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_953Objects5.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_953Objects5[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_955Objects5.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_955Objects5[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level_324Code.GDBall_956Objects5.length ;i < len;++i) {
    gdjs.Level_324Code.GDBall_956Objects5[i].deleteFromScene(runtimeScene);
}
}}

}


{

/* Reuse gdjs.Level_324Code.GDCupObjects4 */
gdjs.copyArray(runtimeScene.getObjects("CupFront"), gdjs.Level_324Code.GDCupFrontObjects4);

gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtsExt__Sticker__IsStuck.func(runtimeScene, gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupFrontObjects4Objects, "Sticker", gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupObjects4Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_324Code.GDCupFrontObjects4 */
{for(var i = 0, len = gdjs.Level_324Code.GDCupFrontObjects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDCupFrontObjects4[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.Level_324Code.eventsList84(runtimeScene);} //End of subevents
}

}


};gdjs.Level_324Code.eventsList86 = function(runtimeScene) {

{



}


{


gdjs.Level_324Code.eventsList81(runtimeScene);
}


{


gdjs.Level_324Code.eventsList83(runtimeScene);
}


{


gdjs.Level_324Code.eventsList85(runtimeScene);
}


};gdjs.Level_324Code.eventsList87 = function(runtimeScene) {

{



}


{


gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
{gdjs.Level_324Code.conditionTrue_1 = gdjs.Level_324Code.condition0IsTrue_0;
gdjs.Level_324Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11676564);
}
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "ExplosionDelay");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Cup"), gdjs.Level_324Code.GDCupObjects4);

gdjs.Level_324Code.condition0IsTrue_0.val = false;
gdjs.Level_324Code.condition1IsTrue_0.val = false;
gdjs.Level_324Code.condition2IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_324Code.mapOfEmptyGDCupObjects) > 0;
}if ( gdjs.Level_324Code.condition0IsTrue_0.val ) {
{
gdjs.Level_324Code.condition1IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "ExplosionDelay") > 0.2;
}if ( gdjs.Level_324Code.condition1IsTrue_0.val ) {
{
gdjs.Level_324Code.condition2IsTrue_0.val = gdjs.evtTools.object.pickRandomObject(runtimeScene, gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupObjects4Objects);
}}
}
if (gdjs.Level_324Code.condition2IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "ExplosionDelay");
}
{ //Subevents
gdjs.Level_324Code.eventsList86(runtimeScene);} //End of subevents
}

}


};gdjs.Level_324Code.eventsList88 = function(runtimeScene) {

{


gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_324Code.mapOfEmptyGDBall_951ObjectsEmptyGDBall_952ObjectsEmptyGDBall_954ObjectsEmptyGDBall_953ObjectsEmptyGDBall_955ObjectsEmptyGDBall_956Objects) == 0;
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Level_324Code.eventsList87(runtimeScene);} //End of subevents
}

}


};gdjs.Level_324Code.mapOfEmptyGDCupObjects = Hashtable.newFrom({"Cup": []});
gdjs.Level_324Code.eventsList89 = function(runtimeScene) {

{


gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_324Code.mapOfEmptyGDCupObjects) == 0;
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
{runtimeScene.getVariables().get("GameState").setString("LevelComplete");
}}

}


};gdjs.Level_324Code.eventsList90 = function(runtimeScene) {

{


gdjs.Level_324Code.eventsList80(runtimeScene);
}


{


gdjs.Level_324Code.eventsList88(runtimeScene);
}


{


gdjs.Level_324Code.eventsList89(runtimeScene);
}


};gdjs.Level_324Code.eventsList91 = function(runtimeScene) {

{


gdjs.Level_324Code.eventsList79(runtimeScene);
}


{


gdjs.Level_324Code.eventsList90(runtimeScene);
}


};gdjs.Level_324Code.eventsList92 = function(runtimeScene) {

{


gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("GameState")) == "CheckIfComplete";
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Level_324Code.eventsList91(runtimeScene);} //End of subevents
}

}


};gdjs.Level_324Code.asyncCallback11681660 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\audio - Success 2a.aac", false, 100, 1);
}}
gdjs.Level_324Code.eventsList93 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.3), (runtimeScene) => (gdjs.Level_324Code.asyncCallback11681660(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_324Code.eventsList94 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("Cloud1"), gdjs.Level_324Code.GDCloud1Objects4);
gdjs.copyArray(runtimeScene.getObjects("Cloud2"), gdjs.Level_324Code.GDCloud2Objects4);
gdjs.copyArray(runtimeScene.getObjects("Cloud3"), gdjs.Level_324Code.GDCloud3Objects4);
gdjs.copyArray(runtimeScene.getObjects("Cloud4"), gdjs.Level_324Code.GDCloud4Objects4);
{gdjs.evtTools.tween.tweenCamera(runtimeScene, "SlideCameraOut", gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) + gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0) + (( gdjs.Level_324Code.GDCloud4Objects4.length === 0 ) ? (( gdjs.Level_324Code.GDCloud3Objects4.length === 0 ) ? (( gdjs.Level_324Code.GDCloud2Objects4.length === 0 ) ? (( gdjs.Level_324Code.GDCloud1Objects4.length === 0 ) ? 0 :gdjs.Level_324Code.GDCloud1Objects4[0].getWidth()) :gdjs.Level_324Code.GDCloud2Objects4[0].getWidth()) :gdjs.Level_324Code.GDCloud3Objects4[0].getWidth()) :gdjs.Level_324Code.GDCloud4Objects4[0].getWidth()), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0), "", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) * 1000, "easeInBack");
}}

}


};gdjs.Level_324Code.asyncCallback11682708 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("CurrentLevel"))), false);
}}
gdjs.Level_324Code.eventsList95 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0))), (runtimeScene) => (gdjs.Level_324Code.asyncCallback11682708(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_324Code.eventsList96 = function(runtimeScene) {

{


{

{ //Subevents
gdjs.Level_324Code.eventsList93(runtimeScene);} //End of subevents
}

}


{


gdjs.Level_324Code.eventsList94(runtimeScene);
}


{


{

{ //Subevents
gdjs.Level_324Code.eventsList95(runtimeScene);} //End of subevents
}

}


};gdjs.Level_324Code.eventsList97 = function(runtimeScene) {

{


gdjs.Level_324Code.condition0IsTrue_0.val = false;
gdjs.Level_324Code.condition1IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("GameState")) == "LevelComplete";
}if ( gdjs.Level_324Code.condition0IsTrue_0.val ) {
{
{gdjs.Level_324Code.conditionTrue_1 = gdjs.Level_324Code.condition1IsTrue_0;
gdjs.Level_324Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11679540);
}
}}
if (gdjs.Level_324Code.condition1IsTrue_0.val) {
{runtimeScene.getVariables().get("CurrentLevel").add(1);
}{gdjs.evtTools.storage.writeNumberInJSONFile("BallCupBoom", "CurrentLevel", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("CurrentLevel")));
}{runtimeScene.getVariables().get("PlayTimer").add(gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSeconds(runtimeScene, "PlayTimer"));
}{gdjs.evtTools.storage.writeNumberInJSONFile("BallCupBoom", "PlayTimer", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("PlayTimer")));
}{gdjs.evtTools.storage.writeNumberInJSONFile("BallCupBoom", "MovesMade", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("MovesMade")));
}{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "PlayTimer");
}
{ //Subevents
gdjs.Level_324Code.eventsList96(runtimeScene);} //End of subevents
}

}


};gdjs.Level_324Code.asyncCallback11624460 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "PauseMenu");
}}
gdjs.Level_324Code.eventsList98 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.25), (runtimeScene) => (gdjs.Level_324Code.asyncCallback11624460(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_324Code.eventsList99 = function(runtimeScene) {

{


gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
{gdjs.Level_324Code.conditionTrue_1 = gdjs.Level_324Code.condition0IsTrue_0;
gdjs.Level_324Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11623788);
}
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
}

}


{


gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
{gdjs.evtTools.window.openURL("https://bit.ly/ball-cup-boom", runtimeScene);
}
{ //Subevents
gdjs.Level_324Code.eventsList98(runtimeScene);} //End of subevents
}

}


};gdjs.Level_324Code.eventsList100 = function(runtimeScene) {

{


gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
{gdjs.Level_324Code.conditionTrue_1 = gdjs.Level_324Code.condition0IsTrue_0;
gdjs.Level_324Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11623188);
}
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
}

}


{


{

{ //Subevents
gdjs.Level_324Code.eventsList99(runtimeScene);} //End of subevents
}

}


};gdjs.Level_324Code.asyncCallback11626116 = function (runtimeScene, asyncObjectsList) {
}
gdjs.Level_324Code.eventsList101 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(9), (runtimeScene) => (gdjs.Level_324Code.asyncCallback11626116(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_324Code.asyncCallback11625268 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.Level_324Code.eventsList101(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Level_324Code.eventsList102 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(9), (runtimeScene) => (gdjs.Level_324Code.asyncCallback11625268(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_324Code.eventsList103 = function(runtimeScene) {

{


gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
{gdjs.Level_324Code.conditionTrue_1 = gdjs.Level_324Code.condition0IsTrue_0;
gdjs.Level_324Code.condition0IsTrue_1.val = false;
gdjs.Level_324Code.condition1IsTrue_1.val = false;
{
gdjs.Level_324Code.condition0IsTrue_1.val = gdjs.evtsExt__RepeatEveryXSeconds__Repeat.func(runtimeScene, "SpinLogo", 20, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if( gdjs.Level_324Code.condition0IsTrue_1.val ) {
    gdjs.Level_324Code.conditionTrue_1.val = true;
}
}
{
gdjs.Level_324Code.condition1IsTrue_1.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if( gdjs.Level_324Code.condition1IsTrue_1.val ) {
    gdjs.Level_324Code.conditionTrue_1.val = true;
}
}
{
}
}
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Level_324Code.eventsList102(runtimeScene);} //End of subevents
}

}


};gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGreyButtonObjects4ObjectsGDgdjs_46Level_95324Code_46GDLeaderboardObjects4ObjectsGDgdjs_46Level_95324Code_46GDMenuObjects4Objects = Hashtable.newFrom({"GreyButton": gdjs.Level_324Code.GDGreyButtonObjects4, "Leaderboard": gdjs.Level_324Code.GDLeaderboardObjects4, "Menu": gdjs.Level_324Code.GDMenuObjects4});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDPlay_9595TextObjects4ObjectsGDgdjs_46Level_95324Code_46GDMainMenu_9595TextObjects4ObjectsGDgdjs_46Level_95324Code_46GDResetProgress_9595TextObjects4ObjectsGDgdjs_46Level_95324Code_46GDStartOver_9595TextObjects4ObjectsGDgdjs_46Level_95324Code_46GDSubmit_9595TextObjects4Objects = Hashtable.newFrom({"Play_Text": gdjs.Level_324Code.GDPlay_95TextObjects4, "MainMenu_Text": gdjs.Level_324Code.GDMainMenu_95TextObjects4, "ResetProgress_Text": gdjs.Level_324Code.GDResetProgress_95TextObjects4, "StartOver_Text": gdjs.Level_324Code.GDStartOver_95TextObjects4, "Submit_Text": gdjs.Level_324Code.GDSubmit_95TextObjects4});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGreyButtonObjects4ObjectsGDgdjs_46Level_95324Code_46GDLeaderboardObjects4ObjectsGDgdjs_46Level_95324Code_46GDMenuObjects4Objects = Hashtable.newFrom({"GreyButton": gdjs.Level_324Code.GDGreyButtonObjects4, "Leaderboard": gdjs.Level_324Code.GDLeaderboardObjects4, "Menu": gdjs.Level_324Code.GDMenuObjects4});
gdjs.Level_324Code.eventsList104 = function(runtimeScene) {

{

/* Reuse gdjs.Level_324Code.GDGreyButtonObjects4 */
/* Reuse gdjs.Level_324Code.GDLeaderboardObjects4 */
gdjs.copyArray(runtimeScene.getObjects("MainMenu_Text"), gdjs.Level_324Code.GDMainMenu_95TextObjects4);
/* Reuse gdjs.Level_324Code.GDMenuObjects4 */
gdjs.copyArray(runtimeScene.getObjects("Play_Text"), gdjs.Level_324Code.GDPlay_95TextObjects4);
gdjs.copyArray(runtimeScene.getObjects("ResetProgress_Text"), gdjs.Level_324Code.GDResetProgress_95TextObjects4);
gdjs.copyArray(runtimeScene.getObjects("StartOver_Text"), gdjs.Level_324Code.GDStartOver_95TextObjects4);
gdjs.copyArray(runtimeScene.getObjects("Submit_Text"), gdjs.Level_324Code.GDSubmit_95TextObjects4);

gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDPlay_9595TextObjects4ObjectsGDgdjs_46Level_95324Code_46GDMainMenu_9595TextObjects4ObjectsGDgdjs_46Level_95324Code_46GDResetProgress_9595TextObjects4ObjectsGDgdjs_46Level_95324Code_46GDStartOver_9595TextObjects4ObjectsGDgdjs_46Level_95324Code_46GDSubmit_9595TextObjects4Objects, gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGreyButtonObjects4ObjectsGDgdjs_46Level_95324Code_46GDLeaderboardObjects4ObjectsGDgdjs_46Level_95324Code_46GDMenuObjects4Objects, false, runtimeScene, false);
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_324Code.GDMainMenu_95TextObjects4 */
/* Reuse gdjs.Level_324Code.GDPlay_95TextObjects4 */
/* Reuse gdjs.Level_324Code.GDResetProgress_95TextObjects4 */
/* Reuse gdjs.Level_324Code.GDStartOver_95TextObjects4 */
/* Reuse gdjs.Level_324Code.GDSubmit_95TextObjects4 */
{for(var i = 0, len = gdjs.Level_324Code.GDPlay_95TextObjects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDPlay_95TextObjects4[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.Level_324Code.GDMainMenu_95TextObjects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDMainMenu_95TextObjects4[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.Level_324Code.GDResetProgress_95TextObjects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDResetProgress_95TextObjects4[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.Level_324Code.GDStartOver_95TextObjects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDStartOver_95TextObjects4[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.Level_324Code.GDSubmit_95TextObjects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDSubmit_95TextObjects4[i].setColor("255;255;255");
}
}}

}


};gdjs.Level_324Code.eventsList105 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("GreyButton"), gdjs.Level_324Code.GDGreyButtonObjects4);
gdjs.copyArray(runtimeScene.getObjects("Leaderboard"), gdjs.Level_324Code.GDLeaderboardObjects4);
gdjs.copyArray(runtimeScene.getObjects("Menu"), gdjs.Level_324Code.GDMenuObjects4);

gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGreyButtonObjects4ObjectsGDgdjs_46Level_95324Code_46GDLeaderboardObjects4ObjectsGDgdjs_46Level_95324Code_46GDMenuObjects4Objects, runtimeScene, true, true);
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_324Code.GDGreyButtonObjects4 */
/* Reuse gdjs.Level_324Code.GDLeaderboardObjects4 */
/* Reuse gdjs.Level_324Code.GDMenuObjects4 */
{for(var i = 0, len = gdjs.Level_324Code.GDGreyButtonObjects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDGreyButtonObjects4[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.Level_324Code.GDLeaderboardObjects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDLeaderboardObjects4[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.Level_324Code.GDMenuObjects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDMenuObjects4[i].setColor("255;255;255");
}
}{for(var i = 0, len = gdjs.Level_324Code.GDGreyButtonObjects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDGreyButtonObjects4[i].enableEffect("Effect", false);
}
for(var i = 0, len = gdjs.Level_324Code.GDLeaderboardObjects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDLeaderboardObjects4[i].enableEffect("Effect", false);
}
for(var i = 0, len = gdjs.Level_324Code.GDMenuObjects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDMenuObjects4[i].enableEffect("Effect", false);
}
}
{ //Subevents
gdjs.Level_324Code.eventsList104(runtimeScene);} //End of subevents
}

}


};gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGreyButtonObjects4ObjectsGDgdjs_46Level_95324Code_46GDLeaderboardObjects4ObjectsGDgdjs_46Level_95324Code_46GDMenuObjects4Objects = Hashtable.newFrom({"GreyButton": gdjs.Level_324Code.GDGreyButtonObjects4, "Leaderboard": gdjs.Level_324Code.GDLeaderboardObjects4, "Menu": gdjs.Level_324Code.GDMenuObjects4});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDPlay_9595TextObjects4ObjectsGDgdjs_46Level_95324Code_46GDMainMenu_9595TextObjects4ObjectsGDgdjs_46Level_95324Code_46GDResetProgress_9595TextObjects4ObjectsGDgdjs_46Level_95324Code_46GDStartOver_9595TextObjects4ObjectsGDgdjs_46Level_95324Code_46GDSubmit_9595TextObjects4Objects = Hashtable.newFrom({"Play_Text": gdjs.Level_324Code.GDPlay_95TextObjects4, "MainMenu_Text": gdjs.Level_324Code.GDMainMenu_95TextObjects4, "ResetProgress_Text": gdjs.Level_324Code.GDResetProgress_95TextObjects4, "StartOver_Text": gdjs.Level_324Code.GDStartOver_95TextObjects4, "Submit_Text": gdjs.Level_324Code.GDSubmit_95TextObjects4});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGreyButtonObjects4ObjectsGDgdjs_46Level_95324Code_46GDLeaderboardObjects4ObjectsGDgdjs_46Level_95324Code_46GDMenuObjects4Objects = Hashtable.newFrom({"GreyButton": gdjs.Level_324Code.GDGreyButtonObjects4, "Leaderboard": gdjs.Level_324Code.GDLeaderboardObjects4, "Menu": gdjs.Level_324Code.GDMenuObjects4});
gdjs.Level_324Code.eventsList106 = function(runtimeScene) {

{

/* Reuse gdjs.Level_324Code.GDGreyButtonObjects4 */
/* Reuse gdjs.Level_324Code.GDLeaderboardObjects4 */
gdjs.copyArray(runtimeScene.getObjects("MainMenu_Text"), gdjs.Level_324Code.GDMainMenu_95TextObjects4);
/* Reuse gdjs.Level_324Code.GDMenuObjects4 */
gdjs.copyArray(runtimeScene.getObjects("Play_Text"), gdjs.Level_324Code.GDPlay_95TextObjects4);
gdjs.copyArray(runtimeScene.getObjects("ResetProgress_Text"), gdjs.Level_324Code.GDResetProgress_95TextObjects4);
gdjs.copyArray(runtimeScene.getObjects("StartOver_Text"), gdjs.Level_324Code.GDStartOver_95TextObjects4);
gdjs.copyArray(runtimeScene.getObjects("Submit_Text"), gdjs.Level_324Code.GDSubmit_95TextObjects4);

gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDPlay_9595TextObjects4ObjectsGDgdjs_46Level_95324Code_46GDMainMenu_9595TextObjects4ObjectsGDgdjs_46Level_95324Code_46GDResetProgress_9595TextObjects4ObjectsGDgdjs_46Level_95324Code_46GDStartOver_9595TextObjects4ObjectsGDgdjs_46Level_95324Code_46GDSubmit_9595TextObjects4Objects, gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGreyButtonObjects4ObjectsGDgdjs_46Level_95324Code_46GDLeaderboardObjects4ObjectsGDgdjs_46Level_95324Code_46GDMenuObjects4Objects, false, runtimeScene, false);
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_324Code.GDMainMenu_95TextObjects4 */
/* Reuse gdjs.Level_324Code.GDPlay_95TextObjects4 */
/* Reuse gdjs.Level_324Code.GDResetProgress_95TextObjects4 */
/* Reuse gdjs.Level_324Code.GDStartOver_95TextObjects4 */
/* Reuse gdjs.Level_324Code.GDSubmit_95TextObjects4 */
{for(var i = 0, len = gdjs.Level_324Code.GDPlay_95TextObjects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDPlay_95TextObjects4[i].setColor("241;91;181");
}
for(var i = 0, len = gdjs.Level_324Code.GDMainMenu_95TextObjects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDMainMenu_95TextObjects4[i].setColor("241;91;181");
}
for(var i = 0, len = gdjs.Level_324Code.GDResetProgress_95TextObjects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDResetProgress_95TextObjects4[i].setColor("241;91;181");
}
for(var i = 0, len = gdjs.Level_324Code.GDStartOver_95TextObjects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDStartOver_95TextObjects4[i].setColor("241;91;181");
}
for(var i = 0, len = gdjs.Level_324Code.GDSubmit_95TextObjects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDSubmit_95TextObjects4[i].setColor("241;91;181");
}
}}

}


};gdjs.Level_324Code.eventsList107 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("GreyButton"), gdjs.Level_324Code.GDGreyButtonObjects4);
gdjs.copyArray(runtimeScene.getObjects("Leaderboard"), gdjs.Level_324Code.GDLeaderboardObjects4);
gdjs.copyArray(runtimeScene.getObjects("Menu"), gdjs.Level_324Code.GDMenuObjects4);

gdjs.Level_324Code.condition0IsTrue_0.val = false;
gdjs.Level_324Code.condition1IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGreyButtonObjects4ObjectsGDgdjs_46Level_95324Code_46GDLeaderboardObjects4ObjectsGDgdjs_46Level_95324Code_46GDMenuObjects4Objects, runtimeScene, true, false);
}if ( gdjs.Level_324Code.condition0IsTrue_0.val ) {
{
{gdjs.Level_324Code.conditionTrue_1 = gdjs.Level_324Code.condition1IsTrue_0;
gdjs.Level_324Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11702508);
}
}}
if (gdjs.Level_324Code.condition1IsTrue_0.val) {
/* Reuse gdjs.Level_324Code.GDGreyButtonObjects4 */
/* Reuse gdjs.Level_324Code.GDLeaderboardObjects4 */
/* Reuse gdjs.Level_324Code.GDMenuObjects4 */
{for(var i = 0, len = gdjs.Level_324Code.GDGreyButtonObjects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDGreyButtonObjects4[i].enableEffect("Effect", true);
}
for(var i = 0, len = gdjs.Level_324Code.GDLeaderboardObjects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDLeaderboardObjects4[i].enableEffect("Effect", true);
}
for(var i = 0, len = gdjs.Level_324Code.GDMenuObjects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDMenuObjects4[i].enableEffect("Effect", true);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\audio - BLLTImpt Hit Marker 07.aac", false, 15, 4);
}
{ //Subevents
gdjs.Level_324Code.eventsList106(runtimeScene);} //End of subevents
}

}


};gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGreyButtonObjects4ObjectsGDgdjs_46Level_95324Code_46GDLeaderboardObjects4ObjectsGDgdjs_46Level_95324Code_46GDMenuObjects4Objects = Hashtable.newFrom({"GreyButton": gdjs.Level_324Code.GDGreyButtonObjects4, "Leaderboard": gdjs.Level_324Code.GDLeaderboardObjects4, "Menu": gdjs.Level_324Code.GDMenuObjects4});
gdjs.Level_324Code.eventsList108 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("GreyButton"), gdjs.Level_324Code.GDGreyButtonObjects4);
gdjs.copyArray(runtimeScene.getObjects("Leaderboard"), gdjs.Level_324Code.GDLeaderboardObjects4);
gdjs.copyArray(runtimeScene.getObjects("Menu"), gdjs.Level_324Code.GDMenuObjects4);

gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGreyButtonObjects4ObjectsGDgdjs_46Level_95324Code_46GDLeaderboardObjects4ObjectsGDgdjs_46Level_95324Code_46GDMenuObjects4Objects, runtimeScene, true, false);
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_324Code.GDGreyButtonObjects4 */
/* Reuse gdjs.Level_324Code.GDLeaderboardObjects4 */
/* Reuse gdjs.Level_324Code.GDMenuObjects4 */
{for(var i = 0, len = gdjs.Level_324Code.GDGreyButtonObjects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDGreyButtonObjects4[i].setColor("74;74;74");
}
for(var i = 0, len = gdjs.Level_324Code.GDLeaderboardObjects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDLeaderboardObjects4[i].setColor("74;74;74");
}
for(var i = 0, len = gdjs.Level_324Code.GDMenuObjects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDMenuObjects4[i].setColor("74;74;74");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\audio - BLLTImpt Hit Marker 07.aac", false, 40, 2);
}}

}


};gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGreyButtonObjects3ObjectsGDgdjs_46Level_95324Code_46GDLeaderboardObjects3ObjectsGDgdjs_46Level_95324Code_46GDMenuObjects3Objects = Hashtable.newFrom({"GreyButton": gdjs.Level_324Code.GDGreyButtonObjects3, "Leaderboard": gdjs.Level_324Code.GDLeaderboardObjects3, "Menu": gdjs.Level_324Code.GDMenuObjects3});
gdjs.Level_324Code.eventsList109 = function(runtimeScene) {

{


gdjs.Level_324Code.condition0IsTrue_0.val = false;
gdjs.Level_324Code.condition1IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.Level_324Code.condition0IsTrue_0.val ) {
{
{gdjs.Level_324Code.conditionTrue_1 = gdjs.Level_324Code.condition1IsTrue_0;
gdjs.Level_324Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11704564);
}
}}
if (gdjs.Level_324Code.condition1IsTrue_0.val) {

{ //Subevents
gdjs.Level_324Code.eventsList108(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("GreyButton"), gdjs.Level_324Code.GDGreyButtonObjects3);
gdjs.copyArray(runtimeScene.getObjects("Leaderboard"), gdjs.Level_324Code.GDLeaderboardObjects3);
gdjs.copyArray(runtimeScene.getObjects("Menu"), gdjs.Level_324Code.GDMenuObjects3);

gdjs.Level_324Code.condition0IsTrue_0.val = false;
gdjs.Level_324Code.condition1IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.Level_324Code.condition0IsTrue_0.val ) {
{
gdjs.Level_324Code.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDGreyButtonObjects3ObjectsGDgdjs_46Level_95324Code_46GDLeaderboardObjects3ObjectsGDgdjs_46Level_95324Code_46GDMenuObjects3Objects, runtimeScene, true, false);
}}
if (gdjs.Level_324Code.condition1IsTrue_0.val) {
/* Reuse gdjs.Level_324Code.GDGreyButtonObjects3 */
/* Reuse gdjs.Level_324Code.GDLeaderboardObjects3 */
/* Reuse gdjs.Level_324Code.GDMenuObjects3 */
{for(var i = 0, len = gdjs.Level_324Code.GDGreyButtonObjects3.length ;i < len;++i) {
    gdjs.Level_324Code.GDGreyButtonObjects3[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.Level_324Code.GDLeaderboardObjects3.length ;i < len;++i) {
    gdjs.Level_324Code.GDLeaderboardObjects3[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.Level_324Code.GDMenuObjects3.length ;i < len;++i) {
    gdjs.Level_324Code.GDMenuObjects3[i].setColor("255;255;255");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\audio - BLLTImpt Hit Marker 07.aac", false, 40, 3);
}}

}


};gdjs.Level_324Code.eventsList110 = function(runtimeScene) {

{


gdjs.Level_324Code.eventsList105(runtimeScene);
}


{


gdjs.Level_324Code.eventsList107(runtimeScene);
}


{


gdjs.Level_324Code.eventsList109(runtimeScene);
}


};gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDMenuObjects4Objects = Hashtable.newFrom({"Menu": gdjs.Level_324Code.GDMenuObjects4});
gdjs.Level_324Code.asyncCallback11686004 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "PauseMenu");
}}
gdjs.Level_324Code.eventsList111 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.25), (runtimeScene) => (gdjs.Level_324Code.asyncCallback11686004(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_324Code.eventsList112 = function(runtimeScene) {

{

gdjs.Level_324Code.GDMenuObjects3.length = 0;


gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
{gdjs.Level_324Code.conditionTrue_1 = gdjs.Level_324Code.condition0IsTrue_0;
gdjs.Level_324Code.GDMenuObjects3_1final.length = 0;gdjs.Level_324Code.condition0IsTrue_1.val = false;
gdjs.Level_324Code.condition1IsTrue_1.val = false;
{
gdjs.Level_324Code.condition0IsTrue_1.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Escape");
if( gdjs.Level_324Code.condition0IsTrue_1.val ) {
    gdjs.Level_324Code.conditionTrue_1.val = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Menu"), gdjs.Level_324Code.GDMenuObjects4);
{gdjs.Level_324Code.conditionTrue_2 = gdjs.Level_324Code.condition1IsTrue_1;
gdjs.Level_324Code.condition0IsTrue_2.val = false;
gdjs.Level_324Code.condition1IsTrue_2.val = false;
{
gdjs.Level_324Code.condition0IsTrue_2.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDMenuObjects4Objects, runtimeScene, true, false);
}if ( gdjs.Level_324Code.condition0IsTrue_2.val ) {
{
gdjs.Level_324Code.condition1IsTrue_2.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}}
gdjs.Level_324Code.conditionTrue_2.val = true && gdjs.Level_324Code.condition0IsTrue_2.val && gdjs.Level_324Code.condition1IsTrue_2.val;
}
if( gdjs.Level_324Code.condition1IsTrue_1.val ) {
    gdjs.Level_324Code.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Level_324Code.GDMenuObjects4.length;j<jLen;++j) {
        if ( gdjs.Level_324Code.GDMenuObjects3_1final.indexOf(gdjs.Level_324Code.GDMenuObjects4[j]) === -1 )
            gdjs.Level_324Code.GDMenuObjects3_1final.push(gdjs.Level_324Code.GDMenuObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level_324Code.GDMenuObjects3_1final, gdjs.Level_324Code.GDMenuObjects3);
}
}
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Level_324Code.eventsList111(runtimeScene);} //End of subevents
}

}


};gdjs.Level_324Code.eventsList113 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Cup"), gdjs.Level_324Code.GDCupObjects4);

gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_324Code.GDCupObjects4.length;i<l;++i) {
    if ( gdjs.Level_324Code.GDCupObjects4[i].getVariableBoolean(gdjs.Level_324Code.GDCupObjects4[i].getVariables().get("StartingCup"), false) ) {
        gdjs.Level_324Code.condition0IsTrue_0.val = true;
        gdjs.Level_324Code.GDCupObjects4[k] = gdjs.Level_324Code.GDCupObjects4[i];
        ++k;
    }
}
gdjs.Level_324Code.GDCupObjects4.length = k;}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_324Code.GDCupObjects4 */
{for(var i = 0, len = gdjs.Level_324Code.GDCupObjects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDCupObjects4[i].setColor("255;255;255");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Cup"), gdjs.Level_324Code.GDCupObjects3);

gdjs.Level_324Code.condition0IsTrue_0.val = false;
gdjs.Level_324Code.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_324Code.GDCupObjects3.length;i<l;++i) {
    if ( gdjs.Level_324Code.GDCupObjects3[i].getVariableBoolean(gdjs.Level_324Code.GDCupObjects3[i].getVariables().get("StartingCup"), true) ) {
        gdjs.Level_324Code.condition0IsTrue_0.val = true;
        gdjs.Level_324Code.GDCupObjects3[k] = gdjs.Level_324Code.GDCupObjects3[i];
        ++k;
    }
}
gdjs.Level_324Code.GDCupObjects3.length = k;}if ( gdjs.Level_324Code.condition0IsTrue_0.val ) {
{
{gdjs.Level_324Code.conditionTrue_1 = gdjs.Level_324Code.condition1IsTrue_0;
gdjs.Level_324Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11687468);
}
}}
if (gdjs.Level_324Code.condition1IsTrue_0.val) {
/* Reuse gdjs.Level_324Code.GDCupObjects3 */
{for(var i = 0, len = gdjs.Level_324Code.GDCupObjects3.length ;i < len;++i) {
    gdjs.Level_324Code.GDCupObjects3[i].setColor("74;144;226");
}
}}

}


};gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupFrontObjects4Objects = Hashtable.newFrom({"CupFront": gdjs.Level_324Code.GDCupFrontObjects4});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDBall_95951Objects4ObjectsGDgdjs_46Level_95324Code_46GDBall_95952Objects4ObjectsGDgdjs_46Level_95324Code_46GDBall_95954Objects4ObjectsGDgdjs_46Level_95324Code_46GDBall_95953Objects4ObjectsGDgdjs_46Level_95324Code_46GDBall_95955Objects4ObjectsGDgdjs_46Level_95324Code_46GDBall_95956Objects4Objects = Hashtable.newFrom({"Ball_1": gdjs.Level_324Code.GDBall_951Objects4, "Ball_2": gdjs.Level_324Code.GDBall_952Objects4, "Ball_4": gdjs.Level_324Code.GDBall_954Objects4, "Ball_3": gdjs.Level_324Code.GDBall_953Objects4, "Ball_5": gdjs.Level_324Code.GDBall_955Objects4, "Ball_6": gdjs.Level_324Code.GDBall_956Objects4});
gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupFrontObjects4Objects = Hashtable.newFrom({"CupFront": gdjs.Level_324Code.GDCupFrontObjects4});
gdjs.Level_324Code.eventsList114 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("CupFront"), gdjs.Level_324Code.GDCupFrontObjects4);
{for(var i = 0, len = gdjs.Level_324Code.GDCupFrontObjects4.length ;i < len;++i) {
    gdjs.Level_324Code.GDCupFrontObjects4[i].enableEffect("Effect", false);
}
}}

}


{

gdjs.Level_324Code.GDBall_951Objects3.length = 0;

gdjs.Level_324Code.GDBall_952Objects3.length = 0;

gdjs.Level_324Code.GDBall_953Objects3.length = 0;

gdjs.Level_324Code.GDBall_954Objects3.length = 0;

gdjs.Level_324Code.GDBall_955Objects3.length = 0;

gdjs.Level_324Code.GDBall_956Objects3.length = 0;

gdjs.Level_324Code.GDCupFrontObjects3.length = 0;


gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
{gdjs.Level_324Code.conditionTrue_1 = gdjs.Level_324Code.condition0IsTrue_0;
gdjs.Level_324Code.GDBall_951Objects3_1final.length = 0;gdjs.Level_324Code.GDBall_952Objects3_1final.length = 0;gdjs.Level_324Code.GDBall_953Objects3_1final.length = 0;gdjs.Level_324Code.GDBall_954Objects3_1final.length = 0;gdjs.Level_324Code.GDBall_955Objects3_1final.length = 0;gdjs.Level_324Code.GDBall_956Objects3_1final.length = 0;gdjs.Level_324Code.GDCupFrontObjects3_1final.length = 0;gdjs.Level_324Code.condition0IsTrue_1.val = false;
gdjs.Level_324Code.condition1IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("CupFront"), gdjs.Level_324Code.GDCupFrontObjects4);
gdjs.Level_324Code.condition0IsTrue_1.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupFrontObjects4Objects, runtimeScene, true, false);
if( gdjs.Level_324Code.condition0IsTrue_1.val ) {
    gdjs.Level_324Code.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Level_324Code.GDCupFrontObjects4.length;j<jLen;++j) {
        if ( gdjs.Level_324Code.GDCupFrontObjects3_1final.indexOf(gdjs.Level_324Code.GDCupFrontObjects4[j]) === -1 )
            gdjs.Level_324Code.GDCupFrontObjects3_1final.push(gdjs.Level_324Code.GDCupFrontObjects4[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Ball_1"), gdjs.Level_324Code.GDBall_951Objects4);
gdjs.copyArray(runtimeScene.getObjects("Ball_2"), gdjs.Level_324Code.GDBall_952Objects4);
gdjs.copyArray(runtimeScene.getObjects("Ball_3"), gdjs.Level_324Code.GDBall_953Objects4);
gdjs.copyArray(runtimeScene.getObjects("Ball_4"), gdjs.Level_324Code.GDBall_954Objects4);
gdjs.copyArray(runtimeScene.getObjects("Ball_5"), gdjs.Level_324Code.GDBall_955Objects4);
gdjs.copyArray(runtimeScene.getObjects("Ball_6"), gdjs.Level_324Code.GDBall_956Objects4);
gdjs.copyArray(runtimeScene.getObjects("CupFront"), gdjs.Level_324Code.GDCupFrontObjects4);
{gdjs.Level_324Code.conditionTrue_2 = gdjs.Level_324Code.condition1IsTrue_1;
gdjs.Level_324Code.condition0IsTrue_2.val = false;
gdjs.Level_324Code.condition1IsTrue_2.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_324Code.GDBall_951Objects4.length;i<l;++i) {
    if ( gdjs.Level_324Code.GDBall_951Objects4[i].getVariableBoolean(gdjs.Level_324Code.GDBall_951Objects4[i].getVariables().get("PickedUp"), true) ) {
        gdjs.Level_324Code.condition0IsTrue_2.val = true;
        gdjs.Level_324Code.GDBall_951Objects4[k] = gdjs.Level_324Code.GDBall_951Objects4[i];
        ++k;
    }
}
gdjs.Level_324Code.GDBall_951Objects4.length = k;for(var i = 0, k = 0, l = gdjs.Level_324Code.GDBall_952Objects4.length;i<l;++i) {
    if ( gdjs.Level_324Code.GDBall_952Objects4[i].getVariableBoolean(gdjs.Level_324Code.GDBall_952Objects4[i].getVariables().get("PickedUp"), true) ) {
        gdjs.Level_324Code.condition0IsTrue_2.val = true;
        gdjs.Level_324Code.GDBall_952Objects4[k] = gdjs.Level_324Code.GDBall_952Objects4[i];
        ++k;
    }
}
gdjs.Level_324Code.GDBall_952Objects4.length = k;for(var i = 0, k = 0, l = gdjs.Level_324Code.GDBall_954Objects4.length;i<l;++i) {
    if ( gdjs.Level_324Code.GDBall_954Objects4[i].getVariableBoolean(gdjs.Level_324Code.GDBall_954Objects4[i].getVariables().get("PickedUp"), true) ) {
        gdjs.Level_324Code.condition0IsTrue_2.val = true;
        gdjs.Level_324Code.GDBall_954Objects4[k] = gdjs.Level_324Code.GDBall_954Objects4[i];
        ++k;
    }
}
gdjs.Level_324Code.GDBall_954Objects4.length = k;for(var i = 0, k = 0, l = gdjs.Level_324Code.GDBall_953Objects4.length;i<l;++i) {
    if ( gdjs.Level_324Code.GDBall_953Objects4[i].getVariableBoolean(gdjs.Level_324Code.GDBall_953Objects4[i].getVariables().get("PickedUp"), true) ) {
        gdjs.Level_324Code.condition0IsTrue_2.val = true;
        gdjs.Level_324Code.GDBall_953Objects4[k] = gdjs.Level_324Code.GDBall_953Objects4[i];
        ++k;
    }
}
gdjs.Level_324Code.GDBall_953Objects4.length = k;for(var i = 0, k = 0, l = gdjs.Level_324Code.GDBall_955Objects4.length;i<l;++i) {
    if ( gdjs.Level_324Code.GDBall_955Objects4[i].getVariableBoolean(gdjs.Level_324Code.GDBall_955Objects4[i].getVariables().get("PickedUp"), true) ) {
        gdjs.Level_324Code.condition0IsTrue_2.val = true;
        gdjs.Level_324Code.GDBall_955Objects4[k] = gdjs.Level_324Code.GDBall_955Objects4[i];
        ++k;
    }
}
gdjs.Level_324Code.GDBall_955Objects4.length = k;for(var i = 0, k = 0, l = gdjs.Level_324Code.GDBall_956Objects4.length;i<l;++i) {
    if ( gdjs.Level_324Code.GDBall_956Objects4[i].getVariableBoolean(gdjs.Level_324Code.GDBall_956Objects4[i].getVariables().get("PickedUp"), true) ) {
        gdjs.Level_324Code.condition0IsTrue_2.val = true;
        gdjs.Level_324Code.GDBall_956Objects4[k] = gdjs.Level_324Code.GDBall_956Objects4[i];
        ++k;
    }
}
gdjs.Level_324Code.GDBall_956Objects4.length = k;}if ( gdjs.Level_324Code.condition0IsTrue_2.val ) {
{
gdjs.Level_324Code.condition1IsTrue_2.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDBall_95951Objects4ObjectsGDgdjs_46Level_95324Code_46GDBall_95952Objects4ObjectsGDgdjs_46Level_95324Code_46GDBall_95954Objects4ObjectsGDgdjs_46Level_95324Code_46GDBall_95953Objects4ObjectsGDgdjs_46Level_95324Code_46GDBall_95955Objects4ObjectsGDgdjs_46Level_95324Code_46GDBall_95956Objects4Objects, gdjs.Level_324Code.mapOfGDgdjs_46Level_95324Code_46GDCupFrontObjects4Objects, false, runtimeScene, true);
}}
gdjs.Level_324Code.conditionTrue_2.val = true && gdjs.Level_324Code.condition0IsTrue_2.val && gdjs.Level_324Code.condition1IsTrue_2.val;
}
if( gdjs.Level_324Code.condition1IsTrue_1.val ) {
    gdjs.Level_324Code.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Level_324Code.GDBall_951Objects4.length;j<jLen;++j) {
        if ( gdjs.Level_324Code.GDBall_951Objects3_1final.indexOf(gdjs.Level_324Code.GDBall_951Objects4[j]) === -1 )
            gdjs.Level_324Code.GDBall_951Objects3_1final.push(gdjs.Level_324Code.GDBall_951Objects4[j]);
    }
    for(var j = 0, jLen = gdjs.Level_324Code.GDBall_952Objects4.length;j<jLen;++j) {
        if ( gdjs.Level_324Code.GDBall_952Objects3_1final.indexOf(gdjs.Level_324Code.GDBall_952Objects4[j]) === -1 )
            gdjs.Level_324Code.GDBall_952Objects3_1final.push(gdjs.Level_324Code.GDBall_952Objects4[j]);
    }
    for(var j = 0, jLen = gdjs.Level_324Code.GDBall_953Objects4.length;j<jLen;++j) {
        if ( gdjs.Level_324Code.GDBall_953Objects3_1final.indexOf(gdjs.Level_324Code.GDBall_953Objects4[j]) === -1 )
            gdjs.Level_324Code.GDBall_953Objects3_1final.push(gdjs.Level_324Code.GDBall_953Objects4[j]);
    }
    for(var j = 0, jLen = gdjs.Level_324Code.GDBall_954Objects4.length;j<jLen;++j) {
        if ( gdjs.Level_324Code.GDBall_954Objects3_1final.indexOf(gdjs.Level_324Code.GDBall_954Objects4[j]) === -1 )
            gdjs.Level_324Code.GDBall_954Objects3_1final.push(gdjs.Level_324Code.GDBall_954Objects4[j]);
    }
    for(var j = 0, jLen = gdjs.Level_324Code.GDBall_955Objects4.length;j<jLen;++j) {
        if ( gdjs.Level_324Code.GDBall_955Objects3_1final.indexOf(gdjs.Level_324Code.GDBall_955Objects4[j]) === -1 )
            gdjs.Level_324Code.GDBall_955Objects3_1final.push(gdjs.Level_324Code.GDBall_955Objects4[j]);
    }
    for(var j = 0, jLen = gdjs.Level_324Code.GDBall_956Objects4.length;j<jLen;++j) {
        if ( gdjs.Level_324Code.GDBall_956Objects3_1final.indexOf(gdjs.Level_324Code.GDBall_956Objects4[j]) === -1 )
            gdjs.Level_324Code.GDBall_956Objects3_1final.push(gdjs.Level_324Code.GDBall_956Objects4[j]);
    }
    for(var j = 0, jLen = gdjs.Level_324Code.GDCupFrontObjects4.length;j<jLen;++j) {
        if ( gdjs.Level_324Code.GDCupFrontObjects3_1final.indexOf(gdjs.Level_324Code.GDCupFrontObjects4[j]) === -1 )
            gdjs.Level_324Code.GDCupFrontObjects3_1final.push(gdjs.Level_324Code.GDCupFrontObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level_324Code.GDBall_951Objects3_1final, gdjs.Level_324Code.GDBall_951Objects3);
gdjs.copyArray(gdjs.Level_324Code.GDBall_952Objects3_1final, gdjs.Level_324Code.GDBall_952Objects3);
gdjs.copyArray(gdjs.Level_324Code.GDBall_953Objects3_1final, gdjs.Level_324Code.GDBall_953Objects3);
gdjs.copyArray(gdjs.Level_324Code.GDBall_954Objects3_1final, gdjs.Level_324Code.GDBall_954Objects3);
gdjs.copyArray(gdjs.Level_324Code.GDBall_955Objects3_1final, gdjs.Level_324Code.GDBall_955Objects3);
gdjs.copyArray(gdjs.Level_324Code.GDBall_956Objects3_1final, gdjs.Level_324Code.GDBall_956Objects3);
gdjs.copyArray(gdjs.Level_324Code.GDCupFrontObjects3_1final, gdjs.Level_324Code.GDCupFrontObjects3);
}
}
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level_324Code.GDCupFrontObjects3 */
{for(var i = 0, len = gdjs.Level_324Code.GDCupFrontObjects3.length ;i < len;++i) {
    gdjs.Level_324Code.GDCupFrontObjects3[i].enableEffect("Effect", true);
}
}}

}


};gdjs.Level_324Code.eventsList115 = function(runtimeScene) {

{


gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
{gdjs.Level_324Code.conditionTrue_1 = gdjs.Level_324Code.condition0IsTrue_0;
gdjs.Level_324Code.condition0IsTrue_1.val = false;
gdjs.Level_324Code.condition1IsTrue_1.val = false;
{
gdjs.Level_324Code.condition0IsTrue_1.val = !(gdjs.evtTools.runtimeScene.timerPaused(runtimeScene, "PlayTimer"));
if( gdjs.Level_324Code.condition0IsTrue_1.val ) {
    gdjs.Level_324Code.conditionTrue_1.val = true;
}
}
{
gdjs.Level_324Code.condition1IsTrue_1.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if( gdjs.Level_324Code.condition1IsTrue_1.val ) {
    gdjs.Level_324Code.conditionTrue_1.val = true;
}
}
{
}
}
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("TimeSpent_Text"), gdjs.Level_324Code.GDTimeSpent_95TextObjects3);
{for(var i = 0, len = gdjs.Level_324Code.GDTimeSpent_95TextObjects3.length ;i < len;++i) {
    gdjs.Level_324Code.GDTimeSpent_95TextObjects3[i].setString("Time: " + gdjs.evtsExt__ExtendedMath__ToFixedString.func(runtimeScene, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("PlayTimer")) + gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSeconds(runtimeScene, "PlayTimer"), 1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}
}}

}


};gdjs.Level_324Code.eventsList116 = function(runtimeScene) {

{


{
{gdjs.evtsExt__CopyCameraSettings__CopyCameraSettings.func(runtimeScene, "", 0, "Balls", 0, true, true, true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__CopyCameraSettings__CopyCameraSettings.func(runtimeScene, "", 0, "FrontCups", 0, true, true, true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__CopyCameraSettings__CopyCameraSettings.func(runtimeScene, "", 0, "Debugging", 0, true, true, true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__CopyCameraSettings__CopyCameraSettings.func(runtimeScene, "", 0, "Clouds", 0, true, true, false, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.Level_324Code.eventsList117 = function(runtimeScene) {

{



}


{


gdjs.Level_324Code.eventsList100(runtimeScene);
}


{


gdjs.Level_324Code.eventsList103(runtimeScene);
}


{



}


{


gdjs.Level_324Code.eventsList110(runtimeScene);
}


{


gdjs.Level_324Code.eventsList112(runtimeScene);
}


{


gdjs.Level_324Code.eventsList113(runtimeScene);
}


{


gdjs.Level_324Code.eventsList114(runtimeScene);
}


{


gdjs.Level_324Code.eventsList115(runtimeScene);
}


{


gdjs.Level_324Code.eventsList116(runtimeScene);
}


};gdjs.Level_324Code.eventsList118 = function(runtimeScene) {

{


gdjs.Level_324Code.eventsList13(runtimeScene);
}


{


gdjs.Level_324Code.eventsList22(runtimeScene);
}


{


gdjs.Level_324Code.eventsList24(runtimeScene);
}


{


gdjs.Level_324Code.eventsList26(runtimeScene);
}


{


gdjs.Level_324Code.eventsList41(runtimeScene);
}


{


gdjs.Level_324Code.eventsList92(runtimeScene);
}


{


gdjs.Level_324Code.eventsList97(runtimeScene);
}


{


gdjs.Level_324Code.eventsList117(runtimeScene);
}


};gdjs.Level_324Code.eventsList119 = function(runtimeScene) {

{



}


{


gdjs.Level_324Code.eventsList118(runtimeScene);
}


{



}


};gdjs.Level_324Code.eventsList120 = function(runtimeScene) {

{


gdjs.Level_324Code.condition0IsTrue_0.val = false;
{
gdjs.Level_324Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Level_324Code.condition0IsTrue_0.val) {
}

}


};gdjs.Level_324Code.eventsList121 = function(runtimeScene) {

{


gdjs.Level_324Code.eventsList119(runtimeScene);
}


{


gdjs.Level_324Code.eventsList120(runtimeScene);
}


};

gdjs.Level_324Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Level_324Code.GDBall_951Objects1.length = 0;
gdjs.Level_324Code.GDBall_951Objects2.length = 0;
gdjs.Level_324Code.GDBall_951Objects3.length = 0;
gdjs.Level_324Code.GDBall_951Objects4.length = 0;
gdjs.Level_324Code.GDBall_951Objects5.length = 0;
gdjs.Level_324Code.GDBall_951Objects6.length = 0;
gdjs.Level_324Code.GDBall_951Objects7.length = 0;
gdjs.Level_324Code.GDBall_951Objects8.length = 0;
gdjs.Level_324Code.GDBall_951Objects9.length = 0;
gdjs.Level_324Code.GDBall_952Objects1.length = 0;
gdjs.Level_324Code.GDBall_952Objects2.length = 0;
gdjs.Level_324Code.GDBall_952Objects3.length = 0;
gdjs.Level_324Code.GDBall_952Objects4.length = 0;
gdjs.Level_324Code.GDBall_952Objects5.length = 0;
gdjs.Level_324Code.GDBall_952Objects6.length = 0;
gdjs.Level_324Code.GDBall_952Objects7.length = 0;
gdjs.Level_324Code.GDBall_952Objects8.length = 0;
gdjs.Level_324Code.GDBall_952Objects9.length = 0;
gdjs.Level_324Code.GDBall_953Objects1.length = 0;
gdjs.Level_324Code.GDBall_953Objects2.length = 0;
gdjs.Level_324Code.GDBall_953Objects3.length = 0;
gdjs.Level_324Code.GDBall_953Objects4.length = 0;
gdjs.Level_324Code.GDBall_953Objects5.length = 0;
gdjs.Level_324Code.GDBall_953Objects6.length = 0;
gdjs.Level_324Code.GDBall_953Objects7.length = 0;
gdjs.Level_324Code.GDBall_953Objects8.length = 0;
gdjs.Level_324Code.GDBall_953Objects9.length = 0;
gdjs.Level_324Code.GDBall_954Objects1.length = 0;
gdjs.Level_324Code.GDBall_954Objects2.length = 0;
gdjs.Level_324Code.GDBall_954Objects3.length = 0;
gdjs.Level_324Code.GDBall_954Objects4.length = 0;
gdjs.Level_324Code.GDBall_954Objects5.length = 0;
gdjs.Level_324Code.GDBall_954Objects6.length = 0;
gdjs.Level_324Code.GDBall_954Objects7.length = 0;
gdjs.Level_324Code.GDBall_954Objects8.length = 0;
gdjs.Level_324Code.GDBall_954Objects9.length = 0;
gdjs.Level_324Code.GDBall_955Objects1.length = 0;
gdjs.Level_324Code.GDBall_955Objects2.length = 0;
gdjs.Level_324Code.GDBall_955Objects3.length = 0;
gdjs.Level_324Code.GDBall_955Objects4.length = 0;
gdjs.Level_324Code.GDBall_955Objects5.length = 0;
gdjs.Level_324Code.GDBall_955Objects6.length = 0;
gdjs.Level_324Code.GDBall_955Objects7.length = 0;
gdjs.Level_324Code.GDBall_955Objects8.length = 0;
gdjs.Level_324Code.GDBall_955Objects9.length = 0;
gdjs.Level_324Code.GDBall_956Objects1.length = 0;
gdjs.Level_324Code.GDBall_956Objects2.length = 0;
gdjs.Level_324Code.GDBall_956Objects3.length = 0;
gdjs.Level_324Code.GDBall_956Objects4.length = 0;
gdjs.Level_324Code.GDBall_956Objects5.length = 0;
gdjs.Level_324Code.GDBall_956Objects6.length = 0;
gdjs.Level_324Code.GDBall_956Objects7.length = 0;
gdjs.Level_324Code.GDBall_956Objects8.length = 0;
gdjs.Level_324Code.GDBall_956Objects9.length = 0;
gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects1.length = 0;
gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects2.length = 0;
gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects3.length = 0;
gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects4.length = 0;
gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects5.length = 0;
gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects6.length = 0;
gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects7.length = 0;
gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects8.length = 0;
gdjs.Level_324Code.GDGlassBreaking_95ParticlesObjects9.length = 0;
gdjs.Level_324Code.GDCupObjects1.length = 0;
gdjs.Level_324Code.GDCupObjects2.length = 0;
gdjs.Level_324Code.GDCupObjects3.length = 0;
gdjs.Level_324Code.GDCupObjects4.length = 0;
gdjs.Level_324Code.GDCupObjects5.length = 0;
gdjs.Level_324Code.GDCupObjects6.length = 0;
gdjs.Level_324Code.GDCupObjects7.length = 0;
gdjs.Level_324Code.GDCupObjects8.length = 0;
gdjs.Level_324Code.GDCupObjects9.length = 0;
gdjs.Level_324Code.GDCupFrontObjects1.length = 0;
gdjs.Level_324Code.GDCupFrontObjects2.length = 0;
gdjs.Level_324Code.GDCupFrontObjects3.length = 0;
gdjs.Level_324Code.GDCupFrontObjects4.length = 0;
gdjs.Level_324Code.GDCupFrontObjects5.length = 0;
gdjs.Level_324Code.GDCupFrontObjects6.length = 0;
gdjs.Level_324Code.GDCupFrontObjects7.length = 0;
gdjs.Level_324Code.GDCupFrontObjects8.length = 0;
gdjs.Level_324Code.GDCupFrontObjects9.length = 0;
gdjs.Level_324Code.GDCloud1Objects1.length = 0;
gdjs.Level_324Code.GDCloud1Objects2.length = 0;
gdjs.Level_324Code.GDCloud1Objects3.length = 0;
gdjs.Level_324Code.GDCloud1Objects4.length = 0;
gdjs.Level_324Code.GDCloud1Objects5.length = 0;
gdjs.Level_324Code.GDCloud1Objects6.length = 0;
gdjs.Level_324Code.GDCloud1Objects7.length = 0;
gdjs.Level_324Code.GDCloud1Objects8.length = 0;
gdjs.Level_324Code.GDCloud1Objects9.length = 0;
gdjs.Level_324Code.GDCloud2Objects1.length = 0;
gdjs.Level_324Code.GDCloud2Objects2.length = 0;
gdjs.Level_324Code.GDCloud2Objects3.length = 0;
gdjs.Level_324Code.GDCloud2Objects4.length = 0;
gdjs.Level_324Code.GDCloud2Objects5.length = 0;
gdjs.Level_324Code.GDCloud2Objects6.length = 0;
gdjs.Level_324Code.GDCloud2Objects7.length = 0;
gdjs.Level_324Code.GDCloud2Objects8.length = 0;
gdjs.Level_324Code.GDCloud2Objects9.length = 0;
gdjs.Level_324Code.GDCloud3Objects1.length = 0;
gdjs.Level_324Code.GDCloud3Objects2.length = 0;
gdjs.Level_324Code.GDCloud3Objects3.length = 0;
gdjs.Level_324Code.GDCloud3Objects4.length = 0;
gdjs.Level_324Code.GDCloud3Objects5.length = 0;
gdjs.Level_324Code.GDCloud3Objects6.length = 0;
gdjs.Level_324Code.GDCloud3Objects7.length = 0;
gdjs.Level_324Code.GDCloud3Objects8.length = 0;
gdjs.Level_324Code.GDCloud3Objects9.length = 0;
gdjs.Level_324Code.GDCloud4Objects1.length = 0;
gdjs.Level_324Code.GDCloud4Objects2.length = 0;
gdjs.Level_324Code.GDCloud4Objects3.length = 0;
gdjs.Level_324Code.GDCloud4Objects4.length = 0;
gdjs.Level_324Code.GDCloud4Objects5.length = 0;
gdjs.Level_324Code.GDCloud4Objects6.length = 0;
gdjs.Level_324Code.GDCloud4Objects7.length = 0;
gdjs.Level_324Code.GDCloud4Objects8.length = 0;
gdjs.Level_324Code.GDCloud4Objects9.length = 0;
gdjs.Level_324Code.GDEditInGDevelop_95TextObjects1.length = 0;
gdjs.Level_324Code.GDEditInGDevelop_95TextObjects2.length = 0;
gdjs.Level_324Code.GDEditInGDevelop_95TextObjects3.length = 0;
gdjs.Level_324Code.GDEditInGDevelop_95TextObjects4.length = 0;
gdjs.Level_324Code.GDEditInGDevelop_95TextObjects5.length = 0;
gdjs.Level_324Code.GDEditInGDevelop_95TextObjects6.length = 0;
gdjs.Level_324Code.GDEditInGDevelop_95TextObjects7.length = 0;
gdjs.Level_324Code.GDEditInGDevelop_95TextObjects8.length = 0;
gdjs.Level_324Code.GDEditInGDevelop_95TextObjects9.length = 0;
gdjs.Level_324Code.GDGreyButtonObjects1.length = 0;
gdjs.Level_324Code.GDGreyButtonObjects2.length = 0;
gdjs.Level_324Code.GDGreyButtonObjects3.length = 0;
gdjs.Level_324Code.GDGreyButtonObjects4.length = 0;
gdjs.Level_324Code.GDGreyButtonObjects5.length = 0;
gdjs.Level_324Code.GDGreyButtonObjects6.length = 0;
gdjs.Level_324Code.GDGreyButtonObjects7.length = 0;
gdjs.Level_324Code.GDGreyButtonObjects8.length = 0;
gdjs.Level_324Code.GDGreyButtonObjects9.length = 0;
gdjs.Level_324Code.GDCurrentLevel_95TextObjects1.length = 0;
gdjs.Level_324Code.GDCurrentLevel_95TextObjects2.length = 0;
gdjs.Level_324Code.GDCurrentLevel_95TextObjects3.length = 0;
gdjs.Level_324Code.GDCurrentLevel_95TextObjects4.length = 0;
gdjs.Level_324Code.GDCurrentLevel_95TextObjects5.length = 0;
gdjs.Level_324Code.GDCurrentLevel_95TextObjects6.length = 0;
gdjs.Level_324Code.GDCurrentLevel_95TextObjects7.length = 0;
gdjs.Level_324Code.GDCurrentLevel_95TextObjects8.length = 0;
gdjs.Level_324Code.GDCurrentLevel_95TextObjects9.length = 0;
gdjs.Level_324Code.GDMenuObjects1.length = 0;
gdjs.Level_324Code.GDMenuObjects2.length = 0;
gdjs.Level_324Code.GDMenuObjects3.length = 0;
gdjs.Level_324Code.GDMenuObjects4.length = 0;
gdjs.Level_324Code.GDMenuObjects5.length = 0;
gdjs.Level_324Code.GDMenuObjects6.length = 0;
gdjs.Level_324Code.GDMenuObjects7.length = 0;
gdjs.Level_324Code.GDMenuObjects8.length = 0;
gdjs.Level_324Code.GDMenuObjects9.length = 0;
gdjs.Level_324Code.GDGameState_95TextObjects1.length = 0;
gdjs.Level_324Code.GDGameState_95TextObjects2.length = 0;
gdjs.Level_324Code.GDGameState_95TextObjects3.length = 0;
gdjs.Level_324Code.GDGameState_95TextObjects4.length = 0;
gdjs.Level_324Code.GDGameState_95TextObjects5.length = 0;
gdjs.Level_324Code.GDGameState_95TextObjects6.length = 0;
gdjs.Level_324Code.GDGameState_95TextObjects7.length = 0;
gdjs.Level_324Code.GDGameState_95TextObjects8.length = 0;
gdjs.Level_324Code.GDGameState_95TextObjects9.length = 0;
gdjs.Level_324Code.GDMovesMade_95TextObjects1.length = 0;
gdjs.Level_324Code.GDMovesMade_95TextObjects2.length = 0;
gdjs.Level_324Code.GDMovesMade_95TextObjects3.length = 0;
gdjs.Level_324Code.GDMovesMade_95TextObjects4.length = 0;
gdjs.Level_324Code.GDMovesMade_95TextObjects5.length = 0;
gdjs.Level_324Code.GDMovesMade_95TextObjects6.length = 0;
gdjs.Level_324Code.GDMovesMade_95TextObjects7.length = 0;
gdjs.Level_324Code.GDMovesMade_95TextObjects8.length = 0;
gdjs.Level_324Code.GDMovesMade_95TextObjects9.length = 0;
gdjs.Level_324Code.GDTimeSpent_95TextObjects1.length = 0;
gdjs.Level_324Code.GDTimeSpent_95TextObjects2.length = 0;
gdjs.Level_324Code.GDTimeSpent_95TextObjects3.length = 0;
gdjs.Level_324Code.GDTimeSpent_95TextObjects4.length = 0;
gdjs.Level_324Code.GDTimeSpent_95TextObjects5.length = 0;
gdjs.Level_324Code.GDTimeSpent_95TextObjects6.length = 0;
gdjs.Level_324Code.GDTimeSpent_95TextObjects7.length = 0;
gdjs.Level_324Code.GDTimeSpent_95TextObjects8.length = 0;
gdjs.Level_324Code.GDTimeSpent_95TextObjects9.length = 0;
gdjs.Level_324Code.GDBallsInCup_95TextObjects1.length = 0;
gdjs.Level_324Code.GDBallsInCup_95TextObjects2.length = 0;
gdjs.Level_324Code.GDBallsInCup_95TextObjects3.length = 0;
gdjs.Level_324Code.GDBallsInCup_95TextObjects4.length = 0;
gdjs.Level_324Code.GDBallsInCup_95TextObjects5.length = 0;
gdjs.Level_324Code.GDBallsInCup_95TextObjects6.length = 0;
gdjs.Level_324Code.GDBallsInCup_95TextObjects7.length = 0;
gdjs.Level_324Code.GDBallsInCup_95TextObjects8.length = 0;
gdjs.Level_324Code.GDBallsInCup_95TextObjects9.length = 0;
gdjs.Level_324Code.GDPlay_95TextObjects1.length = 0;
gdjs.Level_324Code.GDPlay_95TextObjects2.length = 0;
gdjs.Level_324Code.GDPlay_95TextObjects3.length = 0;
gdjs.Level_324Code.GDPlay_95TextObjects4.length = 0;
gdjs.Level_324Code.GDPlay_95TextObjects5.length = 0;
gdjs.Level_324Code.GDPlay_95TextObjects6.length = 0;
gdjs.Level_324Code.GDPlay_95TextObjects7.length = 0;
gdjs.Level_324Code.GDPlay_95TextObjects8.length = 0;
gdjs.Level_324Code.GDPlay_95TextObjects9.length = 0;
gdjs.Level_324Code.GDLeaderboardObjects1.length = 0;
gdjs.Level_324Code.GDLeaderboardObjects2.length = 0;
gdjs.Level_324Code.GDLeaderboardObjects3.length = 0;
gdjs.Level_324Code.GDLeaderboardObjects4.length = 0;
gdjs.Level_324Code.GDLeaderboardObjects5.length = 0;
gdjs.Level_324Code.GDLeaderboardObjects6.length = 0;
gdjs.Level_324Code.GDLeaderboardObjects7.length = 0;
gdjs.Level_324Code.GDLeaderboardObjects8.length = 0;
gdjs.Level_324Code.GDLeaderboardObjects9.length = 0;
gdjs.Level_324Code.GDMainMenu_95TextObjects1.length = 0;
gdjs.Level_324Code.GDMainMenu_95TextObjects2.length = 0;
gdjs.Level_324Code.GDMainMenu_95TextObjects3.length = 0;
gdjs.Level_324Code.GDMainMenu_95TextObjects4.length = 0;
gdjs.Level_324Code.GDMainMenu_95TextObjects5.length = 0;
gdjs.Level_324Code.GDMainMenu_95TextObjects6.length = 0;
gdjs.Level_324Code.GDMainMenu_95TextObjects7.length = 0;
gdjs.Level_324Code.GDMainMenu_95TextObjects8.length = 0;
gdjs.Level_324Code.GDMainMenu_95TextObjects9.length = 0;
gdjs.Level_324Code.GDResetProgress_95TextObjects1.length = 0;
gdjs.Level_324Code.GDResetProgress_95TextObjects2.length = 0;
gdjs.Level_324Code.GDResetProgress_95TextObjects3.length = 0;
gdjs.Level_324Code.GDResetProgress_95TextObjects4.length = 0;
gdjs.Level_324Code.GDResetProgress_95TextObjects5.length = 0;
gdjs.Level_324Code.GDResetProgress_95TextObjects6.length = 0;
gdjs.Level_324Code.GDResetProgress_95TextObjects7.length = 0;
gdjs.Level_324Code.GDResetProgress_95TextObjects8.length = 0;
gdjs.Level_324Code.GDResetProgress_95TextObjects9.length = 0;
gdjs.Level_324Code.GDStartOver_95TextObjects1.length = 0;
gdjs.Level_324Code.GDStartOver_95TextObjects2.length = 0;
gdjs.Level_324Code.GDStartOver_95TextObjects3.length = 0;
gdjs.Level_324Code.GDStartOver_95TextObjects4.length = 0;
gdjs.Level_324Code.GDStartOver_95TextObjects5.length = 0;
gdjs.Level_324Code.GDStartOver_95TextObjects6.length = 0;
gdjs.Level_324Code.GDStartOver_95TextObjects7.length = 0;
gdjs.Level_324Code.GDStartOver_95TextObjects8.length = 0;
gdjs.Level_324Code.GDStartOver_95TextObjects9.length = 0;
gdjs.Level_324Code.GDSubmit_95TextObjects1.length = 0;
gdjs.Level_324Code.GDSubmit_95TextObjects2.length = 0;
gdjs.Level_324Code.GDSubmit_95TextObjects3.length = 0;
gdjs.Level_324Code.GDSubmit_95TextObjects4.length = 0;
gdjs.Level_324Code.GDSubmit_95TextObjects5.length = 0;
gdjs.Level_324Code.GDSubmit_95TextObjects6.length = 0;
gdjs.Level_324Code.GDSubmit_95TextObjects7.length = 0;
gdjs.Level_324Code.GDSubmit_95TextObjects8.length = 0;
gdjs.Level_324Code.GDSubmit_95TextObjects9.length = 0;
gdjs.Level_324Code.GDBallsInCup_95TextObjects1.length = 0;
gdjs.Level_324Code.GDBallsInCup_95TextObjects2.length = 0;
gdjs.Level_324Code.GDBallsInCup_95TextObjects3.length = 0;
gdjs.Level_324Code.GDBallsInCup_95TextObjects4.length = 0;
gdjs.Level_324Code.GDBallsInCup_95TextObjects5.length = 0;
gdjs.Level_324Code.GDBallsInCup_95TextObjects6.length = 0;
gdjs.Level_324Code.GDBallsInCup_95TextObjects7.length = 0;
gdjs.Level_324Code.GDBallsInCup_95TextObjects8.length = 0;
gdjs.Level_324Code.GDBallsInCup_95TextObjects9.length = 0;

gdjs.Level_324Code.eventsList121(runtimeScene);

return;

}

gdjs['Level_324Code'] = gdjs.Level_324Code;
