gdjs.PauseMenuCode = {};
gdjs.PauseMenuCode.GDGreyButtonObjects1_1final = [];

gdjs.PauseMenuCode.GDGreyButtonObjects2_3final = [];

gdjs.PauseMenuCode.GDMenuObjects1_1final = [];

gdjs.PauseMenuCode.GDMenuObjects2_3final = [];

gdjs.PauseMenuCode.GDPlay_95TextObjects1_1final = [];

gdjs.PauseMenuCode.GDBall_951Objects1= [];
gdjs.PauseMenuCode.GDBall_951Objects2= [];
gdjs.PauseMenuCode.GDBall_951Objects3= [];
gdjs.PauseMenuCode.GDBall_951Objects4= [];
gdjs.PauseMenuCode.GDBall_952Objects1= [];
gdjs.PauseMenuCode.GDBall_952Objects2= [];
gdjs.PauseMenuCode.GDBall_952Objects3= [];
gdjs.PauseMenuCode.GDBall_952Objects4= [];
gdjs.PauseMenuCode.GDBall_953Objects1= [];
gdjs.PauseMenuCode.GDBall_953Objects2= [];
gdjs.PauseMenuCode.GDBall_953Objects3= [];
gdjs.PauseMenuCode.GDBall_953Objects4= [];
gdjs.PauseMenuCode.GDBall_954Objects1= [];
gdjs.PauseMenuCode.GDBall_954Objects2= [];
gdjs.PauseMenuCode.GDBall_954Objects3= [];
gdjs.PauseMenuCode.GDBall_954Objects4= [];
gdjs.PauseMenuCode.GDBall_955Objects1= [];
gdjs.PauseMenuCode.GDBall_955Objects2= [];
gdjs.PauseMenuCode.GDBall_955Objects3= [];
gdjs.PauseMenuCode.GDBall_955Objects4= [];
gdjs.PauseMenuCode.GDBall_956Objects1= [];
gdjs.PauseMenuCode.GDBall_956Objects2= [];
gdjs.PauseMenuCode.GDBall_956Objects3= [];
gdjs.PauseMenuCode.GDBall_956Objects4= [];
gdjs.PauseMenuCode.GDGlassBreaking_95ParticlesObjects1= [];
gdjs.PauseMenuCode.GDGlassBreaking_95ParticlesObjects2= [];
gdjs.PauseMenuCode.GDGlassBreaking_95ParticlesObjects3= [];
gdjs.PauseMenuCode.GDGlassBreaking_95ParticlesObjects4= [];
gdjs.PauseMenuCode.GDCupObjects1= [];
gdjs.PauseMenuCode.GDCupObjects2= [];
gdjs.PauseMenuCode.GDCupObjects3= [];
gdjs.PauseMenuCode.GDCupObjects4= [];
gdjs.PauseMenuCode.GDCupFrontObjects1= [];
gdjs.PauseMenuCode.GDCupFrontObjects2= [];
gdjs.PauseMenuCode.GDCupFrontObjects3= [];
gdjs.PauseMenuCode.GDCupFrontObjects4= [];
gdjs.PauseMenuCode.GDCloud1Objects1= [];
gdjs.PauseMenuCode.GDCloud1Objects2= [];
gdjs.PauseMenuCode.GDCloud1Objects3= [];
gdjs.PauseMenuCode.GDCloud1Objects4= [];
gdjs.PauseMenuCode.GDCloud2Objects1= [];
gdjs.PauseMenuCode.GDCloud2Objects2= [];
gdjs.PauseMenuCode.GDCloud2Objects3= [];
gdjs.PauseMenuCode.GDCloud2Objects4= [];
gdjs.PauseMenuCode.GDCloud3Objects1= [];
gdjs.PauseMenuCode.GDCloud3Objects2= [];
gdjs.PauseMenuCode.GDCloud3Objects3= [];
gdjs.PauseMenuCode.GDCloud3Objects4= [];
gdjs.PauseMenuCode.GDCloud4Objects1= [];
gdjs.PauseMenuCode.GDCloud4Objects2= [];
gdjs.PauseMenuCode.GDCloud4Objects3= [];
gdjs.PauseMenuCode.GDCloud4Objects4= [];
gdjs.PauseMenuCode.GDEditInGDevelop_95TextObjects1= [];
gdjs.PauseMenuCode.GDEditInGDevelop_95TextObjects2= [];
gdjs.PauseMenuCode.GDEditInGDevelop_95TextObjects3= [];
gdjs.PauseMenuCode.GDEditInGDevelop_95TextObjects4= [];
gdjs.PauseMenuCode.GDGreyButtonObjects1= [];
gdjs.PauseMenuCode.GDGreyButtonObjects2= [];
gdjs.PauseMenuCode.GDGreyButtonObjects3= [];
gdjs.PauseMenuCode.GDGreyButtonObjects4= [];
gdjs.PauseMenuCode.GDCurrentLevel_95TextObjects1= [];
gdjs.PauseMenuCode.GDCurrentLevel_95TextObjects2= [];
gdjs.PauseMenuCode.GDCurrentLevel_95TextObjects3= [];
gdjs.PauseMenuCode.GDCurrentLevel_95TextObjects4= [];
gdjs.PauseMenuCode.GDMenuObjects1= [];
gdjs.PauseMenuCode.GDMenuObjects2= [];
gdjs.PauseMenuCode.GDMenuObjects3= [];
gdjs.PauseMenuCode.GDMenuObjects4= [];
gdjs.PauseMenuCode.GDGameState_95TextObjects1= [];
gdjs.PauseMenuCode.GDGameState_95TextObjects2= [];
gdjs.PauseMenuCode.GDGameState_95TextObjects3= [];
gdjs.PauseMenuCode.GDGameState_95TextObjects4= [];
gdjs.PauseMenuCode.GDMovesMade_95TextObjects1= [];
gdjs.PauseMenuCode.GDMovesMade_95TextObjects2= [];
gdjs.PauseMenuCode.GDMovesMade_95TextObjects3= [];
gdjs.PauseMenuCode.GDMovesMade_95TextObjects4= [];
gdjs.PauseMenuCode.GDTimeSpent_95TextObjects1= [];
gdjs.PauseMenuCode.GDTimeSpent_95TextObjects2= [];
gdjs.PauseMenuCode.GDTimeSpent_95TextObjects3= [];
gdjs.PauseMenuCode.GDTimeSpent_95TextObjects4= [];
gdjs.PauseMenuCode.GDBallsInCup_95TextObjects1= [];
gdjs.PauseMenuCode.GDBallsInCup_95TextObjects2= [];
gdjs.PauseMenuCode.GDBallsInCup_95TextObjects3= [];
gdjs.PauseMenuCode.GDBallsInCup_95TextObjects4= [];
gdjs.PauseMenuCode.GDPlay_95TextObjects1= [];
gdjs.PauseMenuCode.GDPlay_95TextObjects2= [];
gdjs.PauseMenuCode.GDPlay_95TextObjects3= [];
gdjs.PauseMenuCode.GDPlay_95TextObjects4= [];
gdjs.PauseMenuCode.GDLeaderboardObjects1= [];
gdjs.PauseMenuCode.GDLeaderboardObjects2= [];
gdjs.PauseMenuCode.GDLeaderboardObjects3= [];
gdjs.PauseMenuCode.GDLeaderboardObjects4= [];
gdjs.PauseMenuCode.GDMainMenu_95TextObjects1= [];
gdjs.PauseMenuCode.GDMainMenu_95TextObjects2= [];
gdjs.PauseMenuCode.GDMainMenu_95TextObjects3= [];
gdjs.PauseMenuCode.GDMainMenu_95TextObjects4= [];
gdjs.PauseMenuCode.GDResetProgress_95TextObjects1= [];
gdjs.PauseMenuCode.GDResetProgress_95TextObjects2= [];
gdjs.PauseMenuCode.GDResetProgress_95TextObjects3= [];
gdjs.PauseMenuCode.GDResetProgress_95TextObjects4= [];
gdjs.PauseMenuCode.GDStartOver_95TextObjects1= [];
gdjs.PauseMenuCode.GDStartOver_95TextObjects2= [];
gdjs.PauseMenuCode.GDStartOver_95TextObjects3= [];
gdjs.PauseMenuCode.GDStartOver_95TextObjects4= [];
gdjs.PauseMenuCode.GDSubmit_95TextObjects1= [];
gdjs.PauseMenuCode.GDSubmit_95TextObjects2= [];
gdjs.PauseMenuCode.GDSubmit_95TextObjects3= [];
gdjs.PauseMenuCode.GDSubmit_95TextObjects4= [];
gdjs.PauseMenuCode.GDResetWarning_95TextObjects1= [];
gdjs.PauseMenuCode.GDResetWarning_95TextObjects2= [];
gdjs.PauseMenuCode.GDResetWarning_95TextObjects3= [];
gdjs.PauseMenuCode.GDResetWarning_95TextObjects4= [];
gdjs.PauseMenuCode.GDPaused_95TextObjects1= [];
gdjs.PauseMenuCode.GDPaused_95TextObjects2= [];
gdjs.PauseMenuCode.GDPaused_95TextObjects3= [];
gdjs.PauseMenuCode.GDPaused_95TextObjects4= [];

gdjs.PauseMenuCode.conditionTrue_0 = {val:false};
gdjs.PauseMenuCode.condition0IsTrue_0 = {val:false};
gdjs.PauseMenuCode.condition1IsTrue_0 = {val:false};
gdjs.PauseMenuCode.condition2IsTrue_0 = {val:false};
gdjs.PauseMenuCode.condition3IsTrue_0 = {val:false};
gdjs.PauseMenuCode.condition4IsTrue_0 = {val:false};
gdjs.PauseMenuCode.conditionTrue_1 = {val:false};
gdjs.PauseMenuCode.condition0IsTrue_1 = {val:false};
gdjs.PauseMenuCode.condition1IsTrue_1 = {val:false};
gdjs.PauseMenuCode.condition2IsTrue_1 = {val:false};
gdjs.PauseMenuCode.condition3IsTrue_1 = {val:false};
gdjs.PauseMenuCode.condition4IsTrue_1 = {val:false};
gdjs.PauseMenuCode.conditionTrue_2 = {val:false};
gdjs.PauseMenuCode.condition0IsTrue_2 = {val:false};
gdjs.PauseMenuCode.condition1IsTrue_2 = {val:false};
gdjs.PauseMenuCode.condition2IsTrue_2 = {val:false};
gdjs.PauseMenuCode.condition3IsTrue_2 = {val:false};
gdjs.PauseMenuCode.condition4IsTrue_2 = {val:false};
gdjs.PauseMenuCode.conditionTrue_3 = {val:false};
gdjs.PauseMenuCode.condition0IsTrue_3 = {val:false};
gdjs.PauseMenuCode.condition1IsTrue_3 = {val:false};
gdjs.PauseMenuCode.condition2IsTrue_3 = {val:false};
gdjs.PauseMenuCode.condition3IsTrue_3 = {val:false};
gdjs.PauseMenuCode.condition4IsTrue_3 = {val:false};


gdjs.PauseMenuCode.mapOfGDgdjs_46PauseMenuCode_46GDGreyButtonObjects2ObjectsGDgdjs_46PauseMenuCode_46GDLeaderboardObjects2ObjectsGDgdjs_46PauseMenuCode_46GDMenuObjects2Objects = Hashtable.newFrom({"GreyButton": gdjs.PauseMenuCode.GDGreyButtonObjects2, "Leaderboard": gdjs.PauseMenuCode.GDLeaderboardObjects2, "Menu": gdjs.PauseMenuCode.GDMenuObjects2});
gdjs.PauseMenuCode.mapOfGDgdjs_46PauseMenuCode_46GDPlay_9595TextObjects2ObjectsGDgdjs_46PauseMenuCode_46GDMainMenu_9595TextObjects2ObjectsGDgdjs_46PauseMenuCode_46GDResetProgress_9595TextObjects2ObjectsGDgdjs_46PauseMenuCode_46GDStartOver_9595TextObjects2ObjectsGDgdjs_46PauseMenuCode_46GDSubmit_9595TextObjects2Objects = Hashtable.newFrom({"Play_Text": gdjs.PauseMenuCode.GDPlay_95TextObjects2, "MainMenu_Text": gdjs.PauseMenuCode.GDMainMenu_95TextObjects2, "ResetProgress_Text": gdjs.PauseMenuCode.GDResetProgress_95TextObjects2, "StartOver_Text": gdjs.PauseMenuCode.GDStartOver_95TextObjects2, "Submit_Text": gdjs.PauseMenuCode.GDSubmit_95TextObjects2});
gdjs.PauseMenuCode.mapOfGDgdjs_46PauseMenuCode_46GDGreyButtonObjects2ObjectsGDgdjs_46PauseMenuCode_46GDLeaderboardObjects2ObjectsGDgdjs_46PauseMenuCode_46GDMenuObjects2Objects = Hashtable.newFrom({"GreyButton": gdjs.PauseMenuCode.GDGreyButtonObjects2, "Leaderboard": gdjs.PauseMenuCode.GDLeaderboardObjects2, "Menu": gdjs.PauseMenuCode.GDMenuObjects2});
gdjs.PauseMenuCode.eventsList0 = function(runtimeScene) {

{

/* Reuse gdjs.PauseMenuCode.GDGreyButtonObjects2 */
/* Reuse gdjs.PauseMenuCode.GDLeaderboardObjects2 */
gdjs.copyArray(runtimeScene.getObjects("MainMenu_Text"), gdjs.PauseMenuCode.GDMainMenu_95TextObjects2);
/* Reuse gdjs.PauseMenuCode.GDMenuObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Play_Text"), gdjs.PauseMenuCode.GDPlay_95TextObjects2);
gdjs.copyArray(runtimeScene.getObjects("ResetProgress_Text"), gdjs.PauseMenuCode.GDResetProgress_95TextObjects2);
gdjs.copyArray(runtimeScene.getObjects("StartOver_Text"), gdjs.PauseMenuCode.GDStartOver_95TextObjects2);
gdjs.copyArray(runtimeScene.getObjects("Submit_Text"), gdjs.PauseMenuCode.GDSubmit_95TextObjects2);

gdjs.PauseMenuCode.condition0IsTrue_0.val = false;
{
gdjs.PauseMenuCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PauseMenuCode.mapOfGDgdjs_46PauseMenuCode_46GDPlay_9595TextObjects2ObjectsGDgdjs_46PauseMenuCode_46GDMainMenu_9595TextObjects2ObjectsGDgdjs_46PauseMenuCode_46GDResetProgress_9595TextObjects2ObjectsGDgdjs_46PauseMenuCode_46GDStartOver_9595TextObjects2ObjectsGDgdjs_46PauseMenuCode_46GDSubmit_9595TextObjects2Objects, gdjs.PauseMenuCode.mapOfGDgdjs_46PauseMenuCode_46GDGreyButtonObjects2ObjectsGDgdjs_46PauseMenuCode_46GDLeaderboardObjects2ObjectsGDgdjs_46PauseMenuCode_46GDMenuObjects2Objects, false, runtimeScene, false);
}if (gdjs.PauseMenuCode.condition0IsTrue_0.val) {
/* Reuse gdjs.PauseMenuCode.GDMainMenu_95TextObjects2 */
/* Reuse gdjs.PauseMenuCode.GDPlay_95TextObjects2 */
/* Reuse gdjs.PauseMenuCode.GDResetProgress_95TextObjects2 */
/* Reuse gdjs.PauseMenuCode.GDStartOver_95TextObjects2 */
/* Reuse gdjs.PauseMenuCode.GDSubmit_95TextObjects2 */
{for(var i = 0, len = gdjs.PauseMenuCode.GDPlay_95TextObjects2.length ;i < len;++i) {
    gdjs.PauseMenuCode.GDPlay_95TextObjects2[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.PauseMenuCode.GDMainMenu_95TextObjects2.length ;i < len;++i) {
    gdjs.PauseMenuCode.GDMainMenu_95TextObjects2[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.PauseMenuCode.GDResetProgress_95TextObjects2.length ;i < len;++i) {
    gdjs.PauseMenuCode.GDResetProgress_95TextObjects2[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.PauseMenuCode.GDStartOver_95TextObjects2.length ;i < len;++i) {
    gdjs.PauseMenuCode.GDStartOver_95TextObjects2[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.PauseMenuCode.GDSubmit_95TextObjects2.length ;i < len;++i) {
    gdjs.PauseMenuCode.GDSubmit_95TextObjects2[i].setColor("255;255;255");
}
}}

}


};gdjs.PauseMenuCode.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("GreyButton"), gdjs.PauseMenuCode.GDGreyButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Leaderboard"), gdjs.PauseMenuCode.GDLeaderboardObjects2);
gdjs.copyArray(runtimeScene.getObjects("Menu"), gdjs.PauseMenuCode.GDMenuObjects2);

gdjs.PauseMenuCode.condition0IsTrue_0.val = false;
{
gdjs.PauseMenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.PauseMenuCode.mapOfGDgdjs_46PauseMenuCode_46GDGreyButtonObjects2ObjectsGDgdjs_46PauseMenuCode_46GDLeaderboardObjects2ObjectsGDgdjs_46PauseMenuCode_46GDMenuObjects2Objects, runtimeScene, true, true);
}if (gdjs.PauseMenuCode.condition0IsTrue_0.val) {
/* Reuse gdjs.PauseMenuCode.GDGreyButtonObjects2 */
/* Reuse gdjs.PauseMenuCode.GDLeaderboardObjects2 */
/* Reuse gdjs.PauseMenuCode.GDMenuObjects2 */
{for(var i = 0, len = gdjs.PauseMenuCode.GDGreyButtonObjects2.length ;i < len;++i) {
    gdjs.PauseMenuCode.GDGreyButtonObjects2[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.PauseMenuCode.GDLeaderboardObjects2.length ;i < len;++i) {
    gdjs.PauseMenuCode.GDLeaderboardObjects2[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.PauseMenuCode.GDMenuObjects2.length ;i < len;++i) {
    gdjs.PauseMenuCode.GDMenuObjects2[i].setColor("255;255;255");
}
}{for(var i = 0, len = gdjs.PauseMenuCode.GDGreyButtonObjects2.length ;i < len;++i) {
    gdjs.PauseMenuCode.GDGreyButtonObjects2[i].enableEffect("Effect", false);
}
for(var i = 0, len = gdjs.PauseMenuCode.GDLeaderboardObjects2.length ;i < len;++i) {
    gdjs.PauseMenuCode.GDLeaderboardObjects2[i].enableEffect("Effect", false);
}
for(var i = 0, len = gdjs.PauseMenuCode.GDMenuObjects2.length ;i < len;++i) {
    gdjs.PauseMenuCode.GDMenuObjects2[i].enableEffect("Effect", false);
}
}
{ //Subevents
gdjs.PauseMenuCode.eventsList0(runtimeScene);} //End of subevents
}

}


};gdjs.PauseMenuCode.mapOfGDgdjs_46PauseMenuCode_46GDGreyButtonObjects2ObjectsGDgdjs_46PauseMenuCode_46GDLeaderboardObjects2ObjectsGDgdjs_46PauseMenuCode_46GDMenuObjects2Objects = Hashtable.newFrom({"GreyButton": gdjs.PauseMenuCode.GDGreyButtonObjects2, "Leaderboard": gdjs.PauseMenuCode.GDLeaderboardObjects2, "Menu": gdjs.PauseMenuCode.GDMenuObjects2});
gdjs.PauseMenuCode.mapOfGDgdjs_46PauseMenuCode_46GDPlay_9595TextObjects2ObjectsGDgdjs_46PauseMenuCode_46GDMainMenu_9595TextObjects2ObjectsGDgdjs_46PauseMenuCode_46GDResetProgress_9595TextObjects2ObjectsGDgdjs_46PauseMenuCode_46GDStartOver_9595TextObjects2ObjectsGDgdjs_46PauseMenuCode_46GDSubmit_9595TextObjects2Objects = Hashtable.newFrom({"Play_Text": gdjs.PauseMenuCode.GDPlay_95TextObjects2, "MainMenu_Text": gdjs.PauseMenuCode.GDMainMenu_95TextObjects2, "ResetProgress_Text": gdjs.PauseMenuCode.GDResetProgress_95TextObjects2, "StartOver_Text": gdjs.PauseMenuCode.GDStartOver_95TextObjects2, "Submit_Text": gdjs.PauseMenuCode.GDSubmit_95TextObjects2});
gdjs.PauseMenuCode.mapOfGDgdjs_46PauseMenuCode_46GDGreyButtonObjects2ObjectsGDgdjs_46PauseMenuCode_46GDLeaderboardObjects2ObjectsGDgdjs_46PauseMenuCode_46GDMenuObjects2Objects = Hashtable.newFrom({"GreyButton": gdjs.PauseMenuCode.GDGreyButtonObjects2, "Leaderboard": gdjs.PauseMenuCode.GDLeaderboardObjects2, "Menu": gdjs.PauseMenuCode.GDMenuObjects2});
gdjs.PauseMenuCode.eventsList2 = function(runtimeScene) {

{

/* Reuse gdjs.PauseMenuCode.GDGreyButtonObjects2 */
/* Reuse gdjs.PauseMenuCode.GDLeaderboardObjects2 */
gdjs.copyArray(runtimeScene.getObjects("MainMenu_Text"), gdjs.PauseMenuCode.GDMainMenu_95TextObjects2);
/* Reuse gdjs.PauseMenuCode.GDMenuObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Play_Text"), gdjs.PauseMenuCode.GDPlay_95TextObjects2);
gdjs.copyArray(runtimeScene.getObjects("ResetProgress_Text"), gdjs.PauseMenuCode.GDResetProgress_95TextObjects2);
gdjs.copyArray(runtimeScene.getObjects("StartOver_Text"), gdjs.PauseMenuCode.GDStartOver_95TextObjects2);
gdjs.copyArray(runtimeScene.getObjects("Submit_Text"), gdjs.PauseMenuCode.GDSubmit_95TextObjects2);

gdjs.PauseMenuCode.condition0IsTrue_0.val = false;
{
gdjs.PauseMenuCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PauseMenuCode.mapOfGDgdjs_46PauseMenuCode_46GDPlay_9595TextObjects2ObjectsGDgdjs_46PauseMenuCode_46GDMainMenu_9595TextObjects2ObjectsGDgdjs_46PauseMenuCode_46GDResetProgress_9595TextObjects2ObjectsGDgdjs_46PauseMenuCode_46GDStartOver_9595TextObjects2ObjectsGDgdjs_46PauseMenuCode_46GDSubmit_9595TextObjects2Objects, gdjs.PauseMenuCode.mapOfGDgdjs_46PauseMenuCode_46GDGreyButtonObjects2ObjectsGDgdjs_46PauseMenuCode_46GDLeaderboardObjects2ObjectsGDgdjs_46PauseMenuCode_46GDMenuObjects2Objects, false, runtimeScene, false);
}if (gdjs.PauseMenuCode.condition0IsTrue_0.val) {
/* Reuse gdjs.PauseMenuCode.GDMainMenu_95TextObjects2 */
/* Reuse gdjs.PauseMenuCode.GDPlay_95TextObjects2 */
/* Reuse gdjs.PauseMenuCode.GDResetProgress_95TextObjects2 */
/* Reuse gdjs.PauseMenuCode.GDStartOver_95TextObjects2 */
/* Reuse gdjs.PauseMenuCode.GDSubmit_95TextObjects2 */
{for(var i = 0, len = gdjs.PauseMenuCode.GDPlay_95TextObjects2.length ;i < len;++i) {
    gdjs.PauseMenuCode.GDPlay_95TextObjects2[i].setColor("241;91;181");
}
for(var i = 0, len = gdjs.PauseMenuCode.GDMainMenu_95TextObjects2.length ;i < len;++i) {
    gdjs.PauseMenuCode.GDMainMenu_95TextObjects2[i].setColor("241;91;181");
}
for(var i = 0, len = gdjs.PauseMenuCode.GDResetProgress_95TextObjects2.length ;i < len;++i) {
    gdjs.PauseMenuCode.GDResetProgress_95TextObjects2[i].setColor("241;91;181");
}
for(var i = 0, len = gdjs.PauseMenuCode.GDStartOver_95TextObjects2.length ;i < len;++i) {
    gdjs.PauseMenuCode.GDStartOver_95TextObjects2[i].setColor("241;91;181");
}
for(var i = 0, len = gdjs.PauseMenuCode.GDSubmit_95TextObjects2.length ;i < len;++i) {
    gdjs.PauseMenuCode.GDSubmit_95TextObjects2[i].setColor("241;91;181");
}
}}

}


};gdjs.PauseMenuCode.eventsList3 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("GreyButton"), gdjs.PauseMenuCode.GDGreyButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Leaderboard"), gdjs.PauseMenuCode.GDLeaderboardObjects2);
gdjs.copyArray(runtimeScene.getObjects("Menu"), gdjs.PauseMenuCode.GDMenuObjects2);

gdjs.PauseMenuCode.condition0IsTrue_0.val = false;
gdjs.PauseMenuCode.condition1IsTrue_0.val = false;
{
gdjs.PauseMenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.PauseMenuCode.mapOfGDgdjs_46PauseMenuCode_46GDGreyButtonObjects2ObjectsGDgdjs_46PauseMenuCode_46GDLeaderboardObjects2ObjectsGDgdjs_46PauseMenuCode_46GDMenuObjects2Objects, runtimeScene, true, false);
}if ( gdjs.PauseMenuCode.condition0IsTrue_0.val ) {
{
{gdjs.PauseMenuCode.conditionTrue_1 = gdjs.PauseMenuCode.condition1IsTrue_0;
gdjs.PauseMenuCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11702508);
}
}}
if (gdjs.PauseMenuCode.condition1IsTrue_0.val) {
/* Reuse gdjs.PauseMenuCode.GDGreyButtonObjects2 */
/* Reuse gdjs.PauseMenuCode.GDLeaderboardObjects2 */
/* Reuse gdjs.PauseMenuCode.GDMenuObjects2 */
{for(var i = 0, len = gdjs.PauseMenuCode.GDGreyButtonObjects2.length ;i < len;++i) {
    gdjs.PauseMenuCode.GDGreyButtonObjects2[i].enableEffect("Effect", true);
}
for(var i = 0, len = gdjs.PauseMenuCode.GDLeaderboardObjects2.length ;i < len;++i) {
    gdjs.PauseMenuCode.GDLeaderboardObjects2[i].enableEffect("Effect", true);
}
for(var i = 0, len = gdjs.PauseMenuCode.GDMenuObjects2.length ;i < len;++i) {
    gdjs.PauseMenuCode.GDMenuObjects2[i].enableEffect("Effect", true);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\audio - BLLTImpt Hit Marker 07.aac", false, 15, 4);
}
{ //Subevents
gdjs.PauseMenuCode.eventsList2(runtimeScene);} //End of subevents
}

}


};gdjs.PauseMenuCode.mapOfGDgdjs_46PauseMenuCode_46GDGreyButtonObjects2ObjectsGDgdjs_46PauseMenuCode_46GDLeaderboardObjects2ObjectsGDgdjs_46PauseMenuCode_46GDMenuObjects2Objects = Hashtable.newFrom({"GreyButton": gdjs.PauseMenuCode.GDGreyButtonObjects2, "Leaderboard": gdjs.PauseMenuCode.GDLeaderboardObjects2, "Menu": gdjs.PauseMenuCode.GDMenuObjects2});
gdjs.PauseMenuCode.eventsList4 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("GreyButton"), gdjs.PauseMenuCode.GDGreyButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Leaderboard"), gdjs.PauseMenuCode.GDLeaderboardObjects2);
gdjs.copyArray(runtimeScene.getObjects("Menu"), gdjs.PauseMenuCode.GDMenuObjects2);

gdjs.PauseMenuCode.condition0IsTrue_0.val = false;
{
gdjs.PauseMenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.PauseMenuCode.mapOfGDgdjs_46PauseMenuCode_46GDGreyButtonObjects2ObjectsGDgdjs_46PauseMenuCode_46GDLeaderboardObjects2ObjectsGDgdjs_46PauseMenuCode_46GDMenuObjects2Objects, runtimeScene, true, false);
}if (gdjs.PauseMenuCode.condition0IsTrue_0.val) {
/* Reuse gdjs.PauseMenuCode.GDGreyButtonObjects2 */
/* Reuse gdjs.PauseMenuCode.GDLeaderboardObjects2 */
/* Reuse gdjs.PauseMenuCode.GDMenuObjects2 */
{for(var i = 0, len = gdjs.PauseMenuCode.GDGreyButtonObjects2.length ;i < len;++i) {
    gdjs.PauseMenuCode.GDGreyButtonObjects2[i].setColor("74;74;74");
}
for(var i = 0, len = gdjs.PauseMenuCode.GDLeaderboardObjects2.length ;i < len;++i) {
    gdjs.PauseMenuCode.GDLeaderboardObjects2[i].setColor("74;74;74");
}
for(var i = 0, len = gdjs.PauseMenuCode.GDMenuObjects2.length ;i < len;++i) {
    gdjs.PauseMenuCode.GDMenuObjects2[i].setColor("74;74;74");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\audio - BLLTImpt Hit Marker 07.aac", false, 40, 2);
}}

}


};gdjs.PauseMenuCode.mapOfGDgdjs_46PauseMenuCode_46GDGreyButtonObjects1ObjectsGDgdjs_46PauseMenuCode_46GDLeaderboardObjects1ObjectsGDgdjs_46PauseMenuCode_46GDMenuObjects1Objects = Hashtable.newFrom({"GreyButton": gdjs.PauseMenuCode.GDGreyButtonObjects1, "Leaderboard": gdjs.PauseMenuCode.GDLeaderboardObjects1, "Menu": gdjs.PauseMenuCode.GDMenuObjects1});
gdjs.PauseMenuCode.eventsList5 = function(runtimeScene) {

{


gdjs.PauseMenuCode.condition0IsTrue_0.val = false;
gdjs.PauseMenuCode.condition1IsTrue_0.val = false;
{
gdjs.PauseMenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.PauseMenuCode.condition0IsTrue_0.val ) {
{
{gdjs.PauseMenuCode.conditionTrue_1 = gdjs.PauseMenuCode.condition1IsTrue_0;
gdjs.PauseMenuCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11704564);
}
}}
if (gdjs.PauseMenuCode.condition1IsTrue_0.val) {

{ //Subevents
gdjs.PauseMenuCode.eventsList4(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("GreyButton"), gdjs.PauseMenuCode.GDGreyButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("Leaderboard"), gdjs.PauseMenuCode.GDLeaderboardObjects1);
gdjs.copyArray(runtimeScene.getObjects("Menu"), gdjs.PauseMenuCode.GDMenuObjects1);

gdjs.PauseMenuCode.condition0IsTrue_0.val = false;
gdjs.PauseMenuCode.condition1IsTrue_0.val = false;
{
gdjs.PauseMenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.PauseMenuCode.condition0IsTrue_0.val ) {
{
gdjs.PauseMenuCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.PauseMenuCode.mapOfGDgdjs_46PauseMenuCode_46GDGreyButtonObjects1ObjectsGDgdjs_46PauseMenuCode_46GDLeaderboardObjects1ObjectsGDgdjs_46PauseMenuCode_46GDMenuObjects1Objects, runtimeScene, true, false);
}}
if (gdjs.PauseMenuCode.condition1IsTrue_0.val) {
/* Reuse gdjs.PauseMenuCode.GDGreyButtonObjects1 */
/* Reuse gdjs.PauseMenuCode.GDLeaderboardObjects1 */
/* Reuse gdjs.PauseMenuCode.GDMenuObjects1 */
{for(var i = 0, len = gdjs.PauseMenuCode.GDGreyButtonObjects1.length ;i < len;++i) {
    gdjs.PauseMenuCode.GDGreyButtonObjects1[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.PauseMenuCode.GDLeaderboardObjects1.length ;i < len;++i) {
    gdjs.PauseMenuCode.GDLeaderboardObjects1[i].setColor("255;255;255");
}
for(var i = 0, len = gdjs.PauseMenuCode.GDMenuObjects1.length ;i < len;++i) {
    gdjs.PauseMenuCode.GDMenuObjects1[i].setColor("255;255;255");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\audio\\audio - BLLTImpt Hit Marker 07.aac", false, 40, 3);
}}

}


};gdjs.PauseMenuCode.eventsList6 = function(runtimeScene) {

{


gdjs.PauseMenuCode.eventsList1(runtimeScene);
}


{


gdjs.PauseMenuCode.eventsList3(runtimeScene);
}


{


gdjs.PauseMenuCode.eventsList5(runtimeScene);
}


};gdjs.PauseMenuCode.eventsList7 = function(runtimeScene) {

{


{
{gdjs.evtTools.sound.pauseMusicOnChannel(runtimeScene, 1);
}}

}


};gdjs.PauseMenuCode.eventsList8 = function(runtimeScene) {

{


gdjs.PauseMenuCode.condition0IsTrue_0.val = false;
{
gdjs.PauseMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.PauseMenuCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("ResetWarning_Text"), gdjs.PauseMenuCode.GDResetWarning_95TextObjects1);
{for(var i = 0, len = gdjs.PauseMenuCode.GDResetWarning_95TextObjects1.length ;i < len;++i) {
    gdjs.PauseMenuCode.GDResetWarning_95TextObjects1[i].hide();
}
}
{ //Subevents
gdjs.PauseMenuCode.eventsList7(runtimeScene);} //End of subevents
}

}


};gdjs.PauseMenuCode.mapOfGDgdjs_46PauseMenuCode_46GDGreyButtonObjects3Objects = Hashtable.newFrom({"GreyButton": gdjs.PauseMenuCode.GDGreyButtonObjects3});
gdjs.PauseMenuCode.mapOfGDgdjs_46PauseMenuCode_46GDMenuObjects3Objects = Hashtable.newFrom({"Menu": gdjs.PauseMenuCode.GDMenuObjects3});
gdjs.PauseMenuCode.mapOfGDgdjs_46PauseMenuCode_46GDPlay_9595TextObjects2Objects = Hashtable.newFrom({"Play_Text": gdjs.PauseMenuCode.GDPlay_95TextObjects2});
gdjs.PauseMenuCode.mapOfGDgdjs_46PauseMenuCode_46GDGreyButtonObjects2Objects = Hashtable.newFrom({"GreyButton": gdjs.PauseMenuCode.GDGreyButtonObjects2});
gdjs.PauseMenuCode.eventsList9 = function(runtimeScene) {

{

gdjs.PauseMenuCode.GDGreyButtonObjects1.length = 0;

gdjs.PauseMenuCode.GDMenuObjects1.length = 0;

gdjs.PauseMenuCode.GDPlay_95TextObjects1.length = 0;


gdjs.PauseMenuCode.condition0IsTrue_0.val = false;
{
{gdjs.PauseMenuCode.conditionTrue_1 = gdjs.PauseMenuCode.condition0IsTrue_0;
gdjs.PauseMenuCode.GDGreyButtonObjects1_1final.length = 0;gdjs.PauseMenuCode.GDMenuObjects1_1final.length = 0;gdjs.PauseMenuCode.GDPlay_95TextObjects1_1final.length = 0;gdjs.PauseMenuCode.condition0IsTrue_1.val = false;
gdjs.PauseMenuCode.condition1IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("Play_Text"), gdjs.PauseMenuCode.GDPlay_95TextObjects2);
gdjs.PauseMenuCode.GDGreyButtonObjects2.length = 0;

gdjs.PauseMenuCode.GDMenuObjects2.length = 0;

{gdjs.PauseMenuCode.conditionTrue_2 = gdjs.PauseMenuCode.condition0IsTrue_1;
gdjs.PauseMenuCode.condition0IsTrue_2.val = false;
gdjs.PauseMenuCode.condition1IsTrue_2.val = false;
gdjs.PauseMenuCode.condition2IsTrue_2.val = false;
{
gdjs.PauseMenuCode.condition0IsTrue_2.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.PauseMenuCode.condition0IsTrue_2.val ) {
{
{gdjs.PauseMenuCode.conditionTrue_3 = gdjs.PauseMenuCode.condition1IsTrue_2;
gdjs.PauseMenuCode.GDGreyButtonObjects2_3final.length = 0;gdjs.PauseMenuCode.GDMenuObjects2_3final.length = 0;gdjs.PauseMenuCode.condition0IsTrue_3.val = false;
gdjs.PauseMenuCode.condition1IsTrue_3.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("GreyButton"), gdjs.PauseMenuCode.GDGreyButtonObjects3);
gdjs.PauseMenuCode.condition0IsTrue_3.val = gdjs.evtTools.input.cursorOnObject(gdjs.PauseMenuCode.mapOfGDgdjs_46PauseMenuCode_46GDGreyButtonObjects3Objects, runtimeScene, true, false);
if( gdjs.PauseMenuCode.condition0IsTrue_3.val ) {
    gdjs.PauseMenuCode.conditionTrue_3.val = true;
    for(var j = 0, jLen = gdjs.PauseMenuCode.GDGreyButtonObjects3.length;j<jLen;++j) {
        if ( gdjs.PauseMenuCode.GDGreyButtonObjects2_3final.indexOf(gdjs.PauseMenuCode.GDGreyButtonObjects3[j]) === -1 )
            gdjs.PauseMenuCode.GDGreyButtonObjects2_3final.push(gdjs.PauseMenuCode.GDGreyButtonObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Menu"), gdjs.PauseMenuCode.GDMenuObjects3);
gdjs.PauseMenuCode.condition1IsTrue_3.val = gdjs.evtTools.input.cursorOnObject(gdjs.PauseMenuCode.mapOfGDgdjs_46PauseMenuCode_46GDMenuObjects3Objects, runtimeScene, true, false);
if( gdjs.PauseMenuCode.condition1IsTrue_3.val ) {
    gdjs.PauseMenuCode.conditionTrue_3.val = true;
    for(var j = 0, jLen = gdjs.PauseMenuCode.GDMenuObjects3.length;j<jLen;++j) {
        if ( gdjs.PauseMenuCode.GDMenuObjects2_3final.indexOf(gdjs.PauseMenuCode.GDMenuObjects3[j]) === -1 )
            gdjs.PauseMenuCode.GDMenuObjects2_3final.push(gdjs.PauseMenuCode.GDMenuObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.PauseMenuCode.GDGreyButtonObjects2_3final, gdjs.PauseMenuCode.GDGreyButtonObjects2);
gdjs.copyArray(gdjs.PauseMenuCode.GDMenuObjects2_3final, gdjs.PauseMenuCode.GDMenuObjects2);
}
}
}if ( gdjs.PauseMenuCode.condition1IsTrue_2.val ) {
{
gdjs.PauseMenuCode.condition2IsTrue_2.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PauseMenuCode.mapOfGDgdjs_46PauseMenuCode_46GDPlay_9595TextObjects2Objects, gdjs.PauseMenuCode.mapOfGDgdjs_46PauseMenuCode_46GDGreyButtonObjects2Objects, false, runtimeScene, false);
}}
}
gdjs.PauseMenuCode.conditionTrue_2.val = true && gdjs.PauseMenuCode.condition0IsTrue_2.val && gdjs.PauseMenuCode.condition1IsTrue_2.val && gdjs.PauseMenuCode.condition2IsTrue_2.val;
}
if( gdjs.PauseMenuCode.condition0IsTrue_1.val ) {
    gdjs.PauseMenuCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.PauseMenuCode.GDGreyButtonObjects2.length;j<jLen;++j) {
        if ( gdjs.PauseMenuCode.GDGreyButtonObjects1_1final.indexOf(gdjs.PauseMenuCode.GDGreyButtonObjects2[j]) === -1 )
            gdjs.PauseMenuCode.GDGreyButtonObjects1_1final.push(gdjs.PauseMenuCode.GDGreyButtonObjects2[j]);
    }
    for(var j = 0, jLen = gdjs.PauseMenuCode.GDMenuObjects2.length;j<jLen;++j) {
        if ( gdjs.PauseMenuCode.GDMenuObjects1_1final.indexOf(gdjs.PauseMenuCode.GDMenuObjects2[j]) === -1 )
            gdjs.PauseMenuCode.GDMenuObjects1_1final.push(gdjs.PauseMenuCode.GDMenuObjects2[j]);
    }
    for(var j = 0, jLen = gdjs.PauseMenuCode.GDPlay_95TextObjects2.length;j<jLen;++j) {
        if ( gdjs.PauseMenuCode.GDPlay_95TextObjects1_1final.indexOf(gdjs.PauseMenuCode.GDPlay_95TextObjects2[j]) === -1 )
            gdjs.PauseMenuCode.GDPlay_95TextObjects1_1final.push(gdjs.PauseMenuCode.GDPlay_95TextObjects2[j]);
    }
}
}
{
gdjs.PauseMenuCode.condition1IsTrue_1.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Escape");
if( gdjs.PauseMenuCode.condition1IsTrue_1.val ) {
    gdjs.PauseMenuCode.conditionTrue_1.val = true;
}
}
{
gdjs.copyArray(gdjs.PauseMenuCode.GDGreyButtonObjects1_1final, gdjs.PauseMenuCode.GDGreyButtonObjects1);
gdjs.copyArray(gdjs.PauseMenuCode.GDMenuObjects1_1final, gdjs.PauseMenuCode.GDMenuObjects1);
gdjs.copyArray(gdjs.PauseMenuCode.GDPlay_95TextObjects1_1final, gdjs.PauseMenuCode.GDPlay_95TextObjects1);
}
}
}if (gdjs.PauseMenuCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.continueMusicOnChannel(runtimeScene, 1);
}{gdjs.evtTools.runtimeScene.popScene(runtimeScene);
}}

}


};gdjs.PauseMenuCode.mapOfGDgdjs_46PauseMenuCode_46GDGreyButtonObjects2Objects = Hashtable.newFrom({"GreyButton": gdjs.PauseMenuCode.GDGreyButtonObjects2});
gdjs.PauseMenuCode.mapOfGDgdjs_46PauseMenuCode_46GDResetProgress_9595TextObjects2Objects = Hashtable.newFrom({"ResetProgress_Text": gdjs.PauseMenuCode.GDResetProgress_95TextObjects2});
gdjs.PauseMenuCode.mapOfGDgdjs_46PauseMenuCode_46GDGreyButtonObjects2Objects = Hashtable.newFrom({"GreyButton": gdjs.PauseMenuCode.GDGreyButtonObjects2});
gdjs.PauseMenuCode.asyncCallback11530900 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("ResetWarning_Text"), gdjs.PauseMenuCode.GDResetWarning_95TextObjects3);

{for(var i = 0, len = gdjs.PauseMenuCode.GDResetWarning_95TextObjects3.length ;i < len;++i) {
    gdjs.PauseMenuCode.GDResetWarning_95TextObjects3[i].hide(false);
}
}}
gdjs.PauseMenuCode.eventsList10 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.PauseMenuCode.GDResetWarning_95TextObjects2) asyncObjectsList.addObject("ResetWarning_Text", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.PauseMenuCode.asyncCallback11530900(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.PauseMenuCode.mapOfGDgdjs_46PauseMenuCode_46GDGreyButtonObjects1Objects = Hashtable.newFrom({"GreyButton": gdjs.PauseMenuCode.GDGreyButtonObjects1});
gdjs.PauseMenuCode.mapOfGDgdjs_46PauseMenuCode_46GDResetProgress_9595TextObjects1Objects = Hashtable.newFrom({"ResetProgress_Text": gdjs.PauseMenuCode.GDResetProgress_95TextObjects1});
gdjs.PauseMenuCode.mapOfGDgdjs_46PauseMenuCode_46GDGreyButtonObjects1Objects = Hashtable.newFrom({"GreyButton": gdjs.PauseMenuCode.GDGreyButtonObjects1});
gdjs.PauseMenuCode.asyncCallback11553940 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Title Screen", false);
}}
gdjs.PauseMenuCode.eventsList11 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.PauseMenuCode.asyncCallback11553940(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.PauseMenuCode.eventsList12 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("GreyButton"), gdjs.PauseMenuCode.GDGreyButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("ResetProgress_Text"), gdjs.PauseMenuCode.GDResetProgress_95TextObjects2);

gdjs.PauseMenuCode.condition0IsTrue_0.val = false;
gdjs.PauseMenuCode.condition1IsTrue_0.val = false;
gdjs.PauseMenuCode.condition2IsTrue_0.val = false;
{
gdjs.PauseMenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.PauseMenuCode.condition0IsTrue_0.val ) {
{
gdjs.PauseMenuCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.PauseMenuCode.mapOfGDgdjs_46PauseMenuCode_46GDGreyButtonObjects2Objects, runtimeScene, true, false);
}if ( gdjs.PauseMenuCode.condition1IsTrue_0.val ) {
{
gdjs.PauseMenuCode.condition2IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PauseMenuCode.mapOfGDgdjs_46PauseMenuCode_46GDResetProgress_9595TextObjects2Objects, gdjs.PauseMenuCode.mapOfGDgdjs_46PauseMenuCode_46GDGreyButtonObjects2Objects, false, runtimeScene, false);
}}
}
if (gdjs.PauseMenuCode.condition2IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Ball_1"), gdjs.PauseMenuCode.GDBall_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Ball_2"), gdjs.PauseMenuCode.GDBall_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Ball_3"), gdjs.PauseMenuCode.GDBall_953Objects2);
gdjs.copyArray(runtimeScene.getObjects("Ball_4"), gdjs.PauseMenuCode.GDBall_954Objects2);
gdjs.copyArray(runtimeScene.getObjects("Ball_5"), gdjs.PauseMenuCode.GDBall_955Objects2);
gdjs.copyArray(runtimeScene.getObjects("Ball_6"), gdjs.PauseMenuCode.GDBall_956Objects2);
gdjs.copyArray(runtimeScene.getObjects("ResetWarning_Text"), gdjs.PauseMenuCode.GDResetWarning_95TextObjects2);
{for(var i = 0, len = gdjs.PauseMenuCode.GDBall_951Objects2.length ;i < len;++i) {
    gdjs.PauseMenuCode.GDBall_951Objects2[i].addForceTowardObject((gdjs.PauseMenuCode.GDResetWarning_95TextObjects2.length !== 0 ? gdjs.PauseMenuCode.GDResetWarning_95TextObjects2[0] : null), 1200, 1);
}
for(var i = 0, len = gdjs.PauseMenuCode.GDBall_952Objects2.length ;i < len;++i) {
    gdjs.PauseMenuCode.GDBall_952Objects2[i].addForceTowardObject((gdjs.PauseMenuCode.GDResetWarning_95TextObjects2.length !== 0 ? gdjs.PauseMenuCode.GDResetWarning_95TextObjects2[0] : null), 1200, 1);
}
for(var i = 0, len = gdjs.PauseMenuCode.GDBall_954Objects2.length ;i < len;++i) {
    gdjs.PauseMenuCode.GDBall_954Objects2[i].addForceTowardObject((gdjs.PauseMenuCode.GDResetWarning_95TextObjects2.length !== 0 ? gdjs.PauseMenuCode.GDResetWarning_95TextObjects2[0] : null), 1200, 1);
}
for(var i = 0, len = gdjs.PauseMenuCode.GDBall_953Objects2.length ;i < len;++i) {
    gdjs.PauseMenuCode.GDBall_953Objects2[i].addForceTowardObject((gdjs.PauseMenuCode.GDResetWarning_95TextObjects2.length !== 0 ? gdjs.PauseMenuCode.GDResetWarning_95TextObjects2[0] : null), 1200, 1);
}
for(var i = 0, len = gdjs.PauseMenuCode.GDBall_955Objects2.length ;i < len;++i) {
    gdjs.PauseMenuCode.GDBall_955Objects2[i].addForceTowardObject((gdjs.PauseMenuCode.GDResetWarning_95TextObjects2.length !== 0 ? gdjs.PauseMenuCode.GDResetWarning_95TextObjects2[0] : null), 1200, 1);
}
for(var i = 0, len = gdjs.PauseMenuCode.GDBall_956Objects2.length ;i < len;++i) {
    gdjs.PauseMenuCode.GDBall_956Objects2[i].addForceTowardObject((gdjs.PauseMenuCode.GDResetWarning_95TextObjects2.length !== 0 ? gdjs.PauseMenuCode.GDResetWarning_95TextObjects2[0] : null), 1200, 1);
}
}
{ //Subevents
gdjs.PauseMenuCode.eventsList10(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("GreyButton"), gdjs.PauseMenuCode.GDGreyButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("ResetProgress_Text"), gdjs.PauseMenuCode.GDResetProgress_95TextObjects1);
gdjs.copyArray(runtimeScene.getObjects("ResetWarning_Text"), gdjs.PauseMenuCode.GDResetWarning_95TextObjects1);

gdjs.PauseMenuCode.condition0IsTrue_0.val = false;
gdjs.PauseMenuCode.condition1IsTrue_0.val = false;
gdjs.PauseMenuCode.condition2IsTrue_0.val = false;
gdjs.PauseMenuCode.condition3IsTrue_0.val = false;
{
gdjs.PauseMenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.PauseMenuCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.PauseMenuCode.GDResetWarning_95TextObjects1.length;i<l;++i) {
    if ( gdjs.PauseMenuCode.GDResetWarning_95TextObjects1[i].isVisible() ) {
        gdjs.PauseMenuCode.condition1IsTrue_0.val = true;
        gdjs.PauseMenuCode.GDResetWarning_95TextObjects1[k] = gdjs.PauseMenuCode.GDResetWarning_95TextObjects1[i];
        ++k;
    }
}
gdjs.PauseMenuCode.GDResetWarning_95TextObjects1.length = k;}if ( gdjs.PauseMenuCode.condition1IsTrue_0.val ) {
{
gdjs.PauseMenuCode.condition2IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.PauseMenuCode.mapOfGDgdjs_46PauseMenuCode_46GDGreyButtonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.PauseMenuCode.condition2IsTrue_0.val ) {
{
gdjs.PauseMenuCode.condition3IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PauseMenuCode.mapOfGDgdjs_46PauseMenuCode_46GDResetProgress_9595TextObjects1Objects, gdjs.PauseMenuCode.mapOfGDgdjs_46PauseMenuCode_46GDGreyButtonObjects1Objects, false, runtimeScene, false);
}}
}
}
if (gdjs.PauseMenuCode.condition3IsTrue_0.val) {
{gdjs.evtTools.storage.writeNumberInJSONFile("BallCupBoom", "CurrentLevel", 0);
}{gdjs.evtTools.storage.writeNumberInJSONFile("BallCupBoom", "PlayTimer", 0);
}{gdjs.evtTools.storage.writeNumberInJSONFile("BallCupBoom", "MovesMade", 0);
}
{ //Subevents
gdjs.PauseMenuCode.eventsList11(runtimeScene);} //End of subevents
}

}


};gdjs.PauseMenuCode.mapOfGDgdjs_46PauseMenuCode_46GDGreyButtonObjects1Objects = Hashtable.newFrom({"GreyButton": gdjs.PauseMenuCode.GDGreyButtonObjects1});
gdjs.PauseMenuCode.mapOfGDgdjs_46PauseMenuCode_46GDMainMenu_9595TextObjects1Objects = Hashtable.newFrom({"MainMenu_Text": gdjs.PauseMenuCode.GDMainMenu_95TextObjects1});
gdjs.PauseMenuCode.mapOfGDgdjs_46PauseMenuCode_46GDGreyButtonObjects1Objects = Hashtable.newFrom({"GreyButton": gdjs.PauseMenuCode.GDGreyButtonObjects1});
gdjs.PauseMenuCode.asyncCallback11552556 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Title Screen", false);
}}
gdjs.PauseMenuCode.eventsList13 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.PauseMenuCode.asyncCallback11552556(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.PauseMenuCode.eventsList14 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("GreyButton"), gdjs.PauseMenuCode.GDGreyButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("MainMenu_Text"), gdjs.PauseMenuCode.GDMainMenu_95TextObjects1);

gdjs.PauseMenuCode.condition0IsTrue_0.val = false;
gdjs.PauseMenuCode.condition1IsTrue_0.val = false;
gdjs.PauseMenuCode.condition2IsTrue_0.val = false;
{
gdjs.PauseMenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.PauseMenuCode.condition0IsTrue_0.val ) {
{
gdjs.PauseMenuCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.PauseMenuCode.mapOfGDgdjs_46PauseMenuCode_46GDGreyButtonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.PauseMenuCode.condition1IsTrue_0.val ) {
{
gdjs.PauseMenuCode.condition2IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PauseMenuCode.mapOfGDgdjs_46PauseMenuCode_46GDMainMenu_9595TextObjects1Objects, gdjs.PauseMenuCode.mapOfGDgdjs_46PauseMenuCode_46GDGreyButtonObjects1Objects, false, runtimeScene, false);
}}
}
if (gdjs.PauseMenuCode.condition2IsTrue_0.val) {

{ //Subevents
gdjs.PauseMenuCode.eventsList13(runtimeScene);} //End of subevents
}

}


};gdjs.PauseMenuCode.mapOfEmptyGDBall_951ObjectsEmptyGDBall_952ObjectsEmptyGDBall_954ObjectsEmptyGDBall_953ObjectsEmptyGDBall_955ObjectsEmptyGDBall_956Objects = Hashtable.newFrom({"Ball_1": [], "Ball_2": [], "Ball_4": [], "Ball_3": [], "Ball_5": [], "Ball_6": []});
gdjs.PauseMenuCode.mapOfEmptyGDBall_951ObjectsEmptyGDBall_952ObjectsEmptyGDBall_954ObjectsEmptyGDBall_953ObjectsEmptyGDBall_955ObjectsEmptyGDBall_956Objects = Hashtable.newFrom({"Ball_1": [], "Ball_2": [], "Ball_4": [], "Ball_3": [], "Ball_5": [], "Ball_6": []});
gdjs.PauseMenuCode.mapOfGDgdjs_46PauseMenuCode_46GDBall_95951Objects3ObjectsGDgdjs_46PauseMenuCode_46GDBall_95952Objects3ObjectsGDgdjs_46PauseMenuCode_46GDBall_95954Objects3ObjectsGDgdjs_46PauseMenuCode_46GDBall_95953Objects3ObjectsGDgdjs_46PauseMenuCode_46GDBall_95955Objects3ObjectsGDgdjs_46PauseMenuCode_46GDBall_95956Objects3Objects = Hashtable.newFrom({"Ball_1": gdjs.PauseMenuCode.GDBall_951Objects3, "Ball_2": gdjs.PauseMenuCode.GDBall_952Objects3, "Ball_4": gdjs.PauseMenuCode.GDBall_954Objects3, "Ball_3": gdjs.PauseMenuCode.GDBall_953Objects3, "Ball_5": gdjs.PauseMenuCode.GDBall_955Objects3, "Ball_6": gdjs.PauseMenuCode.GDBall_956Objects3});
gdjs.PauseMenuCode.mapOfEmptyGDBall_951ObjectsEmptyGDBall_952ObjectsEmptyGDBall_954ObjectsEmptyGDBall_953ObjectsEmptyGDBall_955ObjectsEmptyGDBall_956Objects = Hashtable.newFrom({"Ball_1": [], "Ball_2": [], "Ball_4": [], "Ball_3": [], "Ball_5": [], "Ball_6": []});
gdjs.PauseMenuCode.asyncCallback11571500 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().get("StopThrowingBalls"), false);
}}
gdjs.PauseMenuCode.eventsList15 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2), (runtimeScene) => (gdjs.PauseMenuCode.asyncCallback11571500(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.PauseMenuCode.eventsList16 = function(runtimeScene) {

{


gdjs.PauseMenuCode.condition0IsTrue_0.val = false;
{
gdjs.PauseMenuCode.condition0IsTrue_0.val = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PauseMenuCode.mapOfEmptyGDBall_951ObjectsEmptyGDBall_952ObjectsEmptyGDBall_954ObjectsEmptyGDBall_953ObjectsEmptyGDBall_955ObjectsEmptyGDBall_956Objects) >= 100;
}if (gdjs.PauseMenuCode.condition0IsTrue_0.val) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().get("StopThrowingBalls"), true);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("ResetWarning_Text"), gdjs.PauseMenuCode.GDResetWarning_95TextObjects3);

gdjs.PauseMenuCode.condition0IsTrue_0.val = false;
gdjs.PauseMenuCode.condition1IsTrue_0.val = false;
gdjs.PauseMenuCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.PauseMenuCode.GDResetWarning_95TextObjects3.length;i<l;++i) {
    if ( !(gdjs.PauseMenuCode.GDResetWarning_95TextObjects3[i].isVisible()) ) {
        gdjs.PauseMenuCode.condition0IsTrue_0.val = true;
        gdjs.PauseMenuCode.GDResetWarning_95TextObjects3[k] = gdjs.PauseMenuCode.GDResetWarning_95TextObjects3[i];
        ++k;
    }
}
gdjs.PauseMenuCode.GDResetWarning_95TextObjects3.length = k;}if ( gdjs.PauseMenuCode.condition0IsTrue_0.val ) {
{
gdjs.PauseMenuCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getVariables().get("StopThrowingBalls"), false);
}if ( gdjs.PauseMenuCode.condition1IsTrue_0.val ) {
{
gdjs.PauseMenuCode.condition2IsTrue_0.val = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PauseMenuCode.mapOfEmptyGDBall_951ObjectsEmptyGDBall_952ObjectsEmptyGDBall_954ObjectsEmptyGDBall_953ObjectsEmptyGDBall_955ObjectsEmptyGDBall_956Objects) < 100;
}}
}
if (gdjs.PauseMenuCode.condition2IsTrue_0.val) {
gdjs.PauseMenuCode.GDBall_951Objects3.length = 0;

gdjs.PauseMenuCode.GDBall_952Objects3.length = 0;

gdjs.PauseMenuCode.GDBall_953Objects3.length = 0;

gdjs.PauseMenuCode.GDBall_954Objects3.length = 0;

gdjs.PauseMenuCode.GDBall_955Objects3.length = 0;

gdjs.PauseMenuCode.GDBall_956Objects3.length = 0;

{gdjs.evtTools.object.createObjectFromGroupOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PauseMenuCode.mapOfGDgdjs_46PauseMenuCode_46GDBall_95951Objects3ObjectsGDgdjs_46PauseMenuCode_46GDBall_95952Objects3ObjectsGDgdjs_46PauseMenuCode_46GDBall_95954Objects3ObjectsGDgdjs_46PauseMenuCode_46GDBall_95953Objects3ObjectsGDgdjs_46PauseMenuCode_46GDBall_95955Objects3ObjectsGDgdjs_46PauseMenuCode_46GDBall_95956Objects3Objects, "Ball_" + gdjs.evtTools.common.toString(gdjs.randomInRange(1, 6)), gdjs.randomInRange(gdjs.evtTools.camera.getCameraBorderLeft(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraBorderRight(runtimeScene, "", 0)), gdjs.evtTools.camera.getCameraBorderBottom(runtimeScene, "", 0) - 32, "Balls");
}{for(var i = 0, len = gdjs.PauseMenuCode.GDBall_951Objects3.length ;i < len;++i) {
    gdjs.PauseMenuCode.GDBall_951Objects3[i].addPolarForce(270, 800, 1);
}
for(var i = 0, len = gdjs.PauseMenuCode.GDBall_952Objects3.length ;i < len;++i) {
    gdjs.PauseMenuCode.GDBall_952Objects3[i].addPolarForce(270, 800, 1);
}
for(var i = 0, len = gdjs.PauseMenuCode.GDBall_954Objects3.length ;i < len;++i) {
    gdjs.PauseMenuCode.GDBall_954Objects3[i].addPolarForce(270, 800, 1);
}
for(var i = 0, len = gdjs.PauseMenuCode.GDBall_953Objects3.length ;i < len;++i) {
    gdjs.PauseMenuCode.GDBall_953Objects3[i].addPolarForce(270, 800, 1);
}
for(var i = 0, len = gdjs.PauseMenuCode.GDBall_955Objects3.length ;i < len;++i) {
    gdjs.PauseMenuCode.GDBall_955Objects3[i].addPolarForce(270, 800, 1);
}
for(var i = 0, len = gdjs.PauseMenuCode.GDBall_956Objects3.length ;i < len;++i) {
    gdjs.PauseMenuCode.GDBall_956Objects3[i].addPolarForce(270, 800, 1);
}
}}

}


{


gdjs.PauseMenuCode.condition0IsTrue_0.val = false;
gdjs.PauseMenuCode.condition1IsTrue_0.val = false;
{
gdjs.PauseMenuCode.condition0IsTrue_0.val = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PauseMenuCode.mapOfEmptyGDBall_951ObjectsEmptyGDBall_952ObjectsEmptyGDBall_954ObjectsEmptyGDBall_953ObjectsEmptyGDBall_955ObjectsEmptyGDBall_956Objects) == 0;
}if ( gdjs.PauseMenuCode.condition0IsTrue_0.val ) {
{
{gdjs.PauseMenuCode.conditionTrue_1 = gdjs.PauseMenuCode.condition1IsTrue_0;
gdjs.PauseMenuCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11571580);
}
}}
if (gdjs.PauseMenuCode.condition1IsTrue_0.val) {

{ //Subevents
gdjs.PauseMenuCode.eventsList15(runtimeScene);} //End of subevents
}

}


};gdjs.PauseMenuCode.eventsList17 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("Ball_1"), gdjs.PauseMenuCode.GDBall_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Ball_2"), gdjs.PauseMenuCode.GDBall_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Ball_3"), gdjs.PauseMenuCode.GDBall_953Objects2);
gdjs.copyArray(runtimeScene.getObjects("Ball_4"), gdjs.PauseMenuCode.GDBall_954Objects2);
gdjs.copyArray(runtimeScene.getObjects("Ball_5"), gdjs.PauseMenuCode.GDBall_955Objects2);
gdjs.copyArray(runtimeScene.getObjects("Ball_6"), gdjs.PauseMenuCode.GDBall_956Objects2);
{for(var i = 0, len = gdjs.PauseMenuCode.GDBall_951Objects2.length ;i < len;++i) {
    gdjs.PauseMenuCode.GDBall_951Objects2[i].addPolarForce(90, 5, 1);
}
for(var i = 0, len = gdjs.PauseMenuCode.GDBall_952Objects2.length ;i < len;++i) {
    gdjs.PauseMenuCode.GDBall_952Objects2[i].addPolarForce(90, 5, 1);
}
for(var i = 0, len = gdjs.PauseMenuCode.GDBall_954Objects2.length ;i < len;++i) {
    gdjs.PauseMenuCode.GDBall_954Objects2[i].addPolarForce(90, 5, 1);
}
for(var i = 0, len = gdjs.PauseMenuCode.GDBall_953Objects2.length ;i < len;++i) {
    gdjs.PauseMenuCode.GDBall_953Objects2[i].addPolarForce(90, 5, 1);
}
for(var i = 0, len = gdjs.PauseMenuCode.GDBall_955Objects2.length ;i < len;++i) {
    gdjs.PauseMenuCode.GDBall_955Objects2[i].addPolarForce(90, 5, 1);
}
for(var i = 0, len = gdjs.PauseMenuCode.GDBall_956Objects2.length ;i < len;++i) {
    gdjs.PauseMenuCode.GDBall_956Objects2[i].addPolarForce(90, 5, 1);
}
}}

}


};gdjs.PauseMenuCode.eventsList18 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Ball_1"), gdjs.PauseMenuCode.GDBall_951Objects1);
gdjs.copyArray(runtimeScene.getObjects("Ball_2"), gdjs.PauseMenuCode.GDBall_952Objects1);
gdjs.copyArray(runtimeScene.getObjects("Ball_3"), gdjs.PauseMenuCode.GDBall_953Objects1);
gdjs.copyArray(runtimeScene.getObjects("Ball_4"), gdjs.PauseMenuCode.GDBall_954Objects1);
gdjs.copyArray(runtimeScene.getObjects("Ball_5"), gdjs.PauseMenuCode.GDBall_955Objects1);
gdjs.copyArray(runtimeScene.getObjects("Ball_6"), gdjs.PauseMenuCode.GDBall_956Objects1);

gdjs.PauseMenuCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.PauseMenuCode.GDBall_951Objects1.length;i<l;++i) {
    if ( gdjs.PauseMenuCode.GDBall_951Objects1[i].getY() > gdjs.evtTools.camera.getCameraBorderBottom(runtimeScene, "", 0) + 64 ) {
        gdjs.PauseMenuCode.condition0IsTrue_0.val = true;
        gdjs.PauseMenuCode.GDBall_951Objects1[k] = gdjs.PauseMenuCode.GDBall_951Objects1[i];
        ++k;
    }
}
gdjs.PauseMenuCode.GDBall_951Objects1.length = k;for(var i = 0, k = 0, l = gdjs.PauseMenuCode.GDBall_952Objects1.length;i<l;++i) {
    if ( gdjs.PauseMenuCode.GDBall_952Objects1[i].getY() > gdjs.evtTools.camera.getCameraBorderBottom(runtimeScene, "", 0) + 64 ) {
        gdjs.PauseMenuCode.condition0IsTrue_0.val = true;
        gdjs.PauseMenuCode.GDBall_952Objects1[k] = gdjs.PauseMenuCode.GDBall_952Objects1[i];
        ++k;
    }
}
gdjs.PauseMenuCode.GDBall_952Objects1.length = k;for(var i = 0, k = 0, l = gdjs.PauseMenuCode.GDBall_954Objects1.length;i<l;++i) {
    if ( gdjs.PauseMenuCode.GDBall_954Objects1[i].getY() > gdjs.evtTools.camera.getCameraBorderBottom(runtimeScene, "", 0) + 64 ) {
        gdjs.PauseMenuCode.condition0IsTrue_0.val = true;
        gdjs.PauseMenuCode.GDBall_954Objects1[k] = gdjs.PauseMenuCode.GDBall_954Objects1[i];
        ++k;
    }
}
gdjs.PauseMenuCode.GDBall_954Objects1.length = k;for(var i = 0, k = 0, l = gdjs.PauseMenuCode.GDBall_953Objects1.length;i<l;++i) {
    if ( gdjs.PauseMenuCode.GDBall_953Objects1[i].getY() > gdjs.evtTools.camera.getCameraBorderBottom(runtimeScene, "", 0) + 64 ) {
        gdjs.PauseMenuCode.condition0IsTrue_0.val = true;
        gdjs.PauseMenuCode.GDBall_953Objects1[k] = gdjs.PauseMenuCode.GDBall_953Objects1[i];
        ++k;
    }
}
gdjs.PauseMenuCode.GDBall_953Objects1.length = k;for(var i = 0, k = 0, l = gdjs.PauseMenuCode.GDBall_955Objects1.length;i<l;++i) {
    if ( gdjs.PauseMenuCode.GDBall_955Objects1[i].getY() > gdjs.evtTools.camera.getCameraBorderBottom(runtimeScene, "", 0) + 64 ) {
        gdjs.PauseMenuCode.condition0IsTrue_0.val = true;
        gdjs.PauseMenuCode.GDBall_955Objects1[k] = gdjs.PauseMenuCode.GDBall_955Objects1[i];
        ++k;
    }
}
gdjs.PauseMenuCode.GDBall_955Objects1.length = k;for(var i = 0, k = 0, l = gdjs.PauseMenuCode.GDBall_956Objects1.length;i<l;++i) {
    if ( gdjs.PauseMenuCode.GDBall_956Objects1[i].getY() > gdjs.evtTools.camera.getCameraBorderBottom(runtimeScene, "", 0) + 64 ) {
        gdjs.PauseMenuCode.condition0IsTrue_0.val = true;
        gdjs.PauseMenuCode.GDBall_956Objects1[k] = gdjs.PauseMenuCode.GDBall_956Objects1[i];
        ++k;
    }
}
gdjs.PauseMenuCode.GDBall_956Objects1.length = k;}if (gdjs.PauseMenuCode.condition0IsTrue_0.val) {
/* Reuse gdjs.PauseMenuCode.GDBall_951Objects1 */
/* Reuse gdjs.PauseMenuCode.GDBall_952Objects1 */
/* Reuse gdjs.PauseMenuCode.GDBall_953Objects1 */
/* Reuse gdjs.PauseMenuCode.GDBall_954Objects1 */
/* Reuse gdjs.PauseMenuCode.GDBall_955Objects1 */
/* Reuse gdjs.PauseMenuCode.GDBall_956Objects1 */
{for(var i = 0, len = gdjs.PauseMenuCode.GDBall_951Objects1.length ;i < len;++i) {
    gdjs.PauseMenuCode.GDBall_951Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.PauseMenuCode.GDBall_952Objects1.length ;i < len;++i) {
    gdjs.PauseMenuCode.GDBall_952Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.PauseMenuCode.GDBall_954Objects1.length ;i < len;++i) {
    gdjs.PauseMenuCode.GDBall_954Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.PauseMenuCode.GDBall_953Objects1.length ;i < len;++i) {
    gdjs.PauseMenuCode.GDBall_953Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.PauseMenuCode.GDBall_955Objects1.length ;i < len;++i) {
    gdjs.PauseMenuCode.GDBall_955Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.PauseMenuCode.GDBall_956Objects1.length ;i < len;++i) {
    gdjs.PauseMenuCode.GDBall_956Objects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.PauseMenuCode.eventsList19 = function(runtimeScene) {

{


gdjs.PauseMenuCode.eventsList16(runtimeScene);
}


{


gdjs.PauseMenuCode.eventsList17(runtimeScene);
}


{


gdjs.PauseMenuCode.eventsList18(runtimeScene);
}


};gdjs.PauseMenuCode.eventsList20 = function(runtimeScene) {

{



}


{


gdjs.PauseMenuCode.eventsList6(runtimeScene);
}


{


gdjs.PauseMenuCode.eventsList8(runtimeScene);
}


{


gdjs.PauseMenuCode.eventsList9(runtimeScene);
}


{


gdjs.PauseMenuCode.eventsList12(runtimeScene);
}


{


gdjs.PauseMenuCode.eventsList14(runtimeScene);
}


{


gdjs.PauseMenuCode.eventsList19(runtimeScene);
}


};

gdjs.PauseMenuCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.PauseMenuCode.GDBall_951Objects1.length = 0;
gdjs.PauseMenuCode.GDBall_951Objects2.length = 0;
gdjs.PauseMenuCode.GDBall_951Objects3.length = 0;
gdjs.PauseMenuCode.GDBall_951Objects4.length = 0;
gdjs.PauseMenuCode.GDBall_952Objects1.length = 0;
gdjs.PauseMenuCode.GDBall_952Objects2.length = 0;
gdjs.PauseMenuCode.GDBall_952Objects3.length = 0;
gdjs.PauseMenuCode.GDBall_952Objects4.length = 0;
gdjs.PauseMenuCode.GDBall_953Objects1.length = 0;
gdjs.PauseMenuCode.GDBall_953Objects2.length = 0;
gdjs.PauseMenuCode.GDBall_953Objects3.length = 0;
gdjs.PauseMenuCode.GDBall_953Objects4.length = 0;
gdjs.PauseMenuCode.GDBall_954Objects1.length = 0;
gdjs.PauseMenuCode.GDBall_954Objects2.length = 0;
gdjs.PauseMenuCode.GDBall_954Objects3.length = 0;
gdjs.PauseMenuCode.GDBall_954Objects4.length = 0;
gdjs.PauseMenuCode.GDBall_955Objects1.length = 0;
gdjs.PauseMenuCode.GDBall_955Objects2.length = 0;
gdjs.PauseMenuCode.GDBall_955Objects3.length = 0;
gdjs.PauseMenuCode.GDBall_955Objects4.length = 0;
gdjs.PauseMenuCode.GDBall_956Objects1.length = 0;
gdjs.PauseMenuCode.GDBall_956Objects2.length = 0;
gdjs.PauseMenuCode.GDBall_956Objects3.length = 0;
gdjs.PauseMenuCode.GDBall_956Objects4.length = 0;
gdjs.PauseMenuCode.GDGlassBreaking_95ParticlesObjects1.length = 0;
gdjs.PauseMenuCode.GDGlassBreaking_95ParticlesObjects2.length = 0;
gdjs.PauseMenuCode.GDGlassBreaking_95ParticlesObjects3.length = 0;
gdjs.PauseMenuCode.GDGlassBreaking_95ParticlesObjects4.length = 0;
gdjs.PauseMenuCode.GDCupObjects1.length = 0;
gdjs.PauseMenuCode.GDCupObjects2.length = 0;
gdjs.PauseMenuCode.GDCupObjects3.length = 0;
gdjs.PauseMenuCode.GDCupObjects4.length = 0;
gdjs.PauseMenuCode.GDCupFrontObjects1.length = 0;
gdjs.PauseMenuCode.GDCupFrontObjects2.length = 0;
gdjs.PauseMenuCode.GDCupFrontObjects3.length = 0;
gdjs.PauseMenuCode.GDCupFrontObjects4.length = 0;
gdjs.PauseMenuCode.GDCloud1Objects1.length = 0;
gdjs.PauseMenuCode.GDCloud1Objects2.length = 0;
gdjs.PauseMenuCode.GDCloud1Objects3.length = 0;
gdjs.PauseMenuCode.GDCloud1Objects4.length = 0;
gdjs.PauseMenuCode.GDCloud2Objects1.length = 0;
gdjs.PauseMenuCode.GDCloud2Objects2.length = 0;
gdjs.PauseMenuCode.GDCloud2Objects3.length = 0;
gdjs.PauseMenuCode.GDCloud2Objects4.length = 0;
gdjs.PauseMenuCode.GDCloud3Objects1.length = 0;
gdjs.PauseMenuCode.GDCloud3Objects2.length = 0;
gdjs.PauseMenuCode.GDCloud3Objects3.length = 0;
gdjs.PauseMenuCode.GDCloud3Objects4.length = 0;
gdjs.PauseMenuCode.GDCloud4Objects1.length = 0;
gdjs.PauseMenuCode.GDCloud4Objects2.length = 0;
gdjs.PauseMenuCode.GDCloud4Objects3.length = 0;
gdjs.PauseMenuCode.GDCloud4Objects4.length = 0;
gdjs.PauseMenuCode.GDEditInGDevelop_95TextObjects1.length = 0;
gdjs.PauseMenuCode.GDEditInGDevelop_95TextObjects2.length = 0;
gdjs.PauseMenuCode.GDEditInGDevelop_95TextObjects3.length = 0;
gdjs.PauseMenuCode.GDEditInGDevelop_95TextObjects4.length = 0;
gdjs.PauseMenuCode.GDGreyButtonObjects1.length = 0;
gdjs.PauseMenuCode.GDGreyButtonObjects2.length = 0;
gdjs.PauseMenuCode.GDGreyButtonObjects3.length = 0;
gdjs.PauseMenuCode.GDGreyButtonObjects4.length = 0;
gdjs.PauseMenuCode.GDCurrentLevel_95TextObjects1.length = 0;
gdjs.PauseMenuCode.GDCurrentLevel_95TextObjects2.length = 0;
gdjs.PauseMenuCode.GDCurrentLevel_95TextObjects3.length = 0;
gdjs.PauseMenuCode.GDCurrentLevel_95TextObjects4.length = 0;
gdjs.PauseMenuCode.GDMenuObjects1.length = 0;
gdjs.PauseMenuCode.GDMenuObjects2.length = 0;
gdjs.PauseMenuCode.GDMenuObjects3.length = 0;
gdjs.PauseMenuCode.GDMenuObjects4.length = 0;
gdjs.PauseMenuCode.GDGameState_95TextObjects1.length = 0;
gdjs.PauseMenuCode.GDGameState_95TextObjects2.length = 0;
gdjs.PauseMenuCode.GDGameState_95TextObjects3.length = 0;
gdjs.PauseMenuCode.GDGameState_95TextObjects4.length = 0;
gdjs.PauseMenuCode.GDMovesMade_95TextObjects1.length = 0;
gdjs.PauseMenuCode.GDMovesMade_95TextObjects2.length = 0;
gdjs.PauseMenuCode.GDMovesMade_95TextObjects3.length = 0;
gdjs.PauseMenuCode.GDMovesMade_95TextObjects4.length = 0;
gdjs.PauseMenuCode.GDTimeSpent_95TextObjects1.length = 0;
gdjs.PauseMenuCode.GDTimeSpent_95TextObjects2.length = 0;
gdjs.PauseMenuCode.GDTimeSpent_95TextObjects3.length = 0;
gdjs.PauseMenuCode.GDTimeSpent_95TextObjects4.length = 0;
gdjs.PauseMenuCode.GDBallsInCup_95TextObjects1.length = 0;
gdjs.PauseMenuCode.GDBallsInCup_95TextObjects2.length = 0;
gdjs.PauseMenuCode.GDBallsInCup_95TextObjects3.length = 0;
gdjs.PauseMenuCode.GDBallsInCup_95TextObjects4.length = 0;
gdjs.PauseMenuCode.GDPlay_95TextObjects1.length = 0;
gdjs.PauseMenuCode.GDPlay_95TextObjects2.length = 0;
gdjs.PauseMenuCode.GDPlay_95TextObjects3.length = 0;
gdjs.PauseMenuCode.GDPlay_95TextObjects4.length = 0;
gdjs.PauseMenuCode.GDLeaderboardObjects1.length = 0;
gdjs.PauseMenuCode.GDLeaderboardObjects2.length = 0;
gdjs.PauseMenuCode.GDLeaderboardObjects3.length = 0;
gdjs.PauseMenuCode.GDLeaderboardObjects4.length = 0;
gdjs.PauseMenuCode.GDMainMenu_95TextObjects1.length = 0;
gdjs.PauseMenuCode.GDMainMenu_95TextObjects2.length = 0;
gdjs.PauseMenuCode.GDMainMenu_95TextObjects3.length = 0;
gdjs.PauseMenuCode.GDMainMenu_95TextObjects4.length = 0;
gdjs.PauseMenuCode.GDResetProgress_95TextObjects1.length = 0;
gdjs.PauseMenuCode.GDResetProgress_95TextObjects2.length = 0;
gdjs.PauseMenuCode.GDResetProgress_95TextObjects3.length = 0;
gdjs.PauseMenuCode.GDResetProgress_95TextObjects4.length = 0;
gdjs.PauseMenuCode.GDStartOver_95TextObjects1.length = 0;
gdjs.PauseMenuCode.GDStartOver_95TextObjects2.length = 0;
gdjs.PauseMenuCode.GDStartOver_95TextObjects3.length = 0;
gdjs.PauseMenuCode.GDStartOver_95TextObjects4.length = 0;
gdjs.PauseMenuCode.GDSubmit_95TextObjects1.length = 0;
gdjs.PauseMenuCode.GDSubmit_95TextObjects2.length = 0;
gdjs.PauseMenuCode.GDSubmit_95TextObjects3.length = 0;
gdjs.PauseMenuCode.GDSubmit_95TextObjects4.length = 0;
gdjs.PauseMenuCode.GDResetWarning_95TextObjects1.length = 0;
gdjs.PauseMenuCode.GDResetWarning_95TextObjects2.length = 0;
gdjs.PauseMenuCode.GDResetWarning_95TextObjects3.length = 0;
gdjs.PauseMenuCode.GDResetWarning_95TextObjects4.length = 0;
gdjs.PauseMenuCode.GDPaused_95TextObjects1.length = 0;
gdjs.PauseMenuCode.GDPaused_95TextObjects2.length = 0;
gdjs.PauseMenuCode.GDPaused_95TextObjects3.length = 0;
gdjs.PauseMenuCode.GDPaused_95TextObjects4.length = 0;

gdjs.PauseMenuCode.eventsList20(runtimeScene);

return;

}

gdjs['PauseMenuCode'] = gdjs.PauseMenuCode;
